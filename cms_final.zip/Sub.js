const mqtt = require("mqtt");

var client = mqtt.connect("mqtt://broker.hivemq.com");

client.on("connect", function () {

    // var topic = 'VVTest/#'
    var topic = "IOT Test"
    client.subscribe(topic);

    console.log("Client subscribed to " + topic);

});

client.on("message", function (topic, message) {

    console.log(message.toString());

});