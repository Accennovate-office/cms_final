const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Routelogs = require('../models/Routelog');

const asyncHandler = fn => (req, res, next) => {
    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
    var nowDate = new Date().toLocaleString("en-IN", options);
    // console.log(`$$$$$$$$$$$$$ ${req.user}`);
    // console.log(`############ ${nowDate} ${res.statusCode} ${req.method} ${req.protocol}://${req.get('host')}${req.originalUrl}`);

    // @desc  Create new log
    var log_data = {
        dateAndTime: nowDate,
        requestMethod: req.method,
        requestURL: `${req.protocol}://${req.get('host')}${req.originalUrl}`,
        statusCode: res.statusCode,
        user: req.user
    }
    // const routelogs = await Routelogs.create(log_data); // Working
    Routelogs.create(log_data); // Working
    // console.log('------------------------------------------------');
    // console.log(routelogs);
    // if (routelogs) {
    Promise.resolve(fn(req, res, next)).catch(next)
        // return next()
    // } else {
    //     return next(new ErrorResponse('Something went wrong', 500)); // 401 is unauthorized
    // }
    // next()
};

module.exports = asyncHandler;