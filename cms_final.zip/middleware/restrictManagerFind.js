const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');

// Allow manager to FIND, UPDATE, DELETE own or same branch operations only
const restrictManagerFind = () => async (req, res, next) => {
    console.log('Inside restrict manager function');
    if (req.user.role === 'admin') {
        console.log('Inside restrict manager - admin function');
        res.restrictManagerFind = await User.findOne({ slug: req.params.slug });
        next();
    } else if (req.user.role === 'manager' || req.user.role === 'teacher') {
        console.log('Inside restrict manager - manager function');
        res.restrictManagerFind = await User.findOne({ slug: req.params.slug, branch: req.user.branch, deleted: 0 });
        next();
    } else {
        return next(new ErrorResponse('Not authorized to access this route', 401));
    }
};
module.exports = restrictManagerFind;