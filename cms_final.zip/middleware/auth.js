const jwt = require('jsonwebtoken');
const asyncHandler = require('./async');
const ErrorResponse = require('../utils/errorResponse');
const User = require('../models/User');

// Protect routes
exports.protect = asyncHandler(async (req, res, next) => {
    let token;

    // Grabbing token through header
    const auth = req.headers.authorization;
    if (auth && auth.startsWith('Bearer')) {
        token = auth.split(' ')[1];
    }
    // Grabbing token through cookies
    else if (req.cookies.token) {
        token = req.cookies.token;
    }

    // Make sure token exists
    if (!token) {
        // console.log('Error 1111111111111111111111');
        // return next(new ErrorResponse('Not authorized to access this route', 401));
        res.render('partials/error', { title: 'SDP | Error', css: 'error', js: 'error', error: 'Not authorized to access this page. Your session might have expired' });
    }

    try {
        // Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // console.log(decoded);

        req.user = await User.findById(decoded.id);

        next();
    } catch (err) {
        // console.log('Error 222222222222222222222222');
        // return next(new ErrorResponse('Not authorized to access this route', 401));
        res.render('partials/error', { title: 'SDP | Error', css: 'error', js: 'error', error: 'Not authorized to access this page. Your session might have expired', code: 401 });
    }
});

// Grant acess to specific roles
exports.authorize = (...roles) => {
    return (req, res, next) => {
        if (req.user == null) {
            // return next(new ErrorResponse('You are not logged in', 401)); // 401 is unauthorized
            res.render('partials/error', { title: 'SDP | Error', css: 'error', js: 'error', error: 'You are not logged in' });
        }
        if (!roles.includes(req.user.role)) {
            // return next(new ErrorResponse('Not authorized to access this route', 403));
            res.render('partials/error', { title: 'SDP | Error', css: 'error', js: 'error', error: 'Not authorized to access this page' });
            // return next(new ErrorResponse(`User role ${req.user.role} is not authorized to access this route`, 403));
        }
        next();
    }
}

// Allow manager to CREATE own or same branch operations only
exports.restrictManagerCreate = asyncHandler(async (req, res, next) => {
    console.log('restrict 1 ---------------------------');
    if (req.user.role === 'admin') {
        console.log('restrict 2 ---------------------------');
        next();
    } else if ((req.user.role === 'manager' || req.user.role === 'teacher') && req.user.branch === req.body.branch) {
        console.log('restrict 3 ---------------------------');
        next();
    } else {
        console.log('restrict 4 ---------------------------');
        // return next(new ErrorResponse('Not authorized to access this page', 401));
        res.render('partials/error', { title: 'SDP | Error', css: 'error', js: 'error', error: 'Not authorized to access this page' });
    }
});

