
// @desc    Logs request to console
// Sample middleware
const logger = (req, res, next) => {

    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
    var nowDate = new Date().toLocaleString("en-IN", options);

    // console.log(`>>>>>>>>>>>> ${nowDate} ${res.statusCode} ${req.method} ${req.protocol}://${req.get('host')}${req.originalUrl}`);
    // console.log(`@@@@@@@@@@@@@ ${req.user}`);

    next();
};

module.exports = logger;