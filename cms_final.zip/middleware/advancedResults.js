const advancedResults = (model, populate) => async (req, res, next) => { // This is function inside function
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    if (req.user.role === 'admin') {
        // console.log('Inside admin loop');
        reqQuery.deleted = false;
    } else if (req.user.role === 'manager') { // Show only branch users to branch manager
        // console.log('Creating path --------------------------');
        // console.log(req)
        // const path = req._parsedOriginalUrl.path.split('/')[2] 
        const path = req.originalUrl.split('/')[2]
        const finalPath = path.split('?')[0]
        // console.log(path)
        if (finalPath == 'taskcategorys' || finalPath == 'tasksubcategorys' || finalPath == 'branches' || finalPath == 'courses') {
            // do nothing
            var x
            // console.log('-----------------------------------------------------------------------');
        } else {
            reqQuery.branch = req.user.branch;
        }
        reqQuery.deleted = false;
    } else if (req.user.role === 'teacher') { // Show only branch teachers to branch teacher
        // const path = req._parsedOriginalUrl.path.split('/')[2]
        const path = req.originalUrl.split('/')[2]
        const finalPath = path.split('?')[0]
        // console.log(path)
        if (finalPath == 'taskcategorys' || finalPath == 'tasksubcategorys' || finalPath == 'branches' || finalPath == 'courses') {
            // do nothing
            var x
        } else if (finalPath == 'tasks') {
            // console.log('inside tasks else')
            reqQuery.branch = req.user.branch;
            reqQuery.byTeacher = true;
        } else {
            // console.log('inside else only')
            reqQuery.branch = req.user.branch;
        }
        reqQuery.deleted = false;
    }

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over remove fields and delete from query
    removeFields.forEach(param => delete reqQuery[param]); // Because select is not related to filter data but filter fields

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc.)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`); // Here gt-greaterThan, gte=greaterThanEquals, lt-lessThan, lte-lessThanEquals, in-inside, g-global(find all even after getting one found)

    // Finding resource
    query = model.find(JSON.parse(queryStr)); // We can also limit these courses details as done in courses controller with path & select
    // Now we filter data like this > below are some advanced filtering 
    // ?averageCost[lt]=10000&location.city=Kingston , ?careers[in]=Data Science

    // Select fields
    if (req.query.select) {
        const fields = req.query.select.split(',').join(" "); // converting> name,description to> name description
        // console.log(fields);
        query = query.select(fields);
    } else {
        // If admin > select password, deleted fields also
        if (req.user.role === 'admin') {
            query = query.select("+password");
            query = query.select("+deleted");
        }
    }

    // Sort query
    if (req.query.sort) {
        const sortBy = req.query.sort.split(',').join(' ');
        query = query.sort(sortBy);
    } else {
        // Sort by default with descending dates
        query = query.sort('-createdAt');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1; // Here 10 is radix i.e. base10 // 1 is default when nothing is provided
    const limit = parseInt(req.query.limit, 10) || 1000; // 1000 items per page
    const startIndex = (page - 1) * limit; // formula to skip before pages/resources to display
    const endIndex = page * limit;

    var total
    if (req.user.role === 'manager' || req.user.role === 'teacher') {
        total = await model.countDocuments({ deleted: false, branch: req.user.branch });
    } else {
        total = await model.countDocuments({ deleted: false });
    }
    // Total count for teachers tasks from same branch
    const path = req.originalUrl.split('/')[2]
    const finalPath = path.split('?')[0]
    if (finalPath == 'tasks' && req.user.role === 'teacher') {
        console.log('inside teachers special tasks')
        // reqQuery.branch = req.user.branch;
        // reqQuery.byTeacher = true;
        total = await model.countDocuments({ deleted: false, branch: req.user.branch, byTeacher: true });
    }
    
    // const total = await model.countDocuments({ deleted: false });
    query = query.skip(startIndex).limit(limit);

    if (populate) {
        query = query.populate(populate);
    }

    // Executing query
    const results = await query.allowDiskUse(true).lean();

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
        pagination.next = {
            page: page + 1,
            limit // this is same as limit: limit
        }
    }
    if (startIndex > 0) {
        pagination.prev = {
            page: page - 1,
            limit
        }
    }

    res.advancedResults = {
        success: true,
        total_count: total,
        count: results.length,
        pagination,
        data: results
    }

    next();

}

module.exports = advancedResults;