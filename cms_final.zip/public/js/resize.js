
$(window).resize(size);
$(window).ready(size);

function size() {
    // console.log(
    //     $(window).height(),
    //     $(window).width()
    // );
    const width = $(window).width();
    const height = $(window).height();
    // console.log($('#main-body').text());
    if (width < 1200 || height < 550) {
        $('body').css('background-color', '#211749');
        $('#main-body').html(`
        <div id="head" align="center" class="mt-4 p-1">
            <img width="40" src="/images/SDP_logo.png" alt="">
            <img src="/images/smartbyte_logo.png" alt="">
        </div>

        <div align="center" style="font-size: 1.3rem;background: #302363;opacity: 0.5;" class="m-2 mb-5 p-2 text-light"><span class="text-warning">WARNING</span><br>
        This website is not accessible with this device please try below instructions <br> 
        <ul>
            <li>Try using Desktop(PC)/Laptop</li>            
            <li>Maximize the window and reload if you are using Desktop(PC)/Laptop</li>
        </ul> <br> If that doesn't work contact admin or mail us support@smartbytecomputer.com</div>
        
        <div class="signin">
            <center>
                © 2022 Copyright: <a target="blank" href="https://smartbytecomputer.com/">smartbytecomputer</a>. All
                rights reserved.
                <br>
                <a target="blank" href="https://smartbytecomputer.com/tnc.php">Terms</a>
                &nbsp;|&nbsp;
                <a target="blank" href="https://smartbytecomputer.com/privacypolicy.php">Privacy</a>
                <div class="signin">Entry to this site is restricted to employees</div>
            </center>
        </div>`);
        $('#body-imp').css('background-image', 'none');
    } else {
        if ($('#main-body').html() === `
        <div id="head" align="center" class="mt-4 p-1">
            <img width="40" src="/images/SDP_logo.png" alt="">
            <img src="/images/smartbyte_logo.png" alt="">
        </div>

        <div align="center" style="font-size: 1.3rem;background: #302363;opacity: 0.5;" class="m-2 mb-5 p-2 text-light"><span class="text-warning">WARNING</span><br>
        This website is not accessible with this device please try below instructions <br> 
        <ul>
            <li>Try using Desktop(PC)/Laptop</li>            
            <li>Maximize the window and reload if you are using Desktop(PC)/Laptop</li>
        </ul> <br> If that doesn't work contact admin or mail us support@smartbytecomputer.com</div>
        
        <div class="signin">
            <center>
                © 2022 Copyright: <a target="blank" href="https://smartbytecomputer.com/">smartbytecomputer</a>. All
                rights reserved.
                <br>
                <a target="blank" href="https://smartbytecomputer.com/tnc.php">Terms</a>
                &nbsp;|&nbsp;
                <a target="blank" href="https://smartbytecomputer.com/privacypolicy.php">Privacy</a>
                <div class="signin">Entry to this site is restricted to employees</div>
            </center>
        </div>`) {
            location.reload();
        }
    }

}
