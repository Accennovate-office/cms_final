// Navbar open close
$('#opennav,#opennav-sm').click(() => {

    $('#mySidebar').toggleClass('opennav');
    $('#main').toggleClass('opennav');
    let smallLogo = $('#main').hasClass('opennav');
    if (!smallLogo) {
        $('#small-logo').css('display', 'block');
    } else {
        $('#small-logo').css('display', 'none');
    }
});

$('.linkcolor.active').removeClass('linkcolor')

/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;

        if (dropdownContent.style.display === "block") {
            dropdownContent.style.display = "none";
        } else {
            dropdownContent.style.display = "block";
        }
        // if (dropdown[i].hasClass('active')) {
        //     $('.dropdown-btn.active .fa-angle-right').addClass('fa-angle-down');
        //     $('.dropdown-btn.active .fa-angle-right').removeClass('fa-angle-right');
        // } else {
        //     $('.dropdown-btn.active .fa-angle-down').addClass('fa-angle-right');
        //     $('.dropdown-btn.active .fa-angle-down').removeClass('fa-angle-down');
        // }

    });

}

$('#sidebar-logout').click(() => {
    // alert('logout')

    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to <span class="text-danger">Logout</span>`,
        type: 'warning',
        // width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        focusConfirm: false,
        focusCancel: true,
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, logout!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: `/sdp/auth/logout`,
                method: 'get',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'bottom-right',
                            icon: 'success',
                            title: 'Logged out Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        setTimeout(() => {
                            document.location.replace('/sdp/auth/login');
                        }, 1500);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response
                        });
                        console.log(response);

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response
                    });
                    console.log(response);

                }
            });

        }
    })
})

function loadAllTasksNotification() {

    $.ajax({
        url: '/sdp/tasks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-tasks-all').html(`All Tasks <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-tasks').html(`
                        <i class="fas fa-tasks"></i>
                        Tasks&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch tasks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_tasks').html(errorMsg)
            }

        }
    });

}
loadAllTasksNotification()

function loadAllTeachersNotification() {

    $.ajax({
        url: '/sdp/teachers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-teachers-all').html(`All Teachers <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-teachers').html(`
                        <i class="fas fa-user-tie"></i>
                        Teachers&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch teachers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_teachers').html(errorMsg)
            }

        }
    });

}
loadAllTeachersNotification()

function loadAllStudentsNotification() {

    $.ajax({
        url: '/sdp/students/summary/info',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                newelementCount = response.data.today
                if (newelementCount > 0) {
                    $('#sidebar-students-all').html(`All Students <span class="badge badge-noti">${newelementCount}</span>`)
                    $('#sidebar-students').html(`
                    <i class="fas fa-users"></i>
                    Students&nbsp;
                    <i class="fas fa-angle-right"></i>
                    <span class="badge badge-noti">${newelementCount}</span>`)
                }

            } else {

                console.log(response.responseJSON.error);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response.responseJSON.error);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_students').html(errorMsg)
            }

        }
    });

}
loadAllStudentsNotification()

function loadAllEnquiriesNotification() {

    $.ajax({
        url: '/sdp/enquiries',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-enquiries-all').html(`All Enquiries <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-enquiries').html(`
                        <i class="fas fa-question"></i>
                        Enquiries&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response.responseJSON.error);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response.responseJSON.error);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch enquiries list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_enquiries').html(errorMsg)
            }

        }
    });

}
loadAllEnquiriesNotification()

function loadAllCoursesNotification() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-courses-all').html(`All Courses <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-courses').html(`
                        <i class="fas fa-book"></i>
                        Courses&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response.responseJSON.error);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response.responseJSON.error);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_courses').html(errorMsg)
            }

        }
    });

}
loadAllCoursesNotification()

function loadAllAdmissionsNotification() {

    $.ajax({
        url: '/sdp/admissions',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-admissions-all').html(`All Admissions <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-admissions').html(`
                        <i class="fas fa-id-card"></i>
                        Admissions&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch admissions list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_admissions').html(errorMsg)
            }

        }
    });

}
loadAllAdmissionsNotification()

function loadAllFeesNotification() {

    $.ajax({
        url: '/sdp/fees',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-fees-all').html(`All Fees <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-fees').html(`
                        <i class="fas fa-rupee-sign"></i>
                        Fees&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch fees list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_fees').html(errorMsg)
            }

        }
    });

}
loadAllFeesNotification()

function loadAllLecturesNotification() {

    $.ajax({
        url: '/sdp/lectures',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-lectures-all').html(`All Lectures <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-lectures').html(`
                        <i class="fas fa-id-card"></i>
                        Lectures&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch lectures list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_lectures').html(errorMsg)
            }

        }
    });

}
loadAllLecturesNotification()

function loadAllPerksNotification() {

    $.ajax({
        url: '/sdp/perks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var newelementCount = 0;
                response.data.forEach(branch => {

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                    var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                    if (createdCheck === today) {
                        newElement = `<span class="badge badge-noti">New</span>`
                        newelementCount += 1
                    } else {
                        newElement = ''
                    }
                    if (newelementCount > 0) {
                        $('#sidebar-perks-all').html(`All Perks <span class="badge badge-noti">${newelementCount}</span>`)
                        $('#sidebar-perks').html(`
                        <i class="fas fa-medal"></i>
                        Perks&nbsp;
                        <i class="fas fa-angle-right"></i>
                        <span class="badge badge-noti">${newelementCount}</span>`)
                    }

                });

            } else {

                console.log(response);

            }
        },
        error: function (response) {

            if (response.responseJSON) {

                console.log(response);

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch perks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                $('#table_perks').html(errorMsg)
            }

        }
    });

}
loadAllPerksNotification()

function loadAllBirthdaysNotification() {

    var count = 0
    // Fetch birthdays
    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {


                var tbody_birthdays;
                if (response.data.length == 0) {

                    var x

                } else {
                    isEmpty = false

                    response.data.forEach(birthday => {

                        // // var utcCreatedDate = new Date(birthday.createdAt);
                        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                        // // var s = new Date(birthday.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                        // var createdHindiIST = new Date(birthday.createdAt).toLocaleDateString("hi-IN", options)
                        var createdEnglishIST = new Date(birthday.createdAt).toLocaleDateString("en-IN", options)

                        // For join Date
                        var dateOptions = { month: 'long', day: 'numeric' };
                        var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                        var today = new Date().toLocaleDateString("en-IN", dateOptions)

                        // For join Date
                        var dateOptions = { month: 'long', day: 'numeric' };
                        var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                        var today = new Date().toLocaleDateString("en-IN", dateOptions)
                        // var x = new Date(birthday.createdAt).getTimezoneOffset();

                        if (birthdayDateEnglishIST === today) {
                            count += 1
                        }
                    });
                    // console.log('count 1 ' + count)
                    if (count > 0) {

                        $('#sidebar-birthday-book').html(`<i class="fas fa-birthday-cake"></i> Birthday Book <span class="badge badge-noti">${count}</span>`)
                    }


                }

                // Fetch students birthdays
                $.ajax({
                    url: '/sdp/students/birthday/data?select=dob',
                    method: 'get',
                    success: function (response) {
                        if (response.success) {


                            if (response.data.length == 0 && isEmpty) {

                                var x

                            } else {
                                isEmpty = false

                                response.data.forEach(birthday => {

                                    // For join Date
                                    var dateOptions = { month: 'long', day: 'numeric' };
                                    var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                                    var today = new Date().toLocaleDateString("en-IN", dateOptions)

                                    // For join Date
                                    var dateOptions = { month: 'long', day: 'numeric' };
                                    var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                                    var today = new Date().toLocaleDateString("en-IN", dateOptions)
                                    // var x = new Date(birthday.createdAt).getTimezoneOffset();

                                    if (birthdayDateEnglishIST === today) {
                                        count += 1
                                    }

                                });
                                // console.log('count 2 ' + count)
                                if (count > 0) {

                                    $('#sidebar-birthday-book').html(`<i class="fas fa-birthday-cake"></i> Birthday Book <span class="badge badge-noti">${count}</span>`)
                                }

                            }

                        } else {

                            $('#loading').css('display', 'none');
                            $('#table_birthdays tbody tr').text(response.responseJSON.error);
                            console.log(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-birthday-card button').attr('disabled', true)

                        }
                    },
                    error: function (response) {

                        if (response.responseJSON) {
                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            console.log(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-birthday-card button').attr('disabled', true)

                        } else {
                            var errorMsg = `
                            <center>
                            <h2>Oops! Something went wrong</h2>
                            <h4 class="text-danger">
                                Error Code: ${response.status} <br>
                                Error Message: ${response.statusText}
                            </h4>
                            <h5>We were unable to fetch birthdays list</h5>
                            <h6>
                                Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                            </h6>
                            </center>`
                            console.log(`something went wrong ${JSON.stringify(response)}`);
                            // console.log(response.statusText);
                            // $('#table_birthdays tbody .col').html(errorMsg)
                            $('#errorsection').html(errorMsg)
                        }

                    }
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_birthdays tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch birthdays list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_birthdays tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllBirthdaysNotification()