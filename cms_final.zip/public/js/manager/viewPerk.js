
$('#sidebar-perks').trigger("click")
$('#sidebar-perks,#sidebar-perks-view').addClass('active')
$("div#mySidebar").scrollTop(600); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['perk'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/manager/perks')
})

function loadPerksList() {

    $.ajax({
        url: '/sdp/perks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var perks_list;
                $('#viewperk #perk').text(response.data)

                if (response.data.length == 0) {
                    perks_list += `<option value="">Perk List is empty</option>`;
                } else {
                    perks_list = `<option value="">Select Perk Name</option>`;
                    response.data.forEach(perk => {

                        if (perk._id == selected) {

                            perks_list += `
                            <option selected value="${perk._id}">${perk.user.name} [${perk.points}]</option>`;

                        } else {

                            perks_list += `
                            <option value="${perk._id}">${perk.user.name} [${perk.points}]</option>`;

                        }

                    });
                }

                $('#viewperk #perk').html(perks_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Perks Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_perks tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch perks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_perks tbody .col').html(errorMsg)
                $('#no-perk-selected').html(errorMsg)
            }

        }
    });

}
loadPerksList()

function getPerkDetails() {

    console.log('Inside get Perk Details function');

    const selectPerk = $('#perk').val() ? $('#perk').val() : selected
    // console.log(selectPerk);
    if (selectPerk == '') {
        $('#no-perk-selected').css('display', 'block')
        $('#perk-selected').css('display', 'none')
    } else {

        $('#no-perk-selected').css('display', 'none')
        $('#perk-selected').css('display', 'block')
        $('#viewperk #perk-selected').html(`Loading...`)
        $.ajax({
            url: `/sdp/perks/${selectPerk}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewperk #perk-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var perk_data = `
                    <div class="d-flex mb-5">
                        <img src="/images/perks/perk3.png" width="60" alt="">
                        <div align="left" class="ml-4 pt-3">
                            <h2>Perk Details</h2>
                        </div>
                    </div>
                    <div align="left">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-trophy" aria-hidden="true"></i>
                            <small>Perk(s) awarded to</small>
                        </div>
                        <div class="d-flex justify-content-between w-100 h5">
                            <div>${response.data.user.name}</div>
                            <div>${response.data.user.email}</div>
                            <div>${response.data.user.branch} Branch</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-3 ml-5">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-medal" aria-hidden="true"></i>
                                <small>Perks / Points</small>
                            </div>
                            <div class="h2 pl-3">
                                ${response.data.points}
                                <img src="/images/perks/perk1.png" width="35" alt="">
                            </div>
                        </div>
                        <div align="left" class="mt-4">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-comment" aria-hidden="true"></i>
                                <small>Comment</small>
                            </div>
                            <div>${response.data.comment}</div>
                        </div>
                        <div align="left" class="mt-3" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-stream" aria-hidden="true"></i>
                                <small>Sub-Category</small>
                            </div>
                            <div>Birthday Book Birthday Book Birthday Book Book Birthday Book</div>
                        </div>
                    </div>

                    <div class="d-flex w-100">
                        <div align="left" class="mt-5 w-100">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <small>Created By</small>
                            </div>
                            <div class="d-flex justify-content-between w-100">
                            <div>${response.data.createdBy.name}</div>
                            <div>${response.data.createdBy.email}</div>
                            <div>${response.data.createdBy.branch} Branch</div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                        <div align="left" class="mt-3 ml-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewperk #perk-selected').html(perk_data)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Perk Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_perks tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-perk-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-perk-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch perks list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_perks tbody .col').html(errorMsg)
                    $('#no-perk-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-perk-selected').css('display', 'block') // block
$('#perk-selected').css('display', 'none') // none
if (selected != undefined) {
    console.log('inside');
    getPerkDetails()
}
$('#perk').change(() => {

    getPerkDetails()

})
