
$('#sidebar-teachers').trigger("click")
$('#sidebar-teachers,#sidebar-teachers-view').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['teacher'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/manager/teachers')
})

function loadTeachersList() {

    $.ajax({
        url: '/sdp/teachers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var teachers_list;
                $('#viewteacher #teacher').text(response.data)

                if (response.data.length == 0) {
                    teachers_list += `<option value="">Teacher List is empty</option>`;
                } else {
                    teachers_list = `<option value="">Select Teacher Name</option>`;
                    response.data.forEach(teacher => {

                        if (teacher.user._id == selected) {

                            teachers_list += `
                            <option selected value="${teacher.user._id}">${teacher.user.name}</option>`;

                        } else {

                            teachers_list += `
                            <option value="${teacher.user._id}">${teacher.user.name}</option>`;

                        }

                    });
                }

                $('#viewteacher #teacher').html(teachers_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Teachers Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_teachers tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-teacher-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-teacher-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch teachers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_teachers tbody .col').html(errorMsg)
                $('#no-teacher-selected').html(errorMsg)
            }

        }
    });

}
loadTeachersList()

function getTeacherDetails() {

    const selectTeacher = $('#teacher').val() ? $('#teacher').val() : selected
    // console.log(selectTeacher);
    if (selectTeacher == '') {
        $('#no-teacher-selected').css('display', 'block')
        $('#teacher-selected').css('display', 'none')
    } else {

        $('#no-teacher-selected').css('display', 'none')
        $('#teacher-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/teachers/${selectTeacher}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewteacher #teacher-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", date_options)
                    var joindateEnglishIST = new Date(response.data.joiningDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var edu_details = ''
                    const edu_string = response.data.educationalQualification.split(',')
                    // console.log(response.data.educationalQualification);
                    edu_string.forEach(edu => {
                        edu_details += `<span class="badge badge-light mt-0">${edu}</span>`
                    });

                    var skill_details = ''
                    const skill_string = response.data.computerSkills.split(',')
                    // console.log(response.data.computerSkills);
                    skill_string.forEach(skill => {
                        skill_details += `<span class="badge badge-light mt-0">${skill}</span>`
                    });

                    var course_details = ''
                    const course_string = response.data.coursesAllocated.split(',')
                    // console.log(response.data.coursesAllocated);
                    course_string.forEach(course => {
                        course_details += `<span class="badge badge-light mt-0">${course}</span>`
                    });

                    const jobTime = response.data.jobTime.split(',')

                    var teacher_data = `
                    <div class="d-flex mb-3 pl-1">
                        <img src="/images/teachers/teacher2.png" width="70" alt="">
                        <div align="left" class="ml-4">
                            <small>Teacher Name</small>
                            <h2>${response.data.user.name}</h2>
                        </div>
                    </div>

                    <!-- Personal Details -->
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Personal Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Date of Birth</small>
                            </div>
                            <div>${dobEnglishIST}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-phone-alt" aria-hidden="true"></i>
                                <small>Phone</small>
                            </div>
                            <div>${response.data.phone}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                <small>Email</small>
                            </div>
                            <div>${response.data.user.email}</div>
                        </div>
                    </div>

                    <div align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <small>Full Address</small>
                        </div>
                        <h5>${response.data.address}</h5>
                    </div>

                    <!-- Educational Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Educational Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-graduate" aria-hidden="true"></i>
                            <small>Educational Qualification(s)</small>
                        </div>
                        <h4>
                            ${edu_details}
                        </h4>

                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-graduate" aria-hidden="true"></i>
                            <small>Computer Skill(s)</small>
                        </div>
                        <h4>
                            ${skill_details}
                        </h4>
                    </div>

                    <!-- Organization Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Organization Details</h5>
                    <hr class="bg-success mt-0 mb-2">
                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Date of Joining</small>
                            </div>
                            <div>${joindateEnglishIST}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-building" aria-hidden="true"></i>
                                <small>Branch</small>
                            </div>
                            <div>${response.data.user.branch}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-business-time"></i>
                                <small>Job Time</small>
                            </div>
                            <div>From ${jobTime[0]} to ${jobTime[1]}</div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-2">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-book" aria-hidden="true"></i>
                                <small>Courses Allocated</small>
                            </div>
                            <h4>${course_details}</h4> 
                        </div>
                    </div>

                    <!-- Bank Details -->
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Bank Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-address-book" aria-hidden="true"></i>
                                <small>Account Holder Name</small>
                            </div>
                            <div>${response.data.accountHolderName ? response.data.accountHolderName : 'Not added'}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-id-badge" aria-hidden="true"></i>
                                <small>Account Number</small>
                            </div>
                            <div>${response.data.accountNumber ? response.data.accountNumber : 'Not added'}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-location-arrow" aria-hidden="true"></i>
                                <small>IFSC Code</small>
                            </div>
                            <div>${response.data.IFSCcode ? response.data.IFSCcode : 'Not added'}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-university" aria-hidden="true"></i>
                                <small>Bank Name</small>
                            </div>
                            <div>${response.data.bank ? response.data.bank : 'Not added'}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-code-branch" aria-hidden="true"></i>
                                <small>Bank Branch Name</small>
                            </div>
                            <div>${response.data.bankBranch ? response.data.bankBranch : 'Not added'}</div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-id-card" aria-hidden="true"></i>
                                <small>PAN Number</small>
                            </div>
                            <div>${response.data.PAN ? response.data.PAN : 'Not added'}</div>
                        </div>
                    </div>

                    <!-- Login Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Login Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0 mr-2">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                <small>Email</small>
                            </div>
                            <div>${response.data.user.email}</div>
                        </div>
                        <div class="mt-0 ml-2">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-key" aria-hidden="true"></i>
                                <small>Password</small>
                            </div>
                            <small class="text-danger">
                                This password is encrypted (To see orignal password check <a href="#">Login Records</a> section)
                            </small>
                        </div>
                        </div>

                        <div class="d-flex justify-content-between mt-5">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewteacher #teacher-selected').html(teacher_data)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Teacher Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_teachers tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-teacher-card button').attr('disabled', true)
                    $('#teacher-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-teacher-card button').attr('disabled', true)
                    $('#teacher-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch teachers list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_teachers tbody .col').html(errorMsg)
                    $('#teacher-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-teacher-selected').css('display', 'block')
$('#teacher-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getTeacherDetails()
}
$('#teacher').change(() => {

    getTeacherDetails()

})