
$('#no-lecture-available').fadeOut()
$('#table_lectures,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

$('#sidebar-lectures').trigger("click")
$('#sidebar-lectures,#sidebar-lectures-all').addClass('active')
$("div#mySidebar").scrollTop(400); // Ref: https://api.jquery.com/scrolltop/

$('#new-lecture-btn').click(() => {
    document.location.replace('/sdp/manager/addlecture');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllLectures(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllLectures(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllLectures(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllLectures(limit, page + 1)
})
// Page navigator End

function loadAllLectures(limit = 10, page = 1) {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-lecture-available').fadeOut()
    $('#table_lectures,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/lectures?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#error,#loading').css('display', 'none')

                // if (response.data.length == 0) {
                //     var noLecture = `
                //     <img src="/images/lectures/nolecture.png" width="60" alt="">
                //     <div class="h3 mt-2">
                //         <span class="font-weight-bold">Lecture List is empty</span> <br><br>
                //         <span class="h5">Click&nbsp;
                //             <span>
                //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                //                     Lecture</button>
                //             </span>
                //             &nbsp;button at top left to get started
                //         </span>
                //     </div>`
                //     $('#no-lecture-available').fadeIn()
                //     $('#no-lecture-available').html(noLecture)

                // } else {
                //     $('#table_lectures').fadeIn()
                //     $('#view_note').fadeIn()
                //     var tbody_lectures;
                //     // var newelementCount = 0;
                //     response.data.forEach(lecture => {

                //         // // var utcCreatedDate = new Date(lecture.createdAt);
                //         // var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                //         // // var s = new Date(lecture.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                //         // var createdHindiIST = new Date(lecture.createdAt).toLocaleDateString("hi-IN", options)
                //         // var createdEnglishIST = new Date(lecture.createdAt).toLocaleDateString("en-IN", options)

                //         // For join Date
                //         var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                //         var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString("en-IN", dateOptions)
                //         // var x = new Date(lecture.createdAt).getTimezoneOffset();
                //         //Converted UTC to local(IST, etc.,,)
                //         // console.log(utcCreatedDate.toUTCString());

                //         // Check date
                //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var createdCheck = new Date(lecture.createdAt).toLocaleDateString("en-IN", optionsCheck)
                //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)
                //         var newElement;
                //         if (createdCheck === today) {
                //             newElement = `<span class="badge badge-noti">New</span>`
                //             // newelementCount += 1
                //         } else {
                //             newElement = ''
                //         }

                //         const studentsCount = lecture.student.split(',').length
                //         // console.log(studentsCount);
                //         // if (newelementCount > 0) {
                //         //     $('#sidebar-lectures-all').html(`All Lectures <span class="badge badge-noti">${newelementCount}</span>`)
                //         // }

                //         // Code for Update Date
                //         // var updateValue = lecture.updatedAt ? lecture.updatedAt : 'Not updated'
                //         // // Converting update value from UTC to GMT
                //         // if (updateValue != 'Not updated') {
                //         //     // var utcUpdatedDate = new Date(updateValue);
                //         //     // updateValue = utcUpdatedDate.toUTCString()

                //         //     // Hindi Date time
                //         //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                //         //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                //         // }

                //         tbody_lectures += `
                //         <tr>
                //             <td>
                //                 ${lecture.course.name} ${newElement}
                //             </td>
                //             <td>${lecture.teacher.name}</td>
                //             <td>${studentsCount}</td>
                //             <td>${lectureDateTimeEnglishIST}</td>
                //             <td>${lecture.lectureOrExam}</td>
                //         </tr>`;
                //     });
                //     $('#table_lectures tbody').html(tbody_lectures)

                // }

                if (response.data.length == 0 && response.total_count == 0) {
                    var noLecture = `
                    <img src="/images/lectures/nolecture.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Lecture List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Lecture</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-lecture-available').fadeIn()
                    $('#no-lecture-available').html(noLecture)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var nolecture = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-lecture-available').fadeIn()
                    $('#no-lecture-available').html(nolecture)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var nolecture = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-lecture-available').fadeIn()
                        $('#no-lecture-available').html(nolecture)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var lecture = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-lecture-available').fadeIn()
                        $('#no-lecture-available').html(lecture)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_lectures,#myInput').fadeIn()
                        var tbody_lectures;
                        // var newelementCount = 0;
                        response.data.forEach(lecture => {

                            // var utcCreatedDate = new Date(lecture.createdAt);
                            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                            var createdHindiIST = new Date(lecture.createdAt).toLocaleDateString("hi-IN", options)
                            var createdEnglishIST = new Date(lecture.createdAt).toLocaleDateString("en-IN", options)

                            // Check date
                            optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var createdCheck = new Date(lecture.createdAt).toLocaleDateString("en-IN", optionsCheck)
                            var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                            var lectureStartingAt = new Date(lecture.startingAt).toLocaleDateString("en-IN", optionsCheck)
                            var newElement;
                            if (createdCheck === today) {
                                newElement = `<span class="badge badge-noti">New</span>`
                                // newelementCount += 1
                            } else {
                                newElement = ''
                            }
                            // if (newelementCount > 0) {
                            //     $('#sidebar-lectures-all').html(`All Lectures <span class="badge badge-noti">${newelementCount}</span>`)
                            // }

                            // var updateValue = lecture.updatedAt ? lecture.updatedAt : 'Not updated'
                            // // Converting update value from UTC to GMT
                            // if (updateValue != 'Not updated') {
                            //     // var utcUpdatedDate = new Date(updateValue);
                            //     // updateValue = utcUpdatedDate.toUTCString()

                            //     // Hindi Date time
                            //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                            //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                            // }

                            const studentsCount = lecture.student.split(',').length

                            // For join Date
                            // var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                            // var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString("en-IN", dateOptions)
                            var optionsNew = { timeZone: 'UTC', year: 'numeric', month: 'long', day: 'numeric' };
                            // var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString('en-US', optionsNew) // New Testing
                            // lectureDateTimeEnglishIST += '    -    '
                            var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleTimeString('en-US', optionsNew) // New Testing

                            tbody_lectures += `
                            <tr id="${lecture._id}">
                                <td>
                                    ${lecture.course.name} ${newElement}
                                </td>
                                <td>${lecture.teacher.name}</td>
                                <td>${studentsCount}</td>
                                <td>${lectureDateTimeEnglishIST}</td>
                                <td>${lecture.lectureOrExam}</td>
                                <td>
                                    <div class="hover-container">
                                        <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                                        <aside class="hover-popup">
                                            <a align="center" class="p-1 fontt" href="/sdp/manager/viewlecture?lecture=${lecture._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                                            <a align="center" class="p-1 fontt text-success" href="/sdp/manager/editlecture?lecture=${lecture._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                                            <a align="center" class="p-1 fontt text-danger" href="/sdp/manager/deletelecture?lecture=${lecture._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                                        </aside>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        $('#table_lectures tbody').html(tbody_lectures)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Lectures Fetched Successfully',
                    timer: 5000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_lectures tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch lectures list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_lectures tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllLectures()
