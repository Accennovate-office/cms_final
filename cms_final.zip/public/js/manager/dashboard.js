
$('#sidebar-dashboard').addClass('active')
$('#teachers').click(() => { location.replace('/sdp/manager/teachers') })
$('#tasks').click(() => { location.replace('/sdp/manager/tasks') })
$('#fees').click(() => { location.replace('/sdp/manager/fees') })
$('#students').click(() => { location.replace('/sdp/manager/students') })
$('#admissions').click(() => { location.replace('/sdp/manager/admissions') })
$('#lectures').click(() => { location.replace('/sdp/manager/lectures') })
$('#perks').click(() => { location.replace('/sdp/manager/perks') })
$('#birthday').click(() => { location.replace('/sdp/manager/birthday-book') })

// Ref: https://stackoverflow.com/a/9462382
// Learn more about numbering system https://en.wikipedia.org/wiki/Indian_numbering_system
function nFormatter(num, digits) {
    const lookup = [
        { value: 1, symbol: "" },
        { value: 1e3, symbol: " TH" },
        { value: 1e5, symbol: " LK" },
        { value: 1e7, symbol: " CR" },
        { value: 1e9, symbol: " AR" },
        { value: 1e11, symbol: " KH" },
        { value: 1e13, symbol: " NL" },
        { value: 1e15, symbol: " PD" }
    ];
    const rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
    var item = lookup.slice().reverse().find(function (item) {
        return num >= item.value;
    });
    return item ? (num / item.value).toFixed(digits).replace(rx, "$1") + item.symbol : "0";
}

function loadAllTeachers() {

    $('#card1_loading_data').fadeOut(500)
    $('#card1_loading').fadeIn(500)
    $.ajax({
        url: '/sdp/teachers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#teachers_count').text(nFormatter(response.data.length, 1))
                $('#card1_loading_data').fadeIn(500)
                $('#card1_loading').fadeOut(500)

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#table_branches').html(errorMsg)
            }

        }
    });

}
loadAllTeachers()

function loadAllTasks() {

    $('#task_loading_data').fadeOut(500)
    $('#task_loading').fadeIn(500)

    $.ajax({
        url: `/sdp/tasks`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length == 0) {

                    var today = 0, yesterday = 0, month = 0

                    // Display UI when backend tasks are empty
                    $('#todayTasks').text(today)
                    $('#yesterdayTasks').text(yesterday)
                    $('#monthTasks').text(month)

                } else {

                    var today = 0, yesterday = 0, month = 0

                    response.data.forEach(task => {

                        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var optionsDay = { day: 'numeric' };
                        var optionsMonth = { month: 'long' };

                        var todayDay = new Date().toLocaleDateString("en-IN", optionsDay)
                        // console.log(todayDay);
                        var todayMonth = new Date().toLocaleDateString("en-IN", optionsMonth)
                        // console.log('1 - ' + todayMonth);
                        var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", optionsDay)
                        // console.log(createdEnglishIST);
                        var createdEnglishISTMonth = new Date(task.createdAt).toLocaleDateString("en-IN", options)
                        // console.log(createdEnglishISTMonth);
                        const thismonth = createdEnglishISTMonth.split(' ')[2].slice(0, -1)
                        // console.log('2 - ' + thismonth);

                        var todayFullDate = new Date().toLocaleDateString("en-IN", options)
                        // console.log('todayFullDate = ' + todayFullDate);
                        let yesterdayFullDate = new Date(new Date().setDate(new Date().getDate() - 1)).toLocaleDateString("en-IN", options)
                        // console.log('yesterdayFullDate = ' + yesterdayFullDate);

                        if (todayFullDate == createdEnglishISTMonth) { 
                            today += 1
                        } else if (yesterdayFullDate == createdEnglishISTMonth) {
                            yesterday += 1
                        }
                        if (thismonth == todayMonth) {
                            month += 1
                            // console.log(month);
                        }

                    })

                    // Attach this UI in body of tasks with backend data
                    $('#todayTasks').text(nFormatter(today, 2))
                    $('#yesterdayTasks').text(nFormatter(yesterday, 2))
                    $('#monthTasks').text(nFormatter(month, 2))

                }

                $('#task_loading_data').fadeIn(500)
                $('#task_loading').fadeOut(500)

            } else {

                $('#loading').css('display', 'none');
                $('#table_tasks tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch tasks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                $('#table_tasks').html(errorMsg)
            }

        }
    });

}
loadAllTasks()

function loadAllAdmissions() {

    $('#admission_loading_data').fadeOut(500)
    $('#admission_loading').fadeIn(500)
    $('#adm-no-rct').fadeOut(500)
    $('#fees_loading_data').fadeOut(500)
    $('#fees_loading').fadeIn(500)
    $.ajax({
        url: '/sdp/admissions',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var total_fees = 0
                if (response.data.length == 0) {

                    var today = 0, yesterday = 0, month = 0

                    // No admissions found
                    $('#todayAdmissions').text(today)
                    $('#yesterdayAdmissions').text(yesterday)
                    $('#monthAdmissions').text(month)

                    $('#adm-no-rct').fadeIn(500)
                    $('#admission_loading_data').fadeIn(500)
                    $('#admission_loading').fadeOut(500)

                    // No Fees bcoz no admissions
                    $('#received_fees').text(0)
                    $('#pending_fees').text(0)

                    $('#fees_loading_data').fadeIn(500)
                    $('#fees_loading').fadeOut(500)

                } else {

                    // Calculating admission data
                    var today = 0, yesterday = 0, month = 0, count = 0, recent = ``

                    response.data.forEach(admission => {

                        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var optionsDay = { day: 'numeric' };
                        var optionsMonth = { month: 'long' };

                        var todayDay = new Date().toLocaleDateString("en-IN", optionsDay)
                        // console.log(todayDay);
                        var todayMonth = new Date().toLocaleDateString("en-IN", optionsMonth)
                        // console.log('1 - ' + todayMonth);
                        var createdEnglishIST = new Date(admission.createdAt).toLocaleDateString("en-IN", optionsDay)
                        var createdEnglishISTMonth = new Date(admission.createdAt).toLocaleDateString("en-IN", options)
                        // console.log('createdEnglishISTMonth = ' + createdEnglishISTMonth);

                        var todayFullDate = new Date().toLocaleDateString("en-IN", options)
                        // console.log('todayFullDate = ' + todayFullDate);
                        let yesterdayFullDate = new Date(new Date().setDate(new Date().getDate() - 1)).toLocaleDateString("en-IN", options)
                        // console.log('yesterdayFullDate = ' + yesterdayFullDate);

                        const thismonth = createdEnglishISTMonth.split(' ')[2].slice(0, -1)
                        // console.log('2 - ' + thismonth);

                        if (count <= 4) {
                            count += 1

                            const studentName = `${admission.student.firstName} ${admission.student.lastName}`
                            // console.log(studentName);
                            $(`#adm-stu-${count}`).text(studentName)

                            // Finding recent
                            if (todayFullDate == createdEnglishISTMonth) {

                                $(`#adm-dte-${count}`).text('Today')
                            } else if (yesterdayFullDate == createdEnglishISTMonth) {
                                $(`#adm-dte-${count}`).text('Yesterday')
                            } else {

                                const shortdate = createdEnglishISTMonth.split(' ')[1]
                                // console.log('Short Date - ' + shortdate);
                                const shortmonth = createdEnglishISTMonth.split(' ')[2].slice(0, 3)
                                // console.log('Short Month - ' + shortmonth);
                                const shortyear = createdEnglishISTMonth.split(' ')[3].slice(2, 4)
                                // console.log('Short Year - ' + shortyear);
                                const shortFinalDate = `${shortdate} ${shortmonth}, ${shortyear}`
                                // console.log(shortFinalDate);
                                $(`#adm-dte-${count}`).text(shortFinalDate)
                            }

                            var courseName = admission.course.name
                            if (courseName.length > 15) {
                                courseName = courseName.slice(0, 15) + '...'
                            }
                            // console.log(courseName);
                            $(`#adm-cou-${count}`).text(courseName)
                        }

                        if (todayFullDate == createdEnglishISTMonth) { // Change all today & yesterday code to full date
                            today += 1
                        } else if (yesterdayFullDate == createdEnglishISTMonth) {
                            yesterday += 1
                        }
                        if (thismonth == todayMonth) {
                            month += 1
                        }
                    })

                    $('#todayAdmissions').text(today)
                    $('#yesterdayAdmissions').text(yesterday)
                    $('#monthAdmissions').text(month)


                    $('#admission_loading_data').fadeIn(500)
                    $('#admission_loading').fadeOut(500)

                    // Calculating total fees
                    response.data.forEach(admission => {
                        total_fees += admission.course.fees
                    })

                    $.ajax({
                        url: '/sdp/fees',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                if (response.count == 0) {

                                    // No fee records available
                                    $('#received_fees').text(0)
                                    $('#pending_fees').text(0)

                                    $('#fees_loading_data').fadeIn(500)
                                    $('#fees_loading').fadeOut(500)
                                    // console.log('No fees')

                                } else {

                                    var received_fees = 0
                                    response.data.forEach(admission => {
                                        received_fees += admission.feesPaid
                                    })

                                    $('#received_fees').text(nFormatter(received_fees, 2))
                                    $('#pending_fees').text(nFormatter(total_fees - received_fees, 2))

                                    $('#fees_loading_data').fadeIn(500)
                                    $('#fees_loading').fadeOut(500)
                                    // console.log('Yes fees')
                                }


                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_fees tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-fee-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-fee-card button').attr('disabled', true)

                            } else {
                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch fees list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_fees tbody .col').html(errorMsg)
                                $('#errorsection').html(errorMsg)
                            }

                        }
                    });

                }

            } else {

                $('#loading').css('display', 'none');
                $('#table_admissions tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch admissions list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_admissions tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllAdmissions()

function loadAllStudents() {

    $('#student_loading_data').fadeOut(500)
    $('#student_loading').fadeIn(500)

    $.ajax({
        url: '/sdp/students/summary/info',
        method: 'get',
        success: function (response) {
            if (response.success) {

                // Attach this UI in body of students with backend data
                $('#monthStudents').text(nFormatter(response.data.month, 2))
                $('#yearStudents').text(nFormatter(response.data.year, 2))
                $('#totalStudents').text(nFormatter(response.data.total, 2))

                $('#student_loading_data').fadeIn(500)
                $('#student_loading').fadeOut(500)

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                $('#table_students').html(errorMsg)
            }

        }
    });

}
loadAllStudents()

function loadAllLectures() {

    $('#lecture_loading_data').fadeOut(500)
    $('#lec-no-rct').fadeOut(500)
    $('#lecture_loading').fadeIn(500)

    $.ajax({
        url: '/sdp/lectures',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var total_fees = 0
                if (response.data.length == 0) {

                    var today = 0, yesterday = 0, month = 0

                    // No lectures found
                    $('#todayLectures').text(today)
                    $('#yesterdayLectures').text(yesterday)
                    $('#monthLectures').text(month)

                    $('#lec-no-rct').fadeIn(500)
                    $('#lecture_loading_data').fadeIn(500)
                    $('#lecture_loading').fadeOut(500)

                } else {

                    // Calculating lecture data
                    var today = 0, yesterday = 0, month = 0, count = 0, recent = ``

                    response.data.forEach(lecture => {

                        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var optionsTime = { hour: 'numeric', minute: 'numeric', second: 'numeric' };
                        var optionsDay = { day: 'numeric' };
                        var optionsMonth = { month: 'long' };

                        var todayDay = new Date().toLocaleDateString("en-IN", optionsDay)
                        // console.log(todayDay);
                        var todayMonth = new Date().toLocaleDateString("en-IN", optionsMonth)
                        // console.log('1 - ' + todayMonth);
                        var createdEnglishIST = new Date(lecture.createdAt).toLocaleDateString("en-IN", optionsDay)
                        var createdEnglishISTMonth = new Date(lecture.createdAt).toLocaleDateString("en-IN", options)
                        // console.log('Lecture createdEnglishISTMonth = ' + createdEnglishISTMonth);
                        var createdEnglishISTTime = new Date(lecture.createdAt).toLocaleDateString("en-IN", optionsTime)
                        // console.log('Lecture createdEnglishISTTime = ' + createdEnglishISTTime);

                        var todayFullDate = new Date().toLocaleDateString("en-IN", options)
                        // console.log('todayFullDate = ' + todayFullDate);
                        let yesterdayFullDate = new Date(new Date().setDate(new Date().getDate() - 1)).toLocaleDateString("en-IN", options)
                        // console.log('yesterdayFullDate = ' + yesterdayFullDate);

                        const thismonth = createdEnglishISTMonth.split(' ')[2].slice(0, -1)
                        // console.log('2 - ' + thismonth);

                        if (count <= 4) {
                            count += 1

                            const teacherName = lecture.teacher.name
                            // console.log(teacherName);
                            $(`#lec-tch-${count}`).text(teacherName)

                            const time = createdEnglishISTTime.split(' ')[1].slice(0, -3)
                            // console.log(time);
                            const timeEnd = createdEnglishISTTime.split(' ')[2]
                            // console.log(timeEnd);
                            const timeFinal = `${time} ${timeEnd}`

                            // Finding recent
                            if (todayFullDate == createdEnglishISTMonth) {

                                $(`#lec-dte-${count}`).text(`Today - ${timeFinal}`)

                            } else if (yesterdayFullDate == createdEnglishISTMonth) {
                                $(`#lec-dte-${count}`).text(`Yesterday - ${timeFinal}`)

                            } else {

                                const shortdate = createdEnglishISTMonth.split(' ')[1]
                                // console.log('Short Date - ' + shortdate);
                                const shortmonth = createdEnglishISTMonth.split(' ')[2].slice(0, 3)
                                // console.log('Short Month - ' + shortmonth);
                                const shortyear = createdEnglishISTMonth.split(' ')[3].slice(2, 4)
                                // console.log('Short Year - ' + shortyear);
                                const shortFinalDate = `${shortdate} ${shortmonth}, ${shortyear}`
                                // console.log(shortFinalDate);
                                $(`#lec-dte-${count}`).text(`${shortFinalDate} - ${timeFinal}`)
                            }

                            var studentsCount = lecture.student.split(',').length
                            // console.log('studentsCount = ' + studentsCount);
                            $(`#lec-stu-${count}`).text(`${studentsCount} Students`)
                        }

                        if (todayFullDate == createdEnglishISTMonth) { // Change all today & yesterday code to full date
                            today += 1
                        } else if (yesterdayFullDate == createdEnglishISTMonth) {
                            yesterday += 1
                        }
                        if (thismonth == todayMonth) {
                            month += 1
                        }
                    })

                    $('#todayLectures').text(today)
                    $('#yesterdayLectures').text(yesterday)
                    $('#monthLectures').text(month)


                    $('#lecture_loading_data').fadeIn(500)
                    $('#lecture_loading').fadeOut(500)

                }

            } else {

                $('#loading').css('display', 'none');
                $('#table_lectures tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch lectures list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_lectures tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllLectures()

const birthday_list = []
function loadAllBirthdays() {

    $('#birthday_loading_data').fadeOut(500)
    $('#birthday_loading').fadeIn(500)

    // Fetch birthdays
    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {


                var tbody_birthdays;
                if (response.data.length == 0) {

                    $('#birthday-data').html(`<div class="row pt-5 pl-2" style="opacity: 0.8;">No Birthday Found</div>`)
                    $('#birthday-img').attr('src', '/images/dashboard/nobirthday.png')

                } else {
                    isEmpty = false

                    response.data.forEach(birthday => {

                        // // var utcCreatedDate = new Date(birthday.createdAt);
                        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                        // // var s = new Date(birthday.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                        // var createdHindiIST = new Date(birthday.createdAt).toLocaleDateString("hi-IN", options)
                        var createdEnglishIST = new Date(birthday.createdAt).toLocaleDateString("en-IN", options)

                        // For join Date
                        var dateOptions = { month: 'long', day: 'numeric' };
                        var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                        var today = new Date().toLocaleDateString("en-IN", dateOptions)

                        // For join Date
                        var dateOptions = { month: 'long', day: 'numeric' };
                        var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                        var today = new Date().toLocaleDateString("en-IN", dateOptions)
                        // var x = new Date(birthday.createdAt).getTimezoneOffset();

                        if (birthdayDateEnglishIST === today) {
                            birthday_list.push(birthday.name)
                        }
                    });



                }

                // Fetch students birthdays
                $.ajax({
                    url: '/sdp/students/birthday/data?select=dob,firstName,lastName',
                    method: 'get',
                    success: function (response) {
                        if (response.success) {


                            if (response.data.length == 0 && isEmpty) {

                                if (birthday_list.length <= 0) {

                                    $('#birthday-data').html(`<div class="row pt-5 pl-2" style="opacity: 0.8;">No Birthday Today</div>`)
                                    $('#birthday-img').attr('src', '/images/dashboard/nobirthday.png')

                                } else {

                                    var list_data = ``

                                    if (birthday_list.length <= 4) {

                                        birthday_list.forEach(bday => {
                                            list_data += `<div class="row pl-2">${bday}</div>`
                                        });
                                        $('#birthday-data').html(list_data)

                                    } else {

                                        for (let i = 0; i < 3; i++) {
                                            list_data += `<div class="row pl-2">${birthday_list[i]}</div>`
                                        }
                                        list_data += `<div class="row pl-2">+${birthday_list.length - 3} more today</div>`
                                        $('#birthday-data').html(list_data)

                                    }
                                    $('#birthday-img').attr('src', '/images/dashboard/birthday.png')

                                }

                                $('#birthday_loading_data').fadeIn(500)
                                $('#birthday_loading').fadeOut(500)


                            } else {
                                isEmpty = false

                                response.data.forEach(birthday => {

                                    // For join Date
                                    var dateOptions = { month: 'long', day: 'numeric' };
                                    var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                                    var today = new Date().toLocaleDateString("en-IN", dateOptions)

                                    // For join Date
                                    var dateOptions = { month: 'long', day: 'numeric' };
                                    var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                                    var today = new Date().toLocaleDateString("en-IN", dateOptions)
                                    // var x = new Date(birthday.createdAt).getTimezoneOffset();

                                    if (birthdayDateEnglishIST === today) {
                                        birthday_list.push(`${birthday.firstName} ${birthday.lastName}`)
                                    }

                                });

                                if (birthday_list.length <= 0) {

                                    $('#birthday-data').html(`<div class="row pt-5 pl-2" style="opacity: 0.8;">No Birthday Today</div>`)
                                    $('#birthday-img').attr('src', '/images/dashboard/nobirthday.png')

                                } else {

                                    var list_data = ``

                                    if (birthday_list.length <= 4) {

                                        birthday_list.forEach(bday => {
                                            list_data += `<div class="row pl-2">${bday}</div>`
                                        });
                                        $('#birthday-data').html(list_data)

                                    } else {

                                        for (let i = 0; i < 3; i++) {
                                            list_data += `<div class="row pl-2">${birthday_list[i]}</div>`
                                        }
                                        list_data += `<div class="row pl-2">+${birthday_list.length - 3} more today</div>`
                                        $('#birthday-data').html(list_data)

                                    }
                                    $('#birthday-img').attr('src', '/images/dashboard/birthday.png')

                                }

                                $('#birthday_loading_data').fadeIn(500)
                                $('#birthday_loading').fadeOut(500)

                            }

                        } else {

                            $('#loading').css('display', 'none');
                            $('#table_birthdays tbody tr').text(response.responseJSON.error);
                            console.log(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-birthday-card button').attr('disabled', true)

                        }
                    },
                    error: function (response) {

                        if (response.responseJSON) {
                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            console.log(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-birthday-card button').attr('disabled', true)

                        } else {
                            var errorMsg = `
                            <center>
                            <h2>Oops! Something went wrong</h2>
                            <h4 class="text-danger">
                                Error Code: ${response.status} <br>
                                Error Message: ${response.statusText}
                            </h4>
                            <h5>We were unable to fetch birthdays list</h5>
                            <h6>
                                Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                            </h6>
                            </center>`
                            console.log(`something went wrong ${JSON.stringify(response)}`);
                            // console.log(response.statusText);
                            // $('#table_birthdays tbody .col').html(errorMsg)
                            $('#errorsection').html(errorMsg)
                        }

                    }
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_birthdays tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch birthdays list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_birthdays tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllBirthdays()

function loadAllPerks() {

    $('#perk_loading_data').fadeOut(500)
    $('#perk_loading').fadeIn(500)

    $.ajax({
        url: '/sdp/perks?sort=-points',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var total_fees = 0
                if (response.summary.length == 0) {

                    $('#perks-card .body').html(`
                    <div class="pt-4" style="padding-bottom: 28px;">
                    <img src="/images/perks/noperk.png" width="50" alt="">
                    No Perks Found
                </div>`)
                    $('#perk_loading_data').fadeIn(500)
                    $('#perk_loading').fadeOut(500)

                } else {

                    // Calculating perk data
                    var count = 0, list_data = ``

                    if (response.summary.length >= 3) {

                        $('#perks-card .body').html(`
                        <div class="row">
                            <div class="col col-1">
                                <img align="left" src="/images/perks/perkno1.png" width="35" alt="">
                            </div>
                            <div class="col">${response.summary[0].name} (${response.summary[0].points})</div>
                        </div>
                        <div class="row">
                            <div class="col col-1">
                                <img align="left" src="/images/perks/perkno2.png" width="35" alt="">
                            </div>
                            <div class="col">${response.summary[1].name} (${response.summary[1].points})</div>
                        </div>
                        <div class="row">
                            <div class="col col-1">
                                <img align="left" src="/images/perks/perkno3.png" width="35" alt="">
                            </div>
                            <div class="col">${response.summary[2].name} (${response.summary[2].points})</div>
                        </div>`)

                    } else if (response.summary.length == 2) {

                        $('#perks-card .body').html(`
                        <div class="row">
                            <div class="col col-1">
                                <img align="left" src="/images/perks/perkno1.png" width="35" alt="">
                            </div>
                            <div class="col">${response.summary[0].name} (${response.summary[0].points})</div>
                        </div>
                        <div class="row" style="padding-bottom:32px">
                            <div class="col col-1">
                                <img align="left" src="/images/perks/perkno2.png" width="35" alt="">
                            </div>
                            <div class="col">${response.summary[1].name} (${response.summary[1].points})</div>
                        </div>`)

                    } else if (response.summary.length == 1) {

                        $('#perks-card .body').html(`
                        <div class="row" style="padding-bottom:72px">
                            <div class="col col-1">
                                <img align="left" src="/images/perks/perkno1.png" width="35" alt="">
                            </div>
                            <div class="col">${response.summary[0].name} (${response.summary[0].points})</div>
                        </div>`)

                    }


                    $('#perk_loading_data').fadeIn(500)
                    $('#perk_loading').fadeOut(500)

                }

            } else {

                $('#loading').css('display', 'none');
                $('#table_perks tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch perks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_perks tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllPerks()
