
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-teachers').trigger("click")
$('#sidebar-teachers,#sidebar-teachers-edit').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

const courses_all_list = []
const category_id_list = []
var teacher_slug

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['teacher'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/manager/teachers')
})

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
$('#myInput1,#myInput2').focusout(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.png')
})
// Searchable dropdown end

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Teacher Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function disableInputs() {
    $('#teachername').val('Teacher Name here')
    $('#teachername').attr('disabled', true)

    $('#teacheraddress').val('Teacher Address here')
    $('#teacheraddress').attr('disabled', true)

    $('#teacherdob').val('')
    $('#teacherdob').attr('disabled', true)

    $('#teacherphone').val('Teacher Phone here')
    $('#teacherphone').attr('disabled', true)

    $('#teacheremail,#teacheremailagain').val('Teacher Email here')
    $('#teacheremail,#teacheremailagain').attr('disabled', true)

    $('#teacheredu').val('Teacher Educational Qualifications here')
    $('#teacheredu').attr('disabled', true)

    $('#teacherskill').val('Teacher Computer Skills here')
    $('#teacherskill').attr('disabled', true)

    $('#teacherjoin').val('')
    $('#teacherjoin').attr('disabled', true)

    $('#teacherbranch').val('')
    $('#teacherbranch').attr('disabled', true)

    $('#teacherjobstart').val('')
    $('#teacherjobstart').attr('disabled', true)

    $('#teacherjobend').val('')
    $('#teacherjobend').attr('disabled', true)

    $('#myDropdown1-1').val('')
    $('#dropbtn1').attr('disabled', true)

    // Bank details
    $('#accountname').val('Enter account holder name')
    $('#accountno').val('Enter account number')
    $('#ifsccode').val('Enter IFSC code')
    $('#bankname').val('Enter bank name')
    $('#bankbranchname').val('Enter bank branch name')
    $('#panno').val('Enter PAN number')
    $('#accountname,#accountno,#ifsccode,#bankname,#bankbranchname,#panno').attr('disabled', true)
}

function checkInputs() {
    var teachername = $('#teachername').val()
    var teacheraddress = $('#teacheraddress').val()
    var teacherdob = $('#teacherdob').val()
    var teacherphone = $('#teacherphone').val()
    var teacheremail = $('#teacheremail').val()
    var teacheredu = $('#teacheredu').val()
    var teacherskill = $('#teacherskill').val()
    var teacherjoin = $('#teacherjoin').val()
    var teacherbranch = $('#teacherbranch').val()
    var teacherjobstart = $('#teacherjobstart').val()
    var teacherjobend = $('#teacherjobend').val()
    // Bank detials
    var accountname = $('#accountname').val()
    var accountno = $('#accountno').val()
    var ifsccode = $('#ifsccode').val()
    var bankname = $('#bankname').val()
    var bankbranchname = $('#bankbranchname').val()
    var panno = $('#panno').val()

    // Courses allocated
    var courses_allocated = $('#myDropdown1-1').val().toString()
    if (courses_allocated == 'No Course selected') {
        courses_allocated = ''
    }

    if (teachername || teacheraddress || teacherdob || teacherphone || teacheremail || teacheredu || teacherskill || teacherjoin || teacherbranch || teacherjobstart || teacherjobend || courses_allocated || accountname || accountno || ifsccode || bankname || bankbranchname || panno) {
        $('#editteacher #edit-teacher-btn').attr('disabled', true)
        if (teachername && teacheraddress && teacherdob && teacherphone && teacheremail && teacheredu && teacherskill && teacherjoin && teacherbranch && teacherjobstart && teacherjobend && courses_allocated && accountname && accountno && ifsccode && bankname && bankbranchname && panno) {
            $('#editteacher #edit-teacher-btn').attr('disabled', false)
        } else {
            $('#editteacher #edit-teacher-btn').attr('disabled', true)
        }
    }
}

$('#editteacher #teachername,#editteacher #teacheraddress,#editteacher #teacherdob,#editteacher #teacherphone,#editteacher #teacheremail,#editteacher #teacheredu,#editteacher #teacherjoin,#editteacher #teacherbranch,#editteacher #teacherjobstart,#editteacher #teacherjobend,#editteacher input').keyup(() => {

    checkInputs();
})

function loadTeachersList(teachername = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading teachers list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/teachers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var teachers_list;
                $('#editteacher #teacher').text(response.data)

                if (response.data.length == 0) {
                    teachers_list += `<option value="">Teacher List is empty</option>`;
                } else {
                    teachers_list = `<option value="">Select Teacher Name</option>`;
                    response.data.forEach(teacher => {

                        if ((teachername == teacher.user.name) || (teacher.user._id == selected)) {
                            select = 'selected'
                            teacher_slug = teacher.user.slug
                        } else {
                            select = ''
                        }

                        teachers_list += `
                        <option ${select} value="${teacher.user._id}">${teacher.user.name}</option>`;
                    });
                }
                $('#editteacher #teacher').html(teachers_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Teachers Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Teachers',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_teachers tbody .col').html(errorMsg)
                $('#teacher-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Teachers',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#teacher-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-teacher-card #edit-teacher-btn').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch teachers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_teachers tbody .col').html(errorMsg)
                $('#teacher-selected').html(errorMsg)
            }

        }
    });

}
loadTeachersList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing teacher details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#teacher-selected').css('display', 'block')
function getTeacherDetails() {

    const selectTeacher = $('#teacher').val() ? $('#teacher').val() : selected

    $('#editteacher #edit-teacher-btn').attr('disabled', true)
    // console.log(selectTeacher);
    if (selectTeacher == '') {

        disableInputs()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching teacher details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#teachername').attr('disabled', false)
        $('#teacheraddress').attr('disabled', false)
        $('#teacherdob').attr('disabled', false)
        $('#teacherphone').attr('disabled', false)
        $('#teacheremail').attr('disabled', false)
        $('#teacheredu').attr('disabled', false)
        $('#teacherskill').attr('disabled', false)
        $('#teacherjoin').attr('disabled', false)
        $('#teacherbranch').attr('disabled', false)
        $('#teacherjobstart').attr('disabled', false)
        $('#teacherjobend').attr('disabled', false)
        $('#dropbtn1').attr('disabled', false)
        $('#accountname,#accountno,#ifsccode,#bankname,#bankbranchname,#panno').attr('disabled', false)

        $.ajax({
            url: `/sdp/teachers/${selectTeacher}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const teacherBranch = response.data.user.branch
                    const coursesAllocated = response.data.coursesAllocated.split(',')
                    // console.log(coursesAllocated);
                    teacher_slug = response.data.user.slug
                    $('#teacherid').val(response.data._id)
                    $('#teachername').val(response.data.user.name)
                    $('#teacheraddress').val(response.data.address)
                    $('#teacherdob').val(response.data.dob.slice(0, 10))
                    $('#teacherphone').val(response.data.phone)
                    $('#teacheremail,#teacheremailagain').val(response.data.user.email)
                    $('#teacheredu').val(response.data.educationalQualification)
                    $('#teacherskill').val(response.data.computerSkills)
                    $('#teacherjoin').val(response.data.joiningDate.slice(0, 10))
                    $('#teacherjobstart').val(response.data.jobTime.slice(0, 5))
                    $('#teacherjobend').val(response.data.jobTime.slice(6, 11))
                    // Bank details
                    $('#accountname').val(response.data.accountHolderName ? response.data.accountHolderName : '')
                    $('#accountno').val(response.data.accountNumber ? response.data.accountNumber : '')
                    $('#ifsccode').val(response.data.IFSCcode ? response.data.IFSCcode : '')
                    $('#bankname').val(response.data.bank ? response.data.bank : '')
                    $('#bankbranchname').val(response.data.bankBranch ? response.data.bankBranch : '')
                    $('#panno').val(response.data.PAN ? response.data.PAN : '')

                    $.ajax({
                        url: '/sdp/branches',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var branches_list;
                                $('#editteacher #teacherbranch').text(response.data)

                                if (response.data.length == 0) {
                                    branches_list += `<option value="">Branch List is empty</option>`;
                                } else {
                                    // branches_list = `<option value="">Select Branch Name</option>`;
                                    response.data.forEach(branch => {

                                        if (teacherBranch == branch.name) {
                                            branches_list += `
                                        <option selected value="${branch.name}">${branch.name}</option>`;
                                        } else {
                                            branches_list += `
                                        <option value="${branch.name}">${branch.name}</option>`;
                                        }

                                    });
                                }

                                $('#editteacher #teacherbranch').html(branches_list)

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Branches Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Teacher Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                disableInputs()

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Branches',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                // $('#table_branches tbody tr').text(response.responseJSON.error);
                                // console.log(response);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card #edit-teacher-btn').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            disableInputs()

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Branches',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                // $('#error').text(response.responseJSON.error);
                                // console.log(response);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card #edit-teacher-btn').attr('disabled', true)

                            } else {

                                disableInputs()

                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch branches list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_branches tbody .col').html(errorMsg)
                                $('#no-branch-selected').html(errorMsg)
                            }

                        }
                    });

                    $.ajax({
                        url: '/sdp/courses',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var courses_list = ``;
                                $('#teachercourses').text(response.data)

                                if (response.count == 0) {
                                    courses_list += `<option value="">No Course available</option>`;
                                } else {
                                    // courses_list = `
                                    // <input type="checkbox" name="default-batches" id="default-batches" class="mt-0">
                                    // <label for="default-batches">Add default batches</label>`;
                                    response.data.forEach(course => {
                                        var checked = ''

                                        coursesAllocated.forEach(allocated_course => {
                                            if (allocated_course === course.name) {
                                                checked = 'selected'
                                            }
                                        });
                                        // courses_list += `
                                        // <input type="checkbox" ${checked} name="${course._id}" id="${course._id}" class="my-2 mr-1 pt-1">
                                        // <label for="${course._id}" class="my-2 mr-1 pt-1">${course.name}</label>`;
                                        courses_list += `
                                        <option ${checked} id="${course._id}" value="${course.name}">${course.name}</option>`;
                                        category_id_list.push(course._id)
                                        courses_all_list.push([course._id, course.name])

                                    });
                                    // console.log(courses_list);
                                    $('#editteacher #myDropdown1-1').html(courses_list)
                                    const category = $('#myDropdown1-1').val()
                                    if (category != '') {
                                        // console.log(category);
                                        $('#category_selected').text(category)
                                        document.getElementById('category_selected').classList.add('c_selected')
                                    } else {
                                        document.getElementById('category_selected').classList.remove('c_selected')
                                        $('#category_selected').text('No Course selected')
                                        document.getElementById("myDropdown1").classList.remove("show");
                                    }
                                    category_id_list.forEach(cat => {
                                        $(`#${cat}`).click(() => {

                                            const category = $('#myDropdown1-1').val()
                                            if (category != '') {
                                                // console.log(category);
                                                $('#category_selected').text(category)
                                                document.getElementById('category_selected').classList.add('c_selected')
                                                checkInputs()
                                            } else {
                                                document.getElementById('category_selected').classList.remove('c_selected')
                                                $('#category_selected').text('No Course selected')
                                                document.getElementById("myDropdown1").classList.remove("show");
                                                checkInputs();
                                            }


                                        })
                                    });

                                }

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Courses Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                // $('#table_courses tbody tr').text(response.responseJSON.error);
                                // console.log(response);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-course-card #edit-teacher-btn').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                // $('#errors').text(response.responseJSON.error);
                                // console.log(response);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-course-card #edit-teacher-btn').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch courses list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_courses tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    disableInputs()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Teachers',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_teachers tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-teacher-card #edit-teacher-btn').attr('disabled', true)

                }
            },
            error: function (response) {

                disableInputs()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Teachers',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    // $('#error').text(response.responseJSON.error);
                    // console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-teacher-card #edit-teacher-btn').attr('disabled', true)

                } else {
                    disableInputs()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch teacher details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_teachers tbody .col').html(errorMsg)
                    $('#no-teacher-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getTeacherDetails()
}
$('#teacher').change(() => {

    getTeacherDetails()

})

$('#edit-teacher-btn').click(() => {
    // Extra security code
    var teacherid = $('#teacherid').val()
    // console.log(teacherid);
    var nameInput = $('#teachername')
    var teachername = $('#teachername').val()

    var addressInput = $('#teacheraddress')
    var teacheraddress = $('#teacheraddress').val()

    var dobInput = $('#teacherdob')
    var teacherdob = $('#teacherdob').val()

    var phoneInput = $('#teacherphone')
    var teacherphone = $('#teacherphone').val()

    var emailInput = $('#teacheremail')
    var teacheremail = $('#teacheremail').val()

    var eduInput = $('#teacheredu')
    var teacheredu = $('#teacheredu').val()

    var skillInput = $('#teacherskill')
    var teacherskill = $('#teacherskill').val()

    var joinInput = $('#teacherjoin')
    var teacherjoin = $('#teacherjoin').val()

    var branchInput = $('#teacherbranch')
    var teacherbranch = $('#teacherbranch').val()

    var jobstartInput = $('#teacherjobstart')
    var teacherjobstart = $('#teacherjobstart').val()

    var jobendInput = $('#teacherjobend')
    var teacherjobend = $('#teacherjobend').val()

    // Bank detials
    var accountnameInput = $('#accountname')
    var accountnoInput = $('#accountno')
    var ifsccodeInput = $('#ifsccode')
    var banknameInput = $('#bankname')
    var bankbranchnameInput = $('#bankbranchname')
    var pannoInput = $('#panno')

    var accountname = $('#accountname').val()
    var accountno = $('#accountno').val()
    var ifsccode = $('#ifsccode').val()
    var bankname = $('#bankname').val()
    var bankbranchname = $('#bankbranchname').val()
    var panno = $('#panno').val()

    // Courses allocated
    var courses_allocated = $('#myDropdown1-1').val().toString()
    if (courses_allocated == 'No Course selected') {
        courses_allocated = ''
    }

    if (!teachername) {
        nameInput.css('border', '2px solid red')
        nameInput.attr('placeholder', 'Please add teacher name')
    } else if (!teacheraddress) {
        addressInput.css('border', '2px solid red')
        addressInput.attr('placeholder', 'Please add teacher address')
    } else if (!teacherdob) {
        dobInput.css('border', '2px solid red')
    } else if (!teacherphone) {
        phoneInput.css('border', '2px solid red')
        phoneInput.attr('placeholder', 'Please add teacher phone')
    } else if (!teacheremail) {
        emailInput.css('border', '2px solid red')
        emailInput.attr('placeholder', 'Please add teacher email')
    } else if (!teacheredu) {
        eduInput.css('border', '2px solid red')
        eduInput.attr('placeholder', 'Please add teacher edu')
    } else if (!teacherskill) {
        skillInput.css('border', '2px solid red')
        skillInput.attr('placeholder', 'Please add teacher skill')
    } else if (!teacherjoin) {
        joinInput.css('border', '2px solid red')
    } else if (!teacherbranch) {
        branchInput.css('border', '2px solid red')
        branchInput.attr('placeholder', 'Please select teacher branch')
    } else if (!teacherjobstart) {
        jobstartInput.css('border', '2px solid red')
    } else if (!teacherjobend) {
        jobendInput.css('border', '2px solid red')
    } else if (!courses_allocated) {
        error_course.text('Please select atleast 1 course')
    } else if (!accountnameInput) {
        accountname.css('border', '2px solid red')
    } else if (!accountnoInput) {
        accountno.css('border', '2px solid red')
    } else if (!ifsccodeInput) {
        ifsccode.css('border', '2px solid red')
    } else if (!banknameInput) {
        bankname.css('border', '2px solid red')
    } else if (!bankbranchnameInput) {
        bankbranchname.css('border', '2px solid red')
    } else if (!pannoInput) {
        panno.css('border', '2px solid red')
    } else {
        // error_course.text('')

        $('#editteacher #edit-teacher-btn').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Loading swal
        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: `Updating teachers info...`,
            showConfirmButton: false
        });

        // Update teacher
        $.ajax({
            url: `/sdp/teachers/${teacherid}`,
            method: 'put',
            dataType: 'json',
            data: {
                dob: teacherdob,
                phone: teacherphone,
                address: teacheraddress,
                educationalQualification: teacheredu,
                computerSkills: teacherskill,
                coursesAllocated: courses_allocated,
                joiningDate: teacherjoin,
                jobTime: `${teacherjobstart},${teacherjobend}`,
                accountHolderName: accountname,
                accountNumber: accountno,
                IFSCcode: ifsccode,
                bank: bankname,
                bankBranch: bankbranchname,
                PAN: panno,
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-teacher-card #edit-teacher-btn').attr('disabled', true)
                    // console.log('Inside success');
                    // Update user
                    $.ajax({
                        url: `/sdp/users/${teacher_slug}`,
                        method: 'put',
                        dataType: 'json',
                        data: {
                            name: teachername,
                            dob: teacherdob,
                            branch: teacherbranch,
                            email: teacheremail
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                $('#edit-teacher-card #edit-teacher-btn').attr('disabled', true)
                                // console.log('Inside success 2');

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Teacher Updated Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    loadTeachersList(teachername)
                                }, 3000);

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                // console.log(response);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-teacher-card #edit-teacher-btn').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            // console.log(response);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-teacher-card #edit-teacher-btn').attr('disabled', true)

                        }
                    });

                    // Swal.fire({
                    //     toast: true,
                    //     position: 'top-right',
                    //     icon: 'success',
                    //     title: 'Teacher Updated Successfully',
                    //     timer: 3000,
                    //     showConfirmButton: false
                    // });
                    // setTimeout(() => {
                    //     loadTeachersList(teachername)
                    // }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    // console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-teacher-card #edit-teacher-btn').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                // console.log(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-teacher-card #edit-teacher-btn').attr('disabled', true)

            }
        });

    }
})
