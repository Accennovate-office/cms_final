import { setCookie, getCookie } from "../services/cookie.js";
import { addFollowup } from "../services/followup.js";

$('#no-enquiry-available').fadeOut()
$('#table_enquiries,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

$('#sidebar-enquiries').trigger("click")
$('#sidebar-enquiries,#sidebar-enquiries-all').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

var all_enquiries_data
var total_count
var cols = {enqdob: false, enqreligion: false, enqcaste: false, enqaadhaarNo: false, enqmotherName: false, enqfatherOccupation: false, enqmotherTongue: false, enqaddress: false, enqcontact: false, enqqualification: false, enqschoolOrCollegeName: false, enqclassOrTuitionName: false, enqcategory: false, enqbranch: false, enqarea: false, enqcourses: false, enqtakenby: false,
            created: false, updated: false}
// Add gender as Logo / Icon

$('#new-enquiry-btn').click(() => {
    document.location.replace('/sdp/manager/addenquiry');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllEnquiries(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllEnquiries(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllEnquiries(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllEnquiries(limit, page + 1)
})
// Page navigator End

function loadAllEnquiries(limit = 1, page = 1) {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-enquiry-available').fadeOut()
    $('#table_enquiries,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/enquiries?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                all_enquiries_data = response.alldata
                // console.log(all_enquiries_data);
                total_count = response.alldatacount
                $('#error,#loading').css('display', 'none')

                if (response.data.length == 0 && response.total_count == 0) {
                    var noenquiry = `
                    <img src="/images/enquiries/noenquiry.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Enquiry List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Enquiry</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $("#modify-cols-btn").attr("disabled", true);
                    $('#modify-cols-btn').css("cursor","not-allowed")
                    $("#filter-btn").attr("disabled", true);
                    $('#filter-btn').css("cursor","not-allowed")
                    $('#no-enquiry-available').fadeIn()
                    $('#no-enquiry-available').html(noenquiry)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var noenquiry = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-enquiry-available').fadeIn()
                    $('#no-enquiry-available').html(noenquiry)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        // console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var noenquiry = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-enquiry-available').fadeIn()
                        $('#no-enquiry-available').html(noenquiry)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        // console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var enquiry = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-enquiry-available').fadeIn()
                        $('#no-enquiry-available').html(enquiry)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_enquiries,#myInput').fadeIn()

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Enquiries Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });
                
                cols.enqdob = getCookie('enqdob_selected')
                cols.enqreligion = getCookie('enqreligion_selected')
                cols.enqcaste = getCookie('enqcaste_selected')
                cols.enqaadhaarNo = getCookie('enqaadhaarNo_selected')
                cols.enqmotherName = getCookie('enqmotherName_selected')
                cols.enqfatherOccupation = getCookie('enqfatherOccupation_selected')
                cols.enqmotherTongue = getCookie('enqmotherTongue_selected')
                cols.enqaddress = getCookie('enqaddress_selected')
                cols.enqcontact = getCookie('enqcontact_selected')
                cols.enqcategory = getCookie('enqcategory_selected')
                cols.enqbranch = getCookie('enqbranch_selected')
                cols.created = getCookie('createdenq_selected')
                cols.updated = getCookie('updatedenq_selected')
                // Refresh data
                // populateTable(all_enquiries_data, cols)
                getFilterCount()
                callAllFunctions()
                setTimeout(() => {
                    modify_columns()
                }, 1500);

            } else {

                $('#loading').css('display', 'none');
                $('#table_enquiries tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-enquiry-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-enquiry-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch enquiries list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_enquiries tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllEnquiries()

// Feb 2023 update
function populateTable(data, cols) {
    var tbody_enquiries;
    // Columns add
    var dob_column_head = cols.enqdob ? `<th id="dob_thead" class="col col-3 remove-borders">DOB</th>` : ``;
    var religion_column_head = cols.enqreligion ? `<th id="religion_thead" class="col col-1 remove-borders">Religion</th>` : ``;
    var caste_column_head = cols.enqcaste ? `<th id="caste_thead" class="col col-1 remove-borders">Caste</th>` : ``;
    var aadhaarNo_column_head = cols.enqaadhaarNo ? `<th id="aadhaarNo_thead" class="col col-2 remove-borders">Aadhaar No</th>` : ``;
    var motherName_column_head = cols.enqmotherName ? `<th id="motherName_thead" class="col col-2 remove-borders">Mother Name</th>` : ``;
    var fatherOccupation_column_head = cols.enqfatherOccupation ? `<th id="fatherOccupation_thead" class="col col-2 remove-borders">Father Occupation</th>` : ``;
    var motherTongue_column_head = cols.enqmotherTongue ? `<th id="motherTongue_thead" class="col col-2 remove-borders">Mother Tongue</th>` : ``;
    var address_column_head = cols.enqaddress ? `<th id="address_thead" class="col col-2 remove-borders">Address</th>` : ``;
    var contact_column_head = cols.enqcontact ? `<th id="contact_thead" class="col col-2 remove-borders">Contact</th>` : ``;
    var category_column_head = cols.enqcategory ? `<th id="category_thead" class="col col-2 remove-borders">Category</th>` : ``;
    var branch_column_head = cols.enqbranch ? `<th id="branch_thead" class="col col-2 remove-borders">Branch</th>` : ``;
    var area_column_head = cols.enqarea ? `<th id="area_thead" class="col col-2 remove-borders">Area</th>` : ``;
    var courses_column_head = cols.enqcourses ? `<th id="courses_thead" class="col col-2 remove-borders">Courses</th>` : ``;
    var takenby_column_head = cols.enqtakenby ? `<th id="takenby_thead" class="col col-2 remove-borders">Enquiry Taken By</th>` : ``;
    var created_column_head = cols.created ? `<th id="created_thead" class="col col-2 remove-borders">Created</th>` : ``;
    var updated_column_head = cols.updated ? `<th id="updated_thead" class="col col-2 remove-borders">Updated</th>` : ``;
    $('#table_head_enquiries').html(`
    <th id="name_thead" class="col col-2 remove-borders">Name</th>
    <th id="admission_thead" class="col col-2 remove-borders">Admission</th>
    ${dob_column_head}${religion_column_head}${caste_column_head}${aadhaarNo_column_head}${motherName_column_head}${fatherOccupation_column_head}${motherTongue_column_head}${address_column_head}${contact_column_head}${category_column_head}${branch_column_head}${area_column_head}${courses_column_head}${takenby_column_head}${created_column_head}${updated_column_head}`)
    // console.log(data);
    $('#enquiry-entries').html(`Showing ${data.length} of ${total_count} entries`)
    $("#enquiry-entries").addClass("flash_colours");
    setTimeout(() => {
        $("#enquiry-entries").removeClass("flash_colours");
    }, 3000);
    var countOfEnq = 0
    var listOfFollowupButtons = []
    data.forEach(enquiry => {
        // console.log('enquiry');
        // var utcCreatedDate = new Date(enquiry.createdAt);
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

        var createdHindiIST = new Date(enquiry.createdAt).toLocaleDateString("hi-IN", options)
        var createdEnglishIST = new Date(enquiry.createdAt).toLocaleDateString("en-IN", options)

        // Check date
        optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var createdCheck = new Date(enquiry.createdAt).toLocaleDateString("en-IN", optionsCheck)
        var today = new Date().toLocaleDateString("en-IN", optionsCheck)
        var dobEnglishIST = ''
        if (enquiry.dob) {
            dobEnglishIST = new Date(enquiry.dob).toLocaleDateString("en-IN", optionsCheck)
        }

        var newElement;
        if (createdCheck === today) {
            newElement = `<span class="badge badge-noti">New</span>`
            // newelementCount += 1
        } else {
            newElement = ''
        }

        var updateValue = enquiry.updatedAt ? enquiry.updatedAt : 'Not updated'
        // Converting update value from UTC to GMT
        if (updateValue != 'Not updated') {
            updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
        }

        if (enquiry.address) {
            
            if (enquiry.address.length > 50) {
                var truncated_address = enquiry.address.slice(0,50)+'...'
            } else {
                var truncated_address = enquiry.address
            }
        }

        var contactDetails = `${enquiry.phone1}`
        enquiry.email ? contactDetails += ` - ${enquiry.email}` : ''
        enquiry.phone2 ? contactDetails += ` / ${enquiry.phone2}` : ''
        enquiry.parentPhone ? contactDetails += ` / ${enquiry.parentPhone} (parent)` : ''

        var dob_column_data = cols.enqdob ? `<td class="remove-borders">${dobEnglishIST}</td>` : ''
        var religion_column_data = cols.enqreligion ? `<td class="remove-borders">${enquiry.religion}</td>` : ''
        var caste_column_data = cols.enqcaste ? `<td class="remove-borders">${enquiry.caste}</td>` : ''
        var aadhaarNo_column_data = cols.enqaadhaarNo ? `<td class="remove-borders">${enquiry.aadhaarNo ? enquiry.aadhaarNo : ''}</td>` : ''
        var motherName_column_data = cols.enqmotherName ? `<td class="remove-borders">${enquiry.motherName}</td>` : ''
        var fatherOccupation_column_data = cols.enqfatherOccupation ? `<td class="remove-borders">${enquiry.fatherOccupation}</td>` : ''
        var motherTongue_column_data = cols.enqmotherTongue ? `<td class="remove-borders">${enquiry.motherTongue}</td>` : ''
        var address_column_data = cols.enqaddress ? `<td class="remove-borders">${truncated_address ? truncated_address : ''}</td>` : ''
        var contact_column_data = cols.enqcontact ? `<td class="remove-borders">${contactDetails}</td>` : ''
        var category_column_data = cols.enqcategory ? `<td class="remove-borders">${enquiry.category ? enquiry.category : ''}</td>` : ''
        var branch_column_data = cols.enqbranch ? `<td class="remove-borders">${enquiry.branch ? enquiry.branch : ''}</td>` : ''
        var area_column_data = cols.enqarea ? `<td class="remove-borders">${enquiry.area}</td>` : ''
        var courses_column_data = cols.enqcourses ? `<td class="remove-borders">${enquiry.courses ? enquiry.courses.split(',').length : ''}</td>` : ''
        var takenby_column_data = cols.enqtakenby ? `<td class="remove-borders">${enquiry.takenby ? enquiry.takenby.name : enquiry.takenbyother + ' (other)'}</td>` : ''
        var created_column_data = cols.created ? `<td class="remove-borders">${createdEnglishIST}</td>` : ''
        var updated_column_data = cols.updated ? `<td class="remove-borders">${updateValue}</td>` : ''
        
        if (enquiry.gender == 'Male') {
            var gen = 'male'
        } else {
            var gen = 'female'
        }

        // /sdp/students?enquiry=6436a1d54806fb05e8c6a808
        createAdmissionButton(enquiry)
        .then((res)=>{
            
            // console.log(res);
            countOfEnq++
            // console.log(countOfEnq);   
            tbody_enquiries += `
            <tr id="${enquiry._id}">
                <td class="remove-borders"><a href="/sdp/manager/viewenquiry?enquiry=${enquiry._id}" target="_blank">
                    <i class="fa fa-${gen}" aria-hidden="true"></i>
                    ${enquiry.firstName} ${enquiry.middleName} ${enquiry.lastName} ${newElement}
                </a><br>
                <button id="add_followup_${enquiry._id}" name="${enquiry._id}" class="button-55"><i class="fa fa-plus" aria-hidden="true"></i> Followup</button>
                </td>
                <td class="remove-borders">
                ${res}
                </td>
                ${dob_column_data}${religion_column_data}${caste_column_data}${aadhaarNo_column_data}${motherName_column_data}${fatherOccupation_column_data}${motherTongue_column_data}${address_column_data}${contact_column_data}${category_column_data}${branch_column_data}${area_column_data}${courses_column_data}${takenby_column_data}${created_column_data}${updated_column_data}
            </tr>`;
        })
        listOfFollowupButtons.push(`#add_followup_${enquiry._id}`)
        // console.log(admissionButton);
        // console.log(admissionButton.PromiseResult);
        // console.log(typeof(admissionButton));

        // ${enquiry.admission ? 
        //     `<span style="color: #63D471;font-size:13px;"><b>Done</b></span><br>
        //     <button class="btn p-1 pl-2" id="check_btn">Check <img src="/images/enquiries/check.png"></button>`: 
        //     `<span style="color: #641610;font-size:13px;"><b>Not done</b></span><br>
        //     <a href="/sdp/manager/addstudent?enquiry=${enquiry._id}">
        //     <button class="btn p-1 pl-2" id="convert_btn">Convert <img src="/images/enquiries/convert.png"></button>
        //     </a>`}
        
        });
        if (data.length == 0) {
            tbody_enquiries += `
            <tr>
                <td>No data match your filter</td>
            </tr>`;
        }
    var checkData = setInterval(() => {
        if (data.length === countOfEnq) {
            
            $('#table_enquiries tbody').html(tbody_enquiries)
            clearInterval(checkData);
            listOfFollowupButtons.forEach(button => {
                $(button).click((e)=>{
                    // console.log('add followup clicked');
                    // console.log(e.target.attributes.name.value);
                    addFollowup(e.target.attributes.name.value)
                })
            });
            // document.getElementById('add_followup').addEventListener('click',()=>{
            //     alert('clicked now')
            // })
        }
    }, 1000);
}

async function createAdmissionButton(enquiry){
    var admissionButton = ``
    if (enquiry.admission) {
        // console.log(enquiry._id);
        // Get enquiry student information
        const fetchData = await $.ajax({
                url: `/sdp/students?enquiry=${enquiry._id}`,
                method: 'get',
                success: function (response) {
                    if (response.success) {
                        // console.log(response.data);
                        admissionButton = `<span style="color: #63D471;font-size:13px;"><b>Done</b></span><br>
                        <a href="/sdp/manager/viewstudent?student=${response.data[0]._id}" target="_blank">
                        <button class="btn p-1 pl-2" id="check_btn">Check <img src="/images/enquiries/check.png"></button>
                        </a>`
                    }
                }
            })
            return admissionButton
    } else {
        return admissionButton = `<span style="color: #641610;font-size:13px;"><b>Not done</b></span><br>
        <a href="/sdp/manager/addstudent?enquiry=${enquiry._id}">
        <button class="btn p-1 pl-2" id="convert_btn">Convert <img src="/images/enquiries/convert.png"></button>
        </a>`
    }
}

function getFilterCount() {
    let enquiries_filter_count = 0
    var filtered_branches = all_enquiries_data
    // console.log(filtered_branches);
    let filter_enquiries_enquiry_staff = getCookie('filter_enquiries_enquiry_staff');
    let filter_enquiries_branch = getCookie('filter_enquiries_branch');
    let filter_enquiries_enquiry_course = getCookie('filter_enquiries_enquiry_course');
    let filter_enquiry_date_start = getCookie('filter_enquiry_date_start');
    let filter_enquiry_date_end = getCookie('filter_enquiry_date_end');
    
    if (filter_enquiries_enquiry_staff) {
        enquiries_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        // filtered_branches = filtered_branches.filter(
        //     eachObj => eachObj.takenby ? eachObj.takenby.name : eachObj.takenby === filter_enquiries_enquiry_staff);
        // console.log(filtered_branches)
        // filtered_branches.forEach(eachObj => {
        //     console.log(eachObj.takenby);
        //     console.log(filter_enquiries_enquiry_staff);
        //     let soe = eachObj.takenby ? eachObj.takenby.name : eachObj.takenby
        //     console.log(soe === filter_enquiries_enquiry_staff);
        // });
        for (let i = 0; i < filtered_branches.length; i++) {
            const eachObj = filtered_branches[i];
            let soe = eachObj.takenby ? eachObj.takenby.name : eachObj.takenby
            // console.log(soe);
            // console.log(filter_enquiries_enquiry_staff);
            if (soe != filter_enquiries_enquiry_staff) {
                // console.log('slice it');
                filtered_branches.splice(i, 1)
            }
        }
        // console.log(filtered_branches)
    }
    if(filter_enquiries_branch){
        enquiries_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        filtered_branches = filtered_branches.filter(
            eachObj => eachObj.branch.name === filter_enquiries_branch);
        // console.log(filtered_branches)
    }
    if (filter_enquiries_enquiry_course && filtered_branches) {
        var new_filtered_data = []
        enquiries_filter_count++

        for (let i = 0; i < filtered_branches.length; i++) {
            const eachObj = filtered_branches[i];
            let courses = eachObj.courses.split(',')
            // console.log(courses);
            // console.log(filter_enquiries_enquiry_course);
            courses.forEach(course => {
                
                if (course == filter_enquiries_enquiry_course) {
                    // console.log('slice them');
                    new_filtered_data.push(filtered_branches.splice(i, 1))
                }
            });
        }
        if (new_filtered_data) {
            filtered_branches = new_filtered_data[0]  
        }else{
            filtered_branches = []
        }
        // console.log(filtered_branches);
    }

    // Filter datewise
    if(filter_enquiry_date_start || filter_enquiry_date_end){
        enquiries_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        // filtered_branches = filtered_branches.filter(
        //     eachObj => eachObj.fees === parseInt(filter_courses_fees));
        // Ref: https://sebhastian.com/javascript-filter-array-multiple-values/
        if (filter_enquiry_date_end == 0) {
            filtered_branches = filtered_branches.filter((eachObj) => {
                // console.log(eachObj.createdAt >= filter_enquiry_date_start);
                return eachObj.createdAt >= filter_enquiry_date_start;
            });
        } else {
            filtered_branches = filtered_branches.filter((eachObj) => {
                let date = eachObj.createdAt.slice(0,10)
                // console.log('Date '+date);
                // console.log('Start '+filter_enquiry_date_start);
                // console.log('End '+filter_enquiry_date_end);
                // console.log('After '+date >= filter_enquiry_date_start);
                // console.log('Before '+date <= filter_enquiry_date_end);
                return date >= filter_enquiry_date_start && date <= filter_enquiry_date_end;
            });
        }
        // console.log(filtered_branches)
    }

    $('#applied_filters').html(enquiries_filter_count)
    populateTable(filtered_branches, cols)
}
// getFilterCount()

var users_list;
function loadUsersList() {

    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#enquiryuser').text(response.data)
                var filter_enquiries_enquiry_staff_cook = getCookie('filter_enquiries_enquiry_staff')

                if (response.data.length == 0) {
                    users_list += `<option value="">Staff List is empty</option>`;
                } else {
                    users_list = `<option value="">Select Staff Name</option>`;
                    response.data.forEach(user => {

                        if (filter_enquiries_enquiry_staff_cook == user.name) {
                            users_list += `<option value="${user.name}" selected>${user.name} (${user.branch}-${user.role})</option>`;
                        } else {
                            users_list += `<option value="${user.name}">${user.name} (${user.branch}-${user.role})</option>`;
                        }
                    });
                }

                // $('#filter_enquiries_enquiry_staff').html(users_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Branches Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_users tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch users list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_users tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
    }

        }
    });

}
// loadUsersList()

var courses_list;
function loadCoursesList() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#enquiryuser').text(response.data)
                var filter_enquiries_enquiry_course_cook = getCookie('filter_enquiries_enquiry_course')

                if (response.data.length == 0) {
                    courses_list += `<option value="">Course List is empty</option>`;
                } else {
                    courses_list = `<option value="">Select Course Name</option>`;
                    response.data.forEach(course => {

                        if (filter_enquiries_enquiry_course_cook == course._id) {
                            courses_list += `<option value="${course._id}" selected>${course.name}</option>`;
                        } else {
                            courses_list += `<option value="${course._id}">${course.name}</option>`;
                        }
                    });
                }

                // $('#filter_enquiries_enquiry_course').html(courses_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Branches Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_courses tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_courses tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
    }

        }
    });

}
// loadCoursesList()


function callAllFunctions() {

    loadUsersList()
    loadCoursesList()
}

$('#filter-btn').click(() => {

    var filter_enquiry_date_start_cook = getCookie('filter_enquiry_date_start')
    var filter_enquiry_date_end_cook = getCookie('filter_enquiry_date_end')
    Swal.fire({
        title: "<div>Filter Enquiries</div>", 
        html: `<div id="filt_card">
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter Enquiries by staff -</b>
            <form class="d-flex align-items-center">
                <select name="filter_enquiries_enquiry_staff" id="filter_enquiries_enquiry_staff" class="w-75 p-1">
                    ${users_list}
                </select>
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter Enquiries by course -</b>
            <form class="d-flex align-items-center">
                <select name="filter_enquiries_enquiry_course" id="filter_enquiries_enquiry_course" class="w-75 p-1">
                    ${courses_list}
                </select>
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter Enquiries by date between: -</b>
            <form class="d-flex align-items-center">
            <input class="col-5 p-1" type="date" name="filter_enquiry_date_start" value="${filter_enquiry_date_start_cook}" id="filter_enquiry_date_start" />
            &nbsp;&nbsp; to &nbsp;&nbsp;
            <input class="col-5 p-1" type="date" name="filter_enquiry_date_end" value="${filter_enquiry_date_end_cook}" id="filter_enquiry_date_end" />
            </form>
        </div>
        </div>`,  
        confirmButtonText: "Apply Filter", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        showDenyButton: true,
        denyButtonText: "Clear all", 
        // denyButtonColor: '#0b6fad',
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            // Load all data
            var filtered_branches = all_enquiries_data
            // console.log(filtered_branches);
            // Filter enquiry staff
            let filter_enquiries_enquiry_staff = $("#filter_enquiries_enquiry_staff").val()
            // alert(filter_enquiries_enquiry_staff);
            setCookie('filter_enquiries_enquiry_staff', filter_enquiries_enquiry_staff, 7)

            // Filter enquiry course
            let filter_enquiries_enquiry_course = $("#filter_enquiries_enquiry_course").val()
            // alert(filter_enquiries_enquiry_course);
            setCookie('filter_enquiries_enquiry_course', filter_enquiries_enquiry_course, 7)

            // Date filter - start date
            var filter_enquiry_date_start = $("#filter_enquiry_date_start").val()
            // console.log('filter_enquiry_date_start = '+filter_enquiry_date_start);
            if (filter_enquiry_date_start == '' || filter_enquiry_date_start == null || filter_enquiry_date_start == undefined) {
                filter_enquiry_date_start = 0
            }
            setCookie('filter_enquiry_date_start',filter_enquiry_date_start,7)

            // Date filter - end date
            var filter_enquiry_date_end = $("#filter_enquiry_date_end").val()
            // console.log('filter_enquiry_date_end = '+filter_enquiry_date_end);
            if (filter_enquiry_date_end == '' || filter_enquiry_date_end == null || filter_enquiry_date_end == undefined) {
                filter_enquiry_date_end = 0
            }
            setCookie('filter_enquiry_date_end',filter_enquiry_date_end,7)
            
            // console.log(filtered_branches[0].createdAt.slice(0,10));
            // console.log(filtered_branches[0].createdAt);
            // console.log(filtered_branches[0].createdAt);
            // console.log('Backend date = ' + new Date(filtered_branches[0].createdAt));
            // // console.log('Backend date = ' + new Date(filtered_branches[0].createdAt).toLocaleDateString()());
            // console.log(filter_enquiry_date_start);
            // console.log('User input = ' + new Date(filter_enquiry_date_start));
            // // console.log('User input = ' + new Date(filter_enquiry_date_start).toLocaleDateString()());
            // console.log('-------------------------------');
            // console.log(filtered_branches[0].createdAt < filter_enquiry_date_start);
            // console.log(filtered_branches[0].createdAt == filter_enquiry_date_start);
            // console.log(filtered_branches[0].createdAt > filter_enquiry_date_start);

            // if (filter_enquiries_enquiry_staff) {
            //     // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
            //     filtered_branches = filtered_branches.filter(
            //         eachObj => eachObj.takenby ? eachObj.takenby.name : eachObj.takenby === filter_enquiries_enquiry_staff);
            //     // console.log(filtered_branches)
            // }
                // console.log(filtered_branches)
            if (filter_enquiries_enquiry_staff) {

                for (let i = 0; i < filtered_branches.length; i++) {
                    const eachObj = filtered_branches[i];
                    let soe = eachObj.takenby ? eachObj.takenby.name : eachObj.takenby
                    // console.log(soe);
                    // console.log(filter_enquiries_enquiry_staff);
                    if (soe != filter_enquiries_enquiry_staff) {
                        // console.log('slice them');
                        filtered_branches.splice(i, 1)
                    }
                }
            }
            // console.log(filtered_branches)
            // if(filter_enquiries_branch){
            //     // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
            //     filtered_branches = filtered_branches.filter(
            //         eachObj => eachObj.branch.name === filter_enquiries_branch);
            //     // console.log(filtered_branches)
            // }
            // console.log(filtered_branches);
            var new_filtered_data = []
            if (filter_enquiries_enquiry_course) {

                for (let i = 0; i < filtered_branches.length; i++) {
                    const eachObj = filtered_branches[i];
                    let courses = eachObj.courses.split(',')
                    // console.log(courses);
                    // console.log(filter_enquiries_enquiry_course);
                    courses.forEach(course => {
                        
                        if (course == filter_enquiries_enquiry_course) {
                            // console.log('slice them');
                            new_filtered_data.push(filtered_branches.splice(i, 1))
                        }
                    });
                }
                if (new_filtered_data) {
                    filtered_branches = new_filtered_data[0]  
                }
            }
            // console.log(filtered_branches);

            // Filter datewise
            if(filter_enquiry_date_start || filter_enquiry_date_end){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                // filtered_branches = filtered_branches.filter(
                //     eachObj => eachObj.fees === parseInt(filter_courses_fees));
                // Ref: https://sebhastian.com/javascript-filter-array-multiple-values/
                if (filter_enquiry_date_end == 0) {
                    filtered_branches = filtered_branches.filter((eachObj) => {
                        // console.log(eachObj.createdAt >= filter_enquiry_date_start);
                        return eachObj.createdAt >= filter_enquiry_date_start;
                    });
                } else {
                    filtered_branches = filtered_branches.filter((eachObj) => {
                        let date = eachObj.createdAt.slice(0,10)
                        // console.log('Date '+date);
                        // console.log('Start '+filter_enquiry_date_start);
                        // console.log('End '+filter_enquiry_date_end);
                        // console.log('After '+date >= filter_enquiry_date_start);
                        // console.log('Before '+date <= filter_enquiry_date_end);
                        return date >= filter_enquiry_date_start && date <= filter_enquiry_date_end;
                    });
                }
                // console.log(filtered_branches)
            }
            loadAllEnquiries()
            // populateTable(filtered_branches, cols)
            getFilterCount()
            callAllFunctions()
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(all_enquiries_data);
            
        }
        if (result.isDenied) {
            // alert('Clear')
            var filtered_branches = all_enquiries_data
            setCookie('filter_enquiries_enquiry_staff','',7)
            setCookie('filter_enquiries_branch','',7)
            setCookie('filter_enquiries_enquiry_course','',7)
            setCookie('filter_enquiry_date_start','',7)
            setCookie('filter_enquiry_date_end','',7)
            loadAllEnquiries()
            populateTable(filtered_branches, cols)
            getFilterCount()
            callAllFunctions()
        }
    })
})

// Modify columns
// var cols = {dob: false, religion: false, caste: false, aadhaarNo: false, motherName: false, fatherOccupation: false, motherTongue: false, address: false, contact: false, qualification: false, schoolOrCollegeName: false, classOrTuitionName: false, category: false, branch: false, 
//     created: false, updated: false}
function modify_columns() {
    var enqdob_selected_cook = getCookie('enqdob_selected') ? 'checked' : ''
    var enqreligion_selected_cook = getCookie('enqreligion_selected') ? 'checked' : ''
    var enqcaste_selected_cook = getCookie('enqcaste_selected') ? 'checked' : ''
    var enqaadhaarNo_selected_cook = getCookie('enqaadhaarNo_selected') ? 'checked' : ''
    var enqmotherName_selected_cook = getCookie('enqmotherName_selected') ? 'checked' : ''
    var enqfatherOccupation_selected_cook = getCookie('enqfatherOccupation_selected') ? 'checked' : ''
    var enqmotherTongue_selected_cook = getCookie('enqmotherTongue_selected') ? 'checked' : ''
    var enqaddress_selected_cook = getCookie('enqaddress_selected') ? 'checked' : ''
    var enqcontact_selected_cook = getCookie('enqcontact_selected') ? 'checked' : ''
    var enqcategory_selected_cook = getCookie('enqcategory_selected') ? 'checked' : ''
    var enqbranch_selected_cook = getCookie('enqbranch_selected') ? 'checked' : ''
    var createdenq_selected_cook = getCookie('createdenq_selected') ? 'checked' : ''
    var updatedenq_selected_cook = getCookie('updatedenq_selected') ? 'checked' : ''
    // New enquiry fields
    var enqarea_selected_cook = getCookie('enqarea_selected') ? 'checked' : ''
    var enqcourses_selected_cook = getCookie('enqcourses_selected') ? 'checked' : ''
    var enqtakenby_selected_cook = getCookie('enqtakenby_selected') ? 'checked' : ''

    cols.enqdob = getCookie('enqdob_selected')
    cols.enqreligion = getCookie('enqreligion_selected')
    cols.enqcaste = getCookie('enqcaste_selected')
    cols.enqaadhaarNo = getCookie('enqaadhaarNo_selected')
    cols.enqmotherName = getCookie('enqmotherName_selected')
    cols.enqfatherOccupation = getCookie('enqfatherOccupation_selected')
    cols.enqmotherTongue = getCookie('enqmotherTongue_selected')
    cols.enqaddress = getCookie('enqaddress_selected')
    cols.enqcontact = getCookie('enqcontact_selected')
    cols.enqcategory = getCookie('enqcategory_selected')
    cols.enqbranch = getCookie('enqbranch_selected')
    cols.created = getCookie('createdenq_selected')
    cols.updated = getCookie('updatedenq_selected')
    // New enquiry fields
    cols.enqarea = getCookie('enqarea_selected')
    cols.enqcourses = getCookie('enqcourses_selected')
    cols.enqtakenby = getCookie('enqtakenby_selected')

    // Refresh data
    // populateTable(all_enquiries_data, cols)
    getFilterCount()
    callAllFunctions()

    Swal.fire({
        title: "<div>Change Columns</div>", 
        html: `
        <div id="cols_card" class="col card">
            <b class="row">Select columns which you want to display -</b>
            <form>
                <label class="row"><input type="checkbox" checked disabled name="name" value="name_selected" id="name_selected" />&nbsp; Name</label>
                <label class="row"><input type="checkbox" checked disabled name="admission" value="admission_selected" id="admission_selected" />&nbsp; Admission</label>
                <label class="row"><input type="checkbox" ${enqdob_selected_cook} name="enqdob" value="enqdob_selected" id="enqdob_selected" />&nbsp; DOB</label>
                <label class="row"><input type="checkbox" ${enqreligion_selected_cook} name="enqreligion" value="enqreligion_selected" id="enqreligion_selected" />&nbsp; Religion</label>
                <label class="row"><input type="checkbox" ${enqcaste_selected_cook} name="enqcaste" value="enqcaste_selected" id="enqcaste_selected" />&nbsp; Caste</label>
                <label class="row"><input type="checkbox" ${enqaadhaarNo_selected_cook} name="enqaadhaarNo" value="enqaadhaarNo_selected" id="enqaadhaarNo_selected" />&nbsp; Aadhaar No</label>
                <label class="row"><input type="checkbox" ${enqmotherName_selected_cook} name="enqmotherName" value="enqmotherName_selected" id="enqmotherName_selected" />&nbsp; Mother Name</label>
                <label class="row"><input type="checkbox" ${enqfatherOccupation_selected_cook} name="enqfatherOccupation" value="enqfatherOccupation_selected" id="enqfatherOccupation_selected" />&nbsp; Father Occupation</label>
                <label class="row"><input type="checkbox" ${enqmotherTongue_selected_cook} name="enqmotherTongue" value="enqmotherTongue_selected" id="enqmotherTongue_selected" />&nbsp; Mother Tongue</label>
                <label class="row"><input type="checkbox" ${enqaddress_selected_cook} name="enqaddress" value="enqaddress_selected" id="enqaddress_selected" />&nbsp; Address</label>
                <label class="row"><input type="checkbox" ${enqarea_selected_cook} name="enqarea" value="enqarea_selected" id="enqarea_selected" />&nbsp; Area</label>
                <label class="row"><input type="checkbox" ${enqcontact_selected_cook} name="enqcontact" value="enqcontact_selected" id="enqcontact_selected" />&nbsp; Contact</label>
                <label class="row"><input type="checkbox" ${enqcategory_selected_cook} name="enqcategory" value="enqcategory_selected" id="enqcategory_selected" />&nbsp; Category</label>
                <label class="row"><input type="checkbox" ${enqbranch_selected_cook} name="enqbranch" value="enqbranch_selected" id="enqbranch_selected" />&nbsp; Branch</label>
                <label class="row"><input type="checkbox" ${enqcourses_selected_cook} name="enqcourses" value="enqcourses_selected" id="enqcourses_selected" />&nbsp; Courses</label>
                <label class="row"><input type="checkbox" ${enqtakenby_selected_cook} name="enqtakenby" value="enqtakenby_selected" id="enqtakenby_selected" />&nbsp; Enquiry Taken By</label>
                <label class="row"><input type="checkbox" ${createdenq_selected_cook} name="createdat" value="createdenq_selected" id="createdenq_selected" />&nbsp; Created at Date&Time</label>
                <label class="row"><input type="checkbox" ${updatedenq_selected_cook} name="updatedat" value="updatedenq_selected" id="updatedenq_selected" />&nbsp; Updated at Date&Time</label>
            </form>
        </div>`,  
        confirmButtonText: "Submit",
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            let enqdob_col = $("#enqdob_selected").prop("checked")
            let enqreligion_col = $("#enqreligion_selected").prop("checked")
            let enqcaste_col = $("#enqcaste_selected").prop("checked")
            let enqaadhaarNo_col = $("#enqaadhaarNo_selected").prop("checked")
            let enqmotherName_col = $("#enqmotherName_selected").prop("checked")
            let enqfatherOccupation_col = $("#enqfatherOccupation_selected").prop("checked")
            let enqmotherTongue_col = $("#enqmotherTongue_selected").prop("checked")
            let enqaddress_col = $("#enqaddress_selected").prop("checked")
            let enqcontact_col = $("#enqcontact_selected").prop("checked")
            let enqcategory_col = $("#enqcategory_selected").prop("checked")
            let enqbranch_col = $("#enqbranch_selected").prop("checked")
            let created_col = $("#createdenq_selected").prop("checked")
            let updated_col = $("#updatedenq_selected").prop("checked")
            // New enquiry fields
            let area_col = $("#enqarea_selected").prop("checked")
            let courses_col = $("#enqcourses_selected").prop("checked")
            let takenby_col = $("#enqtakenby_selected").prop("checked")
            setCookie('enqdob_selected',enqdob_col,7)
            setCookie('enqreligion_selected',enqreligion_col,7)
            setCookie('enqcaste_selected',enqcaste_col,7)
            setCookie('enqaadhaarNo_selected',enqaadhaarNo_col,7)
            setCookie('enqmotherName_selected',enqmotherName_col,7)
            setCookie('enqfatherOccupation_selected',enqfatherOccupation_col,7)
            setCookie('enqmotherTongue_selected',enqmotherTongue_col,7)
            setCookie('enqaddress_selected',enqaddress_col,7)
            setCookie('enqcontact_selected',enqcontact_col,7)
            setCookie('enqcategory_selected',enqcategory_col,7)
            setCookie('enqbranch_selected',enqbranch_col,7)
            setCookie('createdenq_selected',created_col,7)
            setCookie('updatedenq_selected',updated_col,7)
            // New enquiry fields
            setCookie('enqarea_selected',area_col,7)
            setCookie('enqcourses_selected',courses_col,7)
            setCookie('enqtakenby_selected',takenby_col,7)
            
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(enqdob_col);
            cols.enqdob = enqdob_col
            cols.enqreligion = enqreligion_col
            cols.enqcaste = enqcaste_col
            cols.enqaadhaarNo = enqaadhaarNo_col
            cols.enqmotherName = enqmotherName_col
            cols.enqfatherOccupation = enqfatherOccupation_col
            cols.enqmotherTongue = enqmotherTongue_col
            cols.enqaddress = enqaddress_col
            cols.enqcontact = enqcontact_col
            cols.enqcategory = enqcategory_col
            cols.enqbranch = enqbranch_col
            cols.created = created_col
            cols.updated = updated_col
            // New enquiry fields
            cols.enqarea = area_col
            cols.enqcourses = courses_col
            cols.enqtakenby = takenby_col
            // populateTable(all_enquiries_data, cols)
            getFilterCount()
            callAllFunctions()
        }
    })
}
$('#modify-cols-btn').click(()=>{
    modify_columns()
})
