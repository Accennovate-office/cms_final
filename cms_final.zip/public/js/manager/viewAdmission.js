
$('#sidebar-admissions').trigger("click")
$('#sidebar-admissions,#sidebar-admissions-view').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['admission'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/manager/admissions')
})

function loadAdmissionsList() {

    $.ajax({
        url: '/sdp/admissions',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var admissions_list;
                $('#viewadmission #admission').text(response.data)

                if (response.data.length == 0) {
                    admissions_list += `<option value="">Admission List is empty</option>`;
                } else {
                    admissions_list = `<option value="">Select Admission Name</option>`;
                    response.data.forEach(admission => {

                        if (admission._id == selected) {

                            admissions_list += `
                            <option selected value="${admission._id}">${admission.student.firstName} ${admission.student.lastName} > ${admission.course.name} Admission</option>`;

                        } else {

                            admissions_list += `
                            <option value="${admission._id}">${admission.student.firstName} ${admission.student.lastName} > ${admission.course.name} Admission</option>`;

                        }

                    });
                }

                $('#viewadmission #admission').html(admissions_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Admissions Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_admissions tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch admissions list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_admissions tbody .col').html(errorMsg)
                $('#no-admission-selected').html(errorMsg)
            }

        }
    });

}
loadAdmissionsList()

function getAdmissionDetails() {

    const selectAdmission = $('#admission').val() ? $('#admission').val() : selected
    // console.log(selectAdmission);
    if (selectAdmission == '') {
        $('#no-admission-selected').css('display', 'block')
        $('#admission-selected').css('display', 'none')
    } else {

        $('#no-admission-selected').css('display', 'none')
        $('#admission-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/admissions/${selectAdmission}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewadmission #admission-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var enrollpayEnglishIST = new Date(response.data.enrollmentPaymentDate).toLocaleDateString("en-IN", date_options)
                    var admissionEnglishIST = new Date(response.data.admissionDate).toLocaleDateString("en-IN", date_options)
                    var installmentEnglishIST = new Date(response.data.installmentdate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }
                    // Installment type
                    var installmentType;
                    if (response.data.installment) {
                        installmentType = 'Installment'
                    } else if (response.data.installment == false) {
                        installmentType = 'One Time'
                    }

                    var admission_data = `
                    <div class="d-flex mb-3 pl-1">
                        <img src="/images/admissions/admission2.png" width="70" alt="">
                        <div align="left" class="ml-4 pt-3">
                            <h2>Admission Details</h2>
                            <!-- <small>Admission Details</small> -->
                        </div>
                    </div>

                    <!-- Basic Details -->
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Basic Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <small>Student Full Name</small>
                            </div>
                            <h4>${response.data.student.firstName} ${response.data.student.middleName}
                                ${response.data.student.lastName}</h4>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Admission Date</small>
                            </div>
                            <h4>${admissionEnglishIST}</h4>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-book" aria-hidden="true"></i>
                                <small>Course Name</small>
                            </div>
                            <h4>${response.data.course.name}</h4>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-rupee-sign" aria-hidden="true"></i>
                                <small>Course Fees in ₹</small>
                            </div>
                            <h4>${response.data.fees}</h4>
                        </div>
                    </div>

                    <!-- Admission Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Admission Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user-clock" aria-hidden="true"></i>
                                <small>Student Batch Time</small>
                            </div>
                            <h4>${response.data.batch ? response.data.batch : 'Not added'}</h4>
                        </div>
                        <div class="mt-0">
                            <div align="left" class="d-flex">
                                <i class="fas fa-user-tie" aria-hidden="true"></i>
                                <small>Teacher Allocated</small>
                            </div>
                            <h5 class="d-flex">${response.data.teacher ? response.data.teacher.name : 'Not added'}</h5>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-rupee-sign" aria-hidden="true"></i>
                                <small>Payment Type</small>
                            </div>
                            <h4>${installmentType ? installmentType : 'Not added'}</h4>
                        </div>
                        <div align="left" class="mt-0" id="installmentDate">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-calendar-day"></i>
                                <small>Installment date</small>
                            </div>
                            <h4>${installmentEnglishIST ? installmentEnglishIST : 'Not added'}</h4>
                        </div>
                    </div>

                    <!-- Enrollment Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Enrollment Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div align="left" class="d-flex justify-content-between mt-2">
                        <div class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-id-card" aria-hidden="true"></i>
                                <small>Enrollment Number</small>
                            </div>
                            <h4>${response.data.enrollmentNo ? response.data.enrollmentNo : 'Not added'}</h4>
                        </div>
                        <div class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Enrollment Month</small>
                            </div>
                            <h4>${response.data.enrollmentMonth ? response.data.enrollmentMonth : 'Not added'}</h4>
                        </div>
                    </div>
                    <div align="left" class="d-flex justify-content-between mt-2">
                        <div class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Enrollment Payment Date</small>
                            </div>
                            <h5>${enrollpayEnglishIST ? enrollpayEnglishIST : 'Not added'}</h5>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                            <i class="fa fa-id-card" aria-hidden="true"></i>
                                <small>Roll Number</small>
                            </div>
                            <h4>${response.data.rollNo ? response.data.rollNo : 'Not added'}</h4>
                        </div>
                    </div>


                    <div class="d-flex justify-content-between mt-5">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user-edit" aria-hidden="true"></i>
                                <small>Created By</small>
                            </div>
                            <div>${response.data.createdBy.name} (${response.data.createdBy.role})</div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-1">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewadmission #admission-selected').html(admission_data)

                    if (!response.data.installment) {
                        $('#installmentDate').fadeOut()
                    }

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Admission Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_admissions tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-admission-card button').attr('disabled', true)
                    $('#admission-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-admission-card button').attr('disabled', true)
                    $('#admission-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch admissions list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_admissions tbody .col').html(errorMsg)
                    $('#admission-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-admission-selected').css('display', 'block') // block
$('#admission-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getAdmissionDetails()
}
$('#admission').change(() => {

    getAdmissionDetails()

})