import { setCookie, getCookie } from "../services/cookie.js";

$('#no-teacher-available').fadeOut()
$('#table_teachers,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

var all_teachers_data
var total_count
var cols 
// = {description: false, weeks: false, fees: false, startingAt: false, created: false, updated: false}

$('#sidebar-teachers').trigger("click")
$('#sidebar-teachers,#sidebar-teachers-all').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

$('#new-teacher-btn').click(() => {
    document.location.replace('/sdp/manager/addteacher');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTeachers(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTeachers(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTeachers(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTeachers(limit, page + 1)
})
// Page navigator End

function loadAllTeachers(limit = 5, page = 1) {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-teacher-available').fadeOut()
    $('#table_teachers,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/teachers?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                all_teachers_data = response.alldata
                total_count = response.alldatacount
                $('#error,#loading').css('display', 'none')

                // if (response.data.length == 0) {
                //     var noTeacher = `
                //     <img src="/images/teachers/noteacher.png" width="60" alt="">
                //     <div class="h3 mt-2">
                //         <span class="font-weight-bold">Teacher List is empty</span> <br><br>
                //         <span class="h5">Click&nbsp;
                //             <span>
                //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                //                     Teacher</button>
                //             </span>
                //             &nbsp;button at top left to get started
                //         </span>
                //     </div>`
                //     $('#no-teacher-available').fadeIn()
                //     $('#no-teacher-available').html(noTeacher)

                // } else {
                //     $('#table_teachers').fadeIn()
                //     $('#view_note').fadeIn()
                //     var tbody_teachers;
                //     // var newelementCount = 0;
                //     response.data.forEach(teacher => {

                //         // var utcCreatedDate = new Date(teacher.createdAt);
                //         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                //         // var s = new Date(teacher.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                //         var createdHindiIST = new Date(teacher.createdAt).toLocaleDateString("hi-IN", options)
                //         var createdEnglishIST = new Date(teacher.createdAt).toLocaleDateString("en-IN", options)

                //         // For join Date
                //         var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var joiningEnglishIST = new Date(teacher.joiningDate).toLocaleDateString("en-IN", dateOptions)
                //         // var x = new Date(teacher.createdAt).getTimezoneOffset();
                //         //Converted UTC to local(IST, etc.,,)
                //         // console.log(utcCreatedDate.toUTCString());

                //         // Check date
                //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var createdCheck = new Date(teacher.createdAt).toLocaleDateString("en-IN", optionsCheck)
                //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)
                //         var newElement;
                //         if (createdCheck === today) {
                //             newElement = `<span class="badge badge-noti">New</span>`
                //             // newelementCount += 1
                //         } else {
                //             newElement = ''
                //         }
                //         // if (newelementCount > 0) {
                //         //     $('#sidebar-teachers-all').html(`All Teachers <span class="badge badge-noti">${newelementCount}</span>`)
                //         // }

                //         var updateValue = teacher.updatedAt ? teacher.updatedAt : 'Not updated'
                //         // Converting update value from UTC to GMT
                //         if (updateValue != 'Not updated') {
                //             // var utcUpdatedDate = new Date(updateValue);
                //             // updateValue = utcUpdatedDate.toUTCString()

                //             // Hindi Date time
                //             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                //             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                //         }

                //         tbody_teachers += `
                //         <tr>
                //             <td>
                //                 ${teacher.user.name} ${newElement}
                //             </td>
                //             <td>${teacher.user.branch}</td>
                //             <td>${joiningEnglishIST}</td>
                //             <td>${teacher.phone}</td>
                //             <td>${createdEnglishIST}</td>
                //             <td>${updateValue}</td>
                //         </tr>`;
                //     });
                //     $('#table_teachers tbody').html(tbody_teachers)

                // }

                if (response.data.length == 0 && response.total_count == 0) {
                    var noTeacher = `
                    <img src="/images/teachers/noteacher.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Teacher List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Teacher</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-teacher-available').fadeIn()
                    $('#no-teacher-available').html(noTeacher)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var noteacher = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-teacher-available').fadeIn()
                    $('#no-teacher-available').html(noteacher)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        // console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var noteacher = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-teacher-available').fadeIn()
                        $('#no-teacher-available').html(noteacher)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        // console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var teacher = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-teacher-available').fadeIn()
                        $('#no-teacher-available').html(teacher)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_teachers,#myInput').fadeIn()
                        

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Teachers Fetched Successfully',
                    timer: 5000,
                    showConfirmButton: false
                });

                // Refresh data
                // populateTable(all_teachers_data, cols)
                getFilterCount()
                callAllFunctions()
                // setTimeout(() => {
                //     modify_columns()
                // }, 1500);

            } else {

                $('#loading').css('display', 'none');
                $('#table_teachers tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-teacher-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-teacher-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch teachers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_teachers tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllTeachers()

// Feb 2023 update
function populateTable(data, cols) {
                        var tbody_teachers;
    // console.log(data);
    
    $('#teacher-entries').html(`Showing ${data.length} of ${total_count} entries`)
    $("#teacher-entries").addClass("flash_colours");
    setTimeout(() => {
        $("#teacher-entries").removeClass("flash_colours");
    }, 3000);
    // var newelementCount = 0;
    data.forEach(teacher => {

        // var utcCreatedDate = new Date(teacher.createdAt);
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

        var createdHindiIST = new Date(teacher.createdAt).toLocaleDateString("hi-IN", options)
        var createdEnglishIST = new Date(teacher.createdAt).toLocaleDateString("en-IN", options)

        // Check date
        optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var createdCheck = new Date(teacher.createdAt).toLocaleDateString("en-IN", optionsCheck)
        var today = new Date().toLocaleDateString("en-IN", optionsCheck)

        var teacherStartingAt = new Date(teacher.startingAt).toLocaleDateString("en-IN", optionsCheck)
        var newElement;
        if (createdCheck === today) {
            newElement = `<span class="badge badge-noti">New</span>`
            // newelementCount += 1
        } else {
            newElement = ''
        }
        // if (newelementCount > 0) {
        //     $('#sidebar-teachers-all').html(`All Teachers <span class="badge badge-noti">${newelementCount}</span>`)
        // }

        // var updateValue = teacher.updatedAt ? teacher.updatedAt : 'Not updated'
        // // Converting update value from UTC to GMT
        // if (updateValue != 'Not updated') {
        //     // var utcUpdatedDate = new Date(updateValue);
        //     // updateValue = utcUpdatedDate.toUTCString()

        //     // Hindi Date time
        //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
        //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
        // }

        // For join Date
        var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var joiningEnglishIST = new Date(teacher.joiningDate).toLocaleDateString("en-IN", dateOptions)

        var updateValue = teacher.updatedAt ? teacher.updatedAt : 'Not updated'
        // Converting update value from UTC to GMT
        if (updateValue != 'Not updated') {
            // var utcUpdatedDate = new Date(updateValue);
            // updateValue = utcUpdatedDate.toUTCString()

            // Hindi Date time
            // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
            updateValue = '#Updated ' + new Date(updateValue).toLocaleDateString("en-IN", options)
        }

        tbody_teachers += `
        <tr id="${teacher._id}">
            <td>
                ${teacher.user.name} ${newElement}
            </td>
            <td>${teacher.user.branch}</td>
            <td>${joiningEnglishIST}</td>
            <td>${teacher.phone}</td>
            <td>${createdEnglishIST}</td>
            <td>${updateValue}</td>
            <td>
                <div class="hover-container">
                    <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                    <aside class="hover-popup">
                        <a align="center" class="p-1 fontt" href="/sdp/manager/viewteacher?teacher=${teacher.user._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                        <a align="center" class="p-1 fontt text-success" href="/sdp/manager/editteacher?teacher=${teacher.user._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                        <a align="center" class="p-1 fontt text-danger" href="/sdp/manager/deleteteacher?teacher=${teacher.user._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                    </aside>
                </div>
            </td>
        </tr>`;
    });
    if (data.length == 0) {
        tbody_teachers += `
        <tr>
            <td colspan="6">No data match your filter</td>
            <td></td>
        </tr>`;
    }
                        $('#table_teachers tbody').html(tbody_teachers)
    // ------------------ NEW CODE ---------------------
    // var tbody_courses;
    // // Columns add
    // var description_column_head = cols.description ? `<th id="description_thead" class="col col-3 remove-borders">Description</th>` : ``;
    // var weeks_column_head = cols.weeks ? `<th id="weeks_thead" class="col col-1 remove-borders">Duration (weeks)</th>` : ``;
    // var fees_column_head = cols.fees ? `<th id="fees_thead" class="col col-1 remove-borders">Fees</th>` : ``;
    // var startingAt_column_head = cols.startingAt ? `<th id="startingAt_thead" class="col col-2 remove-borders">Starting At</th>` : ``;
    // var created_column_head = cols.created ? `<th id="createdat_thead" class="col col-2 remove-borders">Created At</th>` : ``;
    // var updated_column_head = cols.updated ? `<th id="updatedat_thead" class="col col-2 remove-borders">Updated At</th>` : ``;
    // $('#table_head_courses').html(`
    // <th id="name_thead" class="col col-2 remove-borders">Name</th>
    // ${description_column_head}${weeks_column_head}${fees_column_head}${startingAt_column_head}${created_column_head}${updated_column_head}`)

    // data.forEach(course => {
    //     // console.log('course');
    //     // var utcCreatedDate = new Date(course.createdAt);
    //     var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

    //     var createdHindiIST = new Date(course.createdAt).toLocaleDateString("hi-IN", options)
    //     var createdEnglishIST = new Date(course.createdAt).toLocaleDateString("en-IN", options)
    //     var startingEnglishIST = new Date(course.startingAt).toLocaleDateString("en-IN", options)

    //     // Check date
    //     optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    //     var createdCheck = new Date(course.createdAt).toLocaleDateString("en-IN", optionsCheck)
    //     var today = new Date().toLocaleDateString("en-IN", optionsCheck)

    //     var courseStartingAt = new Date(course.startingAt).toLocaleDateString("en-IN", optionsCheck)
    //     var newElement;
    //     if (createdCheck === today) {
    //         newElement = `<span class="badge badge-noti">New</span>`
    //         // newelementCount += 1
    //     } else {
    //         newElement = ''
    //     }

    //     var updateValue = course.updatedAt ? course.updatedAt : 'Not updated'
    //     // Converting update value from UTC to GMT
    //     if (updateValue != 'Not updated') {
    //         updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
    //     }

    //     if (course.description.length > 50) {
    //         var truncated_description = course.description.slice(0,50)+'...'
    //     } else {
    //         var truncated_description = course.description
    //     }

    //     var description_column_data = cols.description ? `<td class="remove-borders">${truncated_description}</td>` : ''
    //     var weeks_column_data = cols.weeks ? `<td class="remove-borders">${course.weeks}</td>` : ''
    //     var fees_column_data = cols.fees ? `<td class="remove-borders">${course.fees}</td>` : ''
    //     var startingAt_column_data = cols.startingAt ? `<td class="remove-borders">${startingEnglishIST}</td>` : ''
    //     var created_column_data = cols.created ? `<td class="remove-borders">${createdEnglishIST}</td>` : ''
    //     var updated_column_data = cols.updated ? `<td class="remove-borders">${updateValue}</td>` : ''
        
    //     tbody_courses += `
    //     <tr id="${course._id}">
    //         <td class="remove-borders"><a href="/sdp/admin/viewcourse?course=${course._id}" target="_blank">
    //             ${course.name} ${newElement}
    //         </a></td>
    //         ${description_column_data}
    //         ${weeks_column_data}
    //         ${fees_column_data}
    //         ${startingAt_column_data}
    //         ${created_column_data}
    //         ${updated_column_data}
    //     </tr>`;
    //     });
    //     if (data.length == 0) {
    //         tbody_courses += `
    //         <tr>
    //             <td>No data match your filter</td>
    //         </tr>`;
    //     }
    // $('#table_courses tbody').html(tbody_courses)
    // ------------------ NEW CODE END ---------------------
                    }


function getFilterCount() {

    let teachers_filter_count = 0
    var filtered_branches = all_teachers_data
    let filter_teachers_course = getCookie('filter_teachers_course');
    // console.log(filter_teachers_branch);
    // console.log(filter_teachers_course);

    var new_filtered_data = []
    if (filter_teachers_course && filtered_branches) {
        teachers_filter_count++

        for (let i = 0; i < filtered_branches.length; i++) {
            const eachObj = filtered_branches[i];
            let courses = eachObj.coursesAllocated.split(',')
            // console.log(courses);
            // console.log(filter_teachers_course);
            courses.forEach(course => {
                
                if (course == filter_teachers_course) {
                    // console.log('slice them');
                    new_filtered_data.push(filtered_branches.splice(i, 1))
                }
                });
        }
        // console.log(new_filtered_data);
        if (new_filtered_data.length > 0) {
            filtered_branches = new_filtered_data[0]  
        }else{
            // console.log('Empty branches');
            filtered_branches = []
        }
        // console.log(filtered_branches);
    }
    // console.log(filtered_branches);
    $('#applied_filters').html(teachers_filter_count)
    populateTable(filtered_branches, cols)
}
// getFilterCount()

var courses_list;
function loadCoursesList() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#studentcourse').text(response.data)
                var filter_teachers_course_cook = getCookie('filter_teachers_course')

                if (response.data.length == 0) {
                    courses_list += `<option value="">Course List is empty</option>`;
                } else {
                    courses_list = `<option value="">Select Course Name</option>`;
                    response.data.forEach(course => {

                        if (filter_teachers_course_cook == course.name) {
                            courses_list += `<option value="${course.name}" selected>${course.name}</option>`;
                        } else {
                            courses_list += `<option value="${course.name}">${course.name}</option>`;
                        }
                    });
                }

                // $('#filter_teachers_branch').html(branches_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Branches Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}

function callAllFunctions() {
    loadCoursesList()
}

callAllFunctions()

$('#filter-btn').click(()=>{
    
    Swal.fire({
        title: "<div>Filter Teachers</div>", 
        html: `<div id="filt_card">
        <div id="filter_card" class="col card">
            <b class="row mb-2">Course -</b>
            <form class="d-flex align-items-center">
                <select name="filter_teachers_course" id="filter_teachers_course" class="w-75 p-1">
                    ${courses_list}
                </select>
            </form>
        </div>
        </div>`,  
        confirmButtonText: "Apply Filter", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            var filtered_branches = all_teachers_data
            
            // Filter student course
            let filter_teachers_course = $("#filter_teachers_course").val()
            // alert(filter_teachers_course);
            setCookie('filter_teachers_course',filter_teachers_course,7)

            var new_filtered_data = []
            if (filter_teachers_course && filtered_branches) {

                for (let i = 0; i < filtered_branches.length; i++) {
                    const eachObj = filtered_branches[i];
                    let courses = eachObj.coursesAllocated.split(',')
                    // console.log(courses);
                    // console.log(filter_teachers_course);
                    courses.forEach(course => {
                        
                        if (course == filter_teachers_course) {
                            // console.log('slice them');
                            new_filtered_data.push(filtered_branches.splice(i, 1))
                        }
                    });
                }
                if (new_filtered_data.length > 0) {
                    filtered_branches = new_filtered_data[0]  
                }else{
                    filtered_branches = []
                }
            }
            // console.log(filtered_branches);
            populateTable(filtered_branches, cols)
            getFilterCount()
            callAllFunctions()
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(all_courses_data);
            
        }
    })
})


// function generatePDF() {
//     var element = document.getElementById('teachers-head-container');
//     var opt = {
//         margin: 1,
//         filename: 'myfile.pdf',
//         image: { type: 'jpeg', quality: 0.98 },
//         html2canvas: { scale: 2 },
//         jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
//     };

//     // New Promise-based usage:
//     // html2pdf().from(element).set(opt).save();
//     html2pdf().from(element).save();

//     // Old monolithic-style usage:
//     // html2pdf(element, opt);
// }
// generatePDF()

// $('#export-list-btn').click(() => {
//     Swal.fire({
//         title: 'Export Teachers List',
//         // icon: 'info',
//         html: `
//         <div align="left" style="margin-left: 120px;">
//         <input checked type="radio" id="print" name="fav_language" value="Print">
//         <label for="print">Print</label><br>
//         <input type="radio" id="saveaspdf" name="fav_language" value="saveAsPDF">
//         <label for="saveaspdf">Save as PDF</label><br>
//         <input type="radio" id="exporttoexcel" name="fav_language" value="ExportToExcel">
//         <label for="exporttoexcel">Export to Excel</label>
//         </div>`,
//         showCloseButton: true,
//         showCancelButton: true,
//         focusConfirm: false,
//         confirmButtonColor: '#91c442',
//         confirmButtonText: '<i class="fas fa-file-export"></i> Export',
//         cancelButtonText: 'Cancel'
//     })
// });


// $('#table_teachers').DataTable();
