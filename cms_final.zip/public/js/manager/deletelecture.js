
$('#sidebar-lectures').trigger("click")
$('#sidebar-lectures,#sidebar-lectures-delete').addClass('active')
$("div#mySidebar").scrollTop(400); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['lecture'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/manager/lectures')
})

function loadLecturesList() {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading lectures list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/lectures',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var lectures_list;
                $('#deletelecture #lecture').text(response.data)

                if (response.data.length == 0) {
                    lectures_list += `<option value="">Lecture List is empty</option>`;
                } else {
                    lectures_list = `<option value="">Select Lecture Name</option>`;
                    response.data.forEach(lecture => {

                        // var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                        // var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString("en-IN", dateOptions)
                        var optionsNew = { timeZone: 'UTC', year: 'numeric', month: 'long', day: 'numeric' };
                        var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleTimeString('en-US', optionsNew) // New Testing

                        if (lecture._id == selected) {

                            lectures_list += `
                            <option selected value="${lecture._id}">${lectureDateTimeEnglishIST} > ${lecture.teacher.name}</option>`;

                        } else {

                            lectures_list += `
                            <option value="${lecture._id}">${lectureDateTimeEnglishIST} > ${lecture.teacher.name}</option>`;

                        }
                    });
                }

                $('#deletelecture #lecture').html(lectures_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Lectures Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_lectures tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch lectures list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_lectures tbody .col').html(errorMsg)
                $('#no-lecture-selected').html(errorMsg)
            }

        }
    });

}
loadLecturesList()

const teachername = $('#delete-teachername')
const coursename = $('#delete-coursename')
const students = $('#delete-students')
const dateTime = $('#delete-dateTime')
const topics = $('#delete-topics')

const createdby = $('#delete-lecturecreatedby')
const createdat = $('#delete-lecturecreatedat')
const updatedat = $('#delete-lectureupdatedat')
const lectureid = $('#delete-lectureid')

function getLectureDetails() {

    const selectLecture = $('#lecture').val() ? $('#lecture').val() : selected
    // console.log(selectLecture);
    if (selectLecture == '') {
        $('#no-lecture-selected').css('display', 'block')
        $('#lecture-selected').css('display', 'none')
    } else {

        $('#no-lecture-selected').css('display', 'none')
        $('#lecture-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/lectures/${selectLecture}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deletelecture #lecture-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)
                    // var lectureDateTimeEnglishIST = new Date(response.data.dateTime).toLocaleDateString("en-IN", options)
                    var optionsNew = { timeZone: 'UTC', year: 'numeric', month: 'long', day: 'numeric' };
                    var lectureDateTimeEnglishIST = new Date(response.data.dateTime).toLocaleTimeString('en-US', optionsNew) // New Testing

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var student_details = ''
                    const student_string = response.data.student.split(',')
                    // console.log(response.data.studentcationalQualification);
                    student_string.forEach(student => {
                        student_details += `<span class="badge badge-light mt-2">${student}</span>`
                    });

                    teachername.text(response.data.teacher.name)
                    coursename.text(response.data.course.name)
                    students.html(student_details)
                    dateTime.text(lectureDateTimeEnglishIST)
                    topics.text(response.data.topicsCovered)

                    createdby.text(`${response.data.createdBy.name} (${response.data.createdBy.role})`)
                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    lectureid.val(response.data._id)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Lecture Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_lectures tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-lecture-card button').attr('disabled', true)
                    $('#lecture-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-lecture-card button').attr('disabled', true)
                    $('#lecture-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch lectures list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_lectures tbody .col').html(errorMsg)
                    $('#no-lecture-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-lecture-selected').css('display', 'block')
$('#lecture-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getLectureDetails()
}
$('#lecture').change(() => {

    getLectureDetails()

})

$('#delete-lecture-btn').click(() => {
    var dellectureid = $('#delete-lectureid').val()
    var name = dateTime.text()
    // console.log(dellectureid);
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${name}</span> lecture details!</h4>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: `/sdp/lectures/${dellectureid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Lecture Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-lecture-selected').css('display', 'block')
                        $('#lecture-selected').css('display', 'none')
                        loadLecturesList()

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });
                    console.log(response);

                }
            });

        }
    })
})
