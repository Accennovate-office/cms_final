
$('#no-task-available').fadeOut()
$('#table_tasks,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#sidebar-tasks').trigger("click")
$('#sidebar-tasks,#sidebar-tasks-all').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

$('#new-task-btn').click(() => {
    document.location.replace('/sdp/manager/addtask');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTasks(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTasks(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTasks(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllTasks(limit, page + 1)
})
// Page navigator End

function loadAllTasks(limit = 1, page = 1) {

    $('#no-task-available').fadeOut()
    $('#table_tasks,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/tasks?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length == 0 && response.total_count == 0) {
                    var noTask = `
                    <img src="/images/tasks/notask.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Task List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Task</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-task-available').fadeIn()
                    $('#no-task-available').html(noTask)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var notask = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-task-available').fadeIn()
                    $('#no-task-available').html(notask)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var notask = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-task-available').fadeIn()
                        $('#no-task-available').html(notask)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var task = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-task-available').fadeIn()
                        $('#no-task-available').html(task)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_tasks,#myInput').fadeIn()
                        var tbody_tasks;
                        // var newelementCount = 0;
                        response.data.forEach(task => {

                            // var utcCreatedDate = new Date(task.createdAt);
                            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                            var createdHindiIST = new Date(task.createdAt).toLocaleDateString("hi-IN", options)
                            var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", options)

                            // Check date
                            optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var createdCheck = new Date(task.createdAt).toLocaleDateString("en-IN", optionsCheck)
                            var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                            var taskStartingAt = new Date(task.startingAt).toLocaleDateString("en-IN", optionsCheck)
                            var newElement;
                            if (createdCheck === today) {
                                newElement = `<span class="badge badge-noti">New</span>`
                                // newelementCount += 1
                            } else {
                                newElement = ''
                            }
                            // if (newelementCount > 0) {
                            //     $('#sidebar-tasks-all').html(`All Tasks <span class="badge badge-noti">${newelementCount}</span>`)
                            // }

                            // var updateValue = task.updatedAt ? task.updatedAt : 'Not updated'
                            // // Converting update value from UTC to GMT
                            // if (updateValue != 'Not updated') {
                            //     // var utcUpdatedDate = new Date(updateValue);
                            //     // updateValue = utcUpdatedDate.toUTCString()

                            //     // Hindi Date time
                            //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                            //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                            // }

                            tbody_tasks += `
                            <tr id="${task._id}">
                                <td>
                                    ${task.details} ${newElement}
                                </td>
                                <td>${task.category.title} <span class="badge badge-freq">${task.category.frequency}</span></td>
                                <td>${task.subcategory.title}</td>
                                <td>${task.createdBy ? task.createdBy.name : 'Not found'}</td>
                                <td>${createdEnglishIST}</td>
                                <td>
                                    <div class="hover-container">
                                        <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                                        <aside class="hover-popup">
                                            <a align="center" class="p-1 fontt" href="/sdp/manager/viewtask?task=${task._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                                            <a align="center" class="p-1 fontt text-success" href="/sdp/manager/edittask?task=${task._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                                            <a align="center" class="p-1 fontt text-danger" href="/sdp/manager/deletetask?task=${task._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                                        </aside>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        $('#table_tasks tbody').html(tbody_tasks)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Tasks Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_tasks tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch tasks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                $('#table_tasks').html(errorMsg)
            }

        }
    });

}
loadAllTasks()

// function loadAllTaskCategorys() {

//     $.ajax({
//         url: '/sdp/taskcategorys',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 if (response.data.length == 0) {
//                     var noTask = `
//                     <img src="/images/tasks/notask.png" width="60" alt="">
//                     <div class="h3 mt-2">Category List is empty <br><br>
//                         <span class="h5">
//                             Click<button id="add-category-btn" data-toggle="tooltip" data-placement="bottom" title="Add category"><i class="fa fa-plus"></i></button>
//                             &nbsp;beside Category List to get started
//                         </span>
//                     </div>`
//                     // $('#no-task-available').fadeIn()
//                     // $('#no-task-available').html(noTask)
//                     Swal.fire({
//                         // icon: 'info',
//                         // title: 'Category List',
//                         html: noTask,
//                         showCloseButton: true,
//                         showConfirmButton: false
//                     });
//                 } else {
//                     // $('#table_tasks').fadeIn()
//                     var tbody_tasks = ``;
//                     // var newelementCount = 0;
//                     response.data.forEach(task => {

//                         // var utcCreatedDate = new Date(task.createdAt);
//                         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                         var createdHindiIST = new Date(task.createdAt).toLocaleDateString("hi-IN", options)
//                         var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", options)

//                         // Check date
//                         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                         var createdCheck = new Date(task.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                         var taskStartingAt = new Date(task.startingAt).toLocaleDateString("en-IN", optionsCheck)
//                         var newElement;
//                         if (createdCheck === today) {
//                             newElement = `<span class="badge badge-noti">New</span>`
//                             // newelementCount += 1
//                         } else {
//                             newElement = ''
//                         }
//                         // if (newelementCount > 0) {
//                         //     $('#sidebar-tasks-all').html(`All Tasks <span class="badge badge-noti">${newelementCount}</span>`)
//                         // }

//                         var updateValue = task.updatedAt ? task.updatedAt : 'Not updated'
//                         // Converting update value from UTC to GMT
//                         if (updateValue != 'Not updated') {
//                             // var utcUpdatedDate = new Date(updateValue);
//                             // updateValue = utcUpdatedDate.toUTCString()

//                             // Hindi Date time
//                             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                         }

//                         tbody_tasks += `
//                         <div class="card p-2 mt-3">
//                             <div class="row">
//                                 <div align="left" class="col col-4 font-weight-bold"><span>${task.title}</span> ${newElement}</div>
//                                 <div align="right" class="col col-8 small">${task.description ? `<u>Description</u>: ${task.description}` : 'Description not available'}</div>
//                             </div>
//                             <div align="left" class="small"><u>Created By</u>: ${task.createdBy.name}(${task.createdBy.role}) at ${createdEnglishIST}</div>
//                         </div>`;
//                     });
//                     // $('#table_tasks tbody').html(tbody_tasks)

//                     Swal.fire({
//                         // icon: 'success',
//                         title: `<i class="fa fa-list" aria-hidden="true"></i> Category List`,
//                         html: tbody_tasks,
//                         showCloseButton: true,
//                         showConfirmButton: false,
//                         width: '75%'
//                     });

//                 }

//                 // Swal.fire({
//                 //     toast: true,
//                 //     position: 'top-right',
//                 //     icon: 'success',
//                 //     title: 'Tasks Fetched Successfully',
//                 //     timer: 5000,
//                 //     showConfirmButton: false
//                 // });

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_tasks tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch tasks list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 $('#table_tasks').html(errorMsg)
//             }

//         }
//     });

// }
// $('#category-btn').click(() => {

//     loadAllTaskCategorys()
// })

// function loadAllTaskSubCategorys() {

//     $.ajax({
//         url: '/sdp/tasksubcategorys',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 if (response.data.length == 0) {
//                     var noTask = `
//                     <img src="/images/tasks/notask.png" width="60" alt="">
//                     <div class="h3 mt-2">Sub Category List is empty <br><br>
//                         <span class="h5">
//                             Click<button id="add-category-btn" data-toggle="tooltip" data-placement="bottom" title="Add subcategory"><i class="fa fa-plus"></i></button>
//                             &nbsp;beside Sub-category List to get started
//                         </span>
//                     </div>`
//                     // $('#no-task-available').fadeIn()
//                     // $('#no-task-available').html(noTask)
//                     Swal.fire({
//                         // icon: 'info',
//                         // title: 'Category List',
//                         html: noTask,
//                         showCloseButton: true,
//                         showConfirmButton: false,
//                         width: '600px'
//                     });
//                 } else {
//                     // $('#table_tasks').fadeIn()
//                     var tbody_tasks = ``;
//                     // var newelementCount = 0;
//                     response.data.forEach(task => {

//                         // var utcCreatedDate = new Date(task.createdAt);
//                         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                         var createdHindiIST = new Date(task.createdAt).toLocaleDateString("hi-IN", options)
//                         var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", options)

//                         // Check date
//                         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                         var createdCheck = new Date(task.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                         var taskStartingAt = new Date(task.startingAt).toLocaleDateString("en-IN", optionsCheck)
//                         var newElement;
//                         if (createdCheck === today) {
//                             newElement = `<span class="badge badge-noti">New</span>`
//                             // newelementCount += 1
//                         } else {
//                             newElement = ''
//                         }
//                         // if (newelementCount > 0) {
//                         //     $('#sidebar-tasks-all').html(`All Tasks <span class="badge badge-noti">${newelementCount}</span>`)
//                         // }

//                         var updateValue = task.updatedAt ? task.updatedAt : 'Not updated'
//                         // Converting update value from UTC to GMT
//                         if (updateValue != 'Not updated') {
//                             // var utcUpdatedDate = new Date(updateValue);
//                             // updateValue = utcUpdatedDate.toUTCString()

//                             // Hindi Date time
//                             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                         }
//                         // Pending: Front-end for sub-category #########################################################################
//                         tbody_tasks += `
//                         <div class="card p-2 mt-3">
//                             <div class="row">
//                                 <div align="left" class="col col-4 font-weight-bold"><span>${task.title}</span> ${newElement}</div>
//                                 <div align="right" class="col col-8 small">${task.category.title ? `<u>Category</u>: ${task.category.title}` : 'Category not available'}
//                             </div></div>
//                             <div align="left" class="row">
//                                 <div class="col small">${task.description ? `<u>Description</u>: ${task.description}` : 'Description not available'}</div>
//                             </div>
//                             <div align="left" class="row">
//                                 <div class="col small"><u>Created By</u>: ${task.createdBy.name}(${task.createdBy.role}) at ${createdEnglishIST}</div>
//                                 </div>
//                         </div>`;
//                     });
//                     // $('#table_tasks tbody').html(tbody_tasks)
//                     Swal.fire({
//                         // icon: 'success',
//                         title: `<i class="fa fa-stream" aria-hidden="true"></i> Sub-Category List`,
//                         html: tbody_tasks,
//                         showCloseButton: true,
//                         showConfirmButton: false,
//                         width: '75%'
//                     });

//                 }

//                 // Swal.fire({
//                 //     toast: true,
//                 //     position: 'top-right',
//                 //     icon: 'success',
//                 //     title: 'Tasks Fetched Successfully',
//                 //     timer: 5000,
//                 //     showConfirmButton: false
//                 // });

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_tasks tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch tasks list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 $('#table_tasks').html(errorMsg)
//             }

//         }
//     });

// }
// $('#subcategory-btn').click(() => {

//     loadAllTaskSubCategorys()
// })

// $('#add-category-btn').click(async () => {

//     const { value: formValues } = await Swal.fire({
//         title: `<i class="fa fa-list" aria-hidden="true"></i> Add New category`,
//         html:
//             `<label>Title <span class="text-danger">*</span></label>
//             <input id="swal-input1" class="swal2-input" placeholder="Title of Category">` +
//             `<input id="swal-input2" class="swal2-input w-75" placeholder="Description">`,
//         focusConfirm: false,
//         confirmButtonText: 'Add Category',
//         confirmButtonColor: '#0b6fad',
//         showCancelButton: true,
//         width: '700px',
//         preConfirm: () => {
//             const title = document.getElementById('swal-input1').value
//             const desc = document.getElementById('swal-input2').value
//             if (!title) {
//                 // Ref: https://stackoverflow.com/a/54582551
//                 Swal.showValidationMessage('Please add Title')
//             } else {
//                 return [title, desc]
//             }
//         }
//     })

//     if (formValues) {
//         Swal.fire({
//             toast: true,
//             position: 'top-right',
//             icon: 'info',
//             title: 'Loading...',
//             showConfirmButton: false
//         });
//         // Swal.fire(formValues[0])
//         $.ajax({
//             url: '/sdp/taskcategorys',
//             method: 'post',
//             dataType: 'json',
//             data: {
//                 title: formValues[0],
//                 description: formValues[1],
//             },
//             success: function (response) {
//                 if (response.success) {

//                     $('#error,#loading').css('display', 'none')
//                     $('#add-branch-card button').attr('disabled', true)

//                     Swal.fire({
//                         icon: 'success',
//                         title: `<div class="text-success">Task Category Created</div>`,
//                         confirmButtonText: 'Okay',
//                         confirmButtonColor: '#0b6fad',
//                         allowOutsideClick: false
//                     })
//                     // .then((result) => {
//                     //     /* Read more about isConfirmed, isDenied below */
//                     //     if (result.isConfirmed) {
//                     //         Swal.fire({
//                     //             toast: true,
//                     //             position: 'top-right',
//                     //             icon: 'success',
//                     //             title: 'Redirecting...',
//                     //             timer: 1000,
//                     //             showConfirmButton: false
//                     //         });
//                     //         setTimeout(() => {
//                     //             document.location.replace('/sdp/manager/tasks');
//                     //         }, 1000);
//                     //     }
//                     // })

//                 } else {

//                     console.log(response);
//                     $('#error').text(response.responseJSON.error);
//                     Swal.fire({
//                         icon: 'error',
//                         title: 'Something went wrong',
//                         html: `<div>Response status: ${response.status} &nbsp;&nbsp; Response text: ${response.statusText}</div>
//                         <div>Detailed Error: ${response.responseJSON.error}</div>`,
//                         showCloseButton: true,
//                         showConfirmButton: false,
//                         width: '70%'
//                     });

//                 }
//             },
//             error: function (response) {

//                 console.log(response);
//                 $('#error').text(response.responseJSON.error);
//                 Swal.fire({
//                     icon: 'error',
//                     title: 'Something went wrong',
//                     html: `<div>Response status: ${response.status} &nbsp;&nbsp; Response text: ${response.statusText}</div>
//                     <div>Detailed Error: ${response.responseJSON.error}</div>`,
//                     showCloseButton: true,
//                     showConfirmButton: false,
//                     width: 'max-content'
//                 });

//             }
//         });
//     }

// })

// $('#add-subcategory-btn').click(async () => {
//     Swal.fire({
//         toast: true,
//         position: 'top-right',
//         icon: 'info',
//         title: 'Loading...',
//         showConfirmButton: false
//     });

//     var tbody_tasks = ``;
//     var noTask = ``;
//     var catg_data = false

//     await $.ajax({
//         url: '/sdp/taskcategorys',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 if (response.data.length == 0) {
//                     noTask = `
//                     <img src="/images/tasks/notask.png" width="60" alt="">
//                     <div class="h3 mt-2">Category List is empty <br><br>
//                         <span class="h5">
//                             Click<button id="add-category-btn" data-toggle="tooltip" data-placement="bottom" title="Add category"><i class="fa fa-plus"></i></button>
//                             &nbsp;beside Category List to get started
//                         </span>
//                     </div>`
//                     // $('#no-task-available').fadeIn()
//                     // $('#no-task-available').html(noTask)
//                     // Swal.fire({
//                     //     // icon: 'info',
//                     //     // title: 'Category List',
//                     //     html: noTask,
//                     //     showCloseButton: true,
//                     //     showConfirmButton: false
//                     // });
//                 } else {
//                     catg_data = true
//                     // $('#table_tasks').fadeIn()
//                     // var newelementCount = 0;
//                     response.data.forEach(task => {

//                         // var utcCreatedDate = new Date(task.createdAt);
//                         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                         var createdHindiIST = new Date(task.createdAt).toLocaleDateString("hi-IN", options)
//                         var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", options)

//                         // Check date
//                         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                         var createdCheck = new Date(task.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                         var taskStartingAt = new Date(task.startingAt).toLocaleDateString("en-IN", optionsCheck)

//                         tbody_tasks += `
//                         <option value="${task._id}">${task.title}</option>`;
//                     });

//                     // console.log(tbody_tasks);

//                 }

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_tasks tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch tasks list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 $('#table_tasks').html(errorMsg)
//             }

//         }
//     })

//     if (catg_data) {

//         const { value: formValues } = await Swal.fire({
//             title: `<i class="fa fa-stream" aria-hidden="true"></i> Add New subcategory`,
//             html: `<label for="swal-input3" class="mt-3">Choose a category  <span class="text-danger">*</span></label>
//                 <select id="swal-input3" class="swal2-input" name="swal-input3">
//                 ${tbody_tasks}
//                 </select>
//                 <br>
//                 <label>Title <span class="text-danger">*</span></label>
//                 <input id="swal-input1" class="swal2-input" placeholder="Title of Sub-category">` +
//                 `<input id="swal-input2" class="swal2-input w-75" placeholder="Description">`,
//             focusConfirm: false,
//             confirmButtonText: 'Add Sub-Category',
//             confirmButtonColor: '#0b6fad',
//             showCancelButton: true,
//             width: '700px',
//             preConfirm: () => {
//                 const title = document.getElementById('swal-input1').value
//                 const desc = document.getElementById('swal-input2').value
//                 const category = document.getElementById('swal-input3').value
//                 if (!category) {
//                     // Ref: https://stackoverflow.com/a/54582551
//                     Swal.showValidationMessage('Please select Category')
//                 } else if (!title) {
//                     // Ref: https://stackoverflow.com/a/54582551
//                     Swal.showValidationMessage('Please add Title')
//                 } else {
//                     return [title, desc, category]
//                 }
//             }
//         })

//         if (formValues) {
//             // Swal.fire(formValues[0])
//             $.ajax({
//                 url: '/sdp/tasksubcategorys',
//                 method: 'post',
//                 dataType: 'json',
//                 data: {
//                     title: formValues[0],
//                     description: formValues[1],
//                     category: formValues[2]
//                 },
//                 success: function (response) {
//                     if (response.success) {

//                         $('#error,#loading').css('display', 'none')
//                         $('#add-branch-card button').attr('disabled', true)

//                         Swal.fire({
//                             icon: 'success',
//                             title: `<div class="text-success">Task Sub-Category Created</div>`,
//                             confirmButtonText: 'Okay',
//                             confirmButtonColor: '#0b6fad',
//                             allowOutsideClick: false
//                         })
//                         // .then((result) => {
//                         //     /* Read more about isConfirmed, isDenied below */
//                         //     if (result.isConfirmed) {
//                         //         Swal.fire({
//                         //             toast: true,
//                         //             position: 'top-right',
//                         //             icon: 'success',
//                         //             title: 'Redirecting...',
//                         //             timer: 1000,
//                         //             showConfirmButton: false
//                         //         });
//                         //         setTimeout(() => {
//                         //             document.location.replace('/sdp/manager/tasks');
//                         //         }, 1000);
//                         //     }
//                         // })

//                     } else {

//                         console.log(response);
//                         $('#error').text(response.responseJSON.error);
//                         Swal.fire({
//                             icon: 'error',
//                             title: 'Something went wrong',
//                             html: `<div>Response status: ${response.status} &nbsp;&nbsp; Response text: ${response.statusText}</div>
//                             <div>Detailed Error: ${response.responseJSON.error}</div>`,
//                             showCloseButton: true,
//                             showConfirmButton: false,
//                             width: '70%'
//                         });

//                     }
//                 },
//                 error: function (response) {

//                     console.log(response);
//                     $('#error').text(response.responseJSON.error);
//                     Swal.fire({
//                         icon: 'error',
//                         title: 'Something went wrong',
//                         html: `<div>Response status: ${response.status} &nbsp;&nbsp; Response text: ${response.statusText}</div>
//                         <div>Detailed Error: ${response.responseJSON.error}</div>`,
//                         showCloseButton: true,
//                         showConfirmButton: false,
//                         width: '70%'
//                     });

//                 }
//             });
//         }

//     } else {

//         Swal.fire({
//             // icon: 'info',
//             // title: 'Category List',
//             html: noTask,
//             showCloseButton: true,
//             showConfirmButton: false,
//             width: '600px'
//         });

//     }



// })

// $('#delete-category-btn').click(async () => {
//     Swal.fire({
//         toast: true,
//         position: 'top-right',
//         icon: 'info',
//         title: 'Loading...',
//         showConfirmButton: false
//     });

//     var tbody_tasks = ``;
//     var noTask = ``;
//     var catg_data = false

//     await $.ajax({
//         url: '/sdp/taskcategorys',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 if (response.data.length == 0) {
//                     noTask = `
//                     <img src="/images/tasks/notask.png" width="60" alt="">
//                     <div class="h3 mt-2">Category List is empty <br><br>
//                         <span class="h5">
//                             Click<button id="add-category-btn" data-toggle="tooltip" data-placement="bottom" title="Add category"><i class="fa fa-plus"></i></button>
//                             &nbsp;beside Category List to get started
//                         </span>
//                     </div>`
//                     // $('#no-task-available').fadeIn()
//                     // $('#no-task-available').html(noTask)
//                     // Swal.fire({
//                     //     // icon: 'info',
//                     //     // title: 'Category List',
//                     //     html: noTask,
//                     //     showCloseButton: true,
//                     //     showConfirmButton: false
//                     // });
//                 } else {
//                     catg_data = true
//                     // $('#table_tasks').fadeIn()
//                     // var newelementCount = 0;
//                     response.data.forEach(task => {

//                         // var utcCreatedDate = new Date(task.createdAt);
//                         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                         var createdHindiIST = new Date(task.createdAt).toLocaleDateString("hi-IN", options)
//                         var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", options)

//                         // Check date
//                         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                         var createdCheck = new Date(task.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                         var taskStartingAt = new Date(task.startingAt).toLocaleDateString("en-IN", optionsCheck)
//                         var newElement;
//                         if (createdCheck === today) {
//                             newElement = `<span class="badge badge-noti">New</span>`
//                             // newelementCount += 1
//                         } else {
//                             newElement = ''
//                         }
//                         // if (newelementCount > 0) {
//                         //     $('#sidebar-tasks-all').html(`All Tasks <span class="badge badge-noti">${newelementCount}</span>`)
//                         // }

//                         var updateValue = task.updatedAt ? task.updatedAt : 'Not updated'
//                         // Converting update value from UTC to GMT
//                         if (updateValue != 'Not updated') {
//                             // var utcUpdatedDate = new Date(updateValue);
//                             // updateValue = utcUpdatedDate.toUTCString()

//                             // Hindi Date time
//                             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                         }

//                         tbody_tasks += `
//                         <option value="${task._id}">${task.title}</option>`;
//                     });

//                     // console.log(tbody_tasks);

//                 }

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_tasks tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch tasks list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 $('#table_tasks').html(errorMsg)
//             }

//         }
//     })

//     if (catg_data) {

//         const { value: formValues } = await Swal.fire({
//             title: `<i class="fa fa-list" aria-hidden="true"></i> Delete Category`,
//             html: `<div class="text-danger border border-danger rounded-pill py-1">Deleting a Task category will also delete all its associated Sub-categories</div>
//             <label for="swal-input1" class="mt-3">Choose a category to delete</label>
//             <select id="swal-input1" class="swal2-input" name="swal-input1">
//                 ${tbody_tasks}
//             </select>`,
//             focusConfirm: false,
//             confirmButtonText: `<i class="fa fa-trash" aria-hidden="true"></i> Delete Category`,
//             confirmButtonColor: '#dc3545',
//             showCancelButton: true,
//             width: '700px',
//             preConfirm: () => {
//                 const title = document.getElementById('swal-input1').value
//                 if (!title) {
//                     // Ref: https://stackoverflow.com/a/54582551
//                     Swal.showValidationMessage('Please add Title')
//                 } else {
//                     return [title]
//                 }
//             }
//         })
//         if (formValues) {
//             // console.log(formValues[0]);
//             Swal.fire({
//                 toast: true,
//                 position: 'top-right',
//                 icon: 'info',
//                 title: 'Deleting...',
//                 showConfirmButton: false
//             });

//             // Delete sub-categories
//             $.ajax({
//                 url: '/sdp/tasksubcategorys',
//                 method: 'get',
//                 success: function (response) {
//                     if (response.success) {

//                         if (response.data.length > 0) {

//                             response.data.forEach(subcategory => {
//                                 if (subcategory.category._id == formValues[0]) {

//                                     // Delete single sub-category
//                                     $.ajax({
//                                         url: `/sdp/tasksubcategorys/${subcategory._id}`,
//                                         method: 'delete',
//                                         success: function (response) {
//                                             if (response.success) {

//                                                 Swal.fire({
//                                                     toast: true,
//                                                     position: 'top-right',
//                                                     icon: 'info',
//                                                     title: 'Deleting wait...',
//                                                     showConfirmButton: false
//                                                 });

//                                             } else {

//                                                 Swal.fire({
//                                                     icon: 'danger',
//                                                     title: 'Something went wrong',
//                                                     text: response.responseJSON.error
//                                                 });
//                                                 console.log(response);

//                                             }
//                                         },
//                                         error: function (response) {

//                                             Swal.fire({
//                                                 icon: 'danger',
//                                                 title: 'Server error',
//                                                 text: response.responseJSON.error
//                                             });
//                                             console.log(response);

//                                         }
//                                     });

//                                 }
//                             });

//                         }
//                         $.ajax({
//                             url: `/sdp/taskcategorys/${formValues[0]}`,
//                             method: 'delete',
//                             success: function (response) {
//                                 if (response.success) {

//                                     // All associated sub-categories deleted
//                                     Swal.fire({
//                                         toast: true,
//                                         position: 'top-right',
//                                         icon: 'success',
//                                         title: 'Category and its associated sub-categories Deleted Successfully',
//                                         timer: 6000,
//                                         showConfirmButton: false
//                                     });

//                                 } else {

//                                     Swal.fire({
//                                         icon: 'danger',
//                                         title: 'Something went wrong',
//                                         text: response.responseJSON.error
//                                     });
//                                     console.log(response);

//                                 }
//                             },
//                             error: function (response) {

//                                 Swal.fire({
//                                     icon: 'danger',
//                                     title: 'Server error',
//                                     text: response.responseJSON.error
//                                 });
//                                 console.log(response);

//                             }
//                         });

//                     } else {

//                         $('#loading').css('display', 'none');
//                         $('#table_tasks tbody tr').text(response.responseJSON.error);
//                         console.log(response.responseJSON.error);
//                         $('#error').fadeIn();
//                         $('#error').css('display', 'block');
//                         $('#add-task-card button').attr('disabled', true)

//                     }
//                 },
//                 error: function (response) {

//                     if (response.responseJSON) {
//                         $('#loading').css('display', 'none');
//                         $('#error').text(response.responseJSON.error);
//                         console.log(response.responseJSON.error);
//                         $('#error').fadeIn();
//                         $('#error').css('display', 'block');
//                         $('#add-task-card button').attr('disabled', true)

//                     } else {
//                         var errorMsg = `
//                             <center>
//                             <h2>Oops! Something went wrong</h2>
//                             <h4 class="text-danger">
//                                 Error Code: ${response.status} <br>
//                                 Error Message: ${response.statusText}
//                             </h4>
//                             <h5>We were unable to fetch tasks list</h5>
//                             <h6>
//                                 Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                             </h6>
//                             </center>`
//                         console.log(`something went wrong ${JSON.stringify(response)}`);
//                         // console.log(response.statusText);
//                         $('#table_tasks').html(errorMsg)
//                     }

//                 }
//             })

//         }

//     } else {

//         Swal.fire({
//             // icon: 'info',
//             // title: 'Category List',
//             html: noTask,
//             showCloseButton: true,
//             showConfirmButton: false,
//             width: '600px'
//         });

//     }

// })

// // Delete subcategory event
// $('#delete-subcategory-btn').click(async () => {
//     Swal.fire({
//         toast: true,
//         position: 'top-right',
//         icon: 'info',
//         title: 'Loading...',
//         showConfirmButton: false
//     });

//     var tbody_tasks = ``;
//     var noTask = ``;
//     var sub_data = false

//     await $.ajax({
//         url: '/sdp/tasksubcategorys',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 if (response.data.length == 0) {
//                     noTask = `
//                     <img src="/images/tasks/notask.png" width="60" alt="">
//                     <div class="h3 mt-2">Sub Category List is empty <br><br>
//                         <span class="h5">
//                             Click<button id="add-category-btn" data-toggle="tooltip" data-placement="bottom" title="Add subcategory"><i class="fa fa-plus"></i></button>
//                             &nbsp;beside Sub-Category List to get started
//                         </span>
//                     </div>`
//                     // $('#no-task-available').fadeIn()
//                     // $('#no-task-available').html(noTask)
//                     // Swal.fire({
//                     //     // icon: 'info',
//                     //     // title: 'Category List',
//                     //     html: noTask,
//                     //     showCloseButton: true,
//                     //     showConfirmButton: false
//                     // });
//                 } else {
//                     sub_data = true
//                     // $('#table_tasks').fadeIn()
//                     // var newelementCount = 0;
//                     response.data.forEach(task => {

//                         // var utcCreatedDate = new Date(task.createdAt);
//                         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                         var createdHindiIST = new Date(task.createdAt).toLocaleDateString("hi-IN", options)
//                         var createdEnglishIST = new Date(task.createdAt).toLocaleDateString("en-IN", options)

//                         // Check date
//                         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                         var createdCheck = new Date(task.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                         var taskStartingAt = new Date(task.startingAt).toLocaleDateString("en-IN", optionsCheck)
//                         var newElement;
//                         if (createdCheck === today) {
//                             newElement = `<span class="badge badge-noti">New</span>`
//                             // newelementCount += 1
//                         } else {
//                             newElement = ''
//                         }
//                         // if (newelementCount > 0) {
//                         //     $('#sidebar-tasks-all').html(`All Tasks <span class="badge badge-noti">${newelementCount}</span>`)
//                         // }

//                         var updateValue = task.updatedAt ? task.updatedAt : 'Not updated'
//                         // Converting update value from UTC to GMT
//                         if (updateValue != 'Not updated') {
//                             // var utcUpdatedDate = new Date(updateValue);
//                             // updateValue = utcUpdatedDate.toUTCString()

//                             // Hindi Date time
//                             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                         }

//                         tbody_tasks += `
//                         <option value="${task._id}">${task.title}</option>`;
//                     });

//                 }

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_tasks tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch tasks list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 $('#table_tasks').html(errorMsg)
//             }

//         }
//     })
//     // console.log(tbody_tasks);

//     if (sub_data) {

//         const { value: formValues } = await Swal.fire({
//             title: `<i class="fa fa-stream" aria-hidden="true"></i> Delete Sub-Category`,
//             html: `<div class="text-danger border border-danger rounded-pill py-1">Deleting a Task sub-category will also delete its associated data</div>
//             <label for="swal-input1" class="mt-3">Choose a sub-category to delete</label>
//             <select id="swal-input1" class="swal2-input" name="swal-input1">
//                 ${tbody_tasks}
//             </select>`,
//             focusConfirm: false,
//             confirmButtonText: `<i class="fa fa-trash" aria-hidden="true"></i> Delete Sub-Category`,
//             confirmButtonColor: '#dc3545',
//             showCancelButton: true,
//             width: '700px',
//             preConfirm: () => {
//                 const title = document.getElementById('swal-input1').value
//                 if (!title) {
//                     // Ref: https://stackoverflow.com/a/54582551
//                     Swal.showValidationMessage('Please add Title')
//                 } else {
//                     return [title]
//                 }
//             }
//         })
//         if (formValues) {
//             // console.log(formValues[0]);
//             Swal.fire({
//                 toast: true,
//                 position: 'top-right',
//                 icon: 'info',
//                 title: 'Deleting...',
//                 showConfirmButton: false
//             });

//             // Delete sub-categories
//             $.ajax({
//                 url: `/sdp/tasksubcategorys/${formValues[0]}`,
//                 method: 'delete',
//                 success: function (response) {
//                     if (response.success) {

//                         // Sub-categories deleted
//                         Swal.fire({
//                             toast: true,
//                             position: 'top-right',
//                             icon: 'success',
//                             title: 'Sub-category and its data Deleted Successfully',
//                             timer: 6000,
//                             showConfirmButton: false
//                         });

//                     } else {

//                         $('#loading').css('display', 'none');
//                         $('#table_tasks tbody tr').text(response.responseJSON.error);
//                         console.log(response.responseJSON.error);
//                         $('#error').fadeIn();
//                         $('#error').css('display', 'block');
//                         $('#add-task-card button').attr('disabled', true)

//                     }
//                 },
//                 error: function (response) {

//                     if (response.responseJSON) {
//                         $('#loading').css('display', 'none');
//                         $('#error').text(response.responseJSON.error);
//                         console.log(response.responseJSON.error);
//                         $('#error').fadeIn();
//                         $('#error').css('display', 'block');
//                         $('#add-task-card button').attr('disabled', true)

//                     } else {
//                         var errorMsg = `
//                             <center>
//                             <h2>Oops! Something went wrong</h2>
//                             <h4 class="text-danger">
//                                 Error Code: ${response.status} <br>
//                                 Error Message: ${response.statusText}
//                             </h4>
//                             <h5>We were unable to fetch tasks list</h5>
//                             <h6>
//                                 Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                             </h6>
//                             </center>`
//                         console.log(`something went wrong ${JSON.stringify(response)}`);
//                         // console.log(response.statusText);
//                         $('#table_tasks').html(errorMsg)
//                     }

//                 }
//             })

//         }

//     } else {

//         Swal.fire({
//             // icon: 'info',
//             // title: 'Category List',
//             html: noTask,
//             showCloseButton: true,
//             showConfirmButton: false,
//             width: '600px'
//         });

//     }


// })
