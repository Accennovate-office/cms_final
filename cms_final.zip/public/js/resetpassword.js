$('.btn-success').prop('disabled', true);
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#emoji').fadeIn();
$('#emoji').attr('src', '/images/emoji-blushing.gif');

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#password,#confirmpassword').on('input', function () {
    const password = $('#password').val();
    const confirmpassword = $('#confirmpassword').val();
    if (password || confirmpassword) {
        $('#emoji').fadeIn();
        $('#emoji').attr('src', '/images/emoji-quite.gif');
    }
    if (password && confirmpassword) {
        $('.btn-success').prop('disabled', false);
    } else {
        $('.btn-success').prop('disabled', true);
    }
});


$('#loginMe').click(() => {

    $('#error').fadeOut();
    loading();
    const password = $('#password').val();
    const confirmpassword = $('#confirmpassword').val();

    if (password === confirmpassword) {

        let paramString = window.location.pathname.split('/')[4];
        // console.log(paramString);
        $.ajax({
            url: `/sdp/auth/resetpassword/${paramString}`,
            method: 'put',
            dataType: 'json',
            data: {
                password: password
            },
            success: function (response) {
                if (response.success) {

                    $('#emoji').fadeIn();
                    $('#emoji').attr('src', '/images/emoji-happy.gif');

                    Swal.fire({
                        toast: true,
                        position: 'bottom-right',
                        icon: 'success',
                        title: 'Password Updated',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    $('#error,#loading').css('display', 'none');
                    $('#password,#confirmpassword').val(null);
                    $('.btn-success').prop('disabled', true);

                } else {

                    $('#emoji').fadeIn();
                    $('#emoji').attr('src', '/images/emoji-cry.gif');

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#password,#confirmpassword').val(null);
                    $('.btn-success').prop('disabled', true);

                }
            },
            error: function (response) {

                $('#emoji').fadeIn();
                $('#emoji').attr('src', '/images/emoji-cry.gif');

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#password,#confirmpassword').val(null);
                $('.btn-success').prop('disabled', true);

            }
        });

    } else {

        $('#emoji').fadeIn();
        $('#emoji').attr('src', '/images/emoji-think.gif');

        $('#loading').css('display', 'none');
        $('#error').text('Password and Confirm Password are not same');
        $('#error').fadeIn();
        $('#error').css('display', 'block');
        $('#password,#confirmpassword').val(null);
        $('.btn-success').prop('disabled', true);

    }
});