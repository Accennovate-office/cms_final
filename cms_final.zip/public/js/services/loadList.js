export function loadCoursesList() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var courses_list = ``;
                $('#admissioncourses').text(response.data)

                if (response.data.length == 0) {
                    courses_list += `<option value="">Course List is empty</option>`;
                } else {
                    courses_list = `<option value="">Select Course Name</option>`;
                    response.data.forEach(course => {

                        courses_list += `
                        <option value="${course._id}">${course.name}</option>`;
                    });
                }
                $('#coursename').html(courses_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Courses Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_courses tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_courses tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}

export function loadUsersList() {

    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var users_list = ``;
                $('#username').text(response.data)

                if (response.data.length == 0) {
                    users_list = `<option value="">User List is empty</option>`;
                } else {
                    users_list = `<option value="">Select User Name</option>`;
                    users_list += `<option value="other">Staff not listed</option>`;
                    response.data.forEach(user => {

                        users_list += `
                        <option value="${user._id}">${user.name} | ${user.role} | ${user.branch} Branch</option>`;
                    });
                }
                $('#username').html(users_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Users Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_users tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch users list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_users tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
