export default function typesList() {
    const followupTypes = {
        'Phone_call': 1,
        'Home_visit': 2
    };
    return followupTypes
}


// module.exports.followupTypes = {
//     1: 'Phone_call',
//     2: 'Home_visit'
// };