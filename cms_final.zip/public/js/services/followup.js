import typesList from "./enums.js";
import {loadUsersList} from "./loadList.js";

export function addFollowup(enquiryID) {
    
    var followupTypes_list = ``
    const types = typesList()
    // console.log(types.Home_visit);
    for (const key in types) {
        console.log(`${key}: ${types[key]}`);
        if (key === 'Phone_call' && types[key] === 1) {
            followupTypes_list += `<option selected value="${types[key]}">${key}</option>`;
        } else {
            followupTypes_list += `<option value="${types[key]}">${key}</option>`;
        }
    }
    
    $.ajax({
        url: `/sdp/followups/count/${enquiryID}`,
        method: 'get',
        success: function (response) {
            if (response.success) {
                
                var nextCount = response.next

                Swal.fire({
                    title: `<div>Add Followup <span class="circle-singleline">${nextCount}</span></div>`, 
                    html: `
                    <div class="row d-flex align-items-center ic1">
                        <b class="col m-2">Select Followup Type</b>
                        <select name="followupType" id="followupType" class="col p-1 input">
                            ${followupTypes_list}
                        </select>
                    </div>
                    <div class="input-container textarea ic2">
                        <textarea rows="4" id="comment" class="input" type="text" placeholder=" " ></textarea>
                        <div class="cut cut-long"></div>
                        <label for="comment" class="placeholder">Followup comment</label>
                    </div>
                    <div class="row d-flex align-items-center ic2">
                        <b class="col m-2">Followup taken by</b>
                        <select name="username" id="username" class="col-8 p-1 input"></select>
                    </div>
                    <div class="input-container ic2">
                        <input id="otherUser" class="input" type="text" placeholder=" " />
                        <div class="cut cut-other"></div>
                        <label for="otherUser" class="placeholder">Other user name (If staff not listed)</label>
                    </div>
                    <div class="input-container ic2">
                        <input id="takenon" class="input" type="date" placeholder=" " />
                        <div class="cut cut-date"></div>
                        <label for="takenon" class="placeholder">Followup Date</label>
                    </div>
                    <div class="row d-flex align-items-center justify-content-between ic2">
                        <b class="col col-7 m-2">Converted to admission</b>
                        <input type="radio" id="yes" name="converted" value="Yes" class="custom-checkbox">
                        <label for="yes" class="col col-2">Yes</label>
                        <input checked type="radio" id="no" name="converted" value="No" class="custom-checkbox">
                        <label for="no" class="col col-2">No</label>
                    </div>
                    `,  
                    confirmButtonText: "Add Followup", 
                    confirmButtonColor: '#0b6fad',
                    showCloseButton: true,
                    allowOutsideClick: false,
                    background: 'whitesmoke'
                }).then((result) => {
                    // console.log(result);
                    if (result.isConfirmed) {
                        let followupNo = nextCount
                        let type = $('#followupType').val()
                        let comment = $('#comment').val()
                        let takenby = $('#username').val()
                        let takenbyother = $('#otherUser').val()
                        let takenon = $('#takenon').val()
                        let enquiry = enquiryID
                        let converted = $('input[name=converted]:checked').val()

                        var followupFormData
                        var convertedBool = converted == 'Yes' ? true : false

                        var followupBy = ''
                        if (takenby != '') {
                            followupBy = takenby
                            followupFormData = {
                                followupNo, type, comment, takenby, takenon, enquiry, converted: convertedBool
                            }
                            if (takenby == 'other') {
                                takenby = undefined
                                followupBy = takenbyother
                                followupFormData = {
                                    followupNo, type, comment, takenbyother, takenon, enquiry, converted: convertedBool
                                }
                            }
                        }

                        console.log(`
                        No: ${followupNo} \n 
                        type: ${type} \n
                        comment: ${comment} \n
                        user: ${takenby} \n
                        otheruser: ${takenbyother} \n
                        date: ${takenon} \n
                        enquiry: ${enquiry} \n
                        converted: ${converted}`);
                        console.log(followupFormData);

                        if (!followupNo || !type || !comment || !followupBy || !takenon || !enquiry || !converted) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Incomplete Form Submitted',
                                text: 'Followup is not added due to incomplete form',
                                confirmButtonText: `<div class="text-dark">Okay</div>`,
                                confirmButtonColor: '#fff',
                                showDenyButton: true,
                                denyButtonText: 'Try again',
                                denyButtonColor: '#0b6fad',
                                focusConfirm: false
                            }).then((result) => {
                                // console.log(result);
                                // if (result.isConfirmed) {}
                                if (result.isDenied) { addFollowup(enquiryID) }
                            })
                        } else {
                            
                            $.ajax({
                                url: '/sdp/followups',
                                method: 'post',
                                dataType: 'json',
                                data: followupFormData,
                                success: function (response) {
                                    if (response.success) {

                                        // Followup data added
                                        Swal.fire({
                                            icon: 'success',
                                            title: `<div class="text-success">Followup Added</div>`,
                                            html: `<h5>Followup record ${nextCount} added successfully</h5>`,
                                            confirmButtonText: `<div class="text-dark">Okay</div>`,
                                            confirmButtonColor: '#fff',
                                            allowOutsideClick: false,
                                            showDenyButton: true,
                                            denyButtonText: 'Enquiries List',
                                            denyButtonColor: '#0b6fad',
                                            focusConfirm: false
                                        }).then((result) => {
                                            /* Read more about isConfirmed, isDenied below */
                                            if (result.isConfirmed) {
                                                Swal.fire({
                                                    toast: true,
                                                    position: 'top-right',
                                                    icon: 'success',
                                                    title: 'Redirecting...',
                                                    timer: 1000,
                                                    showConfirmButton: false
                                                });
                                                setTimeout(() => {
                                                    document.location.reload(true)
                                                }, 1000);
                                            } else if (result.isDenied) {
                                                Swal.fire({
                                                    toast: true,
                                                    position: 'top-right',
                                                    icon: 'success',
                                                    title: 'Loading...',
                                                    timer: 1000,
                                                    showConfirmButton: false
                                                });
                                                setTimeout(() => {
                                                    document.location.replace('/sdp/admin/enquiries');
                                                }, 1000);
                                            }
                                        })

                                    } else {

                                        $('#loading').css('display', 'none');
                                        console.log(response);
                                        $('#error').text(response.responseJSON.error);
                                        $('#error').fadeIn();
                                        $('#error').css('display', 'block');
                                        $('#add-branch-card button').attr('disabled', true)
                    
                                    }
                                },
                                error: function (response) {
                    
                                    $('#loading').css('display', 'none');
                                    console.log(response);
                                    // $('#error').text(response.responseJSON.error);
                                    $('#error').fadeIn();
                                    $('#error').css('display', 'block');
                                    $('#add-branch-card button').attr('disabled', true)
                    
                                }
                            });
                        }
                    }
                })
                
            }
        }
    })
    loadUsersList() // Directly load users list in #username
    
}

export function createFollowupUI(enquiryID) {
    var followup_data = ``;

    var timeline_numbers = [
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm12,152a8,8,0,0,1-16,0V98.9l-11.6,7.8a8,8,0,0,1-8.8-13.4l24-16a8.3,8.3,0,0,1,8.2-.4A8,8,0,0,1,140,84Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm24,144a8,8,0,0,1,0,16H104a7.3,7.3,0,0,1-2.5-.4A8,8,0,0,1,96,176a7.5,7.5,0,0,1,1.7-4.9l43.7-58.3A16,16,0,0,0,128,88a15.9,15.9,0,0,0-14.7,9.8,8,8,0,0,1-14.8-6.3,32,32,0,1,1,56,30.4l-.2.3L120,168Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm21.5,153.5a36.2,36.2,0,0,1-51,0,8.1,8.1,0,0,1,11.4-11.4A19.9,19.9,0,1,0,124,132a8.1,8.1,0,0,1-7.1-4.3,8,8,0,0,1,.5-8.3L136.6,92H104a8,8,0,0,1,0-16h48a8.1,8.1,0,0,1,7.1,4.3,8,8,0,0,1-.5,8.3l-21.1,30a37.9,37.9,0,0,1,12,7.9,36.2,36.2,0,0,1,0,51Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm28,152a8,8,0,0,1-16,0V152H100a8,8,0,0,1-6.5-3.4,7.9,7.9,0,0,1-1-7.3l24-68a8,8,0,0,1,15,5.4L111.3,136H140V112a8,8,0,0,1,16,0Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm-4.1,92a36,36,0,1,1-25.5,61.5,8,8,0,1,1,11.2-11.4,20.1,20.1,0,0,0,14.3,5.9,19.9,19.9,0,0,0,14.2-5.9,19.8,19.8,0,0,0,0-28.2,19.9,19.9,0,0,0-14.2-5.9,20.1,20.1,0,0,0-14.3,5.9,8,8,0,0,1-13.5-7l7.8-48.2a8,8,0,0,1,7.9-6.7H152a8,8,0,0,1,0,16H118.6l-4.1,25.2A37.3,37.3,0,0,1,123.9,116Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M148,144a20,20,0,1,1-20-20A20.1,20.1,0,0,1,148,144Zm84-16A104,104,0,1,1,128,24,104.2,104.2,0,0,1,232,128Zm-68,16a36,36,0,0,0-36-36h-1.8l16.7-27.9a8,8,0,1,0-13.8-8.2l-32.2,54-.3.6A36,36,0,1,0,164,144Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm31.6,62.5-32,96A7.9,7.9,0,0,1,120,188a7.3,7.3,0,0,1-2.5-.4,8,8,0,0,1-5.1-10.1L140.9,92H104a8,8,0,0,1,0-16h48a7.9,7.9,0,0,1,6.5,3.3A8.1,8.1,0,0,1,159.6,86.5Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm24,150a33.9,33.9,0,1,1-48-48,26.6,26.6,0,0,1,3.1-2.6l-.3-.2a29.9,29.9,0,0,1,0-42.4c11.3-11.3,31.1-11.3,42.4,0a29.9,29.9,0,0,1,0,42.4l-.3.2A26.6,26.6,0,0,1,152,126a33.8,33.8,0,0,1,0,48Z"/><path d="M137.9,111.9a14,14,0,1,0-19.8,0A14.3,14.3,0,0,0,137.9,111.9Z"/><path d="M128,132a18,18,0,0,0-12.7,30.7,18.4,18.4,0,0,0,25.4,0A18,18,0,0,0,128,132Z"/></svg>`,
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M148,112a20,20,0,1,1-20-20A20.1,20.1,0,0,1,148,112Zm84,16A104,104,0,1,1,128,24,104.2,104.2,0,0,1,232,128Zm-68-16a36,36,0,1,0-36,36h1.8l-16.7,27.9a8.1,8.1,0,0,0,2.8,11A8.7,8.7,0,0,0,120,188a8.1,8.1,0,0,0,6.9-3.9l32.2-54,.3-.5A36,36,0,0,0,164,112Z"/></svg>`
    ]

    var followup_header_item = `
    <li class="timeline-item">
        <span class="timeline-item-icon | avatar-icon">
            <i class="avatar">
                <img src="/images/enquiries/followup_icon.png" width="40" />
            </i>
        </span>
        <div id="container" align="left" class="new-comment">
            <aside class="ribbon3">Followups taken</aside>
        </div>
    </li>`

    var followup_footer_item = `
    <li class="timeline-item">
        <span class="timeline-item-icon | avatar-icon">
            <i class="avatar">
                <img src="/images/enquiries/add_followup.png" width="44" />
            </i>
        </span>
        <div align="left" class="new-comment mt-1">
            <button id="add-new-followup" class="button-55">Add New Followup</button>
        </div>
    </li>`

    $.ajax({
        url: `/sdp/followups/count/${enquiryID}`,
        method: 'get',
        success: function (response) {
            if (response.success) {
                var followups = response.data

                if (followups.length > 0) {
                    // if (0 > 0) {
                    
                    var followup_items = ``
                    for (let x = 0; x < followups.length; x++) {
                        const followup = followups[x];
                        
                        var followup_by
                        if (!followup.takenbyother) {
                            var role = followup.takenby.role
                            if (followup.takenby.role === 'manager') {
                                
                                var slug = followup.takenby.slug
                                // /sdp/admin/viewmanager?manager=majgaonkar.mahodar.17et3006
                                followup_by = `<a target="_blank" href="/sdp/admin/view${role}?${role}=${slug}">${followup.takenby.name}</a>`
                            } else {
                                
                                var ID = followup.takenby._id
                                // /sdp/admin/viewteacher?teacher=645b81c6ce1a1200341e2065
                                followup_by = `<a target="_blank" href="/sdp/admin/view${role}?${role}=${ID}">${followup.takenby.name}</a>`
                            }
                            // console.log(followup_by);
                        } else {
                            followup_by = `${followup.takenbyother} (other)`
                        }

                        var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var followup_date = new Date(followup.takenon).toLocaleDateString("en-IN", date_options)

                        followup_items += `
                        <li class="timeline-item | extra-space">
                            <span class="timeline-item-icon | filled-icon">${timeline_numbers[x]}</span>
                            <div class="timeline-item-wrapper">
                                <div class="timeline-item-description">
                                    <i class="avatar | small">
                                        <img src="/images/enquiries/profile.png" width="24" />
                                    </i>
                                    <span>${followup_by} followed up on <time datetime="20-01-2021">${followup_date}</time></span>
                            </div>
                            <div class="comment">
                                <p align="left" id="comment-text">${followup.comment}.</p>
                                <div id="buttons" style="display:flex;">
                                <button class="button | square">
                                    <svg style="color: #A77B06;" width="24" height="24" stroke-width="1.5" viewBox="0 0 24 24" fill="#E5D68A" xmlns="http://www.w3.org/2000/svg"> <path d="M13.0207 5.82839L15.8491 2.99996L20.7988 7.94971L17.9704 10.7781M13.0207 5.82839L3.41405 15.435C3.22652 15.6225 3.12116 15.8769 3.12116 16.1421V20.6776H7.65669C7.92191 20.6776 8.17626 20.5723 8.3638 20.3847L17.9704 10.7781M13.0207 5.82839L17.9704 10.7781" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/> </svg>
                                </button>
                                <button class="button | square">
                                    <svg style="color:#D82E2F;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-delete"><path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"></path><line x1="18" y1="9" x2="12" y2="15"></line><line x1="12" y1="9" x2="18" y2="15"></line></svg>
                                </button>
                                    </div>
                            </div>  
                        </li>`
                    }

                    // Setting footer
                    if (followups.length >= 8) {
                        // if (8 >= 8) {
                        followup_footer_item = `
                        <li class="timeline-item">
                            <span class="timeline-item-icon | avatar-icon">
                                <i class="avatar">
                                    <img src="/images/enquiries/add_followup.png" width="44" />
                                </i>
                            </span>
                            <div align="left" class="new-comment mt-1">
                                Maximum limit to add followups is reached
                            </div>
                        </li>`
                    }

                } else {
                    var followup_items = ``
                }

                followup_data = `
                <ol class="timeline">
                    ${followup_header_item}
                    ${followup_items} 
                    ${followup_footer_item}
                </ol>`

                $('#followup-list').html(followup_data)

                $('#add-new-followup').click(()=>{
                    addFollowup(enquiryID)
                })
                // End
            }
        }
    })

//     followup_data = `
//     <ol class="timeline">
//         ${followup_header_item}
// <!-- 	2nd LI ITEM -->
    
// <!-- 	3rd LI ITEM -->
//     <li class="timeline-item | extra-space">
//         <span class="timeline-item-icon | filled-icon">
//             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><path d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm24,144a8,8,0,0,1,0,16H104a7.3,7.3,0,0,1-2.5-.4A8,8,0,0,1,96,176a7.5,7.5,0,0,1,1.7-4.9l43.7-58.3A16,16,0,0,0,128,88a15.9,15.9,0,0,0-14.7,9.8,8,8,0,0,1-14.8-6.3,32,32,0,1,1,56,30.4l-.2.3L120,168Z"/></svg>
//         </span>
//         <div class="timeline-item-wrapper">
//             <div class="timeline-item-description">
//                 <i class="avatar | small">
//                     <img src="/images/enquiries/woman.png" width="24" />
//                 </i>
//                 <span><a href="#">Sneha Pawar</a> followed up on <time datetime="20-01-2021">April 20, 2023</time></span>
//         </div>
//         <div class="comment">
//             <p id="comment-text">Student is at native place. He will visit branch once back.</p>
//             <div id="buttons" style="display:flex;">
//             <button class="button | square">
//                 <svg style="color: #A77B06;" width="24" height="24" stroke-width="1.5" viewBox="0 0 24 24" fill="#E5D68A" xmlns="http://www.w3.org/2000/svg"> <path d="M13.0207 5.82839L15.8491 2.99996L20.7988 7.94971L17.9704 10.7781M13.0207 5.82839L3.41405 15.435C3.22652 15.6225 3.12116 15.8769 3.12116 16.1421V20.6776H7.65669C7.92191 20.6776 8.17626 20.5723 8.3638 20.3847L17.9704 10.7781M13.0207 5.82839L17.9704 10.7781" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/> </svg>
//             </button>
//             <button class="button | square">
//                 <svg style="color:#D82E2F;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-delete"><path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"></path><line x1="18" y1="9" x2="12" y2="15"></line><line x1="12" y1="9" x2="18" y2="15"></line></svg>
//             </button>
//                 </div>
//         </div>  
//     </li>
// <!-- 	Add button LI ITEM -->
//     <li class="timeline-item">
//         <span class="timeline-item-icon | avatar-icon">
//             <i class="avatar">
//                 <img src="/images/enquiries/add_followup.png" width="44" />
//             </i>
//         </span>
//         <div align="left" class="new-comment mt-1">
//             <button id="add-new-followup" class="button-55">Add New Followup</button>
//         </div>
//     </li>
// </ol>`
}