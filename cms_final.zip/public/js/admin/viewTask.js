
$('#sidebar-tasks').trigger("click")
$('#sidebar-tasks,#sidebar-tasks-view').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['task'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/tasks')
})

function loadTasksList() {

    $.ajax({
        url: '/sdp/tasks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var tasks_list;
                $('#viewtask #task').text(response.data)

                if (response.data.length == 0) {
                    tasks_list += `<option value="">Task List is empty</option>`;
                } else {
                    tasks_list = `<option value="">Select Task Name</option>`;
                    response.data.forEach(task => {

                        if (task._id == selected) {

                            tasks_list += `
                            <option selected value="${task._id}">${task.details}</option>`;

                        } else {

                            tasks_list += `
                            <option value="${task._id}">${task.details}</option>`;

                        }

                    });
                }

                $('#viewtask #task').html(tasks_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Tasks Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_tasks tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch tasks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_tasks tbody .col').html(errorMsg)
                $('#no-task-selected').html(errorMsg)
            }

        }
    });

}
loadTasksList()

function getTaskDetails() {

    // console.log('Inside get Task Details function');

    const selectTask = $('#task').val() ? $('#task').val() : selected
    // console.log(selectTask);
    if (selectTask == '') {
        $('#no-task-selected').css('display', 'block')
        $('#task-selected').css('display', 'none')
    } else {

        $('#no-task-selected').css('display', 'none')
        $('#task-selected').css('display', 'block')
        $('#viewtask #task-selected').html(`Loading...`)
        $.ajax({
            url: `/sdp/tasks/${selectTask}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewtask #task-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var task_data = `
                    <div class="d-flex mb-5">
                        <img src="/images/tasks/task2.png" width="60" alt="">
                        <div align="left" class="ml-4 pt-3">
                            <h2>Task Details</h2>
                        </div>
                    </div>
                    <div align="left">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                            <small>Task Details</small>
                        </div>
                        <h5>${response.data.details}</h5>
                    </div>

                    <div class="d-flex justify-content-between">
                    <div align="left" class="mt-3">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-list" aria-hidden="true"></i>
                            <small>Category</small>
                        </div>
                        <div>${response.data.category.title} <span class="badge badge-freq">${response.data.category.frequency}</span></div>
                    </div>
                    <div align="left" class="mt-3">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-stream" aria-hidden="true"></i>
                            <small>Sub-Category</small>
                        </div>
                        <div>${response.data.subcategory.title}</div>
                    </div>
                    <div align="left" class="mt-3" style="opacity:0;">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-stream" aria-hidden="true"></i>
                            <small>Sub-Category</small>
                        </div>
                        <div>Copy Book</div>
                    </div>
                    </div>

                    <div class="d-flex w-100">
                        <div align="left" class="mt-5 w-100">
                            <div class="d-flex align-items-center">
                            <i class="fa fa-user" aria-hidden="true"></i>
                                <small>Created By</small>
                            </div>
                            <div class="d-flex justify-content-between w-100">
                                <div>${response.data.createdBy.name}</div>
                                <div>${response.data.createdBy.email}</div>
                                <div>${response.data.createdBy.branch} Branch</div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                        <div align="left" class="mt-3 ml-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewtask #task-selected').html(task_data)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Task Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_tasks tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-task-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-task-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch tasks list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_tasks tbody .col').html(errorMsg)
                    $('#no-task-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-task-selected').css('display', 'block') // block
$('#task-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getTaskDetails()
}
$('#task').change(() => {

    getTaskDetails()

})
