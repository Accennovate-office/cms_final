import { setCookie, getCookie } from "../services/cookie.js";


$('#no-course-available').fadeOut()
$('#table_courses,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#sidebar-courses').trigger("click")
$('#sidebar-courses,#sidebar-courses-all').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

var all_courses_data
var cols = {description: false, weeks: false, fees: false, startingAt: false, created: false, updated: false}

$('#new-course-btn').click(() => {
    document.location.replace('/sdp/admin/addcourse');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllCourses(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllCourses(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllCourses(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllCourses(limit, page + 1)
})
// Page navigator End

function loadAllCourses(limit = 40, page = 1) {

    $('#no-course-available').fadeOut()
    $('#table_courses,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/courses?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {
                
                all_courses_data = response.data
                $('#error,#loading').css('display', 'none')

                // if (response.data.length == 0) {
                //     var noCourse = `
                //     <img src="/images/courses/nocourse.png" width="60" alt="">
                //     <div class="h3 mt-2">
                //         <span class="font-weight-bold">Course List is empty</span> <br><br>
                //         <span class="h5">Click&nbsp;
                //             <span>
                //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                //                     Course</button>
                //             </span>
                //             &nbsp;button at top left to get started
                //         </span>
                //     </div>`
                //     $('#no-course-available').fadeIn()
                //     $('#no-course-available').html(noCourse)

                // } else {
                //     $('#table_courses').fadeIn()
                //     var tbody_courses;
                //     // var newelementCount = 0;
                //     response.data.forEach(course => {

                //         // var utcCreatedDate = new Date(course.createdAt);
                //         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                //         var createdHindiIST = new Date(course.createdAt).toLocaleDateString("hi-IN", options)
                //         var createdEnglishIST = new Date(course.createdAt).toLocaleDateString("en-IN", options)

                //         // Check date
                //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var createdCheck = new Date(course.createdAt).toLocaleDateString("en-IN", optionsCheck)
                //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                //         var courseStartingAt = new Date(course.startingAt).toLocaleDateString("en-IN", optionsCheck)
                //         var newElement;
                //         if (createdCheck === today) {
                //             newElement = `<span class="badge badge-noti">New</span>`
                //             // newelementCount += 1
                //         } else {
                //             newElement = ''
                //         }
                //         // if (newelementCount > 0) {
                //         //     $('#sidebar-courses-all').html(`All Courses <span class="badge badge-noti">${newelementCount}</span>`)
                //         // }

                //         var updateValue = course.updatedAt ? course.updatedAt : 'Not updated'
                //         // Converting update value from UTC to GMT
                //         if (updateValue != 'Not updated') {
                //             // var utcUpdatedDate = new Date(updateValue);
                //             // updateValue = utcUpdatedDate.toUTCString()

                //             // Hindi Date time
                //             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                //             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                //         }

                //         tbody_courses += `
                //         <tr>
                //             <td>
                //                 ${course.name} ${newElement}
                //             </td>
                //             <td>${courseStartingAt}</td>
                //             <td>${course.fees}</td>
                //             <td>${course.createdBy.name}</td>
                //             <td>${createdEnglishIST}</td>
                //             <td>${updateValue}</td>
                //         </tr>`;
                //     });
                //     $('#table_courses tbody').html(tbody_courses)

                // }

                if (response.data.length == 0 && response.total_count == 0) {
                    var noCourse = `
                    <img src="/images/courses/nocourse.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Course List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Course</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-course-available').fadeIn()
                    $('#no-course-available').html(noCourse)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var nocourse = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-course-available').fadeIn()
                    $('#no-course-available').html(nocourse)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        // console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var nocourse = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-course-available').fadeIn()
                        $('#no-course-available').html(nocourse)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        // console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var course = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-course-available').fadeIn()
                        $('#no-course-available').html(course)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_courses,#myInput').fadeIn()
                        // var tbody_courses;
                        // // var newelementCount = 0;
                        // response.data.forEach(course => {

                        //     // var utcCreatedDate = new Date(course.createdAt);
                        //     var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                        //     var createdHindiIST = new Date(course.createdAt).toLocaleDateString("hi-IN", options)
                        //     var createdEnglishIST = new Date(course.createdAt).toLocaleDateString("en-IN", options)

                        //     // Check date
                        //     optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        //     var createdCheck = new Date(course.createdAt).toLocaleDateString("en-IN", optionsCheck)
                        //     var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                        //     var courseStartingAt = new Date(course.startingAt).toLocaleDateString("en-IN", optionsCheck)
                        //     var newElement;
                        //     if (createdCheck === today) {
                        //         newElement = `<span class="badge badge-noti">New</span>`
                        //         // newelementCount += 1
                        //     } else {
                        //         newElement = ''
                        //     }
                        //     // if (newelementCount > 0) {
                        //     //     $('#sidebar-courses-all').html(`All Courses <span class="badge badge-noti">${newelementCount}</span>`)
                        //     // }

                        //     // var updateValue = course.updatedAt ? course.updatedAt : 'Not updated'
                        //     // // Converting update value from UTC to GMT
                        //     // if (updateValue != 'Not updated') {
                        //     //     // var utcUpdatedDate = new Date(updateValue);
                        //     //     // updateValue = utcUpdatedDate.toUTCString()

                        //     //     // Hindi Date time
                        //     //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        //     //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                        //     // }

                        //     var updateValue = course.updatedAt ? course.updatedAt : 'Not updated'
                        //     // Converting update value from UTC to GMT
                        //     if (updateValue != 'Not updated') {
                        //         // var utcUpdatedDate = new Date(updateValue);
                        //         // updateValue = utcUpdatedDate.toUTCString()

                        //         // Hindi Date time
                        //         // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        //         updateValue = '#Updated ' + new Date(updateValue).toLocaleDateString("en-IN", options)
                        //     }

                        //     tbody_courses += `
                        //     <tr id="${course._id}">
                        //         <td><a href="/sdp/admin/viewcourse?course=${course._id}" target="_blank">
                        //             ${course.name} ${newElement}
                        //         </a></td>
                        //         <td>${courseStartingAt}</td>
                        //         <td>${course.fees}</td>
                        //         <td>${createdEnglishIST}</td>
                        //         <td>${updateValue}</td>
                        //     </tr>`;
                        // });
                        // $('#table_courses tbody').html(tbody_courses)
                        // <td>
                        //     <div class="hover-container">
                        //         <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                        //         <aside class="hover-popup">
                        //             <a align="center" class="p-1 fontt" href="/sdp/admin/viewcourse?course=${course._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                        //             <a align="center" class="p-1 fontt text-success" href="/sdp/admin/editcourse?course=${course._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                        //             <a align="center" class="p-1 fontt text-danger" href="/sdp/admin/deletecourse?course=${course._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                        //         </aside>
                        //     </div>
                        // </td>
                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Courses Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });
                
                // if (!getCookie('description_selected') && !getCookie('weeks_selected') && !getCookie('fees_selected') && !getCookie('startingAt_selected') && !getCookie('createdco_selected') && !getCookie('updatedco_selected')) {
                //     setTimeout(() => {
                //         modify_columns()
                //     }, 1500);
                // }else {
                //     cols.description = getCookie('description_selected')
                //     cols.weeks = getCookie('weeks_selected')
                //     cols.fees = getCookie('fees_selected')
                //     cols.startingAt = getCookie('startingAt_selected')
                //     cols.created = getCookie('createdco_selected')
                //     cols.updated = getCookie('updatedco_selected')
                //     // Refresh data
                //     populateTable(all_courses_data, cols)
                //     getFilterCount()
                // }
                cols.description = getCookie('description_selected')
                cols.weeks = getCookie('weeks_selected')
                cols.fees = getCookie('fees_selected')
                cols.startingAt = getCookie('startingAt_selected')
                cols.created = getCookie('createdco_selected')
                cols.updated = getCookie('updatedco_selected')
                // Refresh data
                populateTable(all_courses_data, cols)
                getFilterCount()
                setTimeout(() => {
                    modify_columns()
                }, 1500);

            } else {

                $('#loading').css('display', 'none');
                $('#table_courses tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_courses tbody .col').html(errorMsg)
                $('#table_courses').html(errorMsg)
            }

        }
    });

}
loadAllCourses()

// Feb 2023 update
function populateTable(data, cols) {
    var tbody_courses;
    // Columns add
    var description_column_head = cols.description ? `<th id="description_thead" class="col col-3 remove-borders">Description</th>` : ``;
    var weeks_column_head = cols.weeks ? `<th id="weeks_thead" class="col col-1 remove-borders">Duration (weeks)</th>` : ``;
    var fees_column_head = cols.fees ? `<th id="fees_thead" class="col col-1 remove-borders">Fees</th>` : ``;
    var startingAt_column_head = cols.startingAt ? `<th id="startingAt_thead" class="col col-2 remove-borders">Starting At</th>` : ``;
    var created_column_head = cols.created ? `<th id="createdat_thead" class="col col-2 remove-borders">Created At</th>` : ``;
    var updated_column_head = cols.updated ? `<th id="updatedat_thead" class="col col-2 remove-borders">Updated At</th>` : ``;
    $('#table_head_courses').html(`
    <th id="name_thead" class="col col-2 remove-borders">Name</th>
    ${description_column_head}${weeks_column_head}${fees_column_head}${startingAt_column_head}${created_column_head}${updated_column_head}`)
    
    data.forEach(course => {
        // console.log('course');
        // var utcCreatedDate = new Date(course.createdAt);
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

        var createdHindiIST = new Date(course.createdAt).toLocaleDateString("hi-IN", options)
        var createdEnglishIST = new Date(course.createdAt).toLocaleDateString("en-IN", options)
        var startingEnglishIST = new Date(course.startingAt).toLocaleDateString("en-IN", options)

        // Check date
        optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var createdCheck = new Date(course.createdAt).toLocaleDateString("en-IN", optionsCheck)
        var today = new Date().toLocaleDateString("en-IN", optionsCheck)

        var courseStartingAt = new Date(course.startingAt).toLocaleDateString("en-IN", optionsCheck)
        var newElement;
        if (createdCheck === today) {
            newElement = `<span class="badge badge-noti">New</span>`
            // newelementCount += 1
        } else {
            newElement = ''
        }

        var updateValue = course.updatedAt ? course.updatedAt : 'Not updated'
        // Converting update value from UTC to GMT
        if (updateValue != 'Not updated') {
            updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
        }

        if (course.description.length > 50) {
            var truncated_description = course.description.slice(0,50)+'...'
        } else {
            var truncated_description = course.description
        }

        var description_column_data = cols.description ? `<td class="remove-borders">${truncated_description}</td>` : ''
        var weeks_column_data = cols.weeks ? `<td class="remove-borders">${course.weeks}</td>` : ''
        var fees_column_data = cols.fees ? `<td class="remove-borders">${course.fees}</td>` : ''
        var startingAt_column_data = cols.startingAt ? `<td class="remove-borders">${startingEnglishIST}</td>` : ''
        var created_column_data = cols.created ? `<td class="remove-borders">${createdEnglishIST}</td>` : ''
        var updated_column_data = cols.updated ? `<td class="remove-borders">${updateValue}</td>` : ''
        
        tbody_courses += `
        <tr id="${course._id}">
            <td class="remove-borders"><a href="/sdp/admin/viewcourse?course=${course._id}" target="_blank">
                ${course.name} ${newElement}
            </a></td>
            ${description_column_data}
            ${weeks_column_data}
            ${fees_column_data}
            ${startingAt_column_data}
            ${created_column_data}
            ${updated_column_data}
        </tr>`;
        });
        if (data.length == 0) {
            tbody_courses += `
            <tr>
                <td>No data match your filter</td>
            </tr>`;
        }
    $('#table_courses tbody').html(tbody_courses)
}


function getFilterCount() {

    let courses_filter_count = 0
    var filtered_branches = all_courses_data
    var filter_courses_weeks = getCookie('filter_courses_weeks')
    // console.log(getCookie('filter_courses_fees_low'));
    // console.log(getCookie('filter_courses_fees_high'));
    if (getCookie('filter_courses_fees_low') == '' || getCookie('filter_courses_fees_low') == null || getCookie('filter_courses_fees_low') == undefined) {
        // console.log('Fees low - null / undefined');
        var filter_courses_fees_low = 0
    } else {
        // console.log('Fees low - value');
        var filter_courses_fees_low = getCookie('filter_courses_fees_low')
    }
    // console.log(typeof filter_courses_fees_low);
    if (getCookie('filter_courses_fees_high') == '' || getCookie('filter_courses_fees_high') == null || getCookie('filter_courses_fees_high') == undefined) {
        // console.log('Fees high - null / undefined');
        var filter_courses_fees_high = 0
    } else {
        // console.log('Fees high - value');
        var filter_courses_fees_high = getCookie('filter_courses_fees_high')
    }
    // console.log(typeof filter_courses_fees_high);
    if(filter_courses_weeks){
        // console.log('Inside weeks counter');
        courses_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        filtered_branches = filtered_branches.filter(
            eachObj => eachObj.weeks === filter_courses_weeks);     
        // console.log(filtered_branches)
    }
    if(filter_courses_fees_low || filter_courses_fees_high){
        // console.log('Inside fees counter');
        courses_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        // filtered_branches = filtered_branches.filter(
        //     eachObj => eachObj.fees === parseInt(filter_courses_fees));
        // Ref: https://sebhastian.com/javascript-filter-array-multiple-values/
        if (filter_courses_fees_high == 0) {
            filtered_branches = filtered_branches.filter((eachObj) => {
                return eachObj.fees >= parseInt(filter_courses_fees_low);
            });
        } else {
            filtered_branches = filtered_branches.filter((eachObj) => {
                return eachObj.fees >= parseInt(filter_courses_fees_low) && eachObj.fees <= parseInt(filter_courses_fees_high);
            });
        }
        // filtered_branches = filtered_branches.filter((eachObj) => {
        //     return eachObj.fees > 5000 && eachObj.fees < 8000;
        // });
        // console.log(filtered_branches)
    }
    $('#applied_filters').html(courses_filter_count)
    populateTable(filtered_branches, cols)
}
// getFilterCount()

$('#filter-btn').click(()=>{
    var filter_courses_weeks_cook = getCookie('filter_courses_weeks') 
    var filter_courses_fees_low_cook = getCookie('filter_courses_fees_low')
    var filter_courses_fees_high_cook = getCookie('filter_courses_fees_high')

    Swal.fire({
        title: "<div>Filter Courses</div>", 
        html: `
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter branches with duration (weeks) -</b>
            <form class="d-flex align-items-center">
                <label class="row">Enter duration in weeks: </label> &nbsp;&nbsp;&nbsp;
                <input class="col-2 p-1" type="input" name="filter_courses_weeks" value="${filter_courses_weeks_cook}" id="filter_courses_weeks" />
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter branches with fees -</b>
            <form class="d-flex align-items-center">
                <label class="row">Fees between: </label> &nbsp;&nbsp;&nbsp;
                <input class="col-3 p-1" type="input" name="filter_courses_fees_low" value="${filter_courses_fees_low_cook}" id="filter_courses_fees_low" />
                &nbsp;&nbsp; to &nbsp;&nbsp;
                <input class="col-3 p-1" type="input" name="filter_courses_fees_high" value="${filter_courses_fees_high_cook}" id="filter_courses_fees_high" />
            </form>
        </div>`,  
        confirmButtonText: "Apply Filter", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            var filtered_branches = all_courses_data
            let filter_courses_weeks = $("#filter_courses_weeks").val()
            setCookie('filter_courses_weeks',filter_courses_weeks,7)
            
            // Fee filter - lower limit
            var filter_courses_fees_low = $("#filter_courses_fees_low").val()
            if (filter_courses_fees_low == '' || filter_courses_fees_low == null || filter_courses_fees_low == undefined) {
                filter_courses_fees_low = 0
            }
            setCookie('filter_courses_fees_low',filter_courses_fees_low,7)

            // Fee filter - higher limit
            var filter_courses_fees_high = $("#filter_courses_fees_high").val()
            if (filter_courses_fees_high == '' || filter_courses_fees_high == null || filter_courses_fees_high == undefined) {
                filter_courses_fees_high = 0
            }
            setCookie('filter_courses_fees_high',filter_courses_fees_high,7)

            if(filter_courses_weeks){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                filtered_branches = filtered_branches.filter(
                    eachObj => eachObj.weeks === filter_courses_weeks);
                // console.log(filtered_branches)
            }
            if(filter_courses_fees_low || filter_courses_fees_high){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                // filtered_branches = filtered_branches.filter(
                //     eachObj => eachObj.fees === parseInt(filter_courses_fees));
                // Ref: https://sebhastian.com/javascript-filter-array-multiple-values/
                if (filter_courses_fees_high == 0) {
                    filtered_branches = filtered_branches.filter((eachObj) => {
                        return eachObj.fees >= parseInt(filter_courses_fees_low);
                    });
                } else {
                    filtered_branches = filtered_branches.filter((eachObj) => {
                        return eachObj.fees >= parseInt(filter_courses_fees_low) && eachObj.fees <= parseInt(filter_courses_fees_high);
                    });
                }
                // console.log(filtered_branches)
            }
            populateTable(filtered_branches, cols)
            getFilterCount()
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(all_courses_data);
            
        }
    })
})

// Modify columns
function modify_columns() {
    var description_selected_cook = getCookie('description_selected') ? 'checked' : ''
    var weeks_selected_cook = getCookie('weeks_selected') ? 'checked' : ''
    var fees_selected_cook = getCookie('fees_selected') ? 'checked' : ''
    var startingAt_selected_cook = getCookie('startingAt_selected') ? 'checked' : ''
    var createdco_selected_cook = getCookie('createdco_selected') ? 'checked' : ''
    var updatedco_selected_cook = getCookie('updatedco_selected') ? 'checked' : ''
    cols.description = getCookie('description_selected')
    cols.weeks = getCookie('weeks_selected')
    cols.fees = getCookie('fees_selected')
    cols.startingAt = getCookie('startingAt_selected')
    cols.created = getCookie('createdco_selected')
    cols.updated = getCookie('updatedco_selected')
    // Refresh data
    populateTable(all_courses_data, cols)
    getFilterCount()

    Swal.fire({
        title: "<div>Modify Columns</div>", 
        html: `
        <div id="filter_card" class="col card">
            <b class="row">Select columns which you want to display -</b>
            <form>
                <label class="row"><input type="checkbox" checked disabled name="name" value="name_selected" id="name_selected" />&nbsp; Name</label>
                <label class="row"><input type="checkbox" ${description_selected_cook} name="description" value="description_selected" id="description_selected" />&nbsp; Description</label>
                <label class="row"><input type="checkbox" ${weeks_selected_cook} name="weeks" value="weeks_selected" id="weeks_selected" />&nbsp; Weeks</label>
                <label class="row"><input type="checkbox" ${fees_selected_cook} name="fees" value="fees_selected" id="fees_selected" />&nbsp; Fees</label>
                <label class="row"><input type="checkbox" ${startingAt_selected_cook} name="startingAt" value="startingAt_selected" id="startingAt_selected" />&nbsp; Starting At</label>
                <label class="row"><input type="checkbox" ${createdco_selected_cook} name="createdat" value="createdco_selected" id="createdco_selected" />&nbsp; Created at Date&Time</label>
                <label class="row"><input type="checkbox" ${updatedco_selected_cook} name="updatedat" value="updatedco_selected" id="updatedco_selected" />&nbsp; Updated at Date&Time</label>
            </form>
        </div>`,  
        confirmButtonText: "Modify", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            let description_col = $("#description_selected").prop("checked")
            let weeks_col = $("#weeks_selected").prop("checked")
            let fees_col = $("#fees_selected").prop("checked")
            let startingAt_col = $("#startingAt_selected").prop("checked")
            let created_col = $("#createdco_selected").prop("checked")
            let updated_col = $("#updatedco_selected").prop("checked")
            setCookie('description_selected',description_col,7)
            setCookie('weeks_selected',weeks_col,7)
            setCookie('fees_selected',fees_col,7)
            setCookie('startingAt_selected',startingAt_col,7)
            setCookie('createdco_selected',created_col,7)
            setCookie('updatedco_selected',updated_col,7)
            
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(description_col);
            cols.description = description_col
            cols.weeks = weeks_col
            cols.fees = fees_col
            cols.startingAt = startingAt_col
            cols.created = created_col
            cols.updated = updated_col
            // console.log(cols);
            populateTable(all_courses_data, cols)
            getFilterCount()
        }
    })
}
$('#modify-cols-btn').click(()=>{
    modify_columns()
})