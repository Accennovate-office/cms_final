import { getUrlVars } from "../services/getData.js";

const selected = getUrlVars()['enquiry'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

var selectBranch = ''
function getEnquiryDetails() {
    // console.log('Function getEnquiryDetails');

    const selectenquiry = $('#enquiry').val() ? $('#enquiry').val() : selected
    // console.log(selectenquiry);
    if (selectenquiry == '') {
        $('#no-enquiry-selected').css('display', 'block')
        $('#enquiry-selected').css('display', 'none')
    } else {

        $('#no-enquiry-selected').css('display', 'none')
        $('#enquiry-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/enquiries/${selectenquiry}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#firstname').val(response.data.firstName)
                    $('#middlename').val(response.data.middleName)
                    $('#lastname').val(response.data.lastName)
                    $('#studentdob').val(response.data.dob ? response.data.dob.slice(0, 10) : '')
                    $(`#studentgender option[value='${response.data.gender}']`).attr("selected","selected");
                    var aadhaarNumber = ''
                    if (response.data.aadhaarNo) {

                        var aNo = response.data.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    }
                    $('#studentaadhaar').val(aadhaarNumber)
                    $('#studentreligion').val(response.data.religion)
                    $('#studentcaste').val(response.data.caste)
                    $('#fatheroccupation').val(response.data.fatherOccupation)
                    $('#mothername').val(response.data.motherName)
                    $('#mothertongue').val(response.data.motherTongue)
                    $('#phone1').val(response.data.phone1)
                    $('#phone2').val(response.data.phone2)
                    $('#parentphone').val(response.data.parentPhone)
                    $('#studentemail').val(response.data.email)
                    $('#studentaddress').val(response.data.address)
                    $('#studentqualifications').val(response.data.qualification)
                    $('#studentcollegename').val(response.data.schoolOrCollegeName)
                    $('#studenttuitionname').val(response.data.classOrTuitionName)
                    $(`#studentcategory option[value='${response.data.category}']`).attr("selected","selected");
                    selectBranch = response.data.branch.name
                    
                    loadBranchesList()

                    // $('#viewenquiry #enquiry-selected').html(`<h2>Loading...</h2>`)
                    // enquiryname = `${response.data.firstName} ${response.data.middleName} ${response.data.lastName}`
                    // enquiryID = response.data._id
                    var enquiryrefname = response.data.reference ? response.data.reference._id : ''

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    // var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    // var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    // var dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", date_options)
                    var dobEnglishIST = ''
                    if (response.data.dob) {
                        dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", optionsCheck)
                    }
                    var joindateEnglishIST = new Date(response.data.joiningDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var edu_details = ''
                    if (response.data.qualification != '') {
                        const edu_string = response.data.qualification.split(',')
                        // console.log(response.data.qualification);
                        edu_string.forEach(edu => {
                            edu_details += `<span class="badge badge-light mt-0">${edu}</span>`
                        });
                    }
                    var courses = response.data.courses
                    selectedCoursesIDs = response.data.courses.split(',')

                    // Social media details
                    var social_details = ''

                    const facebook = response.data.facebook
                    facebook ? social_details += `<div class="col col-6 mb-2"><img id="facebook-icon" src="/images/enquiries/facebook-yes.png" width="25" alt=""> &nbsp;${facebook}</div>` : ''

                    const instagram = response.data.instagram
                    instagram ? social_details += `<div class="col col-6 mb-2"><img id="instagram-icon" src="/images/enquiries/instagram-yes.png" width="25" alt="">&nbsp; ${instagram}</div>` : ''

                    const youtube = response.data.youtube
                    youtube ? social_details += `<div class="col col-6 mb-2"><img id="youtube-icon" src="/images/enquiries/youtube-yes.png" width="25" alt=""> &nbsp;${youtube}</div>` : ''

                    const twitter = response.data.twitter
                    twitter ? social_details += `<div class="col col-6 mb-2"><img id="twitter-icon" src="/images/enquiries/twitter-yes.png" width="25" alt=""> &nbsp;${twitter}</div>` : ''

                    const linkedin = response.data.linkedin
                    linkedin ? social_details += `<div class="col col-6 mb-2"><img id="linkedin-icon" src="/images/enquiries/linkedin-yes.png" width="25" alt=""> &nbsp;${linkedin}</div>` : ''

                    if (!facebook && !instagram && !youtube && !twitter && !linkedin) {
                        social_details = 'No social media links added'
                    }

                    // Reference Details
                    var reference_details = ''
                    if (response.data.reference) {
                        if (response.data.reference.ref1Name || response.data.reference.ref1Phone || response.data.reference.ref1Category || response.data.reference.ref1Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref1Name ? response.data.reference.ref1Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref1Phone ? response.data.reference.ref1Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref1Category ? response.data.reference.ref1Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref1Area ? response.data.reference.ref1Area : ''}
                            </div>`
                        }
                        if (response.data.reference.ref2Name || response.data.reference.ref2Phone || response.data.reference.ref2Category || response.data.reference.ref2Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref2Name ? response.data.reference.ref2Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref2Phone ? response.data.reference.ref2Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref2Category ? response.data.reference.ref2Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref2Area ? response.data.reference.ref2Area : ''}
                            </div>`
                        }
                        if (response.data.reference.ref3Name || response.data.reference.ref3Phone || response.data.reference.ref3Category || response.data.reference.ref3Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref3Name ? response.data.reference.ref3Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref3Phone ? response.data.reference.ref3Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref3Category ? response.data.reference.ref3Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref3Area ? response.data.reference.ref3Area : ''}
                            </div>`
                        }
                        if (!response.data.reference.ref1Name && !response.data.reference.ref1Phone && !response.data.reference.ref1Category && !response.data.reference.ref1Area && !response.data.reference.ref2Name && !response.data.reference.ref2Phone && !response.data.reference.ref2Category && !response.data.reference.ref2Area && !response.data.reference.ref3Name && !response.data.reference.ref3Phone && !response.data.reference.ref3Category && !response.data.reference.ref3Area) {
                            reference_details = 'No reference detials added'
                        }
                    } else {
                        reference_details = 'No reference detials added'
                    }

                    // Aadhaar number validation if available or not
                    var aadhaarNumber = ''
                    if (response.data.aadhaarNo) {

                        var aNo = response.data.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    }
                    // console.log(response.data.takenby);
                    if (response.data.takenby) {
                        // console.log('hide');
                        var other = `style="opacity:0;"`
                    } else {
                        // console.log('visible');
                        var other = ''
                    }

                    var enquiry_data = `
                    <div class="d-flex mb-3 pl-1">
                        <img src="/images/enquiries/enquiry2.png" width="70" alt="">
                        <div align="left" class="ml-4">
                            <small>Enquiry Name (Firstname Middlename Lastname)</small>
                            <h2>${response.data.firstName} ${response.data.middleName} ${response.data.lastName}</h2>
                        </div>
                    </div>

                    <!-- Personal Details --><span id="personal-details">
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Personal Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div id="dobEnglishIST" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Date of Birth</small>
                            </div>
                            <div>${dobEnglishIST}</div>
                        </div>
                        <div id="gender" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-venus-mars"></i>
                                <small>Gender</small>
                            </div>
                            <div>${response.data.gender}</div>
                        </div>
                        <div id="aadhaarNumber" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card"></i>
                                <small>Aadhaar No.</small>
                            </div>
                            <div>${aadhaarNumber}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div id="religion" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-dove"></i>
                                <small>Religion</small>
                            </div>
                            <div>${response.data.religion}</div>
                        </div>
                        <div id="caste" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-podcast"></i>
                                <small>Caste</small>
                            </div>
                            <div>${response.data.caste}</div>
                        </div>
                        <div id="rel_cas_extra" class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card"></i>
                                <small>Aadhaar</small>
                            </div>
                            <div>1234-5678-2</div>
                        </div>
                    </div></span>

                    <!-- Family Details --><span id="family-details">
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Family Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div id="fatherOccupation" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-briefcase"></i>
                            <small>Father Occupation</small>
                        </div>
                        <div>${response.data.fatherOccupation}</div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div id="motherName" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-female"></i>
                                <small>Mother Name</small>
                            </div>
                            <div>${response.data.motherName}</div>
                        </div>
                        <div id="motherTongue" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-language"></i>
                                <small>Mother Tongue</small>
                            </div>
                            <div>${response.data.motherTongue}</div>
                        </div>
                        <div class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card"></i>
                                <small>Aadhaar</small>
                            </div>
                            <div>1234-</div>
                        </div>
                    </div></span>

                    <!-- Contact Details --><span id="contact-details">
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Contact Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div id="phone1" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <small>Phone 1</small>
                            </div>
                            <div>${response.data.phone1}</div>
                        </div>
                        <div id="phone2" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-phone"></i>
                                <small>Phone 2</small>
                            </div>
                            <div>${response.data.phone2}</div>
                        </div>
                        <div id="parentPhone" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-phone"></i>
                                <small>Parent Phone</small>
                            </div>
                            <div>${response.data.parentPhone}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div id="email" class="mt-2">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                <small>Email</small>
                            </div>
                            <div>${response.data.email}</div>
                        </div>
                    </div>

                    <div id="area" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <small>Area</small>
                        </div>
                        <h5>${response.data.area}</h5>
                    </div>

                    <div id="address" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <small>Full Address</small>
                        </div>
                        <h5>${response.data.address}</h5>
                    </div>
                    </span>

                    <!-- Educational Details --><span id="educational-details">
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Educational Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div id="courses" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-graduate" aria-hidden="true"></i>
                            <small>Course(s)</small>
                        </div>
                        <h4 id="courses_list">${courses}</h4>
                    </div>

                    <div id="edu_details" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-graduate" aria-hidden="true"></i>
                            <small>Educational Qualification(s)</small>
                        </div>
                        <h4>${edu_details}</h4>
                    </div>

                    <div class="d-flex justify-content-between mt-3 row">
                        <div id="schoolOrCollegeName" align="left" class="mt-0 col col-8">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-school"></i>
                                <small>School or College Name</small>
                            </div>
                            <div>${response.data.schoolOrCollegeName}</div>
                        </div>
                        <div id="classOrTuitionName" align="left" class="mt-0 col col-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-building"></i>
                                <small>Class or Tuition Name</small>
                            </div>
                            <div>${response.data.classOrTuitionName}</div>
                        </div>
                    </div></span>

                    <!-- Other Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Other Details</h5>
                    <hr class="bg-success mt-0 mb-2">
                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card" aria-hidden="true"></i>
                                <small>Enquiry taken by staff</small>
                            </div>
                            <div>${response.data.takenby ? response.data.takenby.name : 'Other'}</div>
                        </div>
                        <div id="otherstaff" align="left" class="mt-0" ${other}>
                            <div class="d-flex align-items-center">
                                <i class="fas fa-id-badge"></i>
                                <small>Other staff</small>
                            </div>
                            <div>${response.data.takenbyother}</div>
                        </div>
                        <div align="left" class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-people-arrows"></i>
                                <small>Ref</small>
                            </div>
                            <div></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-building" aria-hidden="true"></i>
                                <small>Branch</small>
                            </div>
                            <div>${response.data.branch.name}</div>
                        </div>
                        <div id="category" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-user-tag"></i>
                                <small>Category</small>
                            </div>
                            <div>${response.data.category ? response.data.category : ''}</div>
                        </div>
                        <div align="left" class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-people-arrows"></i>
                                <small>Ref</small>
                            </div>
                            <div></div>
                        </div>
                    </div>
                    <div align="left" class="mt-2 w-100">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-share-alt"></i>
                            <small>Social Media</small>
                        </div>
                        <div class="ml-3 row">${social_details}</div>
                    </div>
                    <div align="left" class="mt-2 w-100">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-people-arrows"></i>
                            <small>Reference</small>
                        </div>
                        <div class="ml-3 row">${reference_details}</div>
                    </div>

                    <div id="hidden_note" class="mt-3" style="color:#c84648;">
                    <span style="color:#2a2829;background-color:#eff2f6;padding:1px 3px;border-radius:4px"><b>NOTE</span> 
                    Empty fields are hidden. Kindly click on edit button to add those fields.</b></div>

                    <div class="d-flex justify-content-between mt-3">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                        <div class="mt-3 ml-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewenquiry #enquiry-selected').html(enquiry_data)

                    var hidden = 0
                    editenquiry = `/sdp/admin/editenquiry?enquiry=${enquiryID}`

                    // Hide personal detials
                    if (!dobEnglishIST && !response.data.gender && !aadhaarNumber && !response.data.religion && !response.data.caste) {
                        // All fields blank
                        hidden = 1
                        $('#personal-details').css('display','none')
                    } else {
                        // Some fields are present
                        dobEnglishIST ? '' : $('#dobEnglishIST').css('display','none')
                        response.data.gender ? '' : $('#gender').css('display','none')
                        aadhaarNumber ? '' : $('#aadhaarNumber').css('display','none')
                        response.data.religion ? '' : $('#religion').css('display','none')
                        response.data.caste ? '' : $('#caste').css('display','none')
                        if (!response.data.religion && !response.data.caste) {
                            $('#rel_cas_extra').css('display','none')
                        }
                    }

                    // Hide empty family details
                    if (!response.data.fatherOccupation && !response.data.motherName && !response.data.motherTongue) {
                        // All fields blank
                        hidden = 1
                        $('#family-details').css('display','none')
                    } else {
                        // Some fields are present
                        response.data.fatherOccupation ? '' : $('#fatherOccupation').css('display','none')
                        response.data.motherName ? '' : $('#motherName').css('display','none')
                        response.data.motherTongue ? '' : $('#motherTongue').css('display','none')
                    }

                    // Hide empty contact details
                    if (!response.data.phone1 && !response.data.phone2 && !response.data.parentPhone && !response.data.email && !response.data.address) {
                        // All fields blank
                        hidden = 1
                        $('#contact-details').css('display','none');
                    } else {
                        // Some fields are present
                        response.data.phone1 ? '' : $('#phone1').css('display','none')
                        response.data.phone2 ? '' : $('#phone2').css('display','none')
                        response.data.parentPhone ? '' : $('#parentPhone').css('display','none')
                        response.data.email ? '' : $('#email').css('display','none')
                        response.data.address ? '' : $('#address').css('display','none')
                    }

                    // Hide empty educational details
                    // console.log(edu_details);
                    if (!courses && !edu_details && !response.data.schoolOrCollegeName && !response.data.classOrTuitionName) {
                        // All fields blank
                        hidden = 1
                        $('#educational-details').css('display','none')
                    } else {
                        // Some fields are present
                        edu_details ? '' : $('#edu_details').css('display','none')
                        response.data.schoolOrCollegeName ? '' : $('#schoolOrCollegeName').css('display','none')
                        response.data.classOrTuitionName ? '' : $('#classOrTuitionName').css('display','none')
                    }

                    response.data.category ? '' : $('#category').css('display','none')

                    if (hidden === 0) {
                        $('#hidden_note').css('display','none')
                    }

                    createCoursesUI()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Enquiry Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_enquiries tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-enquiry-card button').attr('disabled', true)
                    $('#enquiry-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-enquiry-card button').attr('disabled', true)
                    $('#enquiry-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch enquiries list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_enquiries tbody .col').html(errorMsg)
                    $('#enquiry-selected').html(errorMsg)
                }

            }
        });
    }
}

if (selected) {
    getEnquiryDetails()
} else {
    loadBranchesList()
}

$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-students').trigger("click")
$('#sidebar-students,#sidebar-students-add').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

// Reference forms toggle
$('#ref1,#ref2,#ref3').fadeOut()
$('#btn-ref1').click(() => {
    $('#ref1').fadeIn(250)
    document.getElementById('btn-ref1').classList.remove('no-ref')
    $('#ref2,#ref3').fadeOut(100)
    document.getElementById('btn-ref2').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref2').click(() => {
    $('#ref2').fadeIn(250)
    document.getElementById('btn-ref2').classList.remove('no-ref')
    $('#ref1,#ref3').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref3').click(() => {
    $('#ref3').fadeIn(250)
    document.getElementById('btn-ref3').classList.remove('no-ref')
    $('#ref1,#ref2').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref2').classList.add('no-ref')

})

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

// Aadhaar validation start - https://stackoverflow.com/a/47428241
$('[data-type="adhaar-number"]').keyup(function () {
    var value = $(this).val();
    value = value.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
    $(this).val(value);
});

// $('[data-type="adhaar-number"]').on("change, blur", function () {
//     var value = $(this).val();
//     var maxLength = $(this).attr("maxLength");
//     if (value.length != maxLength) {
//         $(this).addClass("highlight-error");
//     } else {
//         $(this).removeClass("highlight-error");
//     }
// });
// Aadhaar validation end

// Social media icon color
$('#studentsocialmedia-facebook').keyup(() => {
    const facebook = $('#studentsocialmedia-facebook').val()
    if (facebook != '') {
        $('#facebook-icon').attr('src', '/images/students/facebook-yes.png')
    } else {
        $('#facebook-icon').attr('src', '/images/students/facebook-no.png')
    }
})
$('#studentsocialmedia-instagram').keyup(() => {
    const instagram = $('#studentsocialmedia-instagram').val()
    if (instagram != '') {
        $('#instagram-icon').attr('src', '/images/students/instagram-yes.png')
    } else {
        $('#instagram-icon').attr('src', '/images/students/instagram-no.png')
    }
})
$('#studentsocialmedia-youtube').keyup(() => {
    const youtube = $('#studentsocialmedia-youtube').val()
    if (youtube != '') {
        $('#youtube-icon').attr('src', '/images/students/youtube-yes.png')
    } else {
        $('#youtube-icon').attr('src', '/images/students/youtube-no.png')
    }
})
$('#studentsocialmedia-twitter').keyup(() => {
    const twitter = $('#studentsocialmedia-twitter').val()
    if (twitter != '') {
        $('#twitter-icon').attr('src', '/images/students/twitter-yes.png')
    } else {
        $('#twitter-icon').attr('src', '/images/students/twitter-no.png')
    }
})
$('#studentsocialmedia-linkedin').keyup(() => {
    const linkedin = $('#studentsocialmedia-linkedin').val()
    if (linkedin != '') {
        $('#linkedin-icon').attr('src', '/images/students/linkedin-yes.png')
    } else {
        $('#linkedin-icon').attr('src', '/images/students/linkedin-no.png')
    }
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Student...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;
const courses_all_list = [];

function createStudent() {
    // Form 1
    const firstname = $('#firstname').val()
    const middlename = $('#middlename').val()
    const lastname = $('#lastname').val()
    const studentdob = $('#studentdob').val()
    const studentgender = $('#studentgender').val()
    const studentaadhaar = $('#studentaadhaar').val()
    const studentreligion = $('#studentreligion').val()
    const studentcaste = $('#studentcaste').val()

    // Form 2
    const fatheroccupation = $('#fatheroccupation').val()
    const mothername = $('#mothername').val()
    const mothertongue = $('#mothertongue').val()

    // Form 3
    const phone1 = $('#phone1').val()
    const phone2 = $('#phone2').val()
    const parentphone = $('#parentphone').val()
    const studentemail = $('#studentemail').val()
    const studentaddress = $('#studentaddress').val()

    // Form 4
    const studentqualifications = $('#studentqualifications').val()
    const studentcollegename = $('#studentcollegename').val()
    const studenttuitionname = $('#studenttuitionname').val()

    // Form 5
    const studentcategory = $('#studentcategory').val()
    const studentbranch = $('#studentbranch').val()

    // Social Media
    const facebook = $('#studentsocialmedia-facebook').val() || null
    const instagram = $('#studentsocialmedia-instagram').val() || null
    const youtube = $('#studentsocialmedia-youtube').val() || null
    const twitter = $('#studentsocialmedia-twitter').val() || null
    const linkedin = $('#studentsocialmedia-linkedin').val() || null

    // Reference 1
    const ref1_name = $('#ref1_name').val()
    const ref1_phone = $('#ref1_phone').val()
    const ref1_category = $('#ref1_category').val()
    const ref1_area = $('#ref1_area').val()
    // Reference 2
    const ref2_name = $('#ref2_name').val()
    const ref2_phone = $('#ref2_phone').val()
    const ref2_category = $('#ref2_category').val()
    const ref2_area = $('#ref2_area').val()
    // Reference 3
    const ref3_name = $('#ref3_name').val()
    const ref3_phone = $('#ref3_phone').val()
    const ref3_category = $('#ref3_category').val()
    const ref3_area = $('#ref3_area').val()

    var studentaadhaar_final = studentaadhaar.split('-').join('')
    // console.log(studentaadhaar_final);

    if (!firstname || !middlename || !lastname || !studentdob || !studentgender || !studentreligion || !studentcaste || !fatheroccupation || !mothername || !mothertongue || !phone1 || !studentemail || !studentaddress || !studentqualifications || !studentcollegename || !studenttuitionname || !studentcategory || !studentbranch) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in student form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Create Student Record
        loading()

        $.ajax({
            url: '/sdp/students',
            method: 'post',
            dataType: 'json',
            data: {
                firstName: firstname,
                middleName: middlename,
                lastName: lastname,
                dob: studentdob,
                gender: studentgender,
                aadhaarNo: studentaadhaar_final,
                religion: studentreligion,
                caste: studentcaste,
                fatherOccupation: fatheroccupation,
                motherName: mothername,
                motherTongue: mothertongue,
                phone1: phone1,
                phone2: phone2,
                parentPhone: parentphone,
                email: studentemail,
                address: studentaddress,
                qualification: studentqualifications,
                schoolOrCollegeName: studentcollegename,
                classOrTuitionName: studenttuitionname,
                category: studentcategory,
                branch: studentbranch,
                facebook: facebook,
                instagram: instagram,
                youtube: youtube,
                twitter: twitter,
                linkedin: linkedin,
                enquiry: selected
            },
            success: function (response) {
                if (response.success) {

                    const new_student_id = response.data._id
                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    // if (ref1_name || ref1_phone || ref1_category || ref1_area || ref2_name || ref2_phone || ref2_category || ref2_area || ref3_name || ref3_phone || ref3_category || ref3_area) {

                        // Reference available
                        $.ajax({
                            url: '/sdp/references',
                            method: 'post',
                            dataType: 'json',
                            data: {
                                ref1Name: ref1_name,
                                ref1Phone: ref1_phone,
                                ref1Category: ref1_category,
                                ref1Area: ref1_area,

                                ref2Name: ref2_name,
                                ref2Phone: ref2_phone,
                                ref2Category: ref2_category,
                                ref2Area: ref2_area,

                                ref3Name: ref3_name,
                                ref3Phone: ref3_phone,
                                ref3Category: ref3_category,
                                ref3Area: ref3_area,

                                branch: studentbranch,
                                student: new_student_id
                            },
                            success: function (response) {
                                if (response.success) {

                                    const new_reference_id = response.data._id

                                    // Update student
                                    $.ajax({
                                        url: `/sdp/students/${new_student_id}`,
                                        method: 'put',
                                        dataType: 'json',
                                        data: {
                                            reference: new_reference_id
                                        },
                                        success: function (response) {
                                            if (response.success) {

                                                // Send whatsapp message to student
                                                $.ajax({
                                                    url: `/sdp/whatsapp/welcomestudent`,
                                                    method: 'post',
                                                    dataType: 'json',
                                                    data: {
                                                        name: `${firstname} ${lastname}`,
                                                        branch: studentbranch,
                                                        phone: phone1
                                                    },
                                                    success: function (response) {
                                                        if (response.success) {
                                                            if (selected) {

                                                                // Update enquiry
                                                                $.ajax({
                                                                    url: `/sdp/enquiries/${selected}`,
                                                                    method: 'put',
                                                                    dataType: 'json',
                                                                    data: {
                                                                        admission: true
                                                                    },
                                                                    success: function (response) {
                                                                        if (response.success) {
                                                                            // Student data added
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: `<div class="text-success">Student Details Added</div>`,
                                                                                html: `<h5>We have sent a welcome message to the student's <img src="/images/students/whatsapp.png" height="25" alt=""> WhatsApp number`,                                
                                                                                confirmButtonText: `<div class="text-dark">Students List</div>`,
                                                                                confirmButtonColor: '#fff',
                                                                                allowOutsideClick: false,
                                                                                showDenyButton: true,
                                                                                denyButtonText: 'New admission',
                                                                                denyButtonColor: '#0b6fad',
                                                                                focusConfirm: false
                                                                            }).then((result) => {
                                                                                /* Read more about isConfirmed, isDenied below */
                                                                                if (result.isConfirmed) {
                                                                                    Swal.fire({
                                                                                        toast: true,
                                                                                        position: 'top-right',
                                                                                        icon: 'success',
                                                                                        title: 'Redirecting...',
                                                                                        timer: 1000,
                                                                                        showConfirmButton: false
                                                                                    });
                                                                                    setTimeout(() => {
                                                                                        document.location.replace('/sdp/admin/students');
                                                                                    }, 1000);
                                                                                } else if (result.isDenied) {
                                                                                    Swal.fire({
                                                                                        toast: true,
                                                                                        position: 'top-right',
                                                                                        icon: 'success',
                                                                                        title: 'Redirecting...',
                                                                                        timer: 1000,
                                                                                        showConfirmButton: false
                                                                                    });
                                                                                    setTimeout(() => {
                                                                                        document.location.replace('/sdp/admin/addadmission');
                                                                                    }, 1000);
                                                                                }
                                                                            })
                                                                        }else{
                                                                            console.log(response);
                                                                        }
                                                                    },
                                                                    error: function (response) {
                                                                        console.log(response);
                                                                    }
                                                                })
                                                                
                                                            } else {
                                                                // Student data added
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: `<div class="text-success">Student Details Added</div>`,
                                                                    html: `<h5>We have sent a welcome message to the student's <img src="/images/students/whatsapp.png" height="25" alt=""> WhatsApp number`,                                
                                                                    confirmButtonText: `<div class="text-dark">Students List</div>`,
                                                                    confirmButtonColor: '#fff',
                                                                    allowOutsideClick: false,
                                                                    showDenyButton: true,
                                                                    denyButtonText: 'New admission',
                                                                    denyButtonColor: '#0b6fad',
                                                                    focusConfirm: false
                                                                }).then((result) => {
                                                                    /* Read more about isConfirmed, isDenied below */
                                                                    if (result.isConfirmed) {
                                                                        Swal.fire({
                                                                            toast: true,
                                                                            position: 'top-right',
                                                                            icon: 'success',
                                                                            title: 'Redirecting...',
                                                                            timer: 1000,
                                                                            showConfirmButton: false
                                                                        });
                                                                        setTimeout(() => {
                                                                            document.location.replace('/sdp/admin/students');
                                                                        }, 1000);
                                                                    } else if (result.isDenied) {
                                                                        Swal.fire({
                                                                            toast: true,
                                                                            position: 'top-right',
                                                                            icon: 'success',
                                                                            title: 'Redirecting...',
                                                                            timer: 1000,
                                                                            showConfirmButton: false
                                                                        });
                                                                        setTimeout(() => {
                                                                            document.location.replace('/sdp/admin/addadmission');
                                                                        }, 1000);
                                                                    }
                                                                })
                                                            }
                                                        } else {

                                                            $('#loading').css('display', 'none');
                                                            $('#error').text(response.responseJSON.error);
                                                            console.log(response);
                                                            $('#error').fadeIn();
                                                            $('#error').css('display', 'block');
                                                            $('#add-student-card button').attr('disabled', true)
            
                                                        }
                                                    },
                                                    error: function (response) {
            
                                                        $('#loading').css('display', 'none');
                                                        $('#error').text(response);
                                                        console.log(response);
                                                        $('#error').fadeIn();
                                                        $('#error').css('display', 'block');
                                                        $('#add-student-card button').attr('disabled', true)
            
                                                    }
                                                });

                                            } else {

                                                $('#loading').css('display', 'none');
                                                $('#error').text(response.responseJSON.error);
                                                console.log(response);
                                                $('#error').fadeIn();
                                                $('#error').css('display', 'block');
                                                $('#add-student-card button').attr('disabled', true)

                                            }
                                        },
                                        error: function (response) {

                                            $('#loading').css('display', 'none');
                                            $('#error').text(response);
                                            console.log(response);
                                            $('#error').fadeIn();
                                            $('#error').css('display', 'block');
                                            $('#add-student-card button').attr('disabled', true)

                                        }
                                    });

                                } else {

                                    $('#loading').css('display', 'none');
                                    $('#table_branches tbody tr').text(response.responseJSON.error);
                                    console.log(response);
                                    $('#errors').fadeIn();
                                    $('#errors').css('display', 'block');
                                    $('#add-branch-card button').attr('disabled', true)

                                }
                            },
                            error: function (response) {

                                if (response.responseJSON) {
                                    $('#loading').css('display', 'none');
                                    $('#errors').text(response.responseJSON.error);
                                    console.log(response.responseJSON.error);
                                    $('#errors').fadeIn();
                                    // $('#errors').css('display', 'block');
                                    $('#add-branch-card button').attr('disabled', true)

                                } else {
                                    $('#errors').fadeIn();
                                    var errorMsg = `
                                    <center class="text-danger">
                                    <h2>Oops! Something went wrong</h2>
                                    <h4>
                                        Error Code: ${response.status} <br>
                                        Error Message: ${response.statusText}
                                    </h4>
                                    <h5>We were unable to fetch branches list</h5>
                                    <h6>
                                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                    </h6>
                                    </center>`
                                    console.log(`something went wrong ${JSON.stringify(response)}`);
                                    // console.log(response.statusText);
                                    // $('#table_branches tbody .col').html(errorMsg)
                                    $('#errors').html(errorMsg)
                                }

                            }
                        });
                    // } else {
                    //     Swal.fire({
                    //         icon: 'success',
                    //         title: `<div class="text-success">Student Added</div>`,
                    //         confirmButtonText: 'Okay',
                    //         confirmButtonColor: '#0b6fad',
                    //         allowOutsideClick: false,
                    //         // width: '45rem'
                    //     }).then((result) => {
                    //         /* Read more about isConfirmed, isDenied below */
                    //         if (result.isConfirmed) {
                    //             Swal.fire({
                    //                 toast: true,
                    //                 position: 'top-right',
                    //                 icon: 'success',
                    //                 title: 'Redirecting...',
                    //                 timer: 1000,
                    //                 showConfirmButton: false
                    //             });
                    //             setTimeout(() => {
                    //                 document.location.replace('/sdp/admin/students');
                    //             }, 1000);
                    //         }
                    //     })
                    // }

                } else {

                    $('#loading').css('display', 'none');
                    console.log(response);
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New student trigger
        createStudent()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addstudent-form1,#addstudent-form2,#addstudent-form3,#addstudent-form4,#addstudent-form5,#addstudent-form6').removeClass('active')
    $(`#addstudent-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 5) {
        $('#next').text('Review')
    } else if (actives.length === 6) {

        $('#next').text('Submit')
        // Form 1
        const firstname = $('#firstname').val()
        const middlename = $('#middlename').val()
        const lastname = $('#lastname').val()
        const studentdob = $('#studentdob').val()
        const studentgender = $('#studentgender').val()
        const studentaadhaar = $('#studentaadhaar').val()
        const studentreligion = $('#studentreligion').val()
        const studentcaste = $('#studentcaste').val()

        // Form 2
        const fatheroccupation = $('#fatheroccupation').val()
        const mothername = $('#mothername').val()
        const mothertongue = $('#mothertongue').val()

        // Form 3
        const phone1 = $('#phone1').val()
        const phone2 = $('#phone2').val()
        const parentphone = $('#parentphone').val()
        const studentemail = $('#studentemail').val()
        const studentaddress = $('#studentaddress').val()

        // Form 4
        const studentqualifications = $('#studentqualifications').val()
        const studentcollegename = $('#studentcollegename').val()
        const studenttuitionname = $('#studenttuitionname').val()

        // Form 5
        const studentcategory = $('#studentcategory').val()
        const studentbranch = $('#studentbranch').val()

        // Social Media
        const facebook = $('#studentsocialmedia-facebook').val()
        const instagram = $('#studentsocialmedia-instagram').val()
        const youtube = $('#studentsocialmedia-youtube').val()
        const twitter = $('#studentsocialmedia-twitter').val()
        const linkedin = $('#studentsocialmedia-linkedin').val()
        var socialmedia = ``
        facebook ? socialmedia += `<div><img id="facebook-icon" src="/images/students/facebook-yes.png" width="30" alt=""> ${facebook}</div><br>` : ''
        instagram ? socialmedia += `<div><img id="instagram-icon" src="/images/students/instagram-yes.png" width="30" alt=""> ${instagram}</div><br>` : ''
        youtube ? socialmedia += `<div><img id="youtube-icon" src="/images/students/youtube-yes.png" width="30" alt=""> ${youtube}</div><br>` : ''
        twitter ? socialmedia += `<div><img id="twitter-icon" src="/images/students/twitter-yes.png" width="30" alt=""> ${twitter}</div><br>` : ''
        linkedin ? socialmedia += `<div><img id="linkedin-icon" src="/images/students/linkedin-yes.png" width="30" alt=""> ${linkedin}</div>` : ''

        var references = ``
        // Reference 1
        const ref1_name = $('#ref1_name').val()
        const ref1_phone = $('#ref1_phone').val()
        const ref1_category = $('#ref1_category').val()
        const ref1_area = $('#ref1_area').val()
        if (ref1_name || ref1_phone || ref1_category || ref1_area) {
            references += `
            <div class="card p-1" style="background-color:#B2D57A;width:fit-content;">
                <div><b>Reference 1 Details</b></div>
                <div>Name: ${ref1_name}</div>
                <div>Contact: ${ref1_phone}</div>
                <div>Category: ${ref1_category}</div>
                <div>Area: ${ref1_area}</div>
            </div>`
        }
        // Reference 2
        const ref2_name = $('#ref2_name').val()
        const ref2_phone = $('#ref2_phone').val()
        const ref2_category = $('#ref2_category').val()
        const ref2_area = $('#ref2_area').val()
        if (ref2_name || ref2_phone || ref2_category || ref2_area) {
            references += `
            <div class="card p-1 mt-2" style="background-color:#B2D57A;width:fit-content;">
                <div><b>Reference 2 Details</b></div>
                <div>Name: ${ref2_name}</div>
                <div>Contact: ${ref2_phone}</div>
                <div>Category: ${ref2_category}</div>
                <div>Area: ${ref2_area}</div>
            </div>`
        }
        // Reference 3
        const ref3_name = $('#ref3_name').val()
        const ref3_phone = $('#ref3_phone').val()
        const ref3_category = $('#ref3_category').val()
        const ref3_area = $('#ref3_area').val()
        if (ref3_name || ref3_phone || ref3_category || ref3_area) {
            references += `
            <div class="card p-1 mt-2" style="background-color:#B2D57A;width:fit-content;">
                <div><b>Reference 3 Details</b></div>
                <div>Name: ${ref3_name}</div>
                <div>Contact: ${ref3_phone}</div>
                <div>Category: ${ref3_category}</div>
                <div>Area: ${ref3_area}</div>
            </div>`
        }

        $('#display-firstname').html(firstname ? firstname : '<span class="text-danger">First Name field is empty</span>')
        $('#display-middlename').html(middlename ? middlename : '<span class="text-danger">Middle Name field is empty</span>')
        $('#display-lastname').html(lastname ? lastname : '<span class="text-danger">Last Name field is empty</span>')
        $('#display-studentdob').html(studentdob ? studentdob : '<span class="text-danger">Date of Birth field is empty</span>')
        $('#display-studentgender').html(studentgender ? studentgender : '<span class="text-danger">Please select Gender</span>')
        $('#display-studentaadhaar').html(studentaadhaar ? studentaadhaar : '<span class="text-dark">Aadhaar field is empty</span>')
        $('#display-studentreligion').html(studentreligion ? studentreligion : '<span class="text-danger">Religion field is empty</span>')
        $('#display-studentcaste').html(studentcaste ? studentcaste : '<span class="text-danger">Caste field is empty</span>')
        $('#display-fatheroccupation').html(fatheroccupation ? fatheroccupation : '<span class="text-danger">Father Occupation field is empty</span>')
        $('#display-mothername').html(mothername ? mothername : '<span class="text-danger">Mother Name field is empty</span>')
        $('#display-mothertongue').html(mothertongue ? mothertongue : '<span class="text-danger">Mother Tongue field is empty</span>')
        $('#display-phone1').html(phone1 ? phone1 : '<span class="text-danger">Student Phone 1 field is empty</span>')
        $('#display-phone2').html(phone2 ? phone2 : '<span class="text-dark">Student Phone 2 field is empty</span>')
        $('#display-parentphone').html(parentphone ? parentphone : '<span class="text-dark">Parent Phone field is empty</span>')
        $('#display-studentemail').html(studentemail ? studentemail : '<span class="text-danger">Student Email field is empty</span>')
        $('#display-studentaddress').html(studentaddress ? studentaddress : '<span class="text-danger">Student Address field is empty</span>')
        $('#display-studentqualifications').html(studentqualifications ? studentqualifications : '<span class="text-danger">Student Qualification field is empty</span>')
        $('#display-studentcollegename').html(studentcollegename ? studentcollegename : '<span class="text-danger">Student College Name field is empty</span>')
        $('#display-studenttuitionname').html(studenttuitionname ? studenttuitionname : '<span class="text-danger">Student Tuition Name field is empty</span>')
        $('#display-studentcategory').html(studentcategory ? studentcategory : '<span class="text-danger">Please select Category</span>')
        $('#display-studentbranch').html(studentbranch ? studentbranch : '<span class="text-danger">Please select Branch</span>')
        $('#display-studentsocialmedia').html(socialmedia ? socialmedia : '<span class="text-dark">Student Social Media field is empty</span>')
        $('#display-studentreference').html(references ? references : '<span class="text-dark">Student Reference field is empty</span>')


        if (!firstname || !middlename || !lastname || !studentdob || !studentgender || !studentreligion || !studentcaste || !fatheroccupation || !mothername || !mothertongue || !phone1 || !studentemail || !studentaddress || !studentqualifications || !studentcollegename || !studenttuitionname || !studentcategory || !studentbranch) {
            next.disabled = true
        } else {
            finalSubmit = 1
            next.disabled = false
        }
    }
}
// Progress Steps JS End

function loadBranchesList() {

    $.ajax({
        url: '/sdp/branches',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var branches_list;
                $('#studentbranch').text(response.data)

                if (response.data.length == 0) {
                    branches_list += `<option value="">Branch List is empty</option>`;
                } else {
                    branches_list = `<option value="">Select Branch Name</option>`;
                    response.data.forEach(branch => {

                        branches_list += `
                        <option value="${branch.name}">${branch.name}</option>`;
                    });
                }

                $('#studentbranch').html(branches_list)
                // console.log(selectBranch);
                $(`#studentbranch option[value='${selectBranch}']`).attr("selected","selected");

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Branches Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}

// Feb 2023 update
function checkPhoneNo(ph) {
    // alert('phone changed to ' + ph)
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Checking phone number...',
        showConfirmButton: false
    });

    $.ajax({
        url: `/sdp/students/${ph}`,
        method: 'post',
        success: function (response) {
            if (response.success) {
                // alert(response.data.firstName)
                Swal.fire({
                    icon: 'warning',
                    title: `<div style="color: #dfa878;"><i class='fas fa-check-double'></i>Duplicate phone number
                    </div>
                    <div style="font-size: 20px;">Phone number <span class="text-danger">${ph}</span> is already allocated to <span style="color: #17a2b8;">${response.data.firstName} ${response.data.middleName} ${response.data.lastName}</span> of branch <span style="color: #91C442;">${response.data.branch}</span></div>`,
                    confirmButtonText: `<div class="text-dark">I don't want to add student</div>`,
                    confirmButtonColor: '#fff',
                    allowOutsideClick: false,
                    showDenyButton: true,
                    denyButtonText: 'I want to add duplicate phone number',
                    denyButtonColor: '#c6956b',
                    focusConfirm: false
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Refreshing page...',
                            timer: 1500,
                            showConfirmButton: false
                        });
                        setTimeout(() => {
                            document.location.replace('/sdp/admin/addstudent');
                        }, 1000);
                    }
                })
            } else {
                Swal.fire({
                    icon: 'success',
                    title: `<div class="text-success"><i class='fas fa-check-double'></i>Unique phone number
                    </div>
                    <div style="font-size: 20px;">${response.data}</div>`,
                    confirmButtonText: `<div class="text-dark">Okay</div>`,
                    confirmButtonColor: '#fff',
                    allowOutsideClick: false,
                    focusConfirm: false
                })

            }
        },
        error: function (response) {
            console.log(response);
            alert(response)
        }
    })
}
$('#phone1').change(() => {
    var ph = $('#phone1').val()
    if (ph != '') {
        checkPhoneNo(ph)
    }
})
$('#phone2').change(() => {
    var ph = $('#phone2').val()
    if (ph != '') {
        checkPhoneNo(ph)
    }
})
$('#parentphone').change(() => {
    var ph = $('#parentphone').val()
    if (ph != '') {
        checkPhoneNo(ph)
    }
})