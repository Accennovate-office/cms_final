
$('#sidebar-managers').trigger("click")
$('#sidebar-managers,#sidebar-managers-delete').addClass('active')
$("div#mySidebar").scrollTop(150); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['manager'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/managers')
})

function loadManagersList() {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading managers list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/managers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var managers_list;
                $('#deletemanager #manager').text(response.data)

                if (response.data.length == 0) {
                    managers_list += `<option value="">Manager List is empty</option>`;
                } else {
                    managers_list = `<option value="">Select Manager Name</option>`;
                    response.data.forEach(manager => {

                        if (manager.user.slug == selected) {

                            managers_list += `
                            <option selected value="${manager.user.slug}">${manager.user.name}</option>`;

                        } else {

                            managers_list += `
                            <option value="${manager.user.slug}">${manager.user.name}</option>`;

                        }
                    });
                }

                $('#deletemanager #manager').html(managers_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Managers Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_managers tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-manager-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-manager-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch managers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_managers tbody .col').html(errorMsg)
                $('#no-manager-selected').html(errorMsg)
            }

        }
    });

}
loadManagersList()

const managername = $('#delete-managername')
const managerdob = $('#delete-managerdob')
const managerphone = $('#delete-managerphone')
const manageremail = $('#delete-manageremail')
const manageraddress = $('#delete-manageraddress')
const manageredu = $('#delete-manageredu')
const managerjoin = $('#delete-managerjoin')
const managerbranch = $('#delete-managerbranch')
const managerjobtime = $('#delete-managerjobtime')
const emailmanager = $('#delete-emailmanager')

const createdat = $('#delete-managercreatedat')
const updatedat = $('#delete-managerupdatedat')
const managerid = $('#delete-managerid')

function getManagerDetails() {

    const selectManager = $('#manager').val() ? $('#manager').val() : selected
    // console.log(selectManager);
    if (selectManager == '') {
        $('#no-manager-selected').css('display', 'block')
        $('#manager-selected').css('display', 'none')
    } else {

        $('#no-manager-selected').css('display', 'none')
        $('#manager-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/managers/${selectManager}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deletemanager #manager-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", date_options)
                    var joindateEnglishIST = new Date(response.data.joiningDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var edu_details = ''
                    const edu_string = response.data.educationalQualification.split(',')
                    // console.log(response.data.educationalQualification);
                    edu_string.forEach(edu => {
                        edu_details += `<span class="badge badge-light">${edu}</span>`
                    });

                    const jobTime = response.data.jobTime.split(',')

                    managername.text(response.data.user.name)
                    managerdob.text(dobEnglishIST)
                    managerphone.text(response.data.phone)
                    manageremail.text(response.data.user.email)
                    manageraddress.text(response.data.address)
                    manageredu.html(edu_details)
                    managerjoin.text(joindateEnglishIST)
                    managerbranch.text(response.data.user.branch)
                    managerjobtime.text(`From ${jobTime[0]} to ${jobTime[1]}`)
                    emailmanager.text(response.data.user.email)

                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    managerid.val(response.data._id)

                    // var manager_data = `
                    // <div class="d-flex mb-3 pl-1">
                    //     <img src="/images/managers/manager2.png" width="70" alt="">
                    //     <div align="left" class="ml-4">
                    //         <small>Manager Name</small>
                    //         <h2>${response.data.user.name}</h2>
                    //     </div>
                    // </div>

                    // <!-- Personal Details -->
                    // <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Personal Details</h5>
                    // <hr class="bg-success mt-0 mb-2">

                    // <div class="d-flex justify-content-between">
                    //     <div align="left" class="mt-0">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-calendar" aria-hidden="true"></i>
                    //             <small>Date of Birth</small>
                    //         </div>
                    //         <div>${dobEnglishIST}</div>
                    //     </div>
                    //     <div class="mt-0">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-phone-alt" aria-hidden="true"></i>
                    //             <small>Phone</small>
                    //         </div>
                    //         <div>${response.data.phone}</div>
                    //     </div>
                    //     <div class="mt-0">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-envelope" aria-hidden="true"></i>
                    //             <small>Email</small>
                    //         </div>
                    //         <div>${response.data.user.email}</div>
                    //     </div>
                    // </div>

                    // <div align="left" class="mt-2">
                    //     <div class="d-flex align-items-center">
                    //         <i class="fa fa-map-marker" aria-hidden="true"></i>
                    //         <small>Full Address</small>
                    //     </div>
                    //     <h5>${response.data.address}</h5>
                    // </div>

                    // <!-- Educational Details -->
                    // <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Educational Details</h5>
                    // <hr class="bg-success mt-0 mb-2">

                    // <div align="left" class="mt-2">
                    //     <div class="d-flex align-items-center">
                    //         <i class="fa fa-user-graduate" aria-hidden="true"></i>
                    //         <small>Educational Qualification(s)</small>
                    //     </div>
                    //     <h4>
                    //         ${edu_details}
                    //     </h4>
                    // </div>

                    // <!-- Organization Details -->
                    // <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Organization Details</h5>
                    // <hr class="bg-success mt-0 mb-2">
                    // <div class="d-flex justify-content-between">
                    //     <div align="left" class="mt-0">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-calendar" aria-hidden="true"></i>
                    //             <small>Date of Joining</small>
                    //         </div>
                    //         <div>${joindateEnglishIST}</div>
                    //     </div>
                    //     <div class="mt-0">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fas fa-building" aria-hidden="true"></i>
                    //             <small>Branch</small>
                    //         </div>
                    //         <div>${response.data.user.branch}</div>
                    //     </div>
                    //     <div class="mt-0">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fas fa-business-time"></i>
                    //             <small>Job Time</small>
                    //         </div>
                    //         <div>From ${jobTime[0]} to ${jobTime[1]}</div>
                    //     </div>
                    // </div>
                    // <!-- Login Details -->
                    // <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Login Details</h5>
                    // <hr class="bg-success mt-0 mb-2">

                    // <div class="d-flex justify-content-between">
                    //     <div align="left" class="mt-0 mr-2">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-envelope" aria-hidden="true"></i>
                    //             <small>Email</small>
                    //         </div>
                    //         <div>${response.data.user.email}</div>
                    //     </div>
                    //     <div class="mt-0 ml-2">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-key" aria-hidden="true"></i>
                    //             <small>Password</small>
                    //         </div>
                    //         <small class="text-danger">
                    //             This password is encrypted (To see orignal password check <a href="#">Login Records</a> section)
                    //         </small>
                    //     </div>
                    //     </div>

                    //     <div class="d-flex justify-content-between mt-5">
                    //     <div align="left" class="mt-3">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-calendar" aria-hidden="true"></i>
                    //             <small>Created At</small>
                    //         </div>
                    //         <div>${createdEnglishIST}</div>
                    //     </div>
                    //     <div class="mt-3">
                    //         <div class="d-flex align-items-center">
                    //             <i class="fa fa-calendar" aria-hidden="true"></i>
                    //             <small>Updated At</small>
                    //         </div>
                    //         <div>${updateValue}</div>
                    //     </div>
                    // </div>
                    // <input id="delete-managerid" value="" style="display:none;">
                    // <button id="delete-manager-btn" class="btn btn-danger mt-4 mb-1 w-100">
                    //     Delete Manager Details
                    // </button>`;

                    // $('#deletemanager #manager-selected').html(manager_data)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Manager Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_managers tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-manager-card button').attr('disabled', true)
                    $('#manager-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-manager-card button').attr('disabled', true)
                    $('#manager-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch managers list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_managers tbody .col').html(errorMsg)
                    $('#no-manager-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-manager-selected').css('display', 'block')
$('#manager-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getManagerDetails()
}
$('#manager').change(() => {

    getManagerDetails()

})

$('#delete-manager-btn').click(() => {
    var delmanagerid = $('#delete-managerid').val()
    var name = managername.text()
    var email = manageremail.text()
    // console.log(delmanagerid);
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${name}</span> manager details!</h4>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: `/sdp/managers/${delmanagerid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        $.ajax({
                            url: `/sdp/users/${email.split('@')[0]}`,
                            method: 'delete',
                            success: function (response) {
                                if (response.success) {

                                    Swal.fire({
                                        toast: true,
                                        position: 'top-right',
                                        icon: 'success',
                                        title: 'Manager Deleted Successfully',
                                        timer: 3000,
                                        showConfirmButton: false
                                    });

                                    $('#no-manager-selected').css('display', 'block')
                                    $('#manager-selected').css('display', 'none')
                                    loadManagersList()

                                    // setTimeout(() => {
                                    //     document.location.replace('/sdp/auth/login');
                                    // }, 1500);

                                } else {

                                    Swal.fire({
                                        icon: 'danger',
                                        title: 'Something went wrong',
                                        text: response.responseJSON.error
                                    });
                                    console.log(response);

                                }
                            },
                            error: function (response) {

                                Swal.fire({
                                    icon: 'danger',
                                    title: 'Server error',
                                    text: response.responseJSON.error
                                });
                                console.log(response);

                            }
                        });
                        // Swal.fire({
                        //     toast: true,
                        //     position: 'top-right',
                        //     icon: 'success',
                        //     title: 'Manager Deleted Successfully',
                        //     timer: 3000,
                        //     showConfirmButton: false
                        // });

                        // $('#no-manager-selected').css('display', 'block')
                        // $('#manager-selected').css('display', 'none')
                        // loadManagersList()

                        // setTimeout(() => {
                        //     document.location.replace('/sdp/auth/login');
                        // }, 1500);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });
                    console.log(response);

                }
            });

        }
    })
})
