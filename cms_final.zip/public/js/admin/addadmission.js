import { loadCoursesList } from "../services/loadList.js";

$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');
$('#inst-date-input,#inst-date-display').fadeOut()

$('#sidebar-admissions').trigger("click")
$('#sidebar-admissions,#sidebar-admissions-add').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

function loading(msg = 'Adding New Admission...') {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">${msg}</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;
const courses_all_list = [];
var admission_branch;

$("input[type='radio'][name='installment']").change(() => {
    const installment = $("input[type='radio'][name='installment']:checked").val();
    if (installment == 'true') {
        $('#inst-date-input,#inst-date-display').fadeIn()
    } else {
        $('#inst-date-input,#inst-date-display').fadeOut()
    }
})

function createAdmission() {
    // Form 1
    const studentname = $('#studentname').val()
    const coursename = $('#coursename').val()
    const admissiondate = $('#admissiondate').val()
    const coursefees = $('#coursefees').val()
    // Form 2
    const batchtime = $('#studentbatchtime').val()
    const teachername = $('#teachername').val()
    const installment = $("input[type='radio'][name='installment']:checked").val();
    var paymenttype
    var installmentdate = undefined
    if (installment == 'true') {
        paymenttype = 'Installment'
        installmentdate = $('#installmentdate').val()
    } else {
        paymenttype = 'One Time'
    }
    // Form 3
    const admissionroll = $('#admissionroll').val()
    const enrollnumber = $('#enrollnumber').val()
    const enrollmonth = $('#enrollmonth').val()
    const enrollpaymentdate = $('#enrollpaymentdate').val()


    if (!studentname || !coursename || !admissiondate || !coursefees || !batchtime || !teachername) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in admission form are empty. Please check the form and submit again.',
        });
    } else {

        if ((installment == 'true' && installmentdate) || installment == 'false') {

            next.disabled = true

            document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

            // Create New Admission
            loading()

            $.ajax({
                url: '/sdp/admissions',
                method: 'post',
                dataType: 'json',
                data: {
                    student: studentname,
                    course: coursename,
                    fees: coursefees,
                    admissionDate: admissiondate,
                    batch: batchtime,
                    teacher: teachername,
                    installment,
                    installmentdate,
                    rollNo: admissionroll,
                    enrollmentMonth: enrollmonth,
                    enrollmentNo: enrollnumber,
                    enrollmentPaymentDate: enrollpaymentdate,
                    branch: admission_branch
                },
                success: function (response) {
                    if (response.success) {

                        $('#error,#loading').css('display', 'none')
                        $('#add-branch-card button').attr('disabled', true)

                        // Admission data added
                        Swal.fire({
                            icon: 'success',
                            title: `<div class="text-success">Admission Details Added</div>`,
                            confirmButtonText: `<div class="text-dark">Admissions List</div>`,
                            confirmButtonColor: '#fff',
                            allowOutsideClick: false,
                            showDenyButton: true,
                            denyButtonText: 'New fee record',
                            denyButtonColor: '#0b6fad',
                            focusConfirm: false
                        }).then((result) => {
                            /* Read more about isConfirmed, isDenied below */
                            if (result.isConfirmed) {
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Redirecting...',
                                    timer: 1000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    document.location.replace('/sdp/admin/admissions');
                                }, 1000);
                            } else if (result.isDenied) {
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Redirecting...',
                                    timer: 1000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    document.location.replace('/sdp/admin/addfee');
                                }, 1000);
                            }
                        })

                    } else {

                        $('#loading').css('display', 'none');
                        $('#error').text(response.responseJSON.error);
                        $('#error').fadeIn();
                        $('#error').css('display', 'block');
                        $('#add-branch-card button').attr('disabled', true)

                    }
                },
                error: function (response) {

                    $('#loading').css('display', 'none');
                    console.log(response);
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            });

        } else {

            Swal.fire({
                icon: 'error',
                title: 'Incomplete Form Submitted',
                text: 'Some fields in admission form are empty. Please check the form and submit again.',
            });
        }

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New admission trigger
        createAdmission()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addadmission-form1,#addadmission-form2,#addadmission-form3,#addadmission-form4').removeClass('active')
    $(`#addadmission-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 3) {
        $('#next').text('Review')
    } else if (actives.length === 4) {

        next.disabled = true
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page
        loading('Just a moment...')

        $('#next').text('Submit')
        // Form 1
        const studentname_id = $('#studentname').val()
        // Find student name
        $.ajax({
            url: `/sdp/students/${studentname_id}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    var studentname
                    response.data.firstName ? studentname = response.data.firstName + ' ' + response.data.middleName + ' ' + response.data.lastName : studentname = undefined
                    admission_branch = response.data.branch

                    // Find course name
                    const coursename_id = $('#coursename').val()
                    $.ajax({
                        url: `/sdp/courses/${coursename_id}`,
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                const coursename = response.data.name

                                // Find teacher name
                                const teachername_id = $('#teachername').val()
                                $.ajax({
                                    url: `/sdp/teachers/${teachername_id}`,
                                    method: 'get',
                                    success: function (response) {
                                        if (response.success) {

                                            $('#loading').css('display', 'none');

                                            const teachername = response.data.user ? response.data.user.name : ''

                                            const admissiondate = $('#admissiondate').val()
                                            const coursefees = $('#coursefees').val()
                                            // Form 2
                                            const batchtime = $('#studentbatchtime').val()
                                            const installment = $("input[type='radio'][name='installment']:checked").val();
                                            var paymenttype
                                            var installmentdate = undefined
                                            if (installment == 'true') {
                                                paymenttype = 'Installment'
                                                installmentdate = $('#installmentdate').val()
                                            } else {
                                                paymenttype = 'One Time'
                                            }
                                            // Form 3
                                            const admissionroll = $('#admissionroll').val()
                                            const enrollnumber = $('#enrollnumber').val()
                                            const enrollmonth = $('#enrollmonth').val()
                                            const enrollpaymentdate = $('#enrollpaymentdate').val()

                                            $('#display-studentname').html(studentname ? studentname : '<span class="text-danger">Student Name field is empty</span>')
                                            $('#display-coursename').html(coursename ? coursename : '<span class="text-danger">Course Name field is empty</span>')
                                            $('#display-coursefees').html(coursefees ? coursefees : '<span class="text-danger">Course Fees field is empty</span>')
                                            $('#display-admissiondate').html(admissiondate ? admissiondate : '<span class="text-danger">Admission Date field is empty</span>')
                                            $('#display-studentbatchtime').html(batchtime ? batchtime : '<span class="text-danger">Batch Time field is empty</span>')
                                            $('#display-teachername').html(teachername ? teachername : '<span class="text-danger">Teacher Name field is empty</span>')
                                            $('#display-installment').html(paymenttype ? paymenttype : '<span class="text-danger">Payment Type field is empty</span>')
                                            $('#display-installmentdate').html(installmentdate ? installmentdate : '<span class="text-danger">Installment Date field is empty</span>')
                                            $('#display-admissionroll').html(admissionroll ? admissionroll : '<span class="text-dark">Admission Roll Number field is empty</span>')
                                            $('#display-enrollno').html(enrollnumber ? enrollnumber : '<span class="text-dark">Enrollment Number field is empty</span>')
                                            $('#display-enrollmonth').html(enrollmonth ? enrollmonth : '<span class="text-dark">Enrollment Month field is empty</span>')
                                            $('#display-enrollpaydate').html(enrollpaymentdate ? enrollpaymentdate : '<span class="text-dark">Enrollment Payment field is empty</span>')

                                            if (!studentname || !coursename || !admissiondate || !coursefees || !batchtime || !teachername) {
                                                next.disabled = true
                                            } else {
                                                if ((installment == 'true' && installmentdate) || installment == 'false') {
                                                    finalSubmit = 1
                                                    next.disabled = false
                                                    // } else if (installment == 'false') {
                                                    //     finalSubmit = 1
                                                    //     next.disabled = false
                                                } else {
                                                    next.disabled = true
                                                }
                                            }

                                        } else {

                                            $('#loading').css('display', 'none');
                                            $('#table_students tbody tr').text(response.responseJSON.error);
                                            console.log(response.responseJSON.error);
                                            $('#errors').fadeIn();
                                            $('#errors').css('display', 'block');
                                            $('#add-student-card button').attr('disabled', true)

                                        }
                                    },
                                    error: function (response) {

                                        if (response.responseJSON) {
                                            $('#loading').css('display', 'none');
                                            $('#errors').text(response.responseJSON.error);
                                            console.log(response.responseJSON.error);
                                            $('#errors').fadeIn();
                                            // $('#errors').css('display', 'block');
                                            $('#add-student-card button').attr('disabled', true)

                                        } else {
                                            $('#errors').fadeIn();
                                            var errorMsg = `
                                            <center class="text-danger">
                                            <h2>Oops! Something went wrong</h2>
                                            <h4>
                                                Error Code: ${response.status} <br>
                                                Error Message: ${response.statusText}
                                            </h4>
                                            <h5>We were unable to fetch course name</h5>
                                            <h6>
                                                Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                            </h6>
                                            </center>`
                                            console.log(`something went wrong ${JSON.stringify(response)}`);
                                            // console.log(response.statusText);
                                            // $('#table_students tbody .col').html(errorMsg)
                                            $('#errors').html(errorMsg)
                                        }

                                    }
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch course name</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch student name</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

        // Validating admission details (Feb 2023 update)
        var roll = $('#admissionroll').val()
        if (roll != '') {
            checkRoll(roll)
        }
    }
}
// Progress Steps JS End

// As student name changes check his/her branch and show teachers of same branch
$('#studentname').change(() => {
    checkDuplAdmsn() // Feb 2023 update
    const studentname = $('#studentname').val()
    // alert(studentname)
    if (studentname != '') {
        $.ajax({
            url: `/sdp/students/${studentname}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const branch = response.data.branch

                    $.ajax({
                        url: `/sdp/teachers`,
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var teachers_list;
                                if (response.data.length == 0) {
                                    teachers_list += `<option value="">Teachers List is empty</option>`;
                                } else {
                                    teachers_list = `<option value="">Select Teacher Name</option>`;
                                    response.data.forEach(teacher => {
                                        if (teacher.user.branch == branch) {
                                            teachers_list += `<option value="${teacher.user._id}">${teacher.user.name}</option>`;
                                        }
                                    });

                                }
                                $('#teachername').html(teachers_list)

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch students list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    } else {
        $('#teachername').html(`<option value="">Select Student Name first</option>`)
    }
})

$('#coursename').change(() => {
    checkDuplAdmsn() // Feb 2023 update
    const coursename = $('#coursename').val()
    // alert(coursename)
    if (coursename != '') {
        // $('#coursefees').val('Calculating...')

        $.ajax({
            url: `/sdp/courses/${coursename}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#coursefees').val(response.data.fees)
                    // console.log(response.data.batchTiming.split(','));
                    const batchTimings = response.data.batchTiming.split(',')
                    var batches_list;

                    if (batchTimings.length == 0) {
                        batches_list += `<option value="">Batch Timing List is empty</option>`;
                    } else {
                        batches_list = `<option value="">Select Batch Time</option>`;
                        batchTimings.forEach(batch => {

                            batches_list += `
                            <option value="${batch}">${batch}</option>`;
                        });
                    }

                    $('#studentbatchtime').html(batches_list)

                    // Success
                    // Swal.fire({
                    //     toast: true,
                    //     position: 'top-right',
                    //     icon: 'success',
                    //     title: 'Course Fees Calculated',
                    //     timer: 3000,
                    //     showConfirmButton: false
                    // });



                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    } else {
        $('#coursefees').val('')
        $('#studentbatchtime').html(`<option value="">Select Course Name first</option>`)
    }
})

function loadStudentsList() {

    $.ajax({
        url: '/sdp/students/special/data',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var students_list;
                $('#admissionstudent').text(response.data)

                if (response.data.length == 0) {
                    students_list += `<option value="">Student List is empty</option>`;
                } else {
                    students_list = `<option value="">Select Student Name</option>`;
                    response.data.forEach(student => {

                        students_list += `
                        <option value="${student._id}">${student.firstName} ${student.middleName} ${student.lastName}</option>`;
                    });
                }

                $('#studentname').html(students_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Students Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_students tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadStudentsList()

// Function imported
loadCoursesList()

// Feb 2023 update
function checkDuplAdmsn() {
    // alert('Check admission details')

    // Validating admission details
    var course = $('#coursename').val()
    var student = $('#studentname').val()
    if (course != '' && student != '') {
        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Checking admission details...',
            showConfirmButton: false
        });
    
        $.ajax({
            url: `/sdp/admissions/check`,
            method: 'post',
            dataType: 'json',
            data: {
                student: student,
                course: course
            },
            success: function (response) {
                if (response.success) {
                    // alert(response.data.firstName)
                    Swal.fire({
                        icon: 'warning',
                        title: `<div style="color: #dfa878;"><i class='fas fa-check-double'></i>Admission warning
                        </div>
                        <div style="font-size: 20px;">Student <span style="color: #17a2b8;">${response.data.student.firstName} ${response.data.student.middleName} ${response.data.student.lastName}</span> is already enrolled for <span style="color: #91C442;">${response.data.course.name}</span> in <span class="text-danger">${response.data.student.branch}</span> branch with roll number as <span class="text-danger">${response.data.rollNo}</span></div>`,
                        confirmButtonText: `<div class="text-dark">Cancel Admission</div>`,
                        confirmButtonColor: '#fff',
                        allowOutsideClick: false,
                        showDenyButton: true,
                        denyButtonText: 'Continue',
                        denyButtonColor: '#c6956b',
                        focusConfirm: false
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Refreshing page...',
                                timer: 1500,
                                showConfirmButton: false
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/admin/addadmission');
                            }, 1000);
                        }
                    })
                } else {
                    Swal.fire({
                        icon: 'success',
                        title: `<div class="text-success"><i class='fas fa-check-double'></i>Unique admission details
                        </div>
                        <div style="font-size: 20px;">${response.data}</div>`,
                        confirmButtonText: `<div class="text-dark">Okay</div>`,
                        confirmButtonColor: '#fff',
                        allowOutsideClick: false,
                        focusConfirm: false
                    })
    
                }
            },
            error: function (response) {
                console.log(response);
                alert(response)
            }
        })
    }

}

function checkRoll(roll) {
        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Checking admission details...',
            showConfirmButton: false
        });
    
        $.ajax({
            url: `/sdp/admissions/roll`,
            method: 'post',
            dataType: 'json',
            data: {
                roll: roll
            },
            success: function (response) {
                if (response.success) {
                    // alert(response.data.firstName)
                    Swal.fire({
                        icon: 'warning',
                        title: `<div style="color: #dfa878;"><i class='fas fa-check-double'></i>Admission warning
                        </div>
                        <div style="font-size: 20px;">Student <span style="color: #17a2b8;">${response.data.student.firstName} ${response.data.student.middleName} ${response.data.student.lastName}</span> is already enrolled for <span style="color: #91C442;">${response.data.course.name}</span> in <span class="text-danger">${response.data.student.branch}</span> branch with roll number as <span class="text-danger">${response.data.rollNo}</span></div>`,
                        confirmButtonText: `<div class="text-dark">Cancel Admission</div>`,
                        confirmButtonColor: '#fff',
                        allowOutsideClick: false,
                        showDenyButton: true,
                        denyButtonText: 'Continue',
                        denyButtonColor: '#c6956b',
                        focusConfirm: false
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Refreshing page...',
                                timer: 1500,
                                showConfirmButton: false
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/admin/addadmission');
                            }, 1000);
                        }
                    })
                } else {
                    Swal.fire({
                        icon: 'success',
                        title: `<div class="text-success"><i class='fas fa-check-double'></i>Unique admission details
                        </div>
                        <div style="font-size: 20px;">${response.data}</div>`,
                        confirmButtonText: `<div class="text-dark">Okay</div>`,
                        confirmButtonColor: '#fff',
                        allowOutsideClick: false,
                        focusConfirm: false
                    })
    
                }
            },
            error: function (response) {
                console.log(response);
                alert(response)
            }
        })
}