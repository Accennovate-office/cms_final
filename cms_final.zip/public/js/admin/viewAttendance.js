
$('#sidebar-attendances').trigger("click")
$('#sidebar-attendances,#sidebar-attendances-view').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['attendance'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/attendances')
})

function loadAttendancesList() {

    $.ajax({
        // url: '/sdp/attendances',
        url: '/sdp/registrations', // code by Raj
        method: 'get',
        success: function (response) {
            if (response.success) {

                var attendances_list;
                $('#viewattendance #attendance').text(response.data)

                if (response.data.length == 0) {
                    attendances_list += `<option value="">Attendance List is empty</option>`;
                } else {
                    attendances_list = `<option value="">Select Attendance Name</option>`;
                    response.data.forEach(attendance => {

                        // Code by Raj
                        if (attendance.biometricId == selected) {

                            attendances_list += `
                            <option selected value="${attendance.biometricId}">${attendance.name}</option>`;

                        } else {

                            attendances_list += `
                            <option value="${attendance.biometricId}">${attendance.name}</option>`;

                        }
                        // Code by Raj end
                        // if (attendance._id == selected) {

                        //     attendances_list += `
                        //     <option selected value="${attendance._id}">${attendance.name}</option>`;

                        // } else {

                        //     attendances_list += `
                        //     <option value="${attendance._id}">${attendance.name}</option>`;

                        // }

                    });
                }

                $('#viewattendance #attendance').html(attendances_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Attendances Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_attendances tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-attendance-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-attendance-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch attendances list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_attendances tbody .col').html(errorMsg)
                $('#no-attendance-selected').html(errorMsg)
            }

        }
    });

}
loadAttendancesList()

// Code by Raj

let timeStamp = "monthly";

async function getAttendanceDetails(id) {
    try {
        const selectAttendance = $("#attendance").val()
            ? $("#attendance").val()
            : id ? id : selected;
        console.log(typeof selectAttendance)
        if (selectAttendance == "") {
            $("#no-attendance-selected").css("display", "block");
            $("#attendance-selected").css("display", "none");
        } else {
            $("#no-attendance-selected").css("display", "none");
            $("#attendance-selected").css("display", "block");
            $("#viewattendance #attendance-selected").html(`Loading...`);
            console.log(selectAttendance);
            let duration = await $.ajax({
                url: `/sdp/attendances/duration/${selectAttendance}`,
                method: "get",
                success: function (response) {
                    return response;
                },
            });
            console.log(duration)
            $.ajax({
        url: `/sdp/registrations/${selectAttendance}`,
        method: "get",
        success: async function (response) {
            try {
                const random = (min = 1, max = 3) =>
                    Math.floor(Math.random() * (max - min)) + min;

                if (response.success) {
                    // for (let i = 1; i <= 25; i++) {
                    //   let logoutTime,
                    //     loginTime,
                    //     duration = 5;
                    //   if (String(Math.abs(i)).charAt(0) == i) {
                    //     logoutTime = new Date(`2022-07-0${i}T13:30:00.862Z`);
                    //     loginTime = new Date(`2022-07-0${i}T08:30:00.862Z`);
                    //   } else {
                    //     logoutTime = new Date(`2022-07-${i}T13:30:00.862Z`);
                    //     loginTime = new Date(`2022-07-${i}T08:30:00.862Z`);
                    //   }
                    //   if (random() == 1) {
                    //     if (String(Math.abs(i)).charAt(0) == i) {
                    //       logoutTime = new Date(`2022-07-0${i}T14:30:00.862Z`);
                    //     } else {
                    //       logoutTime = new Date(`2022-07-${i}T14:30:00.862Z`);
                    //     }
                    //     duration = 6;
                    //   } else if (random() == 2) {
                    //     if (String(Math.abs(i)).charAt(0) == i) {
                    //       logoutTime = new Date(`2022-07-0${i}T11:30:00.862Z`);
                    //     } else {
                    //       logoutTime = new Date(`2022-07-${i}T11:30:00.862Z`);
                    //     }
                    //     duration = 3;
                    //   }
                    //   console.log(loginTime)
                    //   console.log(logoutTime)
                    //   let obj1 = {
                    //     loginOrLogout: "Login",
                    //     attendanceType: "System",
                    //     biometricId: "872",
                    //     dateTime: loginTime,
                    //   };
                    //   let obj2 = {
                    //     loginOrLogout: "Logout",
                    //     attendanceType: "System",
                    //     biometricId: "872",
                    //     dateTime: logoutTime,
                    //     duration,
                    //   };
                    //   if (random() != 2) {
                    //     $.ajax({
                    //       url: "/sdp/attendances",
                    //       method: "post",
                    //       data: obj1,
                    //     });

                    //     $.ajax({
                    //       url: "/sdp/attendances",
                    //       method: "post",
                    //       data: obj2,
                    //     });
                    //   }
                    // }
                    // $.ajax({
                    //   url:"/sdp/attendances/1",
                    //   method:"get"
                    // })
                    console.log(response);

                    let res = await $.ajax({
                        url: `/sdp/attendances/custom/${selectAttendance}-${timeStamp}`,
                        method: "GET",
                        success: function (response) {
                    return response;
                },
            });
              console.log(res)
              let attendance = res.data;
              let tableData = [];
              for (let i = 0; i < attendance.length; i++) {
                  for (let j = 0; j < attendance.length; j++) {
                      if (
                          attendance[i].loginOrLogout != attendance[j].loginOrLogout
                      ) {
                          let login = new Date(attendance[i].dateTime);
                          let logout = new Date(attendance[j].dateTime);

                          if (
                              login.getUTCDate() == logout.getUTCDate() &&
                              !attendance[i].match
                          ) {
                              attendance[i].loginOrLogout == "Login"
                                  ? (tableData = [...tableData, i, j])
                                  : (tableData = [...tableData, j, i]);
                              attendance[j] = { ...attendance[j], match: true };
                          }
                      }
                  }
              }

              let tableHtml = ``;
              let presentDays = 0;
              let jobTime = response.data[0].currentJobTime;
              let minimumDuration = 5;
              let totalOverTime = 0;
              function convertMsToHM(milliseconds) {
                  let seconds = Math.floor(milliseconds / 1000);
                  let minutes = Math.floor(seconds / 60);
                  let hours = Math.floor(minutes / 60);
                  return hours;
              }
              for (let i = 0; i < attendance.length - 1; i = i + 2) {
                  presentDays++;
                  let loginTime = new Date(attendance[tableData[i]].dateTime);
                  let logoutTime = new Date(attendance[tableData[i + 1]].dateTime);
                  let difference = logoutTime.getTime() - loginTime.getTime();
                  let overtime = convertMsToHM(difference) - minimumDuration;
                  let notify = "";
                  if (overtime > 0) {
                      notify = "#90ee90";
                  } else if (overtime < 0) {
                      notify = "#C24641";
                  }
                  totalOverTime = overtime + totalOverTime;
                  tableHtml += `
              <tr>
              <td>${loginTime.toLocaleDateString()}</td>
              <td>${loginTime.toLocaleTimeString()}</td>
              <td>${logoutTime.toLocaleTimeString()}</td>
              <td>${convertMsToHM(difference)}</td>
              <td style="background-color:${notify};">${overtime}</td>
              </tr>
              `;
              }

              $("#viewattendance #attendance-selected").html(
                  `<h2>Loading...</h2>`
              );

              var options = {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "numeric",
                  minute: "numeric",
                  second: "numeric",
                  timeZoneName: "long",
              };

              var createdHindiIST = new Date(
                  response.data.createdAt
              ).toLocaleDateString("hi-IN", options);
              var createdEnglishIST = new Date(
                  response.data.createdAt
              ).toLocaleDateString("en-IN", options);

              var updateValue = response.data.updatedAt
                  ? response.data.updatedAt
                  : "Not updated";
            // Converting update value from UTC to GMT
              if (updateValue != "Not updated") {
              // Hindi Date time
              // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                updateValue = new Date(updateValue).toLocaleDateString(
                    "en-IN",
                    options
                );
            }

            // Check date
              optionsCheck = {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
              };
              var attendanceStartingAt = new Date(
                  response.data.startingAt
              ).toLocaleDateString("en-IN", optionsCheck);
              // var batches = ''
              // const batches_string = response.data.batchTiming.split(',')
              // // console.log(response.data.batchTiming);
              // batches_string.forEach(batch => {
              //     batches += `<span class="badge badge-light">${batch}</span>`
              // });
              var data = response.data[0];
              $("#search-btn").click(function () {
                  let a = $("#start").val()
                  let b = $("#end").val()
                  timeStamp = `${a}to${b}`
                  getAttendanceDetails(selectAttendance)
                  console.log("hello")
                  console.log(res)
              })

              var attendance_data = `
                    <div class="d-flex justify-content-between mb-3">
                    <div class="d-flex align-items-center my-1">       
                    <small></small>
                </div>
                <h5>${data.name}</h5>
                    </div>
                    <div class="d-flex justify-content-between">
                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Name</small>
                        </div>
                        <h5>${data.name}</h5>
                    </div>

                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Branch</small>
                        </div>
                        <h5>${data.branch}</h5>
                    </div>

                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Designation</small>
                        </div>
                        <h5>${data.designation}</h5>
                    </div>
                    </div>
                <div class="d-flex justify-content-between">
                    <div align="left">
                    <div class="d-flex align-items-center my-1">
                        <small>Total working duration</small>
                    </div>
                    <h5>${duration.data} hours</h5>
                </div>
                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Average working Hours<small>"Inc Abs"</small></small>
                        </div>
                        <h5>${parseInt(duration.data / 25)} hours</h5>
                    </div>
                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Average working Hours<small>"Exc Abs"</small></small>
                        </div>
                        <h5>${parseInt(
                            duration.data / (25 - presentDays)
                        )} hours</h5>
                    </div>
                    </div>
                <div class="d-flex justify-content-between">
                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Present</small>
                        </div>
                        <h5>${presentDays} days</h5>
                    </div>
                    <div align="left">
                        <div class="d-flex align-items-center my-1">
                            <small>Leave</small>
                        </div>
                        <h5>${25 - presentDays} days</h5>
                    </div>
                    <div align="left">
                    <div class="d-flex align-items-center my-1">       
                        <small>Total overtime</small>
                    </div>
                    <h5>${totalOverTime} hours</h5>
                </div>
                    </div>

              <table class="table">
              <thead>
                <tr>
                  <th scope="col">Date</th>
                  <th scope="col">Login</th>
                  <th scope="col">Logout</th>
                  <th scope="col">Hours</th>
                  <th scope="col">Overtime</th>
                </tr>
              </thead>
              <tbody>
              ${tableHtml}
              </tbody>
              </table>

`;

              $("#viewattendance #attendance-selected").html(attendance_data);
              Swal.fire({
                  toast: true,
                position: "top-right",
                icon: "success",
                title: `Attendance Fetched Successfully for ${data.name}`,
                timer: 3000,
                showConfirmButton: false,
            });
          } else {
              $("#loading").css("display", "none");
              $("#table_attendances tbody tr").text(response.responseJSON.error);
              console.log(response.responseJSON.error);
                    $("#error").fadeIn();
                    $("#error").css("display", "block");
                    $("#add-attendance-card button").attr("disabled", true);
                }
            } catch (e) {
                console.log(e);
            }
        },
        error: function (response) {
          if (response.responseJSON) {
            $("#loading").css("display", "none");
            $("#error").text(response.responseJSON.error);
            console.log(response.responseJSON.error);
            $("#error").fadeIn();
            $("#error").css("display", "block");
            $("#add-attendance-card button").attr("disabled", true);
        } else {
            var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch attendances list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`;
            console.log(`something went wrong ${JSON.stringify(response)}`);
          // console.log(response.statusText);
          // $('#table_attendances tbody .col').html(errorMsg)
            $("#no-attendance-selected").html(errorMsg);
        }
        },
    });
  }


  } catch (e) {
      console.log(e)
}
}
// Code by Raj end

$('#no-attendance-selected').css('display', 'block') // block
$('#attendance-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getAttendanceDetails()
}
$('#attendance').change(() => {
    getAttendanceDetails()
})

// function getAttendanceDetails() {

//     const selectAttendance = $('#attendance').val() ? $('#attendance').val() : selected
//     // console.log(selectAttendance);
//     if (selectAttendance == '') {
//         $('#no-attendance-selected').css('display', 'block')
//         $('#attendance-selected').css('display', 'none')
//     } else {

//         $('#no-attendance-selected').css('display', 'none')
//         $('#attendance-selected').css('display', 'block')
//         $('#viewattendance #attendance-selected').html(`Loading...`)
//         $.ajax({
//             url: `/sdp/attendances/${selectAttendance}`,
//             method: 'get',
//             success: function (response) {
//                 if (response.success) {

//                     $('#viewattendance #attendance-selected').html(`<h2>Loading...</h2>`)

//                     var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                     var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
//                     var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

//                     var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
//                     // Converting update value from UTC to GMT
//                     if (updateValue != 'Not updated') {
//                         // Hindi Date time
//                         // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                         updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                     }

//                     // Check date
//                     optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                     var attendanceStartingAt = new Date(response.data.startingAt).toLocaleDateString("en-IN", optionsCheck)

//                     var batches = ''
//                     const batches_string = response.data.batchTiming.split(',')
//                     // console.log(response.data.batchTiming);
//                     batches_string.forEach(batch => {
//                         batches += `<span class="badge badge-light">${batch}</span>`
//                     });

//                     var attendance_data = `
//                     <div class="d-flex mb-5">
//                         <img src="/images/attendances/attendance1.png" width="60" alt="">
//                         <div align="left" class="ml-4">
//                             <small>Attendance Name</small>
//                             <h2>${response.data.name}</h2>
//                         </div>
//                     </div>
//                     <div align="left">
//                         <div class="d-flex align-items-center">
//                             <i class="fa fa-book" aria-hidden="true"></i>
//                             <small>Attendance Description</small>
//                         </div>
//                         <h5>${response.data.description}</h5>
//                     </div>

//                     <div class="d-flex justify-content-between">
//                         <div align="left" class="mt-3">
//                             <div class="d-flex align-items-center">
//                                 <i class="fa fa-calendar" aria-hidden="true"></i>
//                                 <small>Attendance Start Date</small>
//                             </div>
//                             <div>${attendanceStartingAt}</div>
//                         </div>
//                         <div align="left" class="mt-3">
//                             <div class="d-flex align-items-center">
//                                 <i class="fa fa-clock"></i>
//                                 <small>Attendance Duration (Weeks)</small>
//                             </div>
//                             <div>${response.data.weeks} weeks</div>
//                         </div>
//                         <div align="left" class="mt-3">
//                             <div class="d-flex align-items-center">
//                                 <i class="fas fa-fax" aria-hidden="true"></i>
//                                 <small>Attendance Fees</small>
//                             </div>
//                             <div>₹ ${response.data.fees}</div>
//                         </div>
//                     </div>

//                     <div align="left" class="mt-2">
//                         <div class="d-flex align-items-center">
//                             <i class="fa fa-clock" aria-hidden="true"></i>
//                             <small>Batches</small>
//                         </div>
//                         <h4>
//                             ${batches}
//                         </h4>
//                     </div>

//                     <div class="d-flex w-100">
//                         <div align="left" class="mt-5 w-100">
//                             <div class="d-flex align-items-center">
//                             <i class="fa fa-user" aria-hidden="true"></i>
//                                 <small>Created By</small>
//                             </div>
//                             <div class="d-flex justify-content-between w-100">
//                                 <div>${response.data.createdBy.name}</div>
//                                 <div>${response.data.createdBy.email}</div>
//                                 <div>${response.data.createdBy.branch} Branch</div>
//                             </div>
//                         </div>
//                     </div>

//                     <div class="d-flex justify-content-between">
//                         <div align="left" class="mt-3">
//                             <div class="d-flex align-items-center">
//                                 <i class="fa fa-calendar" aria-hidden="true"></i>
//                                 <small>Created At</small>
//                             </div>
//                             <div>${createdEnglishIST}</div>
//                         </div>
//                         <div align="left" class="mt-3 ml-3">
//                             <div class="d-flex align-items-center">
//                                 <i class="fa fa-calendar" aria-hidden="true"></i>
//                                 <small>Updated At</small>
//                             </div>
//                             <div>${updateValue}</div>
//                         </div>
//                     </div>`;

//                     $('#viewattendance #attendance-selected').html(attendance_data)

//                     Swal.fire({
//                         toast: true,
//                         position: 'top-right',
//                         icon: 'success',
//                         title: 'Attendance Fetched Successfully',
//                         timer: 3000,
//                         showConfirmButton: false
//                     });

//                 } else {

//                     $('#loading').css('display', 'none');
//                     $('#table_attendances tbody tr').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#error').fadeIn();
//                     $('#error').css('display', 'block');
//                     $('#add-attendance-card button').attr('disabled', true)

//                 }
//             },
//             error: function (response) {

//                 if (response.responseJSON) {
//                     $('#loading').css('display', 'none');
//                     $('#error').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#error').fadeIn();
//                     $('#error').css('display', 'block');
//                     $('#add-attendance-card button').attr('disabled', true)

//                 } else {
//                     var errorMsg = `
//                     <center>
//                     <h2>Oops! Something went wrong</h2>
//                     <h4 class="text-danger">
//                         Error Code: ${response.status} <br>
//                         Error Message: ${response.statusText}
//                     </h4>
//                     <h5>We were unable to fetch attendances list</h5>
//                     <h6>
//                         Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                     </h6>
//                     </center>`
//                     console.log(`something went wrong ${JSON.stringify(response)}`);
//                     // console.log(response.statusText);
//                     // $('#table_attendances tbody .col').html(errorMsg)
//                     $('#no-attendance-selected').html(errorMsg)
//                 }

//             }
//         });
//     }

// }

