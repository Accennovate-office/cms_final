
$('#no-routelog-available').fadeOut()
$('#table_routelogs,#myInput').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()

// $('#sidebar-routelogs').trigger("click")
$('#sidebar-website-usage').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/


function loadAllRoutelogs(limit = 10, page = 1, search = '') {

    $('#no-routelog-available').fadeOut()
    $('#table_routelogs,#myInput').fadeOut()

    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $.ajax({
        url: `/sdp/routelogs?limit=${limit}&page=${page}${search}`,
        method: 'get',
        success: function (response) {
            if (response.success) {
                // console.log(response.data);
                $('#table_routelogs tbody').text(response.data)
                // console.log(response.data.length);
                // console.log(response.data[0]);
                $('#error,#loading').css('display', 'none')

                if (response.data.length == 0 && response.total_count == 0) {
                    var noRoutelog = `
                    <img src="/images/routelogs/noroutelog.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Routelog List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Routelog</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-routelog-available').fadeIn()
                    $('#no-routelog-available').html(noRoutelog)
                } else if (response.data.length == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var noRoutelog = `
                    <img src="/images/routelogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-routelog-available').fadeIn()
                    $('#no-routelog-available').html(noRoutelog)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var noRoutelog = `
                        <img src="/images/routelogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-routelog-available').fadeIn()
                        $('#no-routelog-available').html(noRoutelog)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var noRoutelog = `
                        <img src="/images/routelogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-routelog-available').fadeIn()
                        $('#no-routelog-available').html(noRoutelog)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {

                        $('#table_routelogs,#myInput').fadeIn()
                        $('#view_note').fadeIn()
                        var tbody_routelogs;
                        // var newelementCount = 0;
                        response.data.forEach(routelog => {

                            // Check date
                            optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var createdCheck = new Date(routelog.createdAt).toLocaleDateString("en-IN", optionsCheck)
                            var today = new Date().toLocaleDateString("en-IN", optionsCheck)
                            var newElement;
                            if (createdCheck === today) {
                                newElement = `<span class="badge badge-noti">New</span>`
                                // newelementCount += 1
                            } else {
                                newElement = ''
                            }

                            // Formating user
                            var user_data
                            if (routelog.user == undefined) {
                                user_data = 'Not Found'
                            } else {
                                // const json_user = JSON.parse(routelog.user)
                                user_data = `${routelog.user.name} (${routelog.user.role}) <br>
                                ${routelog.user.branch} Branch`
                            }

                            var status_color
                            if (routelog.statusCode.toString()[0] == '2') {
                                status_color = 'success'
                            } else if (routelog.statusCode.toString()[0] == '3') {
                                status_color = 'info'
                            } else if (routelog.statusCode.toString()[0] == '4') {
                                status_color = 'danger'
                            } else if (routelog.statusCode.toString()[0] == '5') {
                                status_color = 'warning'
                            }

                            tbody_routelogs += `
                            <tr>
                                <td>${routelog.requestMethod}</td>
                                <td>${routelog.requestURL}</td>
                                <td class="text-${status_color} font-weight-bold">${routelog.statusCode}</td>
                                <td>${user_data}</td>
                                <td>${routelog.dateAndTime}</td>
                            </tr>`;
                    });
                        $('#table_routelogs tbody').html(tbody_routelogs)

                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Routelogs Fetched Successfully',
                    timer: 5000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_routelogs tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-routelog-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-routelog-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch routelogs list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_routelogs tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
// loadAllRoutelogs()

async function checkPass() {
    // Onload Password check
    const { value: password } = await Swal.fire({

        title: `<h3>Enter your login <span class="text-danger">password</span> to <span class="text-success">Verify</span></h3>`,
        input: 'password',
        position: 'center',
        inputPlaceholder: 'Enter your password',
        confirmButtonText: `<span style="color: #0b6fad;"><i class="fas fa-shield-alt"></i>  Verify</span>`,
        confirmButtonColor: '#91C442',
        width: '40rem',
        padding: '3rem',
        allowOutsideClick: () => !Swal.isLoading(),
        inputAttributes: {
            minlength: 6,
            autocapitalize: 'off',
            autocorrect: 'off'
        }
    })

    if (password) {
        // Swal.fire(`Entered password: ${password}`)

        $.ajax({
            url: `/sdp/auth/me`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const email = response.data.email
                    $.ajax({
                        url: '/sdp/auth/login',
                        method: 'post',
                        dataType: 'json',
                        data: {
                            email: email,
                            password: password
                        },
                        success: function (response) {
                            if (response.success) {

                                Swal.fire({
                                    toast: true,
                                    position: 'bottom-right',
                                    icon: 'success',
                                    title: 'Verified Successfully',
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                                $('#verify-pass-btn').html(`
                                <i class="fas fa-shield-alt"></i>
                                Verified`)
                                $('#verify-pass-btn').attr('disabled', true)
                                $('#verify-pass-btn').css('cursor', 'not-allowed')
                                loadAllRoutelogs()

                            } else {

                                Swal.fire({
                                    icon: 'danger',
                                    title: 'Something went wrong',
                                    text: response.responseJSON.error
                                });
                                console.log(response);

                            }
                        },
                        error: function (response) {

                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });
                            console.log(response);

                        }
                    });

                } else {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Something went wrong',
                        text: response.responseJSON.error
                    });
                    console.log(response);

                }
            },
            error: function (response) {

                Swal.fire({
                    icon: 'danger',
                    title: 'Server error',
                    text: response.responseJSON.error
                });
                console.log(response);

            }
        });
    }
}

$('#verify-pass-btn').click(() => {
    // console.log('Verify!!!!!!!!!!');
    checkPass()
})

$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllRoutelogs(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllRoutelogs(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllRoutelogs(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllRoutelogs(limit, page + 1)
})

$(document).ready(function () {

    var noRoutelog = `
    <img src="/images/routelogs/noroutelog.png" width="60" alt="">
    <div class="h3 mt-2">
        <span class="font-weight-bold">Verify yourself to see Website Usage Records</span> <br><br>
        <span class="h5">Click&nbsp;
            <span>
                <button id="verify-pass" class="btn btn-dark" style="background-color: #91C442;">
                    <i class="fas fa-shield-alt"></i> 
                    <span class="font-weight-bold">Verify</span>
                </button>
            </span>
            &nbsp;button at top left to get started
        </span>
    </div>`
    $('#no-routelog-available').fadeIn()
    $('#no-routelog-available').html(noRoutelog)
    checkPass()

    // Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
    $("#myInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});

// Status Code Guide
$('.status-code-info').click(() => {
    Swal.fire({
        title: 'Status Code Guide',
        html: ` <table class="table table-borderless font-weight-bold">
                <tr class="row text-success">
                    <td class="col">200,201...</td>
                    <td align="left" class="col">Success</td>
                </tr>
                <tr class="row text-info">
                    <td class="col">300,302...</td>
                    <td align="left" class="col">Redirection</td>
                </tr>
                <tr class="row text-danger">
                    <td class="col">400,401,403,404...</td>
                    <td align="left" class="col">Client Error</td>
                </tr>
                <tr class="row text-warning">
                    <td class="col">500,502,503...</td>
                    <td align="left" class="col">Server Error</td>
                </tr>
                </table>`,

        position: 'top',
        confirmButtonText: 'Got it',
        confirmButtonColor: '#0b6fad',
        showCloseButton: true
    });
})
