import { setCookie, getCookie } from "../services/cookie.js";

$('#no-branch-available').fadeOut()
$('#table_branches').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#sidebar-branches').trigger("click")
$('#sidebar-branches,#sidebar-branches-all').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

var all_branches_data
var cols = {address: false, email: false, created: false, updated: false}

$('#new-branch-btn').click(() => {
    document.location.replace('/sdp/admin/addbranch');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllBranches(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllBranches(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllBranches(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllBranches(limit, page + 1)
})
// Page navigator End

function loadAllBranches(limit = 9, page = 1) {

    $('#no-branch-available').fadeOut()
    $('#table_branches,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/branches?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {
                all_branches_data = response.data
                
                $('#error,#loading').css('display', 'none')

                // if (response.data.length == 0) {
                //     var noBranch = `
                //     <img src="/images/branches/nobranch.png" width="60" alt="">
                //     <div class="h3 mt-2">
                //         <span class="font-weight-bold">Branch List is empty</span> <br><br>
                //         <span class="h5">Click&nbsp;
                //             <span>
                //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                //                     Branch</button>
                //             </span>
                //             &nbsp;button at top left to get started
                //         </span>
                //     </div>`
                //     $('#no-branch-available').fadeIn()
                //     $('#no-branch-available').html(noBranch)

                // } else {
                //     $('#table_branches').fadeIn()
                //     var tbody_branches;
                //     // var newelementCount = 0;
                //     response.data.forEach(branch => {

                //         // var utcCreatedDate = new Date(branch.createdAt);
                //         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                //         // var s = new Date(branch.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                //         var createdHindiIST = new Date(branch.createdAt).toLocaleDateString("hi-IN", options)
                //         var createdEnglishIST = new Date(branch.createdAt).toLocaleDateString("en-IN", options)
                //         // var x = new Date(branch.createdAt).getTimezoneOffset();
                //         //Converted UTC to local(IST, etc.,,)
                //         // console.log(utcCreatedDate.toUTCString());

                //         // Check date
                //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
                //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)
                //         var newElement;
                //         if (createdCheck === today) {
                //             newElement = `<span class="badge badge-noti">New</span>`
                //             // newelementCount += 1
                //         } else {
                //             newElement = ''
                //         }
                //         // if (newelementCount > 0) {
                //         //     $('#sidebar-branches-all').html(`All Branches <span class="badge badge-noti">${newelementCount}</span>`)
                //         // }

                //         var updateValue = branch.updatedAt ? branch.updatedAt : 'Not updated'
                //         // Converting update value from UTC to GMT
                //         if (updateValue != 'Not updated') {
                //             // var utcUpdatedDate = new Date(updateValue);
                //             // updateValue = utcUpdatedDate.toUTCString()

                //             // Hindi Date time
                //             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                //             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                //         }

                //         tbody_branches += `
                //         <tr>
                //             <td>
                //                 ${branch.name} ${newElement}
                //             </td>
                //             <td>${branch.address}</td>
                //             <td>${createdEnglishIST}</td>
                //             <td>${updateValue}</td>
                //         </tr>`;
                //     });
                //     $('#table_branches tbody').html(tbody_branches)

                // }

                if (response.data.length == 0 && response.total_count == 0) {
                    var nobranch = `
                    <img src="/images/branches/nobranch.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Branch List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    branch</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-branch-available').fadeIn()
                    $('#no-branch-available').html(nobranch)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var nobranch = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-branch-available').fadeIn()
                    $('#no-branch-available').html(nobranch)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var nobranch = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-branch-available').fadeIn()
                        $('#no-branch-available').html(nobranch)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var branch = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-branch-available').fadeIn()
                        $('#no-branch-available').html(branch)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        populateTable(response.data, cols)
                        getFilterCount()
                        $('#table_branches,#myInput').fadeIn()
                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Branches Fetched Successfully',
                    timer: 5000,
                    showConfirmButton: false
                });

                // if (!getCookie('address_selected') && !getCookie('email_selected') && !getCookie('createdat_selected') && !getCookie('updatedat_selected')) {
                //     setTimeout(() => {
                //         modify_columns()
                //     }, 1500);
                // }else {
                //     cols.address = getCookie('address_selected')
                //     cols.email = getCookie('email_selected')
                //     cols.created = getCookie('createdat_selected')
                //     cols.updated = getCookie('updatedat_selected')
                //     // Refresh data
                //     populateTable(all_branches_data, cols)
                //     getFilterCount()
                // }
                cols.address = getCookie('address_selected')
                cols.email = getCookie('email_selected')
                cols.created = getCookie('createdat_selected')
                cols.updated = getCookie('updatedat_selected')
                // Refresh data
                populateTable(all_branches_data, cols)
                getFilterCount()
                setTimeout(() => {
                    modify_columns()
                }, 1500);

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#table_branches').html(errorMsg)
            }

        }
    });

}
loadAllBranches()

// Feb 2023 update
// function copyText() {
//     /* Copy text into clipboard */
//     navigator.clipboard.writeText
//         ("Geeksforgeeks is best learning platform.");
// }

function populateTable(data, cols) {
    var tbody_branches;
    // Columns add
    var address_column_head = cols.address ? `<th id="address_thead" class="col col-3 remove-borders">Address</th>` : ``;
    var email_column_head = cols.email ? `<th id="email_thead" class="col col-3 remove-borders">Email ID</th>` : ``;
    var created_column_head = cols.created ? `<th id="createdat_thead" class="col col-2 remove-borders">Created At</th>` : ``;
    var updated_column_head = cols.updated ? `<th id="updatedat_thead" class="col col-2 remove-borders">Updated At</th>` : ``;
    $('#table_head_branches').html(`
    <th id="name_thead" class="col col-2 remove-borders">Name</th>
    ${address_column_head}${email_column_head}${created_column_head}${updated_column_head}`)
    // var newelementCount = 0;
    data.forEach(branch => {

        // var utcCreatedDate = new Date(branch.createdAt);
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

        var createdHindiIST = new Date(branch.createdAt).toLocaleDateString("hi-IN", options)
        var createdEnglishIST = new Date(branch.createdAt).toLocaleDateString("en-IN", options)

        // Check date
        optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var createdCheck = new Date(branch.createdAt).toLocaleDateString("en-IN", optionsCheck)
        var today = new Date().toLocaleDateString("en-IN", optionsCheck)

        var branchStartingAt = new Date(branch.startingAt).toLocaleDateString("en-IN", optionsCheck)
        var newElement;
        if (createdCheck === today) {
            newElement = `<span class="badge badge-noti">New</span>`
            // newelementCount += 1
        } else {
            newElement = ''
        }

        var updateValue = branch.updatedAt ? branch.updatedAt : 'Not updated'
        // Converting update value from UTC to GMT
        if (updateValue != 'Not updated') {
            updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
        }

        if (branch.address.length > 50) {
            var truncated_address = branch.address.slice(0,50)+'...'
        } else {
            var truncated_address = branch.address
        }

        var address_column_data = cols.address ? `<td class="remove-borders">${truncated_address}</td>` : ''
        var email_column_data = cols.email ? `<td class="remove-borders">${branch.email ? branch.email : 'Not provided'}</td>` : ''
        var created_column_data = cols.created ? `<td class="remove-borders">${createdEnglishIST}</td>` : ''
        var updated_column_data = cols.updated ? `<td class="remove-borders">${updateValue}</td>` : ''
        
        tbody_branches += `
        <tr id="${branch._id}">
            <td class="remove-borders"><a href="/sdp/admin/viewbranch?branch=${branch.name}" target="_blank">
                ${branch.name} ${newElement}
            </a></td>
            ${address_column_data}
            ${email_column_data}
            ${created_column_data}
            ${updated_column_data}
        </tr>`;
        });
    $('#table_branches tbody').html(tbody_branches)
}

function getFilterCount() {

    let email_yes = getCookie('email_provided_yes');
    let email_no = getCookie('email_provided_no');
    if (email_yes && email_no) {
        $('#applied_filters').html(2)
        populateTable(all_branches_data, cols)
    }else if(email_yes){
        $('#applied_filters').html(1)
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        let filtered_branches = all_branches_data.filter(
            eachObj => eachObj.email !== undefined);
        // console.log(filtered_branches);
        populateTable(filtered_branches, cols)
    }else if(email_no){
        $('#applied_filters').html(1)
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        let filtered_branches = all_branches_data.filter(
            eachObj => eachObj.email == undefined);
        // console.log(filtered_branches);
        populateTable(filtered_branches, cols)
    } else {
        $('#applied_filters').html(0)
        populateTable(all_branches_data, cols)
    }
}
// getFilterCount()

$('#filter-btn').click(()=>{
    var email_provided_yes_cook = getCookie('email_provided_yes') ? 'checked' : '' 
    var email_provided_no_cook = getCookie('email_provided_no') ? 'checked' : ''

    Swal.fire({
        title: "<div>Filter Branches</div>", 
        html: `
        <div id="filter_card" class="col card">
            <b class="row">Filter branches with Email ID -</b>
            <form>
                <label class="row"><input type="checkbox" ${email_provided_yes_cook} name="email" value="email_provided_yes" id="email_provided_yes" />&nbsp; Email provided</label>
                <label class="row"><input type="checkbox" ${email_provided_no_cook} name="email" value="email_provided_no" id="email_provided_no" />&nbsp; Email not provided</label>
            </form>
        </div>`,  
        confirmButtonText: "Apply Filter", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            let email_yes = $("#email_provided_yes").prop("checked")
            setCookie('email_provided_yes',email_yes,7)
            let email_no = $("#email_provided_no").prop("checked")
            setCookie('email_provided_no',email_no,7)
            if (email_yes && email_no) {
                populateTable(all_branches_data, cols)
            }else if(email_yes){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                let filtered_branches = all_branches_data.filter(
                    eachObj => eachObj.email !== undefined);
                // console.log(filtered_branches);
                populateTable(filtered_branches, cols)
            }else if(email_no){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                let filtered_branches = all_branches_data.filter(
                    eachObj => eachObj.email == undefined);
                // console.log(filtered_branches);
                populateTable(filtered_branches, cols)
            } else {
                populateTable(all_branches_data, cols)
            }
            getFilterCount()
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(all_branches_data);
            
        }
    })
})

// Modify columns
function modify_columns() {
    var address_selected_cook = getCookie('address_selected') ? 'checked' : ''
    var email_selected_cook = getCookie('email_selected') ? 'checked' : ''
    var createdat_selected_cook = getCookie('createdat_selected') ? 'checked' : ''
    var updatedat_selected_cook = getCookie('updatedat_selected') ? 'checked' : ''
    cols.address = getCookie('address_selected')
    cols.email = getCookie('email_selected')
    cols.created = getCookie('createdat_selected')
    cols.updated = getCookie('updatedat_selected')
    // Refresh data
    populateTable(all_branches_data, cols)
    getFilterCount()

    Swal.fire({
        title: "<div>Modify Columns</div>", 
        html: `
        <div id="filter_card" class="col card">
            <b class="row">Select columns which you want to display -</b>
            <form>
                <label class="row"><input type="checkbox" checked disabled name="name" value="name_selected" id="name_selected" />&nbsp; Name</label>
                <label class="row"><input type="checkbox" ${address_selected_cook} name="address" value="address_selected" id="address_selected" />&nbsp; Address</label>
                <label class="row"><input type="checkbox" ${email_selected_cook} name="email" value="email_selected" id="email_selected" />&nbsp; Email</label>
                <label class="row"><input type="checkbox" ${createdat_selected_cook} name="createdat" value="createdat_selected" id="createdat_selected" />&nbsp; Created at Date&Time</label>
                <label class="row"><input type="checkbox" ${updatedat_selected_cook} name="updatedat" value="updatedat_selected" id="updatedat_selected" />&nbsp; Updated at Date&Time</label>
            </form>
        </div>`,  
        confirmButtonText: "Modify", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            let address_col = $("#address_selected").prop("checked")
            let email_col = $("#email_selected").prop("checked")
            let created_col = $("#createdat_selected").prop("checked")
            let updated_col = $("#updatedat_selected").prop("checked")
            setCookie('address_selected',address_col,7)
            setCookie('email_selected',email_col,7)
            setCookie('createdat_selected',created_col,7)
            setCookie('updatedat_selected',updated_col,7)
            
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(address_col);
            cols.address = address_col
            cols.email = email_col
            cols.created = created_col
            cols.updated = updated_col
            // console.log(cols);
            populateTable(all_branches_data, cols)
            getFilterCount()
        }
    })
}
$('#modify-cols-btn').click(()=>{
    modify_columns()
})