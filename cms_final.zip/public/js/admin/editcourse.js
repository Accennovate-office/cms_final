
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-courses').trigger("click")
$('#sidebar-courses,#sidebar-courses-edit').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars
}

const selected = getUrlVars()['course'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/courses')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Course Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#editcourse #coursename,#editcourse #coursedescription,#editcourse #coursestartdate,#editcourse #courseduration,#editcourse #coursefees,#editcourse #coursebatches').keyup(() => {

    var coursename = $('#coursename').val()
    var coursedescription = $('#coursedescription').val()
    var coursestartdate = $('#coursestartdate').val()
    var courseduration = $('#courseduration').val()
    var coursefees = $('#coursefees').val()
    var coursebatches = $('#coursebatches').val()

    if (coursename || coursedescription || coursestartdate || courseduration || coursefees || coursebatches) {
        $('#editcourse button').attr('disabled', true)
        if (coursename && coursedescription && coursestartdate && courseduration && coursefees && coursebatches) {
            $('#editcourse button').attr('disabled', false)
        } else {
            $('#editcourse button').attr('disabled', true)
        }
    }
})

// function loadCoursesList(coursename = null) {

//     // Loading by blocking outsideClick
//     Swal.fire({
//         imageUrl: '/images/loading/sdp_logo_loading.gif',
//         title: `Loading courses list`,
//         showConfirmButton: false,
//         allowOutsideClick: false
//     });

//     $.ajax({
//         url: '/sdp/courses',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var courses_list;
//                 $('#editcourse #course').text(response.data)

//                 if (response.data.length == 0) {
//                     courses_list += `<option value="">Course List is empty</option>`;
//                 } else {
//                     courses_list = `<option value="">Select Course Name</option>`;
//                     response.data.forEach(course => {
//                         var select
//                         if ((coursename == course.name) || (course._id == selected)) {
//                             select = 'selected'
//                         } else {
//                             select = ''
//                         }

//                         courses_list += `
//                         <option ${select} value="${course._id}">${course.name}</option>`;
//                     });
//                 }
//                 $('#editcourse #course').html(courses_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Courses Loaded Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'error',
//                     title: 'Error Loading Courses',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Request Success: ${response.success} <br>
//                     Data Received: ${JSON.stringify(response.data)}
//                 </h4>
//                 <h5>We were unable to process the request</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_courses tbody .col').html(errorMsg)
//                 $('#course-selected').html(errorMsg)

//             }
//         },
//         error: function (response) {

//             Swal.fire({
//                 toast: true,
//                 position: 'top-right',
//                 icon: 'error',
//                 title: 'Error Loading Courses',
//                 timer: 3000,
//                 showConfirmButton: false
//             });

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#course-selected').html(response.responseJSON.error)
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-course-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch courses list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_courses tbody .col').html(errorMsg)
//                 $('#course-selected').html(errorMsg)
//             }

//         }
//     });

// }
// loadCoursesList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing course details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#course-selected').css('display', 'block')

function addTopic() {
    // Get the new topic value
    const newTopic = $('#newCourseTopic').val();
    const selectCourse = $('#course').val() ? $('#course').val() : selected

    // Check if the input is empty
    if (!newTopic) {
        // Display an error message
        $('#error-message').text('Please enter a topic before adding.');
        return;
    }

    // Clear any previous error messages
    $('#error-message').text('');

    // Make the AJAX request to add the topic
    $.post('/sdp/topics', 
    { 
        name: newTopic,
        course: selectCourse
    }, function (addedTopic) {
        // You can handle the response if needed
        console.log('Topic added:', addedTopic);
        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'success',
            title: `New topic added`,
            timer: 3000,
            showConfirmButton: false
        });

        // Clear the input field
        $('#newCourseTopic').val('');

        // Reload or update the topic list
        getCourseDetails();
    }).fail(function (error) {
        // Handle the error if the AJAX request fails
        console.error('Error adding topic:', error.responseText);
    });
}

$('#newCourseTopic-btn').click(() => addTopic())

function deleteTopic(topicId, topicName) {
    // Use SweetAlert to confirm deletion
    Swal.fire({
        title: `Are you sure you want to delete "${topicName}"?`,
        text: 'You won\'t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // User confirmed, proceed with deletion
            $.ajax({
                url: `/sdp/topics/${topicId}`,
                type: 'DELETE',
                success: function (deletedTopic) {
                    getCourseDetails();
                },
                error: function (error) {
                    console.error('Error deleting topic:', error.responseText);
                }
            });
        }
    });
}


var courseID = ''
function getCourseDetails() {

    const selectCourse = $('#course').val() ? $('#course').val() : selected

    $('#editcourse button').attr('disabled', true)
    // console.log(selectCourse);
    if (selectCourse == '') {

        $('#coursename').val('Course Name here')
        $('#coursename').attr('disabled', true)

        $('#coursedescription').val('Course Description here')
        $('#coursedescription').attr('disabled', true)

        $('#coursestartdate').val('')
        $('#coursestartdate').attr('disabled', true)

        $('#courseduration').val('')
        $('#courseduration').attr('disabled', true)

        $('#coursefees').val('')
        $('#coursefees').attr('disabled', true)

        $('#coursebatches').val('Course Batches here')
        $('#coursebatches').attr('disabled', true)

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching course details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#coursename').attr('disabled', false)
        $('#coursedescription').attr('disabled', false)
        $('#coursestartdate').attr('disabled', false)
        $('#courseduration').attr('disabled', false)
        $('#coursefees').attr('disabled', false)
        $('#coursebatches').attr('disabled', false)

        $.ajax({
            url: `/sdp/courses/${selectCourse}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#courseid').val(response.data._id)
                    courseID = response.data._id
                    $('#coursename').val(response.data.name)
                    $('#edit-course').text(response.data.name)
                    $('#coursedescription').val(response.data.description)
                    $('#coursestartdate').val(response.data.startingAt.slice(0, 10))
                    $('#courseduration').val(response.data.weeks)
                    $('#coursefees').val(response.data.fees)
                    $('#coursebatches').val(response.data.batchTiming)

                    let topics_id_list = []
                    $.ajax({
                        url: `/sdp/topics?course=${selectCourse}`,
                        method: 'get',
                        success: function (response) {
                            if (response.success) {
                                let topics = ``
                                response.data.forEach(topic => {
                                    // console.log(topic);
                                    let topicElement = `
                                    <li style="font-size: x-large;">
                                        <span>${topic.name}</span>
                                        <span id="delete-${topic._id}" class="btn btn-outline-danger rounded-circle ml-3">X</span>
                                    </li>`
                                    topics_id_list.push({ id: topic._id, name: topic.name })
                                    topics += topicElement
                                });
                                $('#topics').html(topics)
                                
                                for (let topicObj of topics_id_list) {
                                    var element = document.getElementById(`delete-${topicObj.id}`);
                                    
                                    element.addEventListener('click', () => {
                                        deleteTopic(topicObj.id, topicObj.name);
                                    });
                                }
                            }
                        }
                    })

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Course Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Courses',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_courses tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-course-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Courses',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-course-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch course details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_courses tbody .col').html(errorMsg)
                    $('#no-course-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getCourseDetails()
}
$('#course').change(() => {

    getCourseDetails()

})

$('#edit-course-btn').click(() => {
    // Extra security code
    var courseid = $('#courseid').val()
    // console.log(courseid);
    var nameInput = $('#coursename')
    var coursename = $('#coursename').val()

    var descriptionInput = $('#coursedescription')
    var coursedescription = $('#coursedescription').val()

    var startdateInput = $('#coursestartdate')
    var coursestartdate = $('#coursestartdate').val()

    var durationInput = $('#courseduration')
    var courseduration = $('#courseduration').val()

    var feesInput = $('#coursefees')
    var coursefees = $('#coursefees').val()

    if (!coursename) {
        nameInput.css('border', '2px solid red')
        nameInput.attr('placeholder', 'Please add course name')
    } else if (!coursedescription) {
        descriptionInput.css('border', '2px solid red')
        descriptionInput.attr('placeholder', 'Please add course description')
    } else if (!coursestartdate) {
        startdateInput.css('border', '2px solid red')
    } else if (!courseduration) {
        durationInput.css('border', '2px solid red')
        durationInput.attr('placeholder', 'Please add course duration')
    } else if (!coursefees) {
        feesInput.css('border', '2px solid red')
        feesInput.attr('placeholder', 'Please add course fees')
    } else {

        $('#editcourse button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // Update course
        $.ajax({
            url: `/sdp/courses/${courseid}`,
            method: 'put',
            dataType: 'json',
            data: {
                name: coursename,
                description: coursedescription,
                startingAt: coursestartdate,
                weeks: courseduration,
                fees: coursefees
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-course-card button').attr('disabled', true)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Course Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        loadCoursesList(coursename)
                    }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-course-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        });

    }
})

$('#edit-course').click(() => {
    document.location.replace(`/sdp/admin/viewcourse?course=${courseID}`)
})

function customCourseUpdateTime() {

    console.time('customCourseUpdateTime-function');
    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading courses list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    const batchTime = '7-8am,8-9am,9-10am,10-11am,11-12pm,12-1pm,1-2pm,2-3pm,3-4pm,4-5pm,5-6pm,6-7pm,7-8pm,8-9pm,9-10pm,9:30-10:30pm';

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Courses Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

                response.data.forEach(course => {

                    console.time(course.name);
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'info',
                        title: `Updating course ${course.name}`,
                        showConfirmButton: false
                    });

                    var courseid = course._id

                    // Updating courses
                    $.ajax({
                        url: `/sdp/courses/${courseid}`,
                        method: 'put',
                        dataType: 'json',
                        data: {
                            batchTiming: batchTime
                        },
                        success: function (response) {
                            if (response.success) {

                                console.log(`${course.name} course updated 🎉`);
                                console.timeEnd(course.name);

                            } else {

                                console.log(`${course.name} course not updated`);

                            }
                        },
                        error: function (response) {

                            console.log(`${course.name} course not updated`);
                            console.log(response)

                        }
                    });

                })
                console.timeEnd('customCourseUpdateTime-function');

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Courses',
                    showConfirmButton: false
                });

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Courses',
                showConfirmButton: false
            });

        }
    });
}
// 1 time update
// customCourseUpdateTime()