$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-teachers').trigger("click")
$('#sidebar-teachers,#sidebar-teachers-add').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Teacher...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;
const courses_all_list = [];
const category_id_list = [];

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
$('#myInput1,#myInput2').focusout(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.png')
})
// Searchable dropdown end

function createTeacher() {
    // Form 1
    const name = $('#teachername').val()
    const email = $('#teacheremail').val()
    const dob = $('#teacherdob').val()
    const phone = $('#teacherphone').val()
    const address = $('#teacheraddress').val()
    // Form 2
    const qualifications = $('#teacherqualifications').val()
    const computerskills = $('#teachercomputerskills').val()
    // Form 3
    const joiningDate = $('#teacherjd').val()
    const branch = $('#teacherbranch').val()
    const jobStartTime = $('#teacherjobtimestart').val()
    const jobEndTime = $('#teacherjobtimeend').val()
    // Courses allocated
    var courses_allocated = $('#myDropdown1-1').val().toString()
    if (courses_allocated == 'No Course selected') {
        courses_allocated = ''
    }
    // console.log(courses_allocated);
    // Form 4
    const accountname = $('#accountname').val()
    const accountno = $('#accountno').val()
    const ifsccode = $('#ifsccode').val()
    const bankname = $('#bankname').val()
    const bankbranchname = $('#bankbranchname').val()
    const panno = $('#panno').val()
    // Form 5
    const password = $('#teacherpassword').val()

    var jobTime = `${jobStartTime},${jobEndTime}`
    // console.log(jobTime);

    if (!name || !email || !dob || !phone || !address || !qualifications || !computerskills || !joiningDate || !branch || !jobStartTime || !jobEndTime || !courses_allocated || !password) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in teacher form are empty. Please check the form and submit again.',
        });
    } else {

        // console.log('Good job!!!');

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // Create Teacher Login
        $.ajax({
            url: '/sdp/users',
            method: 'post',
            dataType: 'json',
            data: {
                name,
                dob,
                branch,
                email,
                role: 'teacher',
                password
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)
                    loading()
                    // console.log(response.data);
                    // console.log(response.data._id);
                    const new_user = response.data._id;
                    // console.log(new_user);
                    // console.log('User added successfully');


                    // Save Teacher details
                    $.ajax({
                        url: '/sdp/teachers',
                        method: 'post',
                        dataType: 'json',
                        data: {
                            dob,
                            phone,
                            address,
                            educationalQualification: qualifications,
                            computerSkills: computerskills,
                            coursesAllocated: courses_allocated,
                            joiningDate,
                            jobTime,
                            accountHolderName: accountname,
                            accountNumber: accountno,
                            IFSCcode: ifsccode,
                            bank: bankname,
                            bankBranch: bankbranchname,
                            PAN: panno,
                            user: new_user,
                            branch
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                // nameInput.val(null)
                                // addressInput.val(null)
                                loading()
                                $('#add-branch-card button').attr('disabled', true)

                                // Send Welcome message
                                $.ajax({
                                    url: '/sdp/whatsapp/welcometeacher',
                                    method: 'post',
                                    dataType: 'json',
                                    data: {
                                        name,
                                        // branch,
                                        // email,
                                        // role: 'manager',
                                        // password,
                                        phone
                                    },
                                    success: function (response) {
                                        if (response.success) {

                                            // Implement a mail template function to send mail if told by admin

                                            $('#error,#loading').css('display', 'none')
                                            // nameInput.val(null)
                                            // addressInput.val(null)
                                            $('#add-branch-card button').attr('disabled', true)

                                            // Send Welcome message
                                            $.ajax({
                                                url: '/sdp/whatsapp/welcome',
                                                method: 'post',
                                                dataType: 'json',
                                                data: {
                                                    name,
                                                    branch,
                                                    email,
                                                    role: 'teacher',
                                                    password,
                                                    phone
                                                },
                                                success: function (response) {
                                                    if (response.success) {

                                                        // Implement a mail template function to send mail if told by admin

                                                        $('#error,#loading').css('display', 'none')
                                                        // nameInput.val(null)
                                                        // addressInput.val(null)
                                                        $('#add-branch-card button').attr('disabled', true)

                                                        Swal.fire({
                                                            icon: 'success',
                                                            title: `<div class="text-success">Teacher Created</div>`,
                                                            html: `<h5>We have sent a welcome message to the teacher's <img src="/images/managers/whatsapp.png" height="25" alt=""> WhatsApp number
                                                            , including login credentials.</h5> 
                                                            <div class="text-danger"><small>Please confirm with the manager that they have received the welcome message and remind them to keep their credentials safe.</small></div>`,
                                                            confirmButtonText: 'Got it',
                                                            confirmButtonColor: '#0b6fad',
                                                            allowOutsideClick: false,
                                                            width: '50rem'
                                                        }).then((result) => {
                                                            /* Read more about isConfirmed, isDenied below */
                                                            if (result.isConfirmed) {
                                                                Swal.fire({
                                                                    toast: true,
                                                                    position: 'top-right',
                                                                    icon: 'success',
                                                                    title: 'Redirecting...',
                                                                    timer: 1000,
                                                                    showConfirmButton: false
                                                                });
                                                                setTimeout(() => {
                                                                    document.location.replace('/sdp/admin/teachers');
                                                                }, 1000);
                                                            }
                                                        })


                                                    } else {

                                                        $('#loading').css('display', 'none');
                                                        $('#error').text(response.responseJSON.error);
                                                        $('#error').fadeIn();
                                                        $('#error').css('display', 'block');
                                                        $('#add-branch-card button').attr('disabled', true)

                                                    }
                                                },
                                                error: function (response) {

                                                    $('#loading').css('display', 'none');
                                                    // $('#error').text(response.responseJSON.error);
                                                    $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                                                    $('#error').fadeIn();
                                                    $('#error').css('display', 'block');
                                                    $('#add-branch-card button').attr('disabled', true)

                                                }
                                            });

                                        } else {

                                            $('#loading').css('display', 'none');
                                            $('#error').text(response.responseJSON.error);
                                            $('#error').fadeIn();
                                            $('#error').css('display', 'block');
                                            $('#add-branch-card button').attr('disabled', true)

                                        }
                                    },
                                    error: function (response) {

                                        $('#loading').css('display', 'none');
                                        // $('#error').text(response.responseJSON.error);
                                        $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                                        $('#error').fadeIn();
                                        $('#error').css('display', 'block');
                                        $('#add-branch-card button').attr('disabled', true)

                                    }
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)
                                // console.log(response);

                            }
                        },
                        error: function (response) {

                            // console.log(response);
                            $('#loading').css('display', 'none');
                            // $('#error').text(response.responseJSON.error);
                            $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-branch-card button').attr('disabled', true)

                        }
                    });

                } else {

                    // console.log(response);
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                console.log(response);
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON ? response.responseJSON.error : response.responseText);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New teacher trigger
        createTeacher()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addteacher-form1,#addteacher-form2,#addteacher-form3,#addteacher-form4,#addteacher-form5,#addteacher-form6').removeClass('active')
    $(`#addteacher-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 5) {
        $('#next').text('Review')
    } else if (actives.length === 6) {

        $('#next').text('Submit')
        // Form 1
        const name = $('#teachername').val()
        const email = $('#teacheremail').val()
        const dob = $('#teacherdob').val()
        const phone = $('#teacherphone').val()
        const address = $('#teacheraddress').val()
        // Form 2
        const qualifications = $('#teacherqualifications').val()
        const computerskills = $('#teachercomputerskills').val()
        // Form 3
        const joindate = $('#teacherjd').val()
        const branch = $('#teacherbranch').val()
        const jobStartTime = $('#teacherjobtimestart').val()
        const jobEndTime = $('#teacherjobtimeend').val()
        // Courses allocated
        var courses_allocated = $('#myDropdown1-1').val().toString()
        if (courses_allocated == 'No Course selected') {
            courses_allocated = ''
        }
        // console.log(courses_allocated);
        // Form 4
        const accountname = $('#accountname').val()
        const accountno = $('#accountno').val()
        const ifsccode = $('#ifsccode').val()
        const bankname = $('#bankname').val()
        const bankbranchname = $('#bankbranchname').val()
        const panno = $('#panno').val()
        // Form 5
        var pass = null
        var password = $('#teacherpassword').val()
        const passwordConfirm = $('#teacherpasswordconfirm').val()
        if (password.length < 6) {
            password = '<span class="text-danger">Password length must be atleast 6</span>'
        } else if (passwordConfirm.length < 6) {
            password = '<span class="text-danger">Confirm Password length must be atleast 6</span>'
        } else if (password != passwordConfirm) {
            password = '<span class="text-danger">Password and Confirm Password are not same</span>'
        } else if (password.length >= 6 && passwordConfirm.length >= 6 && (password === passwordConfirm)) {
            pass = 1
        }

        $('#display-name').html(name ? name : '<span class="text-danger">Name field is empty</span>')
        $('#display-email').html(email ? email : '<span class="text-danger">Email field is empty</span>')
        $('#display-dob').html(dob ? dob : '<span class="text-danger">Date of Birth field is empty</span>')
        $('#display-phone').html(phone ? phone : '<span class="text-danger">Phone field is empty</span>')
        $('#display-address').html(address ? address : '<span class="text-danger">Address field is empty</span>')
        $('#display-qualifications').html(qualifications ? qualifications : '<span class="text-danger">Educational Qualifications field is empty</span>')
        $('#display-computerskills').html(computerskills ? computerskills : '<span class="text-danger">Computer skills field is empty</span>')
        $('#display-joindate').html(joindate ? joindate : '<span class="text-danger">Join Date field is empty</span>')
        $('#display-branch').html(branch ? branch : '<span class="text-danger">Branch field is empty</span>')
        $('#display-jobStartTime').html(jobStartTime ? jobStartTime : '<span class="text-danger">Job Start Time field is empty</span>')
        $('#display-jobEndTime').html(jobEndTime ? jobEndTime : '<span class="text-danger">Job End Time field is empty</span>')
        $('#display-courses_allocated').html(courses_allocated ? courses_allocated : '<span class="text-danger">Course(s) allocation field is empty</span>')
        $('#display-accountname').html(accountname ? accountname : '<span class="text-dark">Account Name field is empty</span>')
        $('#display-accountno').html(accountno ? accountno : '<span class="text-dark">Account Number field is empty</span>')
        $('#display-ifsccode').html(ifsccode ? ifsccode : '<span class="text-dark">IFSC Code field is empty</span>')
        $('#display-bankname').html(bankname ? bankname : '<span class="text-dark">Bank Name field is empty</span>')
        $('#display-bankbranchname').html(bankbranchname ? bankbranchname : '<span class="text-dark">Bank Branch Name field is empty</span>')
        $('#display-panno').html(panno ? panno : '<span class="text-dark">PAN Number field is empty</span>')
        $('#display-password').html(password ? password : '<span class="text-danger">Password field is empty</span>')

        // console.log(!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !password);
        if (!name || !email || !dob || !phone || !address || !qualifications || !computerskills || !joindate || !branch || !jobStartTime || !jobEndTime || !courses_allocated || !pass) {
            next.disabled = true
        } else {
            finalSubmit = 1
            next.disabled = false
        }
    }
}
// Progress Steps JS End

$('#teacherpassword').change(() => {

    const password = $('#teacherpassword').val()
    const confirmPassword = $('#teacherpasswordconfirm').val()

    if (password.length >= 6) {
        $('#passSuccessContainer').css('display', 'block')
        $('#passSuccess').html(`<li>Password length is 6 characters</li>`)

        $('#passErrorsContainer').css('display', 'none')
        if (confirmPassword.length >= 6) {
            if (password === confirmPassword) {
                $('#passSuccessContainer').css('display', 'block')
                $('#passSuccess').html(`<li>Password length is 6 characters</li><li>Password and Confirm Password matches</li>`)

                $('#passErrorsContainer').css('display', 'none')
            }
        }
    } else {
        $('#passErrorsContainer').css('display', 'block')
        $('#passErrors').html(`<li>Password length must be at least 6 characters</li>`)

        $('#passSuccessContainer').css('display', 'none')
    }
})

function loadBranchesList() {

    $.ajax({
        url: '/sdp/branches',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var branches_list;
                $('#teacherbranch').text(response.data)

                if (response.data.length == 0) {
                    branches_list += `<option value="">Branch List is empty</option>`;
                } else {
                    branches_list = `<option value="">Select Branch Name</option>`;
                    response.data.forEach(branch => {

                        branches_list += `
                        <option value="${branch.name}">${branch.name}</option>`;
                    });
                }

                $('#teacherbranch').html(branches_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Branches Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadBranchesList()

function loadCoursesList() {

    var tbody_tasks = ``;

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var courses_list = ``;
                $('#teachercourses').text(response.data)

                if (response.count == 0) {
                    tbody_tasks += `
                        <option value="">No Course available</option>`;
                } else {
                    // courses_list = `
                    // <input type="checkbox" name="default-batches" id="default-batches" class="mt-0">
                    // <label for="default-batches">Add default batches</label>`;
                    response.data.forEach(course => {

                        tbody_tasks += `
                        <option id="${course._id}" value="${course.name}">${course.name}</option>`;
                        category_id_list.push(course._id)
                        courses_all_list.push([course._id, course.name])
                    });
                }

                $('#myDropdown1-1').html(tbody_tasks)
                category_id_list.forEach(cat => {
                    $(`#${cat}`).click(() => {

                        const category = $('#myDropdown1-1').val()
                        if (category != '') {
                            // console.log(category);
                            $('#category_selected').text(category)
                            document.getElementById('category_selected').classList.add('c_selected')
                            update()
                        } else {
                            document.getElementById('category_selected').classList.remove('c_selected')
                            $('#category_selected').text('No Course selected')
                            document.getElementById("myDropdown1").classList.remove("show");
                        }


                    })
                });

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Courses Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_courses tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_courses tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadCoursesList()

$('#teacherpassword,#teacherpasswordconfirm').keyup(() => {
    const password = $('#teacherpassword').val()
    const confirmPassword = $('#teacherpasswordconfirm').val()

    if (password.length >= 6) {
        if (confirmPassword.length >= 6) {
            $('#passSuccessContainer').css('display', 'block')
            $('#passSuccess').html(`<li>Password length is 6 characters</li>`)

            $('#passErrorsContainer').css('display', 'none')
            if (password === confirmPassword) {
                $('#passSuccessContainer').css('display', 'block')
                $('#passSuccess').html(`<li>Password length is 6 characters</li><li>Password and Confirm Password matches</li>`)

                $('#passErrorsContainer').css('display', 'none')
            } else {
                $('#passErrorsContainer').css('display', 'block')
                $('#passErrors').html(`<li>Password and Confirm Password does not match</li>`)

                $('#passSuccessContainer').css('display', 'none')
            }
        } else {
            $('#passErrorsContainer').css('display', 'block')
            $('#passErrors').html(`<li>Confirm Password length must be at least 6 characters</li>`)

            $('#passSuccessContainer').css('display', 'none')
        }
    } else {
        $('#passErrorsContainer').css('display', 'block')
        $('#passErrors').html(`<li>Password length must be at least 6 characters</li>`)

        $('#passSuccessContainer').css('display', 'none')
    }
})

// console.log(courses_all_list); // Use this array to fetch courses allocated for teacher

// $('.addNewTeacher').click(() => {
//     alert('Submit')
//     // var nameInput = $('#teachername')
//     // var teachername = $('#teachername').val()

//     // var addressInput = $('#teacheraddress')
//     // var teacheraddress = $('#teacheraddress').val()

//     // if (!teachername) {
//     //     nameInput.css('border', '2px solid red')
//     //     nameInput.attr('placeholder', 'Please add teacher name')
//     // } else if (!teacheraddress) {
//     //     addressInput.css('border', '2px solid red')
//     //     addressInput.attr('placeholder', 'Please add teacher address')
//     // } else {

//     //     loading()

//     //     $.ajax({
//     //         url: '/sdp/teachers',
//     //         method: 'post',
//     //         dataType: 'json',
//     //         data: {
//     //             name: teachername,
//     //             address: teacheraddress
//     //         },
//     //         success: function (response) {
//     //             if (response.success) {

//     //                 $('#error,#loading').css('display', 'none')
//     //                 nameInput.val(null)
//     //                 addressInput.val(null)
//     //                 $('#add-teacher-card button').attr('disabled', true)
//     //                 Swal.fire({
//     //                     toast: true,
//     //                     position: 'top-right',
//     //                     icon: 'success',
//     //                     title: 'Teacher Added Successfully',
//     //                     timer: 3000,
//     //                     showConfirmButton: false
//     //                 });
//     //                 setTimeout(() => {
//     //                     document.location.replace('/sdp/admin/teachers');
//     //                 }, 2500);

//     //             } else {

//     //                 $('#loading').css('display', 'none');
//     //                 $('#error').text(response.responseJSON.error);
//     //                 $('#error').fadeIn();
//     //                 $('#error').css('display', 'block');
//     //                 $('#add-teacher-card button').attr('disabled', true)

//     //             }
//     //         },
//     //         error: function (response) {

//     //             $('#loading').css('display', 'none');
//     //             $('#error').text(response.responseJSON.error);
//     //             $('#error').fadeIn();
//     //             $('#error').css('display', 'block');
//     //             $('#add-teacher-card button').attr('disabled', true)

//     //         }
//     //     });

//     // }
// })