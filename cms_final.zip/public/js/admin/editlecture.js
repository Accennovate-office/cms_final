
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-lectures').trigger("click")
$('#sidebar-lectures,#sidebar-lectures-edit').addClass('active')
$("div#mySidebar").scrollTop(400); // Ref: https://api.jquery.com/scrolltop/

var students_all_list = []
const students_id_list = []
var selectedCourseID 

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i, div;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        var txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none"
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
$('#myInput1,#myInput2').focusout(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.png')
})
// Searchable dropdown end


// New feature - topics
function fetchTopics(courseID) {

    // Change placeholder
    $('#topics').prop('placeholder', 'Select topics from dropdown');
    checkInputs()
    $.ajax({
        url: `/sdp/topics?course=${courseID}`,
        method: 'get',
        success: function (response) {
            if (response.success) {
                // console.log(response.data);

                var topics_list;
                if (response.data.length == 0) {
                    topics_list += `<option value="">Topics List is empty</option>`;
                } else {
                    topics_list = `<option value="">Add topic</option>`;
                    response.data.forEach(topic => {

                        topics_list += `
                        <option value="${topic.name}">${topic.name}</option>`;
                    });
                }

                $('#lecture_topics').html(topics_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Topics Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });
            }
        }
    })
    
}
$('#coursename').change(()=>{
    // console.log(`Course changed to `+$('#coursename').val());
    const coursename = $('#coursename').val()

    if (coursename != '') fetchTopics(coursename)

})

$('#lecture_topics').change(() => {
    const topicSelected = $('#lecture_topics').val()
    if (topicSelected !== '') {
        
        const value = $('#topics').val()

        if (value == '') $('#topics').val(value + topicSelected)
        else $('#topics').val(value + ',' + topicSelected)

        $('#clearTopicsButton').prop('disabled', false)
        checkInputs()
    }
})

$('#clearTopicsButton').click(() => {
    checkInputs()
    $('#topics').val('')
    $('#clearTopicsButton').prop('disabled', true)
})


// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['lecture'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/lectures')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Lecture Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function disableInputs() {

    $('#teachername').val('')
    $('#coursename').val('')
    $('#category_selected').val('No Student selected')
    $('#dateTime').val('')
    $('#lectureOrExam').val('')
    $('#topics').val('Course Fees here')

    $('#teachername,#dropbtn1,#coursename,#lectureOrExam,#dateTime').attr('disabled', true)
}

function checkInputs() {

    var teachername = $('#teachername').val()
    var coursename = $('#coursename').val()

    // Students list
    var students_allocated = $('#myDropdown1-1').val().toString()
    if (students_allocated == 'No Course selected') {
        students_allocated = ''
    }

    var dateTime = $('#dateTime').val()
    var lectureOrExam = $("input[type='radio'][name='lectureOrExam']:checked").val();
    var topics = $('#topics').val()

    if (teachername || students_allocated || coursename || topics || lectureOrExam || dateTime) {
        $('#editlecture #edit-lecture-btn').attr('disabled', true)
        if (teachername && students_allocated && coursename && topics && lectureOrExam && dateTime) {
            $('#editlecture #edit-lecture-btn').attr('disabled', false)
        } else {
            $('#editlecture #edit-lecture-btn').attr('disabled', true)
        }
    }
}

$('#editlecture #teachername,#editlecture #dropbtn1,#editlecture #coursename,#editlecture #topics,#editlecture #dateTime,#editlecture input').change(() => { checkInputs(); })
$('#editlecture #topics').keyup(() => { checkInputs(); })

function loadLecturesList(teachername = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading lectures list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/lectures',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var lectures_list;
                $('#editlecture #lecture-list').text(response.data)

                if (response.data.length == 0) {
                    lectures_list += `<option value="">Lecture List is empty</option>`;
                } else {
                    lectures_list = `<option value="">Select Lecture Name</option>`;
                    response.data.forEach(lecture => {
                        var select;
                        if ((teachername == `${lecture.student.firstName} ${lecture.student.lastName}`) || (lecture._id == selected)) {
                            select = 'selected'
                        } else {
                            select = ''
                        }

                        // var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                        // var dateTimeTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString("en-IN", dateOptions)

                        var optionsNew = { timeZone: 'UTC', year: 'numeric', month: 'long', day: 'numeric' };
                        var dateTimeTimeEnglishIST = new Date(lecture.dateTime).toLocaleTimeString('en-US', optionsNew) // New Testing

                        lectures_list += `
                        <option ${select} value="${lecture._id}">${dateTimeTimeEnglishIST} > ${lecture.teacher.name}</option>`;
                    });
                }
                $('#editlecture #lecture-list').html(lectures_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Lectures Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Lectures',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_lectures tbody .col').html(errorMsg)
                $('#lecture-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Lectures',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#lecture-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch lectures list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_lectures tbody .col').html(errorMsg)
                $('#lecture-selected').html(errorMsg)
            }

        }
    });

}
loadLecturesList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing lecture details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#lecture-selected').css('display', 'block')
function getLectureDetails() {

    students_all_list = []
    const selectLecture = $('#lecture-list').val() ? $('#lecture-list').val() : selected

    $('#editlecture button').attr('disabled', true)
    // console.log(selectLecture);
    if (selectLecture == '') {

        disableInputs()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching lecture details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#teachername,#dropbtn1,#coursename,#lectureOrExam,#dateTime').attr('disabled', false)

        $.ajax({
            url: `/sdp/lectures/${selectLecture}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const lectureTeacher = response.data.teacher.name
                    const lectureCourse = response.data.course.name
                    selectedCourseID = response.data.course._id
                    fetchTopics(selectedCourseID)
                    const studentsAllocated = response.data.student.split(',')
                    // console.log(coursesAllocated);

                    $('#lectureid').val(response.data._id)
                    $('#topics').val(response.data.topicsCovered)

                    var lectureDate = response.data.dateTime.slice(0, 10)
                    var dateOptions = { hour: 'numeric', minute: 'numeric' };
                    var lectureTimeEnglishIST = new Date(response.data.dateTime).toLocaleDateString("en-IN", dateOptions)
                    // console.log(lectureTimeEnglishIST);
                    var lectureTime = lectureTimeEnglishIST.split(' ')[1]
                    // console.log(lectureTime);
                    var dateTime
                    if (lectureTime.length == 5) {
                        dateTime = `${lectureDate}T${lectureTime}`
                    } else {
                        dateTime = `${lectureDate}T0${lectureTime}`
                    }
                    // console.log(dateTime);
                    // $('#dateTime').val(dateTime) // Previous
                    $('#dateTime').val(response.data.dateTime.slice(0, 16)) // New testing

                    var Lecture = ''
                    var Exam = ''
                    if (response.data.lectureOrExam == 'Lecture') {
                        Lecture = 'checked'
                    } else if (response.data.lectureOrExam == 'Exam') {
                        Exam = 'checked'
                    }
                    $('#lectureOrExam').html(`
                    <input ${Lecture} type="radio" name="lectureOrExam" value="Lecture" id="lecture" class="my-2 mr-1 pt-1">
                    <label for="lecture" class="my-2 mr-1 pt-1">Lecture</label>
                    <input ${Exam} type="radio" name="lectureOrExam" value="Exam" id="exam" class="my-2 mr-1 pt-1">
                    <label for="exam" class="my-2 mr-1 pt-1">Exam</label>`)

                    const change_list = ['lecture', 'exam']
                    for (let x = 0; x < change_list.length; x++) {
                        var element = document.getElementById(change_list[x])
                        element.addEventListener('click', () => {
                            // alert('Update')
                            checkInputs();
                        })

                    }

                    $.ajax({
                        url: '/sdp/students/special/data',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var students_list = ``;
                                $('#editlecture #students').text(response.data)

                                if (response.data.length == 0) {
                                    students_list += `<option value="">No Student available</option>`;
                                } else {

                                    response.data.forEach(student => {
                                        var checked = ''

                                        studentsAllocated.forEach(allocated_student => {
                                            if (allocated_student === `${student.firstName} ${student.middleName} ${student.lastName}`) {
                                                checked = 'selected'
                                            }
                                        });

                                        students_list += `
                                        <option ${checked} id="${student._id}" value="${student.firstName} ${student.middleName} ${student.lastName}">${student.firstName} ${student.middleName} ${student.lastName}</option>`;
                                        students_id_list.push(student._id)
                                        students_all_list.push([student._id, `${student.firstName} ${student.middleName} ${student.lastName}`])

                                    });
                                    // console.log(students_list);
                                    $('#editlecture #myDropdown1-1').html(students_list)
                                    const category = $('#myDropdown1-1').val()
                                    if (category != '') {
                                        // console.log(category);
                                        $('#category_selected').text(category)
                                        document.getElementById('category_selected').classList.add('c_selected')
                                    } else {
                                        document.getElementById('category_selected').classList.remove('c_selected')
                                        $('#category_selected').text('No Course selected')
                                        document.getElementById("myDropdown1").classList.remove("show");
                                    }
                                    students_id_list.forEach(cat => {
                                        $(`#${cat}`).click(() => {

                                            const category = $('#myDropdown1-1').val()
                                            if (category != '') {
                                                // console.log(category);
                                                $('#category_selected').text(category)
                                                document.getElementById('category_selected').classList.add('c_selected')
                                                checkInputs()
                                            } else {
                                                document.getElementById('category_selected').classList.remove('c_selected')
                                                $('#category_selected').text('No Student selected')
                                                document.getElementById("myDropdown1").classList.remove("show");
                                                checkInputs();
                                            }


                                        })
                                    });

                                }

                                // $('#editlecture #teachername').html(students_list)

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Students Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Lecture Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                            } else {

                                disableInputs()

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Students',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            disableInputs()

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Students',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {

                                disableInputs()

                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch students list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#no-student-selected').html(errorMsg)
                            }

                        }
                    });

                    $.ajax({
                        url: '/sdp/courses',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var courses_list = ``;
                                $('#coursename').text(response.data)

                                if (response.count == 0) {
                                    courses_list += `<span class="badge badge-light">Course list is empty</span>`;
                                } else {
                                    // courses_list = `
                                    // <input type="checkbox" name="default-batches" id="default-batches" class="mt-0">
                                    // <label for="default-batches">Add default batches</label>`;
                                    response.data.forEach(course => {

                                        if (lectureCourse == course.name) {
                                            courses_list += `
                                        <option selected value="${course._id}">${course.name}</option>`;
                                        } else {
                                            courses_list += `
                                        <option value="${course._id}">${course.name}</option>`;
                                        }

                                    });
                                    // console.log(courses_list);
                                    $('#editlecture #coursename').html(courses_list)

                                }

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Courses Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_courses tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-course-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-course-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch courses list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_courses tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                    $.ajax({
                        url: '/sdp/teachers',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var teachers_list = ``;
                                $('#lectureteachers').text(response.data)

                                if (response.count == 0) {
                                    teachers_list += `<span class="badge badge-light">Teacher list is empty</span>`;
                                } else {
                                    // teachers_list = `
                                    // <input type="checkbox" name="default-batches" id="default-batches" class="mt-0">
                                    // <label for="default-batches">Add default batches</label>`;
                                    response.data.forEach(teacher => {

                                        if (lectureTeacher == teacher.user.name) {
                                            teachers_list += `
                                        <option selected value="${teacher.user._id}">${teacher.user.name}</option>`;
                                        } else {
                                            teachers_list += `
                                        <option value="${teacher.user._id}">${teacher.user.name}</option>`;
                                        }

                                    });
                                    // console.log(teachers_list);
                                    $('#editlecture #teachername').html(teachers_list)

                                }

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Teachers Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_teachers tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-teacher-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-teacher-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch teachers list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_teachers tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    disableInputs()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Lectures',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_lectures tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-lecture-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                disableInputs()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Lectures',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-lecture-card button').attr('disabled', true)

                } else {
                    disableInputs()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch lecture details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_lectures tbody .col').html(errorMsg)
                    $('#no-lecture-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getLectureDetails()
}
$('#lecture-list').change(() => {

    getLectureDetails()

})

$('#edit-lecture-btn').click(() => {
    // Extra security code
    var lectureid = $('#lectureid').val()
    // console.log(lectureid);
    var teachernameInput = $('#teachername')
    var teachername = $('#teachername').val()

    var coursenameInput = $('#coursename')
    var coursename = $('#coursename').val()

    // Students list
    var studentsInput = $('#dropbtn1')
    var students_allocated = $('#myDropdown1-1').val().toString()
    if (students_allocated == 'No Student selected') {
        students_allocated = ''
    }

    var topicsInput = $('#topics')
    var topics = $('#topics').val()

    var lectureOrExamInput = $('#lectureOrExam')
    var lectureOrExam = $("input[type='radio'][name='lectureOrExam']:checked").val();

    var dateTimeInput = $('#dateTime')
    var dateTime = $('#dateTime').val()

    if (!teachername) {
        teachernameInput.css('border', '2px solid red')
    } else if (!students_allocated) {
        studentsInput.css('border', '2px solid red')
    } else if (!coursename) {
        coursenameInput.css('border', '2px solid red')
    } else if (!topics) {
        topicsInput.css('border', '2px solid red')
        topicsInput.attr('placeholder', 'Please add Lecture Topics')
    } else if (!lectureOrExam) {
        lectureOrExamInput.css('border', '2px solid red')
    } else if (!dateTime) {
        dateTimeInput.css('border', '2px solid red')
    } else {

        $('#editlecture button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // Update lecture
        $.ajax({
            url: `/sdp/lectures/${lectureid}`,
            method: 'put',
            dataType: 'json',
            data: {
                teacher: teachername,
                course: coursename,
                student: students_allocated,
                dateTime: dateTime,
                lectureOrExam: lectureOrExam,
                topicsCovered: topics,
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-lecture-card button').attr('disabled', true)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Lecture Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        loadLecturesList(teachername)
                    }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-lecture-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            }
        });

    }
})

// $('#coursename').change(() => {
//     const coursename = $('#coursename').val()
//     // alert(coursename)
//     if (coursename != '') {
//         $('#topics').val('Calculating...')

//         $.ajax({
//             url: `/sdp/courses/${coursename}`,
//             method: 'get',
//             success: function (response) {
//                 if (response.success) {

//                     $('#topics').val(response.data.fees)

//                     // Success
//                     Swal.fire({
//                         toast: true,
//                         position: 'top-right',
//                         icon: 'success',
//                         title: 'Course Fees Calculated',
//                         timer: 3000,
//                         showConfirmButton: false
//                     });



//                 } else {

//                     $('#loading').css('display', 'none');
//                     $('#table_students tbody tr').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#errors').fadeIn();
//                     $('#errors').css('display', 'block');
//                     $('#add-student-card button').attr('disabled', true)

//                 }
//             },
//             error: function (response) {

//                 if (response.responseJSON) {
//                     $('#loading').css('display', 'none');
//                     $('#errors').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#errors').fadeIn();
//                     // $('#errors').css('display', 'block');
//                     $('#add-student-card button').attr('disabled', true)

//                 } else {
//                     $('#errors').fadeIn();
//                     var errorMsg = `
//                     <center class="text-danger">
//                     <h2>Oops! Something went wrong</h2>
//                     <h4>
//                         Error Code: ${response.status} <br>
//                         Error Message: ${response.statusText}
//                     </h4>
//                     <h5>We were unable to fetch students list</h5>
//                     <h6>
//                         Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                     </h6>
//                     </center>`
//                     console.log(`something went wrong ${JSON.stringify(response)}`);
//                     // console.log(response.statusText);
//                     // $('#table_students tbody .col').html(errorMsg)
//                     $('#errors').html(errorMsg)
//                 }

//             }
//         });

//     } else {
//         $('#topics').val('Course Fees here')
//     }
// })
