
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-managers').trigger("click")
$('#sidebar-managers,#sidebar-managers-edit').addClass('active')
$("div#mySidebar").scrollTop(150); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['manager'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/managers')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Manager Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#editmanager #managername,#editmanager #manageraddress,#editmanager #managerdob,#editmanager #managerphone,#editmanager #manageremail,#editmanager #manageredu,#editmanager #managerjoin,#editmanager #managerbranch,#editmanager #managerjobstart,#editmanager #managerjobend').change(() => {

    var managername = $('#managername').val()
    var manageraddress = $('#manageraddress').val()
    var managerdob = $('#managerdob').val()
    var managerphone = $('#managerphone').val()
    var manageremail = $('#manageremail').val()
    var manageredu = $('#manageredu').val()
    var managerjoin = $('#managerjoin').val()
    var managerbranch = $('#managerbranch').val()
    var managerjobstart = $('#managerjobstart').val()
    var managerjobend = $('#managerjobend').val()

    if (managername || manageraddress || managerdob || managerphone || manageremail || manageredu || managerjoin || managerbranch || managerjobstart || managerjobend) {
        $('#editmanager button').attr('disabled', true)
        if (managername && manageraddress && managerdob && managerphone && manageremail && manageredu && managerjoin && managerbranch && managerjobstart && managerjobend) {
            $('#editmanager button').attr('disabled', false)
        } else {
            $('#editmanager button').attr('disabled', true)
        }
    }
})

// function loadManagersList(managername = null) {

//     // Loading by blocking outsideClick
//     Swal.fire({
//         imageUrl: '/images/loading/sdp_logo_loading.gif',
//         title: `Loading managers list`,
//         showConfirmButton: false,
//         allowOutsideClick: false
//     });

//     $.ajax({
//         url: '/sdp/managers',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var managers_list;
//                 $('#editmanager #manager').text(response.data)

//                 if (response.data.length == 0) {
//                     managers_list += `<option value="">Manager List is empty</option>`;
//                 } else {
//                     managers_list = `<option value="">Select Manager Name</option>`;
//                     response.data.forEach(manager => {
//                         var select
//                         if ((managername == manager.user.name) || (manager.user.slug == selected)) {
//                             select = 'selected'
//                         } else {
//                             select = ''
//                         }

//                         managers_list += `
//                         <option ${select} value="${manager.user.slug}">${manager.user.name}</option>`;
//                     });
//                 }
//                 $('#editmanager #manager').html(managers_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Managers Loaded Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'error',
//                     title: 'Error Loading Managers',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Request Success: ${response.success} <br>
//                     Data Received: ${JSON.stringify(response.data)}
//                 </h4>
//                 <h5>We were unable to process the request</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_managers tbody .col').html(errorMsg)
//                 $('#manager-selected').html(errorMsg)

//             }
//         },
//         error: function (response) {

//             Swal.fire({
//                 toast: true,
//                 position: 'top-right',
//                 icon: 'error',
//                 title: 'Error Loading Managers',
//                 timer: 3000,
//                 showConfirmButton: false
//             });

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#manager-selected').html(response.responseJSON.error)
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-manager-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch managers list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_managers tbody .col').html(errorMsg)
//                 $('#manager-selected').html(errorMsg)
//             }

//         }
//     });

// }
// loadManagersList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing manager details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#manager-selected').css('display', 'block')

var managerSlug = ''
function getManagerDetails() {

    const selectManager = $('#manager').val() ? $('#manager').val() : selected

    $('#editmanager button').attr('disabled', true)
    // console.log(selectManager);
    if (selectManager == '') {

        $('#managername').val('Manager Name here')
        $('#managername').attr('disabled', true)

        $('#manageraddress').val('Manager Address here')
        $('#manageraddress').attr('disabled', true)

        $('#managerdob').val('')
        $('#managerdob').attr('disabled', true)

        $('#managerphone').val('Manager Phone here')
        $('#managerphone').attr('disabled', true)

        $('#manageremail,#manageremailagain').val('Manager Email here')
        $('#manageremail,#manageremailagain').attr('disabled', true)

        $('#manageredu').val('Manager Educational Qualifications here')
        $('#manageredu').attr('disabled', true)

        $('#managerjoin').val('')
        $('#managerjoin').attr('disabled', true)

        $('#managerbranch').val('')
        $('#managerbranch').attr('disabled', true)

        $('#managerjobstart').val('')
        $('#managerjobstart').attr('disabled', true)

        $('#managerjobend').val('')
        $('#managerjobend').attr('disabled', true)

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching ${selectManager} manager details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#managername').attr('disabled', false)
        $('#manageraddress').attr('disabled', false)
        $('#managerdob').attr('disabled', false)
        $('#managerphone').attr('disabled', false)
        $('#manageremail').attr('disabled', false)
        $('#manageredu').attr('disabled', false)
        $('#managerjoin').attr('disabled', false)
        $('#managerbranch').attr('disabled', false)
        $('#managerjobstart').attr('disabled', false)
        $('#managerjobend').attr('disabled', false)

        $.ajax({
            url: `/sdp/managers/${selectManager}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const managerBranch = response.data.user.branch
                    managerSlug = response.data.user.slug
                    $('#edit-manager').text(response.data.user.name)
                    $('#managerid').val(response.data._id)
                    $('#managername').val(response.data.user.name)
                    $('#manageraddress').val(response.data.address)
                    $('#managerdob').val(response.data.dob.slice(0, 10))
                    $('#managerphone').val(response.data.phone)
                    $('#manageremail,#manageremailagain').val(response.data.user.email)
                    $('#manageredu').val(response.data.educationalQualification)
                    $('#managerjoin').val(response.data.joiningDate.slice(0, 10))
                    $('#managerjobstart').val(response.data.jobTime.slice(0, 5))
                    $('#managerjobend').val(response.data.jobTime.slice(6, 11))

                    $.ajax({
                        url: '/sdp/branches',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var branches_list;
                                $('#editmanager #managerbranch').text(response.data)

                                if (response.data.length == 0) {
                                    branches_list += `<option value="">Branch List is empty</option>`;
                                } else {
                                    // branches_list = `<option value="">Select Branch Name</option>`;
                                    response.data.forEach(branch => {

                                        if (managerBranch == branch.name) {
                                            branches_list += `
                                        <option selected value="${branch.name}">${branch.name}</option>`;
                                        } else {
                                            branches_list += `
                                        <option value="${branch.name}">${branch.name}</option>`;
                                        }

                                    });
                                }

                                $('#editmanager #managerbranch').html(branches_list)

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Branches Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Manager Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Branches',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                $('#table_branches tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Branches',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            } else {
                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch branches list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_branches tbody .col').html(errorMsg)
                                $('#no-branch-selected').html(errorMsg)
                            }

                        }
                    });

                } else {

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Managers',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_managers tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-manager-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Managers',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-manager-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch manager details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_managers tbody .col').html(errorMsg)
                    $('#no-manager-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getManagerDetails()
}
$('#manager').change(() => {

    getManagerDetails()

})

$('#edit-manager-btn').click(() => {
    // Extra security code
    var managerid = $('#managerid').val()
    // console.log(managerid);
    var nameInput = $('#managername')
    var managername = $('#managername').val()

    var addressInput = $('#manageraddress')
    var manageraddress = $('#manageraddress').val()

    var dobInput = $('#managerdob')
    var managerdob = $('#managerdob').val()

    var phoneInput = $('#managerphone')
    var managerphone = $('#managerphone').val()

    var emailInput = $('#manageremail')
    var manageremail = $('#manageremail').val()

    var eduInput = $('#manageredu')
    var manageredu = $('#manageredu').val()

    var joinInput = $('#managerjoin')
    var managerjoin = $('#managerjoin').val()

    var branchInput = $('#managerbranch')
    var managerbranch = $('#managerbranch').val()

    var jobstartInput = $('#managerjobstart')
    var managerjobstart = $('#managerjobstart').val()

    var jobendInput = $('#managerjobend')
    var managerjobend = $('#managerjobend').val()

    if (!managername) {
        nameInput.css('border', '2px solid red')
        nameInput.attr('placeholder', 'Please add manager name')
    } else if (!manageraddress) {
        addressInput.css('border', '2px solid red')
        addressInput.attr('placeholder', 'Please add manager address')
    } else if (!managerdob) {
        dobInput.css('border', '2px solid red')
    } else if (!managerphone) {
        phoneInput.css('border', '2px solid red')
        phoneInput.attr('placeholder', 'Please add manager phone')
    } else if (!manageremail) {
        emailInput.css('border', '2px solid red')
        emailInput.attr('placeholder', 'Please add manager email')
    } else if (!manageredu) {
        eduInput.css('border', '2px solid red')
        eduInput.attr('placeholder', 'Please add manager edu')
    } else if (!managerjoin) {
        joinInput.css('border', '2px solid red')
    } else if (!managerbranch) {
        branchInput.css('border', '2px solid red')
        branchInput.attr('placeholder', 'Please select manager branch')
    } else if (!managerjobstart) {
        jobstartInput.css('border', '2px solid red')
    } else if (!managerjobend) {
        jobendInput.css('border', '2px solid red')
    } else {

        $('#editmanager button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // Update manager
        $.ajax({
            url: `/sdp/managers/${managerid}`,
            method: 'put',
            dataType: 'json',
            data: {
                dob: managerdob,
                phone: managerphone,
                address: manageraddress,
                educationalQualification: manageredu,
                joiningDate: managerjoin,
                jobTime: `${managerjobstart},${managerjobend}`
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-manager-card button').attr('disabled', true)

                    // Update user
                    $.ajax({
                        url: `/sdp/users/${manageremail.split('@')[0]}`,
                        method: 'put',
                        dataType: 'json',
                        data: {
                            name: managername,
                            dob: managerdob,
                            branch: managerbranch,
                            email: manageremail
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                $('#edit-manager-card button').attr('disabled', true)
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Manager Updated Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    loadManagersList(managername)
                                }, 3000);

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-manager-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-manager-card button').attr('disabled', true)

                        }
                    });

                    // Swal.fire({
                    //     toast: true,
                    //     position: 'top-right',
                    //     icon: 'success',
                    //     title: 'Manager Updated Successfully',
                    //     timer: 3000,
                    //     showConfirmButton: false
                    // });
                    // setTimeout(() => {
                    //     loadManagersList(managername)
                    // }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-manager-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-manager-card button').attr('disabled', true)

            }
        });

    }
})

$('#edit-manager').click(() => {
    document.location.replace(`/sdp/admin/viewmanager?manager=${managerSlug}`)
})
