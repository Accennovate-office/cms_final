
$('#sidebar-attendances').trigger("click")
$('#sidebar-attendances,#sidebar-attendances-delete').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['attendance'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/attendances')
})

function loadAttendancesList() {

    $.ajax({
        url: '/sdp/attendances',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var attendances_list;
                $('#deleteattendance #attendance').text(response.data)

                if (response.data.length == 0) {
                    attendances_list += `<option value="">Attendance List is empty</option>`;
                } else {
                    attendances_list = `<option value="">Select Attendance Name</option>`;
                    response.data.forEach(attendance => {

                        if (attendance._id == selected) {

                            attendances_list += `
                            <option selected value="${attendance._id}">${attendance.name}</option>`;

                        } else {

                            attendances_list += `
                            <option value="${attendance._id}">${attendance.name}</option>`;

                        }
                    });
                }

                $('#deleteattendance #attendance').html(attendances_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Attendances Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_attendances tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-attendance-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-attendance-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch attendances list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_attendances tbody .col').html(errorMsg)
                $('#no-attendance-selected').html(errorMsg)
            }

        }
    });

}
loadAttendancesList()

const attendancename = $('#delete-attendancename')
const attendancedescription = $('#delete-attendancedescription')

const attendancestart = $('#delete-attendancestart')
const attendanceweeks = $('#delete-attendanceweeks')
const attendancefees = $('#delete-attendancefees')
const attendancebatches = $('#delete-attendancebatches')

const createbyname = $('#attendance-createbyname')
const createbyemail = $('#attendance-createbyemail')
const createbybranch = $('#attendance-createbybranch')

const createdat = $('#delete-attendancecreatedat')
const updatedat = $('#delete-attendanceupdatedat')
const attendanceid = $('#delete-attendanceid')

function getAttendanceDetails() {

    const selectAttendance = $('#attendance').val() ? $('#attendance').val() : selected
    // console.log(selectAttendance);
    if (selectAttendance == '') {
        $('#no-attendance-selected').css('display', 'block')
        $('#attendance-selected').css('display', 'none')
    } else {

        $('#no-attendance-selected').css('display', 'none')
        $('#attendance-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/attendances/${selectAttendance}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deleteattendance #attendance-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var attendanceStartingAt = new Date(response.data.startingAt).toLocaleDateString("en-IN", optionsCheck)

                    attendancename.text(response.data.name)
                    attendancedescription.text(response.data.description)

                    attendancestart.text(attendanceStartingAt)
                    attendanceweeks.text(`${response.data.weeks} weeks`)
                    attendancefees.text(`₹ ${response.data.fees}`)

                    var batches = ''
                    const batches_string = response.data.batchTiming.split(',')
                    // console.log(response.data.batchTiming);
                    batches_string.forEach(batch => {
                        batches += `<span class="badge badge-light">${batch}</span>`
                    });
                    attendancebatches.html(batches)
                    createbyname.text(response.data.createdBy.name)
                    createbyemail.text(response.data.createdBy.email)
                    createbybranch.text(`${response.data.createdBy.branch} Branch`)

                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    attendanceid.val(response.data._id)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Attendance Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_attendances tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-attendance-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-attendance-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch attendances list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_attendances tbody .col').html(errorMsg)
                    $('#no-attendance-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-attendance-selected').css('display', 'block')
$('#attendance-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getAttendanceDetails()
}
$('#attendance').change(() => {

    getAttendanceDetails()

})

$('#delete-attendance-btn').click(() => {
    var delattendanceid = $('#delete-attendanceid').val()
    var name = attendancename.text()
    // console.log(delattendanceid);
    swal.fire({
        title: 'Are you sure?',
        html: `You want to delete <span class="text-danger font-weight-bold">${name}</span> attendance details!`,
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({ 
                url: `/sdp/attendances/${delattendanceid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Attendance Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-attendance-selected').css('display', 'block')
                        $('#attendance-selected').css('display', 'none')
                        loadAttendancesList()

                        setTimeout(() => {
                            document.location.replace('/sdp/admin/deleteattendance');
                        }, 3000);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });

                }
            });

        }
    })
})
