$('#no-attendance-available').fadeOut()
$('#table_attendances,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#sidebar-attendances').trigger("click")
$('#sidebar-attendances,#sidebar-attendances-all').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

$('#new-attendance-btn').click(() => {
    document.location.replace('/sdp/admin/addattendance');
})

// Code by Raj
$(async function () {
    try {
        let registrations = await $.ajax({
            url: "/sdp/registrations",
            method: "GET",
            success: function (response) {
                return response;
            },
        });

        // Total daily

        // let presentToday = [];

        // registrations.data.forEach((a) => {
        //   dailyAttendance.data.forEach((b) => {
        //     if (a.biometricId == b.biometricId) {
        //       presentToday.push({biometricId:a.biometricId, name:a.name,designation:a.designation,loginOrLogout:b.loginOrLogout, time:new Date(b.dateTime).toLocaleString('en-IN', { hour12: true })})
        //       // presentToday.push(a.biometricId);
        //     }
        //   });
        // });

        // // $("#overview-list").html(table)

        // presentToday = presentToday.filter(
        //   (item, index) => presentToday.indexOf(item) == index
        // );

        // console.log(presentToday);
        // console.log(registrations.data);

        // let percentageDaily = (presentToday.length / registrations.data.length) * 100;

        // $("#daily-attendance").text(`${parseInt(percentageDaily)}%`);
        // if (percentageDaily > 50) {
        //   $("#daily-attendance-graph").addClass(
        //     `progress-circle over50 p${percentage(parseInt(percentageDaily))}`
        //   );
        // } else {
        //   $("#daily-attendance-graph").addClass(
        //     `progress-circle p${parseInt(percentageDaily)}`
        //   );
        // }

        //Attendance table
        let monthlyAttendance = await $.ajax({
            url: "/sdp/attendances/monthlyAttendance",
            method: "GET",
            success: function (response) {
                return response;
            },
        });


        //Totalmonthly

        let presentMonthly = [];

        registrations.data.forEach((a) => {
            monthlyAttendance.data.forEach((b) => {
                if (a.biometricId == b.biometricId) {
                    presentMonthly.push(a.biometricId);
                }
            });
        });

        presentMonthly = presentMonthly.filter(
            (item, index) => presentMonthly.indexOf(item) == index
        );

        console.log(presentMonthly);
        console.log(registrations.data);

        let percentageMonthly = (presentMonthly.length / registrations.data.length) * 100;

        $("#monthly-attendance").text(`${parseInt(percentageMonthly)}%`);
        if (percentageMonthly > 50) {
            $("#monthly-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(percentageMonthly)}`
            );
        } else {
            $("#monthly-attendance-graph").addClass(
                `progress-circle p${parseInt(percentageMonthly)}`
            );
        }

        //Managersmonthly

        let totalManagersMonthly = 0;
        let managerspresentMonthly = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Manager") {
                console.log(a.biometricId);
                totalManagersMonthly = totalManagersMonthly + 1;
            }
            monthlyAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Manager"
                ) {
                    managerspresentMonthly.push(a.biometricId);
                }
            });
        });

        managerspresentMonthly = managerspresentMonthly.filter(
            (item, index) => managerspresentMonthly.indexOf(item) == index
        );
        console.log(managerspresentMonthly);
        console.log(totalManagersMonthly);
        let managerpercentageMonthly =
            (managerspresentMonthly.length / totalManagersMonthly) * 100;

        $("#monthly-manager-attendance").text(`${parseInt(managerpercentageMonthly)}%`);
        if (managerpercentageMonthly > 50) {
            $("#monthly-manager-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(managerpercentageMonthly)}`
            );
        } else {
            $("#monthly-manager-attendance-graph").addClass(
                `progress-circle p${parseInt(managerpercentageMonthly)}`
            );
        }

        //Teachersmonthly

        let totalTeachersMonthly = 0;
        let teacherspresentMonthly = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Teacher") {
                totalTeachersMonthly = totalTeachersMonthly + 1;
            }
            monthlyAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Teacher"
                ) {
                    console.log(a.biometricId);
                    teacherspresentMonthly.push(a.biometricId);
                }
            });
        });

        teacherspresentMonthly = teacherspresentMonthly.filter(
            (item, index) => teacherspresentMonthly.indexOf(item) == index
        );

        console.log(teacherspresentMonthly);

        let teacherpercentageMonthly =
            (teacherspresentMonthly.length / totalTeachersMonthly) * 100;

        $("#monthly-teacher-attendance").text(`${parseInt(teacherpercentageMonthly)}%`);
        if (teacherpercentageMonthly > 50) {
            $("#monthly-teacher-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(teacherpercentageMonthly)}`
            );
        } else {
            $("#monthly-teacher-attendance-graph").addClass(
                `progress-circle p${parseInt(teacherpercentageMonthly)}`
            );
        }

        //Studentsmonthly
        let totalStudentsMonthly = 0;
        let studentspresentMonthly = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Student") {
                totalStudentsMonthly = totalStudentsMonthly + 1;
            }
            monthlyAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Student"
                ) {
                    console.log(a.biometricId);
                    studentspresentMonthly.push(a.biometricId);
                }
            });
        });

        studentspresentMonthly = studentspresentMonthly.filter(
            (item, index) => studentspresentMonthly.indexOf(item) == index
        );

        console.log(studentspresentMonthly);

        let studentpercentageMonthly =
            (studentspresentMonthly.length / totalStudentsMonthly) * 100;
        console.log(studentpercentageMonthly)
        $("#monthly-student-attendance").text(`${parseInt(studentpercentageMonthly)}%`);
        if (studentpercentageMonthly > 50) {
            $("#monthly-student-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(studentpercentageMonthly)}`
            );
        } else {
            $("#monthly-student-attendance-graph").addClass(
                `progress-circle p${parseInt(studentpercentageMonthly)}`
            );
        }

        //Monthly table
        let monthlyTableData = [];
        for (let i = 0; i < monthlyAttendance.data.length; i++) {
            for (let j = 0; j < monthlyAttendance.data.length; j++) {
                if (
                    monthlyAttendance.data[i].loginOrLogout !=
                    monthlyAttendance.data[j].loginOrLogout &&
                    monthlyAttendance.data[i].biometricId ==
                    monthlyAttendance.data[j].biometricId
                ) {
                    let login = new Date(monthlyAttendance.data[i].dateTime);
                    let logout = new Date(monthlyAttendance.data[j].dateTime);
                    if (
                        login.getUTCDate() == logout.getUTCDate() &&
                        !monthlyAttendance.data[i].match
                    ) {
                        monthlyAttendance.data[i].loginOrLogout == "Login"
                            ? (monthlyTableData = [...monthlyTableData, i, j])
                            : (monthlyTableData = [...monthlyTableData, j, i]);
                        monthlyAttendance.data[j] = {
                            ...monthlyAttendance.data[j],
                            match: true,
                        };
                    }
                }
            }
        }

        let monthlyTableHtml = `
                  
  `;

        for (let i = 0; i < monthlyAttendance.data.length; i = i + 2) {
            const user = registrations.data.filter((val) => {
                return (
                    val.biometricId ==
                    monthlyAttendance.data[monthlyTableData[i]].biometricId
                );
            });
            // console.log(user.name)
            // console.log({biometricId:monthlyAttendance.data[monthlyTableData[i]].biometricId,loginTime: (new Date(monthlyAttendance.data[monthlyTableData[i]].dateTime)).toLocaleString(), logoutTime: (new Date(monthlyAttendance.data[monthlyTableData[i+1]].dateTime)).toLocaleString() })
            monthlyTableHtml += `
    <div class="row">
    <div class="col">${user[0].name}</div>
    <div class="col">${user[0].branch}</div>
    <div class="col">${new Date(
                monthlyAttendance.data[monthlyTableData[i]].dateTime
            ).toLocaleString()}</div>
    <div class="col">${new Date(
                monthlyAttendance.data[monthlyTableData[i + 1]].dateTime
            ).toLocaleString()}</div>
    </div>
    `;
        }

        $("#contact-tab").click(function () {
            $("#overview-list").html(monthlyTableHtml);
        });



        //Attendance table
        try {
            let previousMonthlyAttendance = await $.ajax({
                url: "/sdp/attendances/prevMonthlyAttendance",
                method: "GET",
                success: function (response) {
                    return response;
                },
            });


            //Totalpreviousmonthly

            let presentPreviousMonthly = [];

            registrations.data.forEach((a) => {
                previousMonthlyAttendance.data.forEach((b) => {
                    if (a.biometricId == b.biometricId) {
                        presentPreviousMonthly.push(a.biometricId);
                    }
                });
            });

            presentPreviousMonthly = presentPreviousMonthly.filter(
                (item, index) => presentPreviousMonthly.indexOf(item) == index
            );

            console.log(presentPreviousMonthly);
            console.log(registrations.data);

            let percentagePreviousMonthly = (presentPreviousMonthly.length / registrations.data.length) * 100;

            $("#previous-monthly-attendance").text(`${parseInt(percentagePreviousMonthly)}%`);
            if (percentagePreviousMonthly > 50) {
                $("#previous-monthly-attendance-graph").addClass(
                    `progress-circle over50 p${parseInt(percentagePreviousMonthly)}`
                );
            } else {
                $("#previous-monthly-attendance-graph").addClass(
                    `progress-circle p${parseInt(percentagePreviousMonthly)}`
                );
            }

            //Managerspreviousmonthly

            let totalManagersPreviousMonthly = 0;
            let managerspresentPreviousMonthly = [];

            registrations.data.forEach((a) => {
                if (a.designation == "Manager") {
                    console.log(a.biometricId);
                    totalManagersPreviousMonthly = totalManagersPreviousMonthly + 1;
                }
                previousMonthlyAttendance.data.forEach((b) => {
                    if (
                        a.biometricId == b.biometricId &&
                        b.loginOrLogout == "Login" &&
                        a.designation == "Manager"
                    ) {
                        managerspresentPreviousMonthly.push(a.biometricId);
                    }
                });
            });

            managerspresentPreviousMonthly = managerspresentPreviousMonthly.filter(
                (item, index) => managerspresentPreviousMonthly.indexOf(item) == index
            );
            console.log(managerspresentPreviousMonthly);
            console.log(totalManagersPreviousMonthly);
            let managerpercentagePreviousMonthly =
                (managerspresentPreviousMonthly.length / totalManagersPreviousMonthly) * 100;

            $("#previous-monthly-manager-attendance").text(`${parseInt(managerpercentagePreviousMonthly)}%`);
            if (managerpercentagePreviousMonthly > 50) {
                $("#previous-monthly-manager-attendance-graph").addClass(
                    `progress-circle over50 p${parseInt(managerpercentagePreviousMonthly)}`
                );
            } else {
                $("#previous-monthly-manager-attendance-graph").addClass(
                    `progress-circle p${parseInt(managerpercentagePreviousMonthly)}`
                );
            }

            //Teacherspreviousmonthly

            let totalTeachersPreviousMonthly = 0;
            let teacherspresentPreviousMonthly = [];

            registrations.data.forEach((a) => {
                if (a.designation == "Teacher") {
                    totalTeachersPreviousMonthly = totalTeachersPreviousMonthly + 1;
                }
                previousMonthlyAttendance.data.forEach((b) => {
                    if (
                        a.biometricId == b.biometricId &&
                        b.loginOrLogout == "Login" &&
                        a.designation == "Teacher"
                    ) {
                        console.log(a.biometricId);
                        teacherspresentPreviousMonthly.push(a.biometricId);
                    }
                });
            });

            teacherspresentPreviousMonthly = teacherspresentPreviousMonthly.filter(
                (item, index) => teacherspresentPreviousMonthly.indexOf(item) == index
            );

            console.log(teacherspresentPreviousMonthly);

            let teacherpercentagePreviousMonthly =
                (teacherspresentPreviousMonthly.length / totalTeachersPreviousMonthly) * 100;

            $("#previous-monthly-teacher-attendance").text(`${parseInt(teacherpercentagePreviousMonthly)}%`);
            if (teacherpercentagePreviousMonthly > 50) {
                $("#previous-monthly-teacher-attendance-graph").addClass(
                    `progress-circle over50 p${parseInt(teacherpercentagePreviousMonthly)}`
                );
            } else {
                $("#previous-monthly-teacher-attendance-graph").addClass(
                    `progress-circle p${parseInt(teacherpercentagePreviousMonthly)}`
                );
            }

            //Studentspreviousmonthly
            let totalStudentsPreviousMonthly = 0;
            let studentspresentPreviousMonthly = [];

            registrations.data.forEach((a) => {
                if (a.designation == "Student") {
                    totalStudentsPreviousMonthly = totalStudentsPreviousMonthly + 1;
                }
                previousMonthlyAttendance.data.forEach((b) => {
                    if (
                        a.biometricId == b.biometricId &&
                        b.loginOrLogout == "Login" &&
                        a.designation == "Student"
                    ) {
                        console.log(a.biometricId);
                        studentspresentPreviousMonthly.push(a.biometricId);
                    }
                });
            });

            studentspresentPreviousMonthly = studentspresentPreviousMonthly.filter(
                (item, index) => studentspresentPreviousMonthly.indexOf(item) == index
            );

            console.log(studentspresentPreviousMonthly);

            let studentpercentagePreviousMonthly =
                (studentspresentPreviousMonthly.length / totalStudentsPreviousMonthly) * 100;
            console.log(studentpercentagePreviousMonthly)
            $("#previous-monthly-student-attendance").text(`${parseInt(studentpercentagePreviousMonthly)}%`);
            if (studentpercentagePreviousMonthly > 50) {
                $("#previous-monthly-student-attendance-graph").addClass(
                    `progress-circle over50 p${parseInt(studentpercentagePreviousMonthly)}`
                );
            } else {
                $("#previous-monthly-student-attendance-graph").addClass(
                    `progress-circle p${parseInt(studentpercentagePreviousMonthly)}`
                );
            }

            let previousMonthlyTableData = [];
            for (let i = 0; i < previousMonthlyAttendance.data.length; i++) {
                for (let j = 0; j < previousMonthlyAttendance.data.length; j++) {
                    if (
                        previousMonthlyAttendance.data[i].loginOrLogout !=
                        previousMonthlyAttendance.data[j].loginOrLogout &&
                        previousMonthlyAttendance.data[i].biometricId ==
                        previousMonthlyAttendance.data[j].biometricId
                    ) {
                        let login = new Date(monthlyAttendance.data[i].dateTime);
                        let logout = new Date(monthlyAttendance.data[j].dateTime);
                        if (
                            login.getUTCDate() == logout.getUTCDate() &&
                            !monthlyAttendance.data[i].match
                        ) {
                            previousMonthlyAttendance.data[i].loginOrLogout == "Login"
                                ? (previousMonthlyTableData = [...previousMonthlyTableData, i, j])
                                : (previousMonthlyTableData = [
                                    ...previousMonthlyTableData,
                                    j,
                                    i,
                                ]);
                            previousMonthlyAttendance.data[j] = {
                                ...previousMonthlyAttendance.data[j],
                                match: true,
                            };
                        }
                    }
                }
            }

            let previousMonthlyTableHtml = `
                  
  `;

            for (let i = 0; i < previousMonthlyAttendance.data.length; i = i + 2) {
                const user = registrations.data.filter((val) => {
                    return (
                        val.biometricId ==
                        previousMonthlyAttendance.data[previousMonthlyTableData[i]]
                            .biometricId
                    );
                });
                // console.log(user.name)
                // console.log({biometricId:monthlyAttendance.data[monthlyTableData[i]].biometricId,loginTime: (new Date(monthlyAttendance.data[monthlyTableData[i]].dateTime)).toLocaleString(), logoutTime: (new Date(monthlyAttendance.data[monthlyTableData[i+1]].dateTime)).toLocaleString() })
                previousMonthlyTableHtml += `
    <div class="row">
    <div class="col">${user[0].name}</div>
    <div class="col">${user[0].branch}</div>
    <div class="col">${new Date(
                    previousMonthlyAttendance.data[previousMonthlyTableData[i]].dateTime
                ).toLocaleString()}</div>
    <div class="col">${new Date(
                    previousMonthlyAttendance.data[previousMonthlyTableData[i + 1]].dateTime
                ).toLocaleString()}</div>
    </div>
    `;
            }

            $("#previous-tab").click(function () {
                $("#overview-list").html(previousMonthlyTableHtml);
            });
        } catch (e) {
            console.log(e);
        }

        // const random = (min = 1, max = 3) =>
        // Math.floor(Math.random() * (max - min)) + min;
        //   for (let i = 1; i <= 25; i++) {
        //   let logoutTime,
        //     loginTime,
        //     duration = 5;
        //   if (String(Math.abs(i)).charAt(0) == i) {
        //     logoutTime = new Date(`2022-07-0${i}T13:30:00.862Z`);
        //     loginTime = new Date(`2022-07-0${i}T08:30:00.862Z`);
        //   } else {
        //     logoutTime = new Date(`2022-07-${i}T13:30:00.862Z`);
        //     loginTime = new Date(`2022-07-${i}T08:30:00.862Z`);
        //   }
        //   if (random() == 1) {
        //     if (String(Math.abs(i)).charAt(0) == i) {
        //       logoutTime = new Date(`2022-07-0${i}T14:30:00.862Z`);
        //     } else {
        //       logoutTime = new Date(`2022-07-${i}T14:30:00.862Z`);
        //     }
        //     duration = 6;
        //   } else if (random() == 2) {
        //     if (String(Math.abs(i)).charAt(0) == i) {
        //       logoutTime = new Date(`2022-07-0${i}T11:30:00.862Z`);
        //     } else {
        //       logoutTime = new Date(`2022-07-${i}T11:30:00.862Z`);
        //     }
        //     duration = 3;
        //   }
        //   console.log(loginTime)
        //   console.log(logoutTime)
        //   try{
        //   ["412","361"].forEach((e)=>{
        //     console.log(`1`)
        //     let obj1 = {
        //       loginOrLogout: "Login",
        //       attendanceType: "System",
        //       biometricId: e,
        //       dateTime: loginTime,
        //     };
        //     let obj2 = {
        //       loginOrLogout: "Logout",
        //       attendanceType: "System",
        //       biometricId: e,
        //       dateTime: logoutTime,
        //       duration,
        //     };
        //     $.ajax({
        //       url: "/sdp/attendances",
        //       method: "post",
        //       data: obj1,
        //     });

        //     $.ajax({
        //       url: "/sdp/attendances",
        //       method: "post",
        //       data: obj2,
        //     });
        //   })}catch(e){
        //     console.log(e)
        //   }
        // }
        // console.log(response);
        let dailyAttendance = await $.ajax({
            url: "/sdp/attendances/dailyAttendance",
            method: "GET",
            success: function (response) {
                return response;
            },
        });

        //TotalDaily

        let presentToday = [];

        registrations.data.forEach((a) => {
            dailyAttendance.data.forEach((b) => {
                if (a.biometricId == b.biometricId) {
                    presentToday.push(a.biometricId);
                }
            });
        });

        presentToday = presentToday.filter(
            (item, index) => presentToday.indexOf(item) == index
        );

        console.log(presentToday);
        console.log(registrations.data);

        let percentageDaily = (presentToday.length / registrations.data.length) * 100;

        $("#daily-attendance").text(`${parseInt(percentageDaily)}%`);
        if (percentageDaily > 50) {
            $("#daily-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(percentageDaily)}`
            );
        } else {
            $("#daily-attendance-graph").addClass(
                `progress-circle p${parseInt(percentageDaily)}`
            );
        }

        //ManagersDaily

        let totalManagers = 0;
        let managersPresentToday = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Manager") {
                console.log(a.biometricId);
                totalManagers = totalManagers + 1;
            }
            dailyAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Manager"
                ) {
                    managersPresentToday.push(a.biometricId);
                }
            });
        });

        managersPresentToday = managersPresentToday.filter(
            (item, index) => managersPresentToday.indexOf(item) == index
        );
        console.log(managersPresentToday);
        console.log(totalManagers);
        let managerPercentageDaily =
            (managersPresentToday.length / totalManagers) * 100;

        $("#daily-manager-attendance").text(
            `${parseInt(totalManagers ? managerPercentageDaily : 0)}%`
        );
        if (managerPercentageDaily > 50) {
            $("#daily-manager-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(managerPercentageDaily)}`
            );
        } else {
            $("#daily-manager-attendance-graph").addClass(
                `progress-circle p${parseInt(managerPercentageDaily)}`
            );
        }

        //TeachersDaily

        let totalTeachers = 0;
        let teachersPresentToday = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Teacher") {
                totalTeachers = totalTeachers + 1;
            }
            dailyAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Teacher"
                ) {
                    console.log(a.biometricId);
                    teachersPresentToday.push(a.biometricId);
                }
            });
        });

        teachersPresentToday = teachersPresentToday.filter(
            (item, index) => teachersPresentToday.indexOf(item) == index
        );

        console.log(teachersPresentToday);

        let teacherPercentageDaily =
            (teachersPresentToday.length / totalTeachers) * 100;

        $("#daily-teacher-attendance").text(
            `${parseInt(totalTeachers ? teacherPercentageDaily : 0)}%`
        );
        if (teacherPercentageDaily > 50) {
            $("#daily-teacher-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(teacherPercentageDaily)}`
            );
        } else {
            $("#daily-teacher-attendance-graph").addClass(
                `progress-circle p${parseInt(teacherPercentageDaily)}`
            );
        }

        //StudentsDaily
        let totalStudents = 0;
        let studentsPresentToday = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Student") {
                totalStudents = totalStudents + 1;
            }
            dailyAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Student"
                ) {
                    console.log(a.biometricId);
                    studentsPresentToday.push(a.biometricId);
                }
            });
        });

        studentsPresentToday = studentsPresentToday.filter(
            (item, index) => studentsPresentToday.indexOf(item) == index
        );

        console.log(studentsPresentToday);

        let studentPercentageDaily =
            (studentsPresentToday.length / totalStudents) * 100;
        console.log(studentPercentageDaily);
        $("#daily-student-attendance").text(
            `${parseInt(totalStudents ? studentPercentageDaily : 0)}%`
        );
        if (studentPercentageDaily > 50) {
            $("#daily-student-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(studentPercentageDaily)}`
            );
        } else {
            $("#daily-student-attendance-graph").addClass(
                `progress-circle p${parseInt(studentPercentageDaily)}`
            );
        }

        //DailyTable
        let dailyTableData = [];
        for (let i = 0; i < dailyAttendance.data.length; i++) {
            for (let j = 0; j < dailyAttendance.data.length; j++) {
                if (
                    dailyAttendance.data[i].loginOrLogout !=
                    dailyAttendance.data[j].loginOrLogout &&
                    dailyAttendance.data[i].biometricId ==
                    dailyAttendance.data[j].biometricId
                ) {
                    if (!dailyAttendance.data[i].match) {
                        console.log("in");
                        dailyAttendance.data[i].loginOrLogout == "Login"
                            ? (dailyTableData = [...dailyTableData, i, j])
                            : (dailyTableData = [...dailyTableData, j, i]);
                        dailyAttendance.data[j] = {
                            ...dailyAttendance.data[j],
                            match: true,
                        };
                    }
                }
            }
        }
        console.log(dailyTableData);

        let dailyTableHtml = ``;

        for (let i = 0; i < dailyAttendance.data.length; i = i + 2) {
            try {
                const user = registrations.data.filter((val) => {
                    return (
                        val.biometricId == dailyAttendance.data[dailyTableData[i]].biometricId
                    );
                });
                console.log(user[0].branch);
                dailyTableHtml += `
    <div class="row">
    <div class="col">${user[0].name}</div>
    <div class="col">${user[0].branch}</div>
    <div class="col">${new Date(
                    dailyAttendance.data[dailyTableData[i]].dateTime
                ).toLocaleString()}</div>
    <div class="col">${new Date(
                    dailyAttendance.data[dailyTableData[i + 1]].dateTime
                ).toLocaleString()}</div>
    </div>
    `;
            } catch (e) {
                console.log(e);
            }
        }

        $("#overview-list").html(dailyTableHtml);

        $("#home-tab").click(function () {
            $("#overview-list").html(dailyTableHtml);
        });

        let yesterDayAttendance = await $.ajax({
            url: "/sdp/attendances/yesterdayAttendance",
            method: "GET",
            success: function (response) {
                return response;
            },
        });

        //Totalyesterday

        let presentYesterday = [];

        registrations.data.forEach((a) => {
            yesterDayAttendance.data.forEach((b) => {
                if (a.biometricId == b.biometricId) {
                    presentYesterday.push(a.biometricId);
                }
            });
        });

        presentYesterday = presentYesterday.filter(
            (item, index) => presentYesterday.indexOf(item) == index
        );

        console.log(presentYesterday);
        console.log(registrations.data);

        let percentageYesterday =
            (presentYesterday.length / registrations.data.length) * 100;

        $("#yesterday-attendance").text(`${parseInt(percentageYesterday)}%`);
        if (percentageYesterday > 50) {
            $("#yesterday-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(percentageYesterday)}`
            );
        } else {
            $("#yesterday-attendance-graph").addClass(
                `progress-circle p${parseInt(percentageYesterday)}`
            );
        }

        //Managersyesterday

        let totalManagersYesterday = 0;
        let managersPresentYesterday = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Manager") {
                console.log(a.biometricId);
                totalManagersYesterday = totalManagersYesterday + 1;
            }
            yesterDayAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Manager"
                ) {
                    managersPresentYesterday.push(a.biometricId);
                }
            });
        });

        managersPresentYesterday = managersPresentYesterday.filter(
            (item, index) => managersPresentYesterday.indexOf(item) == index
        );
        console.log(managersPresentYesterday);
        console.log(totalManagersYesterday);
        let managerpercentageYesterday =
            (managersPresentYesterday.length / totalManagersYesterday) * 100;

        $("#yesterday-manager-attendance").text(
            `${parseInt(managerpercentageYesterday)}%`
        );
        if (managerpercentageYesterday > 50) {
            $("#yesterday-manager-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(
                    totalManagersYesterday != 0 ? managerpercentageYesterday : 0
                )}`
            );
        } else {
            $("#yesterday-manager-attendance-graph").addClass(
                `progress-circle p${parseInt(managerpercentageYesterday)}`
            );
        }

        //Teachersyesterday

        let totalTeachersYesterday = 0;
        let teachersPresentYesterday = [];

        registrations.data.forEach((a) => {
            if (a.designation == "Teacher") {
                totalTeachersYesterday = totalTeachersYesterday + 1;
            }
            yesterDayAttendance.data.forEach((b) => {
                if (
                    a.biometricId == b.biometricId &&
                    b.loginOrLogout == "Login" &&
                    a.designation == "Teacher"
                ) {
                    console.log(a.biometricId);
                    teachersPresentYesterday.push(a.biometricId);
                }
            });
        });

        teachersPresentYesterday = teachersPresentYesterday.filter(
            (item, index) => teachersPresentYesterday.indexOf(item) == index
        );

        console.log(teachersPresentYesterday);

        let teacherpercentageYesterday =
            (teachersPresentYesterday.length / totalTeachersYesterday) * 100;

        $("#yesterday-teacher-attendance").text(
            `${parseInt(totalTeachersYesterday != 0 ? teacherpercentageYesterday : 0)}%`
        );
        if (teacherpercentageYesterday > 50) {
            $("#yesterday-teacher-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(teacherpercentageYesterday)}`
            );
        } else {
            $("#yesterday-teacher-attendance-graph").addClass(
                `progress-circle p${parseInt(teacherpercentageYesterday)}`
            );
        }

        //Studentsyesterday
        let totalStudentsYesterday = 0;
        let studentsPresentYesterday = [];
        try {
            registrations.data.forEach((a) => {
                if (a.designation == "Student") {
                    totalStudentsYesterday = totalStudentsYesterday + 1;
                }
                yesterDayAttendance.data.forEach((b) => {
                    if (
                        a.biometricId == b.biometricId &&
                        b.loginOrLogout == "Login" &&
                        a.designation == "Student"
                    ) {
                        console.log(a.biometricId);
                        studentsPresentYesterday.push(a.biometricId);
                    }
                });
            });
        } catch (e) {
            console.log(e);
        }
        studentsPresentYesterday = studentsPresentYesterday.filter(
            (item, index) => studentsPresentYesterday.indexOf(item) == index
        );

        console.log(studentsPresentYesterday);

        let studentpercentageYesterday =
            (studentsPresentYesterday.length / totalStudentsYesterday) * 100;
        console.log(studentpercentageYesterday);
        $("#yesterday-student-attendance").text(
            `${parseInt(totalStudentsYesterday != 0 ? studentpercentageYesterday : 0)}%`
        );
        $("#yesterday-student-attendance").click(function () {
            console.log(111);
        });
        if (studentpercentageYesterday > 50) {
            console.log(11)
            $("#yesterday-student-attendance-graph").addClass(
                `progress-circle over50 p${parseInt(totalStudentsYesterday != 0 ? studentpercentageYesterday : 0)}`
            );
        } else {
            console.log(22)
            $("#yesterday-student-attendance-graph").addClass(
                `progress-circle p${parseInt(totalStudentsYesterday != 0 ? studentpercentageYesterday : 0)}`
            );
        }

        //Yesterdaytable
        let yesterdayTableData = [];

        for (let i = 0; i < yesterDayAttendance.data.length; i++) {
            for (let j = 0; j < yesterDayAttendance.data.length; j++) {
                if (
                    yesterDayAttendance.data[i].loginOrLogout !=
                    yesterDayAttendance.data[j].loginOrLogout &&
                    yesterDayAttendance.data[i].biometricId ==
                    yesterDayAttendance.data[j].biometricId
                ) {
                    if (!yesterDayAttendance.data[i].match) {
                        console.log("in");
                        yesterDayAttendance.data[i].loginOrLogout == "Login"
                            ? (yesterdayTableData = [...yesterdayTableData, i, j])
                            : (yesterdayTableData = [...yesterdayTableData, j, i]);
                        yesterDayAttendance.data[j] = {
                            ...yesterDayAttendance.data[j],
                            match: true,
                        };
                    }
                }
            }
        }

        let yesterDayTableHtml = ``;

        try {
            for (let i = 0; i < yesterDayAttendance.data.length; i = i + 2) {
                const user = registrations.data.filter((val) => {
                    return (
                        val.biometricId ==
                        yesterDayAttendance.data[yesterdayTableData[i]].biometricId
                    );
                });
                console.log(user[0].branch);
                yesterDayTableHtml += `
    <div class="row">
    <div class="col">${user[0].name}</div>
    <div class="col">${user[0].branch}</div>
    <div class="col">${new Date(
                    yesterDayAttendance.data[yesterdayTableData[i]].dateTime
                ).toLocaleString()}</div>
    <div class="col">${new Date(
                    yesterDayAttendance.data[yesterdayTableData[i + 1]].dateTime
                ).toLocaleString()}</div>
    </div>
    `;
            }
        } catch (e) {
            console.log(e);
        }

        $("#profile-tab").click(function () {
            $("#overview-list").html(yesterDayTableHtml);
        });

        console.log(yesterdayTableData);
    } catch (e) {
        console.log(e)
    };
})
// Code by Raj end

// Calendar start
$(function () {
    function c() {
        p();
        var e = h();
        var r = 0;
        var u = false;
        l.empty();
        while (!u) {
            if (s[r] == e[0].weekday) {
                u = true
            } else {
                l.append('<div class="blank"></div>');
                r++
            }
        }
        for (var c = 0; c < 42 - r; c++) {
            if (c >= e.length) {
                l.append('<div class="blank"></div>')
            } else {
                var v = e[c].day;
                var m = g(new Date(t, n - 1, v)) ? '<div class="today">' : "<div>";
                l.append(m + "" + v + "</div>")
            }
        }
        var y = o[n - 1];
        a.css("background-color", y).find("h1").text(i[n - 1] + " " + t);
        f.find("div").css("color", y);
        l.find(".today").css("background-color", y);
        d()
    }

    function h() {
        var e = [];
        for (var r = 1; r < v(t, n) + 1; r++) {
            e.push({
                day: r,
                weekday: s[m(t, n, r)]
            })
        }
        return e
    }

    function p() {
        f.empty();
        for (var e = 0; e < 7; e++) {
            f.append("<div>" + s[e].substring(0, 3) + "</div>")
        }
    }

    function d() {
        var t;
        var n = $("#calendar").css("width", e + "px");
        n.find(t = "#calendar_weekdays, #calendar_content").css("width", e + "px").find("div").css({
            width: e / 9 + "px",
            height: e / 9 + "px",
            "line-height": e / 9 + "px"
        });
        n.find("#calendar_header").css({
            height: e * (1 / 9) + "px"
        }).find('i[class^="ca"]').css("line-height", e * (1 / 9) + "px")
    }

    function v(e, t) {
        return (new Date(e, t, 0)).getDate()
    }

    function m(e, t, n) {
        return (new Date(e, t - 1, n)).getDay()
    }

    function g(e) {
        return y(new Date) == y(e)
    }

    function y(e) {
        return e.getFullYear() + "/" + (e.getMonth() + 1) + "/" + e.getDate()
    }

    function b() {
        var e = new Date;
        t = e.getFullYear();
        n = e.getMonth() + 1
    }
    var e = 480;
    var t = 2013;
    var n = 9;
    var r = [];
    var i = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
    var s = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var o = ["#16a085", "#1abc9c", "#c0392b", "#27ae60", "#FF6860", "#f39c12", "#f1c40f", "#e67e22", "#2ecc71", "#e74c3c", "#d35400", "#2c3e50"];
    var u = $("#calendar");
    var a = u.find("#calendar_header");
    var f = u.find("#calendar_weekdays");
    var l = u.find("#calendar_content");
    b();
    c();
    a.find('i[class^="ca"]').on("click", function () {
        var e = $(this);
        var r = function (e) {
            n = e == "next" ? n + 1 : n - 1;
            if (n < 1) {
                n = 12;
                t--
            } else if (n > 12) {
                n = 1;
                t++
            }
            c()
        };
        if (e.attr("class").indexOf("left") != -1) {
            r("previous")
        } else {
            r("next")
        }
    })
})
// Calender end

// Code by Raj
$("#register-user").click(async () => {
    var users_list = "";
    var users;
    var createdBy;
    Swal.fire({
        toast: true,
        position: "top-right",
        icon: "info",
        title: "Loading...",
        showConfirmButton: false,
    });
    await $.ajax({
        url: "/sdp/auth/me",
        method: "GET",
        success: function (response) {
            createdBy = response.data;
        },
    });
    await $.ajax({
        url: "/sdp/users",
        method: "get",
        success: function (response) {
            if (response.success) {
            if (response.data.length == 0) {
              users_list = null;
          } else {
              users = response.data;
              response.data.forEach((task) => {
                  users_list += `
                          <option value="${task._id}-${task.name}">${task.name} (${task.role})</option>`;
              });
            // console.log(users_list)
          }
        } else {
            $("#loading").css("display", "none");
            $("#table_tasks tbody tr").text(response.responseJSON.error);
            console.log(response.responseJSON.error);
                $("#error").fadeIn();
                $("#error").css("display", "block");
                $("#add-task-card button").attr("disabled", true);
            }
        },
        error: function (response) {
          if (response.responseJSON) {
            $("#loading").css("display", "none");
            $("#error").text(response.responseJSON.error);
            console.log(response.responseJSON.error);
            $("#error").fadeIn();
            $("#error").css("display", "block");
            $("#add-task-card button").attr("disabled", true);
        } else {
            var errorMsg = `
                  <center>
                  <h2>Oops! Something went wrong</h2>
                  <h4 class="text-danger">
                      Error Code: ${response.status} <br>
                      Error Message: ${response.statusText}
                  </h4>
                  <h5>We were unable to fetch tasks list</h5>
                  <h6>
                      Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                  </h6>
                  </center>`;
            console.log(`something went wrong ${JSON.stringify(response)}`);
          // console.log(response.statusText);
            $("#table_tasks").html(errorMsg);
        }
        },
    });
    // console.log('Outside...')
    // console.log(users_list)
    if (!users_list) {
        Swal.fire({
            title: `<h3 style="color:#0b6fad;">Register New User </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
            html: `<h2>No users found<h2>
              <img src="/images/attendance/no-user.png" width="170"><br>
              <h6>Your organization does not contain any Teacher or Manager to register for Biometric Attendance</h6>`,
            focusConfirm: false,
            showCloseButton: true,
          confirmButtonText: "Proceed",
          confirmButtonColor: "#181414",
      });
    } else {
        const { value: formValues } = await Swal.fire({
            title: `<h3 style="color:#0b6fad;">Register New User </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
            html: `
              <img src="/images/attendance/fingerprint-register.gif" width="150"><br>
              <select id="swal-input3" class="swal2-input" name="swal-input3">
                  <option value="">Select User to register</option>
                  ${users_list}
              </select>`,
            focusConfirm: false,
            showCloseButton: true,
          confirmButtonText: "Proceed",
          confirmButtonColor: "#0b6fad",
          width: "min-content",
          preConfirm: () => {
            const userName = document.getElementById("swal-input3").value;
            if (!userName) {
            // Ref: https://stackoverflow.com/a/54582551
              Swal.showValidationMessage("Please select User");
          } else {
              return [userName];
          }
          },
      });

        if (formValues) {
            const values = formValues[0].split("-");
          await Swal.fire({
              title: `<h3 style="color:#0b6fad;">Registration in process </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
              html: `
                  <img src="/images/attendance/fingerprint-register.gif" width="150"><br>
                  ${values[1]}`,
              focusConfirm: false,
              showCloseButton: true,
            confirmButtonText: "Proceed",
            confirmButtonColor: "#0b6fad",
        }).then(() => {
            state1(values);
        });
        }
    }

    //Code for 4 states start here

    //Place your finger..
    async function state1(values) {
        const selectedUser = users.filter((user) => user._id == values[0]);
        console.log("inside state 1");
        // debugger
        await $.ajax({
            url: "/biometric/enroll/firstState",
            method: "put",
            data: `userId=${values[0]}&name=${values[1]}&role=${selectedUser[0].role}&branch=${selectedUser[0].branch}&createdBy=${createdBy._id}`,
            success: async function (response) {
                await Swal.fire({
                    title: `${response.state}`,
                    html: `
                        <img src="/images/attendance/fingerprint-register.gif" width="150"><br>
                        `,
                    focusConfirm: false,
                    confirmButtonText: "Next",
                    confirmButtonColor: "#0b6fad",
                    preConfirm: async () => {
                        // debugger
                        const res = await $.ajax({
                            url: "/biometric/enroll/secondState",
                            method: "post",
                            data: { id: response.id },
                            success: function (response) {
                                console.log(response);
                                return response;
                            },
                        });
                        if (
                            res.state == "remove finger" ||
                            res.state == "Place same finger.."
                        ) {
                            state2(response.id);
                        } else {
                            await Swal.showValidationMessage("Place your finger");
                        }
                    },
                });
            },
        });
    }

    //Remove your finger..
    async function state2(id) {
        console.log("inside state 2");
        await Swal.fire(
            {
                title: "Remove your finger",
                showConfirmButton: false,
                timer: 1000,
            },
            function () {
                location.reload(true);
                tr.hide();
            }
        ).then(() => {
            state3(id);
        });
    }

    //Place your finger again..
    async function state3(id) {
        console.log("inside state 3");
        Swal.fire({
            toast: true,
            position: "center",
            icon: "info",
            title: "Loading...",
            showConfirmButton: false,
        });
        // debugger
        await $.ajax({
            url: "/biometric/enroll/thirdState",
            method: "post",
            data: { id: id },
            success: async function (response) {
                await Swal.fire({
                    title: `${response.state}`,
                    html: `
                        <img src="/images/attendance/fingerprint-register.gif" width="150"><br>
                        `,
                    focusConfirm: false,
                    confirmButtonText: "Next",
                    confirmButtonColor: "#0b6fad",
                    preConfirm: async () => {
                        // debugger
                        const res = await $.ajax({
                            url: "/biometric/enroll/fourthState",
                            method: "post",
                            data: { id: id },
                            success: function (response) {
                                return response;
                            },
                        });
                        if (res.state == "Place same finger..") {
                            Swal.showValidationMessage("Place same finger..");
                        } else {
                            state4(res);
                        }
                    },
                });
            },
        });
    }

    //Confirmation...
    async function state4(res) {
        console.log("inside state 4");
        console.log(res);
        setTimeout(() => {
            window.location.reload();
        }, 4000);
        if (res == "Success, stored!") {
            await Swal.fire(
                {
                    title: "Stored!",
                    icon: "success",
                    showConfirmButton: false,
                    timer: 3000,
                },
                function () {
                    location.reload(true);
                    tr.hide();
                }
            );
        } else {
            await Swal.fire(
                {
                    title: "Not Stored!",
                    showConfirmButton: false,
                    timer: 3000,
                },
                function () {
                    location.reload(true);
                    tr.hide();
                }
            );
        }
    }

    //Code for 4 states end here
});
// code by Raj end

// // Prevous code
// $('#register-user').click(async () => {
//     var users_list = ''
//     var users;
//     var createdBy;
//     Swal.fire({
//         toast: true,
//         position: 'top-right',
//         icon: 'info',
//         title: 'Loading...',
//         showConfirmButton: false
//     });

//     await $.ajax({
//         url: '/sdp/users',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 if (response.data.length == 0) {

//                     users_list = null

//                 } else {

//                     response.data.forEach(task => {

//                         users_list += `
//                         <option value="${task._id}-${task.name}">${task.name} (${task.role})</option>`;
//                     });
//                     // console.log(users_list)

//                 }

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_tasks tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-task-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch tasks list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 $('#table_tasks').html(errorMsg)
//             }

//         }
//     });
//     // console.log('Outside...')
//     // console.log(users_list)
//     if (!users_list) {

//         Swal.fire({
//             title: `<h3 style="color:#0b6fad;">Register New User </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
//             html: `<h2>No users found<h2>
//             <img src="/images/attendance/no-user.png" width="170"><br>
//             <h6>Your organization does not contain any Teacher or Manager to register for Biometric Attendance</h6>`,
//             focusConfirm: false,
//             showCloseButton: true,
//             confirmButtonText: 'Proceed',
//             confirmButtonColor: '#181414'
//         });

//     } else {

//         const { value: formValues } = await Swal.fire({
//             title: `<h3 style="color:#0b6fad;">Register New User </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
//             html: `
//             <img src="/images/attendance/fingerprint-register.gif" width="150"><br>
//             <select id="swal-input3" class="swal2-input" name="swal-input3">
//                 <option value="">Select User to register</option>
//                 ${users_list}
//             </select>`,
//             focusConfirm: false,
//             showCloseButton: true,
//             confirmButtonText: 'Proceed',
//             confirmButtonColor: '#0b6fad',
//             width: 'min-content',
//             preConfirm: () => {
//                 const userName = document.getElementById('swal-input3').value
//                 if (!userName) {
//                     // Ref: https://stackoverflow.com/a/54582551
//                     Swal.showValidationMessage('Please select User')
//                 } else {
//                     return [userName]
//                 }
//             }
//         });

//         if (formValues) {
//             const values = formValues[0].split("-");
//             console.log(values)

//             Swal.fire({
//                 title: `<h3 style="color:#0b6fad;">Registration in process </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
//                 html: `
//                 <img src="/images/attendance/fingerprint-register.gif" width="150"><br>
//                 ${values[1]}`,
//                 focusConfirm: false,
//                 showCloseButton: true,
//                 confirmButtonText: 'Proceed',
//                 confirmButtonColor: '#0b6fad'
//             });
//         }
//     }
// })
// // Prevous code end

// Testing
// Swal.fire({
//     title: `<h3 style="color:#0b6fad;">Register New User </h3> <h5 style="color:#FF6860;"><i class="fa fa-fingerprint"></i> Biometric Attendance</h5>`,
//     html: `<h2>No users found<h2>
//     <img src="/images/attendance/no-user.png" width="170"><br>
//     <h6>Your organization does not contain any Teacher or Manager to register for Biometric Attendance</h6>`,
//     focusConfirm: false,
//     showCloseButton: true,
//     confirmButtonText: 'Proceed',
//     confirmButtonColor: '#181414'
// });
// Testing end

// Summary Tabs JS
$('#home-tab').click(() => {
    const buttons = document.getElementsByClassName('nav-link');
    [].forEach.call(buttons, function (el) {
        el.classList.remove("active");
    });
    $('#home-tab').addClass("active")

    const contentTabs = document.getElementsByClassName('tab-pane');
    [].forEach.call(contentTabs, function (el) {
        el.classList.remove("show");
        el.classList.remove("active");
    });
    $('#home').addClass("show")
    $('#home').addClass("active")
    $('#graph_title').text("Today's")
})

$('#profile-tab').click(() => {
    const buttons = document.getElementsByClassName('nav-link');
    [].forEach.call(buttons, function (el) {
        el.classList.remove("active");
    });
    $('#profile-tab').addClass("active")

    const contentTabs = document.getElementsByClassName('tab-pane');
    [].forEach.call(contentTabs, function (el) {
        el.classList.remove("show");
        el.classList.remove("active");
    });
    $('#profile').addClass("show")
    $('#profile').addClass("active")
    $('#graph_title').text("Yesterday's")
})

$('#contact-tab').click(() => {
    const buttons = document.getElementsByClassName('nav-link');
    [].forEach.call(buttons, function (el) {
        el.classList.remove("active");
    });
    $('#contact-tab').addClass("active")

    const contentTabs = document.getElementsByClassName('tab-pane');
    [].forEach.call(contentTabs, function (el) {
        el.classList.remove("show");
        el.classList.remove("active");
    });
    $('#contact').addClass("show")
    $('#contact').addClass("active")
    $('#graph_title').text("Monthly")
})
// Summary Tabs JS End

// function loadAllAttendances(limit = 10, page = 1) {

//     $('#no-attendance-available').fadeOut()
//     $('#table_attendances,#myInput').fadeOut()

//     $.ajax({
//         url: `/sdp/attendances?limit=${limit}&page=${page}`,
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 $('#error,#loading').css('display', 'none')

//                 // if (response.data.length == 0) {
//                 //     var noAttendance = `
//                 //     <img src="/images/attendances/noattendance.png" width="60" alt="">
//                 //     <div class="h3 mt-2">
//                 //         <span class="font-weight-bold">Attendance List is empty</span> <br><br>
//                 //         <span class="h5">Click&nbsp;
//                 //             <span>
//                 //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
//                 //                     Attendance</button>
//                 //             </span>
//                 //             &nbsp;button at top left to get started
//                 //         </span>
//                 //     </div>`
//                 //     $('#no-attendance-available').fadeIn()
//                 //     $('#no-attendance-available').html(noAttendance)

//                 // } else {
//                 //     $('#table_attendances').fadeIn()
//                 //     var tbody_attendances;
//                 //     // var newelementCount = 0;
//                 //     response.data.forEach(attendance => {

//                 //         // var utcCreatedDate = new Date(attendance.createdAt);
//                 //         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                 //         var createdHindiIST = new Date(attendance.createdAt).toLocaleDateString("hi-IN", options)
//                 //         var createdEnglishIST = new Date(attendance.createdAt).toLocaleDateString("en-IN", options)

//                 //         // Check date
//                 //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                 //         var createdCheck = new Date(attendance.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                 //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                 //         var attendanceStartingAt = new Date(attendance.startingAt).toLocaleDateString("en-IN", optionsCheck)
//                 //         var newElement;
//                 //         if (createdCheck === today) {
//                 //             newElement = `<span class="badge badge-noti">New</span>`
//                 //             // newelementCount += 1
//                 //         } else {
//                 //             newElement = ''
//                 //         }
//                 //         // if (newelementCount > 0) {
//                 //         //     $('#sidebar-attendances-all').html(`All Attendances <span class="badge badge-noti">${newelementCount}</span>`)
//                 //         // }

//                 //         var updateValue = attendance.updatedAt ? attendance.updatedAt : 'Not updated'
//                 //         // Converting update value from UTC to GMT
//                 //         if (updateValue != 'Not updated') {
//                 //             // var utcUpdatedDate = new Date(updateValue);
//                 //             // updateValue = utcUpdatedDate.toUTCString()

//                 //             // Hindi Date time
//                 //             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                 //             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                 //         }

//                 //         tbody_attendances += `
//                 //         <tr>
//                 //             <td>
//                 //                 ${attendance.name} ${newElement}
//                 //             </td>
//                 //             <td>${attendanceStartingAt}</td>
//                 //             <td>${attendance.fees}</td>
//                 //             <td>${attendance.createdBy.name}</td>
//                 //             <td>${createdEnglishIST}</td>
//                 //             <td>${updateValue}</td>
//                 //         </tr>`;
//                 //     });
//                 //     $('#table_attendances tbody').html(tbody_attendances)

//                 // }

//                 if (response.data.length == 0 && response.total_count == 0) {
//                     var noAttendance = `
//                     <img src="/images/attendances/noattendance.png" width="60" alt="">
//                     <div class="h3 mt-2">
//                         <span class="font-weight-bold">Attendance List is empty</span> <br><br>
//                         <span class="h5">Click&nbsp;
//                             <span>
//                                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
//                                     Attendance</button>
//                             </span>
//                             &nbsp;button at top left to get started
//                         </span>
//                     </div>`
//                     $('#no-attendance-available').fadeIn()
//                     $('#no-attendance-available').html(noAttendance)

//                 } else if (response.count == 0 && response.total_count != 0) {

//                     const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
//                     // console.log(max_pages);
//                     if (page == 1 || !response.pagination.prev) {
//                         $('#prev_page').css('display', 'none')
//                     } else {
//                         $('#prev_page').css('display', 'block')
//                     }
//                     if (page == max_pages || !response.pagination.next) {
//                         $('#next_page').css('display', 'none')
//                     } else {
//                         $('#next_page').css('display', 'block')
//                     }

//                     var error
//                     if (page < 1) {
//                         error = `<span class="text-danger">
//                         ${page} page number not allowed <br>
//                         Please add positive number
//                         </span>`
//                     } else if (page > max_pages) {
//                         error = `<span class="text-danger">
//                         ${page} page number exceeded maximum pages <br>
//                         Maximum page number is ${max_pages}
//                         </span>`
//                     } else if (limit < 1) {
//                         error = `<span class="text-danger">
//                         ${limit} record number not allowed <br>
//                         Please add positive number
//                         </span>`
//                     } else if (limit > response.total_count) {
//                         error = `<span class="text-danger">
//                         ${limit} record number exceeded maximum records <br>
//                         Maximum record number is ${response.total_count}
//                         </span>`
//                     }

//                     var noattendance = `
//                     <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
//                     <div class="h3 mt-2">
//                         <span class="font-weight-bold">No data found</span> <br><br>
//                         <span class="h5">${error}</span>
//                     </div>`
//                     $('#no-attendance-available').fadeIn()
//                     $('#no-attendance-available').html(noattendance)

//                     var showing_data = 'No Results Found'

//                     // Bottom Data
//                     $('#view_note').fadeIn()
//                     $('#showing').html(showing_data)
//                     $('#perPage_main,#pageNo_main').fadeIn()
//                     $('#perPage').val(limit)
//                     $('#pageNo').val(page)

//                 } else {
//                     console.log('wow 1');
//                     const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
//                     // console.log(max_pages);
//                     if (page == 1) {
//                         $('#prev_page').css('display', 'none')
//                     } else {
//                         $('#prev_page').css('display', 'block')
//                     }
//                     if (page == max_pages) {
//                         $('#next_page').css('display', 'none')
//                     } else {
//                         $('#next_page').css('display', 'block')
//                     }

//                     if (limit < 1) {
//                         console.log('wow 1.1');
//                         error = `<span class="text-danger">
//                         ${limit} record number not allowed <br>
//                         Please add positive number
//                         </span>`

//                         var noattendance = `
//                         <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
//                         <div class="h3 mt-2">
//                             <span class="font-weight-bold">No data found</span> <br><br>
//                             <span class="h5">${error}</span>
//                         </div>`
//                         $('#no-attendance-available').fadeIn()
//                         $('#no-attendance-available').html(noattendance)

//                         var showing_data = 'No Results Found'

//                         // Bottom Data
//                         $('#view_note').fadeIn()
//                         $('#showing').html(showing_data)
//                         $('#perPage_main,#pageNo_main').fadeIn()
//                         $('#perPage').val(limit)
//                         $('#pageNo').val(page)

//                     } else if (limit > response.total_count) {
//                         console.log('wow 1.2');
//                         error = `<span class="text-danger">
//                         ${limit} record number exceeded maximum records <br>
//                         Maximum record number is ${response.total_count}
//                         </span>`

//                         var attendance = `
//                         <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
//                         <div class="h3 mt-2">
//                             <span class="font-weight-bold">No data found</span> <br><br>
//                             <span class="h5">${error}</span>
//                         </div>`
//                         $('#no-attendance-available').fadeIn()
//                         $('#no-attendance-available').html(attendance)

//                         var showing_data = 'No Results Found'

//                         // Bottom Data
//                         $('#view_note').fadeIn()
//                         $('#showing').html(showing_data)
//                         $('#perPage_main,#pageNo_main').fadeIn()
//                         $('#perPage').val(limit)
//                         $('#pageNo').val(page)

//                     } else {
//                         console.log('wow 1.3');
//                         var showing_data
//                         if (response.pagination.prev == undefined) {
//                             // First Page
//                             showing_data = `Results 1 - ${response.count} of ${response.total_count}`
//                             // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
//                         } else if (response.pagination.next == undefined) {
//                             // Last page
//                             showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
//                             // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
//                         } else {
//                             // Middle page
//                             showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
//                             // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
//                         }

//                         // Bottom Data
//                         $('#showing').html(showing_data)
//                         $('#perPage_main,#pageNo_main').fadeIn()
//                         $('#perPage').val(limit)
//                         $('#pageNo').val(page)

//                         $('#table_attendances,#myInput').fadeIn()
//                         var tbody_attendances;
//                         // var newelementCount = 0;
//                         response.data.forEach(attendance => {

//                             // var utcCreatedDate = new Date(attendance.createdAt);
//                             var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                             var createdHindiIST = new Date(attendance.createdAt).toLocaleDateString("hi-IN", options)
//                             var createdEnglishIST = new Date(attendance.createdAt).toLocaleDateString("en-IN", options)

//                             // Check date
//                             optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
//                             var createdCheck = new Date(attendance.createdAt).toLocaleDateString("en-IN", optionsCheck)
//                             var today = new Date().toLocaleDateString("en-IN", optionsCheck)

//                             var attendanceStartingAt = new Date(attendance.startingAt).toLocaleDateString("en-IN", optionsCheck)
//                             var newElement;
//                             if (createdCheck === today) {
//                                 newElement = `<span class="badge badge-noti">New</span>`
//                                 // newelementCount += 1
//                             } else {
//                                 newElement = ''
//                             }
//                             // if (newelementCount > 0) {
//                             //     $('#sidebar-attendances-all').html(`All Attendances <span class="badge badge-noti">${newelementCount}</span>`)
//                             // }

//                             // var updateValue = attendance.updatedAt ? attendance.updatedAt : 'Not updated'
//                             // // Converting update value from UTC to GMT
//                             // if (updateValue != 'Not updated') {
//                             //     // var utcUpdatedDate = new Date(updateValue);
//                             //     // updateValue = utcUpdatedDate.toUTCString()

//                             //     // Hindi Date time
//                             //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                             //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                             // }

//                             var updateValue = attendance.updatedAt ? attendance.updatedAt : 'Not updated'
//                             // Converting update value from UTC to GMT
//                             if (updateValue != 'Not updated') {
//                                 // var utcUpdatedDate = new Date(updateValue);
//                                 // updateValue = utcUpdatedDate.toUTCString()

//                                 // Hindi Date time
//                                 // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                                 updateValue = '#Updated ' + new Date(updateValue).toLocaleDateString("en-IN", options)
//                             }

//                             tbody_attendances += `
//                             <tr id="${attendance._id}">
//                                 <td>
//                                     ${attendance.name} ${newElement}
//                                 </td>
//                                 <td>${attendanceStartingAt}</td>
//                                 <td>${attendance.fees}</td>
//                                 <td>${createdEnglishIST}</td>
//                                 <td>${updateValue}</td>
//                                 <td>
//                                     <div class="hover-container">
//                                         <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
//                                         <aside class="hover-popup">
//                                             <a align="center" class="p-1 fontt" href="/sdp/admin/viewattendance?attendance=${attendance._id}"><i class="fas fa-info"></i><br><span>View</span></a>
//                                             <a align="center" class="p-1 fontt text-success" href="/sdp/admin/editattendance?attendance=${attendance._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
//                                             <a align="center" class="p-1 fontt text-danger" href="/sdp/admin/deleteattendance?attendance=${attendance._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
//                                         </aside>
//                                     </div>
//                                 </td>
//                             </tr>`;
//                         });
//                         $('#table_attendances tbody').html(tbody_attendances)

//                     }

//                 }

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Attendances Fetched Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_attendances tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-attendance-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-attendance-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch attendances list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_attendances tbody .col').html(errorMsg)
//                 $('#table_attendances').html(errorMsg)
//             }

//         }
//     });

// }
// loadAllAttendances()
