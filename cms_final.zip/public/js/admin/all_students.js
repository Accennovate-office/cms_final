import { setCookie, getCookie } from "../services/cookie.js";

$('#no-student-available').fadeOut()
$('#table_students,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

$('#sidebar-students').trigger("click")
$('#sidebar-students,#sidebar-students-all').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

// Flow of Functions
// getFilterCount - Auto call on start
// - loadAllStudents
    // - populateTable
        // - callAllFunctions
            // - loadBranchesList
            // - loadCoursesList
            // - loadTeachersList
            // - loadBatches
    // - modify_columns

// filter-btn
    // - getFilterCount

// modify_columns
    // - getFilterCount

var all_students_data
var total_count
var cols = {stucourses: false, stuteachers: false, stutotalFees: false, stufeesPaid: false, stufeesPending: false,
    studob: false, stureligion: false, stucaste: false, stuaadhaarNo: false, stumotherName: false, stufatherOccupation: false, stumotherTongue: false, stuaddress: false, stucontact: false, stuqualification: false, stuschoolOrCollegeName: false, stuclassOrTuitionName: false, stucategory: false, stubranch: false, 
    created: false, updated: false}
// Add gender as Logo / Icon

$('#new-student-btn').click(() => {
    document.location.replace('/sdp/admin/addstudent');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllStudents(filter_query, limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllStudents(filter_query, limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllStudents(filter_query, limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllStudents(filter_query, limit, page + 1)
})
// Page navigator End

var filter_query = ``
function loadAllStudents(query, limit = 10, page = 1) {
    // console.log('Inside loadAllStudents()');
    // select=dob,religion,caste,aadhaarNo,motherName,fatherOccupation,address,phone1,phone2,parentPhone,email,category,branch,createdAt,updatedAt
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-student-available').fadeOut()
    $('#table_students,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/students?limit=${limit}&page=${page}${query}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                all_students_data = response.data
                total_count = response.total_count
                $('#error,#loading').css('display', 'none')

                if (response.data.length == 0 && response.total_count == 0) {
                    var noStudent = `
                    <img src="/images/students/nostudent.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Student List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Student</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-student-available').fadeIn()
                    $('#no-student-available').html(noStudent)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error = ``
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var nostudent = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-student-available').fadeIn()
                    $('#no-student-available').html(nostudent)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        // console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var nostudent = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-student-available').fadeIn()
                        $('#no-student-available').html(nostudent)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        // console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var student = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-student-available').fadeIn()
                        $('#no-student-available').html(student)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_students,#myInput').fadeIn()
                        // var tbody_students;
                        // // var newelementCount = 0;
                        // response.data.forEach(student => {

                        //     // var utcCreatedDate = new Date(student.createdAt);
                        //     var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                        //     var createdHindiIST = new Date(student.createdAt).toLocaleDateString("hi-IN", options)
                        //     var createdEnglishIST = new Date(student.createdAt).toLocaleDateString("en-IN", options)

                        //     // Check date
                        //     optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        //     var createdCheck = new Date(student.createdAt).toLocaleDateString("en-IN", optionsCheck)
                        //     var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                        //     var studentStartingAt = new Date(student.startingAt).toLocaleDateString("en-IN", optionsCheck)
                        //     var newElement;
                        //     if (createdCheck === today) {
                        //         newElement = `<span class="badge badge-noti">New</span>`
                        //         // newelementCount += 1
                        //     } else {
                        //         newElement = ''
                        //     }
                        //     // if (newelementCount > 0) {
                        //     //     $('#sidebar-students-all').html(`All Students <span class="badge badge-noti">${newelementCount}</span>`)
                        //     // }

                        //     // var updateValue = student.updatedAt ? student.updatedAt : 'Not updated'
                        //     // // Converting update value from UTC to GMT
                        //     // if (updateValue != 'Not updated') {
                        //     //     // var utcUpdatedDate = new Date(updateValue);
                        //     //     // updateValue = utcUpdatedDate.toUTCString()

                        //     //     // Hindi Date time
                        //     //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        //     //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                        //     // }

                        //     tbody_students += `
                        //     <tr id="${student._id}">
                        //         <td>
                        //         ${student.firstName} ${student.middleName} ${student.lastName} ${newElement}
                        //         </td>
                        //         <td>${student.phone1} /
                        //         ${student.phone2} /
                        //         ${student.parentPhone} (Parent) /
                        //         ${student.email}</td>
                        //         <td>${student.branch}</td>
                        //         <td>${student.category}</td>
                        //         <td>${createdEnglishIST}</td>
                        //         <td>
                        //             <div class="hover-container">
                        //                 <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                        //                 <aside class="hover-popup">
                        //                     <a align="center" class="p-1 fontt" href="/sdp/admin/viewstudent?student=${student._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                        //                     <a align="center" class="p-1 fontt text-success" href="/sdp/admin/editstudent?student=${student._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                        //                     <a align="center" class="p-1 fontt text-danger" href="/sdp/admin/deletestudent?student=${student._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                        //                 </aside>
                        //             </div>
                        //         </td>
                        //     </tr>`;
                        // });
                        // $('#table_students tbody').html(tbody_students)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Students Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });
                
                // if (!getCookie('description_selected') && !getCookie('weeks_selected') && !getCookie('fees_selected') && !getCookie('startingAt_selected') && !getCookie('createdstu_selected') && !getCookie('updatedstu_selected')) {
                //     setTimeout(() => {
                //         modify_columns()
                //     }, 1500);
                // }else {
                //     cols.studob = getCookie('studob_selected')
                //     cols.stureligion = getCookie('stureligion_selected')
                //     cols.stucaste = getCookie('stucaste_selected')
                //     cols.stuaadhaarNo = getCookie('stuaadhaarNo_selected')
                //     cols.stumotherName = getCookie('stumotherName_selected')
                //     cols.stufatherOccupation = getCookie('stufatherOccupation_selected')
                //     cols.stumotherTongue = getCookie('stumotherTongue_selected')
                //     cols.stuaddress = getCookie('stuaddress_selected')
                //     cols.stucontact = getCookie('stucontact_selected')
                //     cols.stucategory = getCookie('stucategory_selected')
                //     cols.stubranch = getCookie('stubranch_selected')
                //     cols.created = getCookie('createdstu_selected')
                //     cols.updated = getCookie('updatedstu_selected')
                //     // Refresh data
                //     populateTable(all_students_data, cols)
                //     getFilterCount()
                // }

                // New fields
                cols.stucourses = getCookie('stucourses_selected')
                cols.stuteachers = getCookie('stuteachers_selected')
                cols.stutotalFees = getCookie('stutotalFees_selected')
                cols.stufeesPaid = getCookie('stufeesPaid_selected')
                cols.stufeesPending = getCookie('stufeesPending_selected')
                // Old fields
                cols.studob = getCookie('studob_selected')
                cols.stureligion = getCookie('stureligion_selected')
                cols.stucaste = getCookie('stucaste_selected')
                cols.stuaadhaarNo = getCookie('stuaadhaarNo_selected')
                cols.stumotherName = getCookie('stumotherName_selected')
                cols.stufatherOccupation = getCookie('stufatherOccupation_selected')
                cols.stumotherTongue = getCookie('stumotherTongue_selected')
                cols.stuaddress = getCookie('stuaddress_selected')
                cols.stucontact = getCookie('stucontact_selected')
                cols.stucategory = getCookie('stucategory_selected')
                cols.stubranch = getCookie('stubranch_selected')
                cols.created = getCookie('createdstu_selected')
                cols.updated = getCookie('updatedstu_selected')
                // Refresh data
                populateTable(all_students_data, cols) 
                // getFilterCount()
                // callAllFunctions()
                setTimeout(() => {
                    modify_columns()
                }, 1500);

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_students tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
// loadAllStudents()

// Feb 2023 update
function populateTable(data, cols) {
    // console.log('Inside populateTable()');
    var tbody_students;
    // Columns add
    var courses_column_head = cols.stucourses ? `<th id="courses_thead" class="col col-3 remove-borders">Courses</th>` : ``;
    var teachers_column_head = cols.stuteachers ? `<th id="teachers_thead" class="col col-3 remove-borders">Teachers</th>` : ``;
    var totalFees_column_head = cols.stutotalFees ? `<th id="totalFees_thead" class="col col-3 remove-borders">Total Fees</th>` : ``;
    var feesPaid_column_head = cols.stufeesPaid ? `<th id="feesPaid_thead" class="col col-3 remove-borders">Paid Fees</th>` : ``;
    var feesPending_column_head = cols.stufeesPending ? `<th id="feesPending_thead" class="col col-3 remove-borders">Pending Fees</th>` : ``;
    var dob_column_head = cols.studob ? `<th id="dob_thead" class="col col-3 remove-borders">DOB</th>` : ``;
    var religion_column_head = cols.stureligion ? `<th id="religion_thead" class="col col-1 remove-borders">Religion</th>` : ``;
    var caste_column_head = cols.stucaste ? `<th id="caste_thead" class="col col-1 remove-borders">Caste</th>` : ``;
    var aadhaarNo_column_head = cols.stuaadhaarNo ? `<th id="aadhaarNo_thead" class="col col-2 remove-borders">Aadhaar No</th>` : ``;
    var motherName_column_head = cols.stumotherName ? `<th id="motherName_thead" class="col col-2 remove-borders">Mother Name</th>` : ``;
    var fatherOccupation_column_head = cols.stufatherOccupation ? `<th id="fatherOccupation_thead" class="col col-2 remove-borders">Father Occupation</th>` : ``;
    var motherTongue_column_head = cols.stumotherTongue ? `<th id="motherTongue_thead" class="col col-2 remove-borders">Mother Tongue</th>` : ``;
    var address_column_head = cols.stuaddress ? `<th id="address_thead" class="col col-2 remove-borders">Address</th>` : ``;
    var contact_column_head = cols.stucontact ? `<th id="contact_thead" class="col col-2 remove-borders">Contact</th>` : ``;
    var category_column_head = cols.stucategory ? `<th id="category_thead" class="col col-2 remove-borders">Category</th>` : ``;
    var branch_column_head = cols.stubranch ? `<th id="branch_thead" class="col col-2 remove-borders">Branch</th>` : ``;
    var created_column_head = cols.created ? `<th id="created_thead" class="col col-2 remove-borders">Created</th>` : ``;
    var updated_column_head = cols.updated ? `<th id="updated_thead" class="col col-2 remove-borders">Updated</th>` : ``;
    $('#table_head_students').html(`
    <th id="name_thead" class="col col-2 remove-borders">Name</th>
    ${courses_column_head}${teachers_column_head}${totalFees_column_head}${feesPaid_column_head}${feesPending_column_head}${dob_column_head}${religion_column_head}${caste_column_head}${aadhaarNo_column_head}${motherName_column_head}${fatherOccupation_column_head}${motherTongue_column_head}${address_column_head}${contact_column_head}${category_column_head}${branch_column_head}${created_column_head}${updated_column_head}`)
    // alert(data.length)
    // console.log(data.length);
    $('#student-entries').html(`Showing ${data.length} of ${total_count} entries`)
    $("#student-entries").addClass("flash_colours");
    setTimeout(() => {
        $("#student-entries").removeClass("flash_colours");
    }, 3000);
    data.forEach(studentData => {
        var student = studentData
        // console.log(student);
        // var utcCreatedDate = new Date(student.createdAt);
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

        // var createdHindiIST = new Date(student.createdAt).toLocaleDateString("hi-IN", options)
        var createdEnglishIST = new Date(student.createdAt).toLocaleDateString("en-IN", options)

        // Check date
        optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var createdCheck = new Date(student.createdAt).toLocaleDateString("en-IN", optionsCheck)
        var today = new Date().toLocaleDateString("en-IN", optionsCheck)
        var dobEnglishIST = new Date(student.dob).toLocaleDateString("en-IN", optionsCheck)

        // var studentstartingAt = new Date(student.startingAt).toLocaleDateString("en-IN", optionsCheck)
        var newElement;
        if (createdCheck === today) {
            newElement = `<span class="badge badge-noti">New</span>`
            // newelementCount += 1
        } else {
            newElement = ''
        }

        var updateValue = student.updatedAt ? student.updatedAt : 'Not updated'
        // Converting update value from UTC to GMT
        if (updateValue != 'Not updated') {
            updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
        }

        if (student.address.length > 50) {
            var truncated_address = student.address.slice(0,50)+'...'
        } else {
            var truncated_address = student.address
        }

        var contactDetails = `${student.phone1} - ${student.email}`
        student.phone2 ? contactDetails += ` / ${student.phone2}` : ''
        student.parentPhone ? contactDetails += ` / ${student.parentPhone} (parent)` : ''

        var courses_list = []
        var teachers_list = []
        var total_fees = 0
        for (let i = 0; i < studentData.courses.length; i++) {
            let data = studentData.courses[i]
            courses_list.push(data.course ? data.course.name : 'Empty')
            teachers_list.push(data.teacher ? data.teacher.name : 'Empty')
            total_fees += data.fees
        }
        var fees_paid = 0
        for (let i = 0; i < studentData.fees.length; i++) {
            const data = studentData.fees[i]
            fees_paid += data.feesPaid
        }

        var courses_column_data = cols.stucourses ? `<td class="remove-borders">${courses_list}</td>` : ''
        var teachers_column_data = cols.stuteachers ? `<td class="remove-borders">${teachers_list}</td>` : ''
        var totalFees_column_data = cols.stutotalFees ? `<td class="remove-borders">${total_fees}</td>` : ''
        var feesPaid_column_data = cols.stufeesPaid ? `<td class="remove-borders text-success">${fees_paid}</td>` : ''
        var feesPending_column_data = cols.stufeesPending ? `<td class="remove-borders text-danger">${total_fees - fees_paid}</td>` : ''
        var dob_column_data = cols.studob ? `<td class="remove-borders">${dobEnglishIST}</td>` : ''
        var religion_column_data = cols.stureligion ? `<td class="remove-borders">${student.religion}</td>` : ''
        var caste_column_data = cols.stucaste ? `<td class="remove-borders">${student.caste}</td>` : ''
        var aadhaarNo_column_data = cols.stuaadhaarNo ? `<td class="remove-borders">${student.aadhaarNo ? student.aadhaarNo : ''}</td>` : ''
        var motherName_column_data = cols.stumotherName ? `<td class="remove-borders">${student.motherName}</td>` : ''
        var fatherOccupation_column_data = cols.stufatherOccupation ? `<td class="remove-borders">${student.fatherOccupation}</td>` : ''
        var motherTongue_column_data = cols.stumotherTongue ? `<td class="remove-borders">${student.motherTongue}</td>` : ''
        var address_column_data = cols.stuaddress ? `<td class="remove-borders">${truncated_address}</td>` : ''
        var contact_column_data = cols.stucontact ? `<td class="remove-borders">${contactDetails}</td>` : ''
        var category_column_data = cols.stucategory ? `<td class="remove-borders">${student.category}</td>` : ''
        var branch_column_data = cols.stubranch ? `<td class="remove-borders">${student.branch}</td>` : ''
        var created_column_data = cols.created ? `<td class="remove-borders">${createdEnglishIST}</td>` : ''
        var updated_column_data = cols.updated ? `<td class="remove-borders">${updateValue}</td>` : ''
        
        if (student.gender == 'Male') {
            var gen = 'male'
        } else {
            var gen = 'female'
        }

        tbody_students += `
        <tr id="${student._id}">
            <td class="remove-borders"><a href="/sdp/admin/viewstudent?student=${student._id}" target="_blank">
                <i class="fa fa-${gen}" aria-hidden="true"></i>
                ${student.firstName} ${student.middleName} ${student.lastName} ${newElement}
            </a></td>
            ${courses_column_data}${teachers_column_data}${totalFees_column_data}${feesPaid_column_data}${feesPending_column_data}${dob_column_data}${religion_column_data}${caste_column_data}${aadhaarNo_column_data}${motherName_column_data}${fatherOccupation_column_data}${motherTongue_column_data}${address_column_data}${contact_column_data}${category_column_data}${branch_column_data}${created_column_data}${updated_column_data}
        </tr>`;
        });
        if (data.length == 0) {
            tbody_students += `
            <tr>
                <td>No data match your filter</td>
            </tr>`;
        }
    $('#table_students tbody').html(tbody_students)
    callAllFunctions()
}


function getFilterCount() {
    // console.log('Inside getFilterCount()');

    let students_filter_count = 0
    var filtered_branches = all_students_data
    filter_query = ``
    let filter_students_student_category = getCookie('filter_students_student_category');
    let filter_students_branch = getCookie('filter_students_branch');
    let filter_students_course = getCookie('filter_students_course');
    let filter_students_teacher = getCookie('filter_students_teacher');
    let filter_students_admission_date_start = getCookie('filter_students_admission_date_start')
    let filter_students_admission_date_end = getCookie('filter_students_admission_date_end')
    let filter_students_batch = getCookie('filter_students_batch');
    // console.log(filter_students_batch);
    // console.log(typeof(filter_students_batch));
    
    if(filter_students_student_category){
        // alert('category')
        students_filter_count++
        filter_query += `&category=${filter_students_student_category}`
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
    }
    if(filter_students_branch){
        // alert('branch')
        students_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        filter_query += `&branch=${filter_students_branch}`
    }
    // if(filter_students_course){
    //     students_filter_count++
    //     // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
    //     // filtered_branches = filtered_branches.filter(
    //     //     eachObj => {
    //     //         // console.log(eachObj.courses);
    //     //         eachObj.courses.filter(courseName => {
    //     //             courseName == filter_students_course
    //     //         });
    //     //         // eachObj.courses.find(filter_students_course); // Not working
    //     //         // console.log(eachObj.courses.find(filter_students_course));
    //     //         // eachObj.course.name === filter_students_course
    //     // });
    //     let newData = []
    //     for (let i = 0; i < filtered_branches.length; i++) {
            
    //         filtered_branches[i].courses.forEach(courseName => {
    //             console.log(courseName, filter_students_course);
    //             let check = courseName.toString() === filter_students_course.toString()
    //             console.log(check);
    //             if (check) {
    //                 newData.push(filtered_branches[i])  
    //             }
    //         })
            
    //     }
    //     filtered_branches = newData
    //     console.log(filtered_branches)
    // }
    // if(filter_students_teacher){
    //     students_filter_count++
    //     // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
    //     // filtered_branches = filtered_branches.filter(
    //     //     eachObj => eachObj.teacher._id === filter_students_teacher);
    //     let newData = []
    //     for (let i = 0; i < filtered_branches.length; i++) {
            
    //         let trigger = 0
    //         filtered_branches[i].teachers.forEach(teacherName => {
    //             console.log(teacherName, filter_students_teacher);
    //             let check = teacherName.toString() === filter_students_teacher.toString()
    //             console.log(check);
    //             if (check && trigger == 0) {
    //                 trigger = 1
    //                 newData.push(filtered_branches[i]) 
    //             }
    //         })
            
    //     }
    //     filtered_branches = newData
    //     console.log(filtered_branches)
    // }

    // if(filter_students_batch){
    //     students_filter_count++
    //     // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
    //     // filtered_branches = filtered_branches.filter(
    //     //     eachObj => eachObj.batch === filter_students_batch);
    //     let newData = []
    //     for (let i = 0; i < filtered_branches.length; i++) {
            
    //         let trigger = 0
    //         filtered_branches[i].batches.forEach(batchName => {
    //             console.log(batchName, filter_students_batch);
    //             let check = batchName.toString() === filter_students_batch.toString()
    //             console.log(check);
    //             if (check && trigger == 0) {
    //                 trigger = 1
    //                 newData.push(filtered_branches[i])
    //             }
                
    //         })
            
    //     }
    //     filtered_branches = newData
    //     console.log(filtered_branches)
    // }
    // console.log(filtered_branches)

    // // Filter admission-date datewise
    // if(filter_students_admission_date_start || filter_students_admission_date_end){
    //     students_filter_count++
    //     // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
    //     // filtered_branches = filtered_branches.filter(
    //     //     eachObj => eachObj.fees === parseInt(filter_courses_fees));
    //     // Ref: https://sebhastian.com/javascript-filter-array-multiple-values/
    //     if (filter_students_admission_date_end == 0) {
    //         filtered_branches = filtered_branches.filter((eachObj) => {
    //             // console.log(eachObj.admissionDate >= filter_students_admission_date_start);
    //             return eachObj.admissionDate >= filter_students_admission_date_start;
    //         });
    //     } else {
    //         filtered_branches = filtered_branches.filter((eachObj) => {
    //             let date = eachObj.admissionDate.slice(0,10)
    //             // console.log('Date '+date);
    //             // console.log('Start '+filter_students_admission_date_start);
    //             // console.log('End '+filter_students_admission_date_end);
    //             // console.log('After '+date >= filter_students_admission_date_start);
    //             // console.log('Before '+date <= filter_students_admission_date_end);
    //             return date >= filter_students_admission_date_start && date <= filter_students_admission_date_end;
    //         });
    //     }
        
    // }
    $('#applied_filters').html(students_filter_count)
    // console.log('Populate call');
    // console.log(filtered_branches);
    // populateTable(filtered_branches, cols)
    loadAllStudents(filter_query);
}
getFilterCount()

var branches_list;
function loadBranchesList() {

    $.ajax({
        url: '/sdp/branches',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#studentbranch').text(response.data)
                var filter_students_branch_cook = getCookie('filter_students_branch')

                if (response.data.length == 0) {
                    branches_list += `<option value="">Branch List is empty</option>`;
                } else {
                    branches_list = `<option value="">Select Branch Name</option>`;
                    response.data.forEach(branch => {

                        if (filter_students_branch_cook == branch.name) {
                            branches_list += `<option value="${branch.name}" selected>${branch.name}</option>`;
                        } else {
                            branches_list += `<option value="${branch.name}">${branch.name}</option>`;
                        }
                    });
                }

                // $('#filter_students_branch').html(branches_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Branches Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
// loadBranchesList()

var courses_list;
function loadCoursesList() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#studentcourse').text(response.data)
                var filter_students_course_cook = getCookie('filter_students_course')

                if (response.data.length == 0) {
                    courses_list += `<option value="">Course List is empty</option>`;
                } else {
                    courses_list = `<option value="">Select Course Name</option>`;
                    response.data.forEach(course => {

                        if (filter_students_course_cook == course.name) {
                            courses_list += `<option value="${course.name}" selected>${course.name}</option>`;
                        } else {
                            courses_list += `<option value="${course.name}">${course.name}</option>`;
                        }
                    });
                }

                // $('#filter_students_branch').html(branches_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Branches Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
// loadCoursesList()

var teachers_list;
function loadTeachersList() {

    $.ajax({
        url: '/sdp/teachers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#studentteacher').text(response.data)
                var filter_students_teacher_cook = getCookie('filter_students_teacher')
                // console.log(filter_students_teacher_cook);
                if (response.data.length == 0) {
                    teachers_list += `<option value="">Teacher List is empty</option>`;
                } else {
                    teachers_list = `<option value="">Select Teacher Name</option>`;
                    response.data.forEach(teacher => {
                        // console.log(teacher.user.name);
                        let teacher_name = teacher.user ? teacher.user.name : ''
                        let teacher_branch = teacher.user ? teacher.user.branch : ''
                        if (filter_students_teacher_cook == teacher_name) {
                            // console.log('Selected');
                            teachers_list += `<option value="${teacher_name}" selected>${teacher_name} (${teacher_branch} Branch)</option>`;
                        } else {
                            teachers_list += `<option value="${teacher_name}">${teacher_name} (${teacher_branch} Branch)</option>`;
                        }
                    });
                }

                // $('#filter_students_branch').html(branches_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Branches Fetched Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
// loadTeachersList()

var batchs_list
var batchs_options = ['7-8am','8-9am','9-10am','10-11am','11-12pm','12-1pm','1-2pm','2-3pm','3-4pm','4-5pm','5-6pm','6-7pm','7-8pm','8-9pm','9-10pm','9:30-10:30pm']
function loadBatches() {
    var filter_students_batch_cook = getCookie('filter_students_batch')
    batchs_list = `<option value="">Select Batch Time</option>`;
    batchs_options.forEach(batch => {
        // console.log(batch);
        if (filter_students_batch_cook == batch) {
            // console.log('Selected');
            batchs_list += `<option value="${batch}" selected>${batch}</option>`;
        } else {
            batchs_list += `<option value="${batch}">${batch}</option>`;
        }
    });
}
// loadBatches()

function callAllFunctions() {
    // console.log('Inside callAllFunctions()');
    loadBranchesList()
    loadCoursesList()
    loadTeachersList()
    loadBatches()
}

// callAllFunctions()

$('#filter-btn').click(()=>{
    var filter_students_student_category_cook = getCookie('filter_students_student_category')
    var filter_students_admission_date_start_cook = getCookie('filter_students_admission_date_start')
    var filter_students_admission_date_end_cook = getCookie('filter_students_admission_date_end')
    // var filter_students_branch_cook = getCookie('filter_students_branch')

    // Setting value
    var student_category_select = ''
    var student_category_Student = ''
    var student_category_Service = ''
    var student_category_HomeMaker = ''
    if (filter_students_student_category_cook == '') {
        student_category_select = 'selected'
    } else if (filter_students_student_category_cook == 'Student') {
        // alert('inside category Student')
        student_category_Student  = 'selected'
    } else if (filter_students_student_category_cook == 'Service') {
        student_category_Service  = 'selected'
    } else if (filter_students_student_category_cook == 'HomeMaker') {
        student_category_HomeMaker  = 'selected'
    }

    Swal.fire({
        title: "<div>Filter Students</div>", 
        html: `<div id="filt_card">
        <div id="filter_card" class="col card">
            <b class="row mb-2">Category -</b>
            <form class="d-flex align-items-center">
                <select name="filter_students_student_category" id="filter_students_student_category" class="w-50 p-1">
                        <option value="" ${student_category_select}>Select Category</option>
                        <option value="Student" ${student_category_Student}>Student</option>
                        <option value="Service" ${student_category_Service}>Service</option>
                        <option value="HomeMaker" ${student_category_HomeMaker}>Home Maker</option>
                </select>
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Branch -</b>
            <form class="d-flex align-items-center">
                <select name="filter_students_branch" id="filter_students_branch" class="w-75 p-1">
                    ${branches_list}
                </select>
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Course -</b>
            <form class="d-flex align-items-center">
                <select name="filter_students_course" id="filter_students_course" class="w-75 p-1">
                    ${courses_list}
                </select>
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Teacher -</b>
            <form class="d-flex align-items-center">
                <select name="filter_students_teacher" id="filter_students_teacher" class="w-75 p-1">
                    ${teachers_list}
                </select>
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Admission date between: -</b>
            <form class="d-flex align-items-center">
                <input class="col-5 p-1" type="date" name="filter_students_admission_date_start" value="${filter_students_admission_date_start_cook}" id="filter_students_admission_date_start" />
                &nbsp;&nbsp; to &nbsp;&nbsp;
                <input class="col-5 p-1" type="date" name="filter_students_admission_date_end" value="${filter_students_admission_date_end_cook}" id="filter_students_admission_date_end" />
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Batch Timings -</b>
            <form class="d-flex align-items-center">
                <select name="filter_students_batch" id="filter_students_batch" class="w-75 p-1">
                    ${batchs_list}
                </select>
            </form>
        </div>
        </div>`,  
        confirmButtonText: "Apply Filter", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        showDenyButton: true,
        denyButtonText: "Clear all", 
        // denyButtonColor: '#0b6fad',
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            // Load all data
            // var filtered_branches = all_students_data

            // Filter student category
            let filter_students_student_category = $("#filter_students_student_category").val()
            // alert(filter_students_student_category);
            setCookie('filter_students_student_category',filter_students_student_category,7)

            // Filter student branch
            let filter_students_branch = $("#filter_students_branch").val()
            // alert(filter_students_branch);
            setCookie('filter_students_branch',filter_students_branch,7)

            // Filter student course
            let filter_students_course = $("#filter_students_course").val()
            // alert(filter_students_course);
            setCookie('filter_students_course',filter_students_course,7)

            // Filter student teacher
            let filter_students_teacher = $("#filter_students_teacher").val()
            // alert(filter_students_teacher);
            setCookie('filter_students_teacher',filter_students_teacher,7)

            getFilterCount()
            // callAllFunctions()
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(all_students_data);
            
        }
        if (result.isDenied) {
            // alert('Clear')
            // var filtered_branches = all_students_data
            setCookie('filter_students_student_category','',7)
            setCookie('filter_students_branch','',7)
            setCookie('filter_students_course','',7)
            setCookie('filter_students_teacher','',7)
            setCookie('filter_students_admission_date_start','',7)
            setCookie('filter_students_admission_date_end','',7)
            setCookie('filter_students_batch','',7)
            // console.log(filtered_branches);
            getFilterCount()
            // callAllFunctions()
        }
    })
})

// Modify columns
// var cols = {dob: false, religion: false, caste: false, aadhaarNo: false, motherName: false, fatherOccupation: false, motherTongue: false, address: false, contact: false, qualification: false, schoolOrCollegeName: false, classOrTuitionName: false, category: false, branch: false, 
//     created: false, updated: false}
function modify_columns() {
    var stucourses_selected_cook = getCookie('stucourses_selected') ? 'checked' : ''
    var stuteachers_selected_cook = getCookie('stuteachers_selected') ? 'checked' : ''
    var stutotalFees_selected_cook = getCookie('stutotalFees_selected') ? 'checked' : ''
    var stufeesPaid_selected_cook = getCookie('stufeesPaid_selected') ? 'checked' : ''
    var stufeesPending_selected_cook = getCookie('stufeesPending_selected') ? 'checked' : ''
    var studob_selected_cook = getCookie('studob_selected') ? 'checked' : ''
    var stureligion_selected_cook = getCookie('stureligion_selected') ? 'checked' : ''
    var stucaste_selected_cook = getCookie('stucaste_selected') ? 'checked' : ''
    var stuaadhaarNo_selected_cook = getCookie('stuaadhaarNo_selected') ? 'checked' : ''
    var stumotherName_selected_cook = getCookie('stumotherName_selected') ? 'checked' : ''
    var stufatherOccupation_selected_cook = getCookie('stufatherOccupation_selected') ? 'checked' : ''
    var stumotherTongue_selected_cook = getCookie('stumotherTongue_selected') ? 'checked' : ''
    var stuaddress_selected_cook = getCookie('stuaddress_selected') ? 'checked' : ''
    var stucontact_selected_cook = getCookie('stucontact_selected') ? 'checked' : ''
    var stucategory_selected_cook = getCookie('stucategory_selected') ? 'checked' : ''
    var stubranch_selected_cook = getCookie('stubranch_selected') ? 'checked' : ''
    var createdstu_selected_cook = getCookie('createdstu_selected') ? 'checked' : ''
    var updatedstu_selected_cook = getCookie('updatedstu_selected') ? 'checked' : ''
    cols.stucourses = getCookie('stucourses_selected')
    cols.stuteachers = getCookie('stuteachers_selected')
    cols.stutotalFees = getCookie('stutotalFees_selected')
    cols.stufeesPaid = getCookie('stufeesPaid_selected')
    cols.stufeesPending = getCookie('stufeesPending_selected')
    cols.studob = getCookie('studob_selected')
    cols.stureligion = getCookie('stureligion_selected')
    cols.stucaste = getCookie('stucaste_selected')
    cols.stuaadhaarNo = getCookie('stuaadhaarNo_selected')
    cols.stumotherName = getCookie('stumotherName_selected')
    cols.stufatherOccupation = getCookie('stufatherOccupation_selected')
    cols.stumotherTongue = getCookie('stumotherTongue_selected')
    cols.stuaddress = getCookie('stuaddress_selected')
    cols.stucontact = getCookie('stucontact_selected')
    cols.stucategory = getCookie('stucategory_selected')
    cols.stubranch = getCookie('stubranch_selected')
    cols.created = getCookie('createdstu_selected')
    cols.updated = getCookie('updatedstu_selected')
    // Refresh data
    // console.log('Populate call');
    // console.log(all_students_data);
    // populateTable(all_students_data, cols)
    // getFilterCount()
    // callAllFunctions()

    Swal.fire({
        title: "<div>Change Columns</div>", 
        html: `
        <div id="cols_card" class="col card">
            <b class="row">Select columns which you want to display -</b>
            <form>
                <label class="row"><input type="checkbox" checked disabled name="name" value="name_selected" id="name_selected" />&nbsp; Name</label>
                <label class="row"><input type="checkbox" ${stucourses_selected_cook} name="stucourses" value="stucourses_selected" id="stucourses_selected" />&nbsp; Courses</label>
                <label class="row"><input type="checkbox" ${stuteachers_selected_cook} name="stuteachers" value="stuteachers_selected" id="stuteachers_selected" />&nbsp; Teachers</label>
                <label class="row"><input type="checkbox" ${stutotalFees_selected_cook} name="stutotalFees" value="stutotalFees_selected" id="stutotalFees_selected" />&nbsp; Total Fees</label>
                <label class="row"><input type="checkbox" ${stufeesPaid_selected_cook} name="stufeesPaid" value="stufeesPaid_selected" id="stufeesPaid_selected" />&nbsp; Paid Fees</label>
                <label class="row"><input type="checkbox" ${stufeesPending_selected_cook} name="stufeesPending" value="stufeesPending_selected" id="stufeesPending_selected" />&nbsp; Pending Fees</label>
                <label class="row"><input type="checkbox" ${studob_selected_cook} name="studob" value="studob_selected" id="studob_selected" />&nbsp; DOB</label>
                <label class="row"><input type="checkbox" ${stureligion_selected_cook} name="stureligion" value="stureligion_selected" id="stureligion_selected" />&nbsp; Religion</label>
                <label class="row"><input type="checkbox" ${stucaste_selected_cook} name="stucaste" value="stucaste_selected" id="stucaste_selected" />&nbsp; Caste</label>
                <label class="row"><input type="checkbox" ${stuaadhaarNo_selected_cook} name="stuaadhaarNo" value="stuaadhaarNo_selected" id="stuaadhaarNo_selected" />&nbsp; Aadhaar No</label>
                <label class="row"><input type="checkbox" ${stumotherName_selected_cook} name="stumotherName" value="stumotherName_selected" id="stumotherName_selected" />&nbsp; Mother Name</label>
                <label class="row"><input type="checkbox" ${stufatherOccupation_selected_cook} name="stufatherOccupation" value="stufatherOccupation_selected" id="stufatherOccupation_selected" />&nbsp; Father Occupation</label>
                <label class="row"><input type="checkbox" ${stumotherTongue_selected_cook} name="stumotherTongue" value="stumotherTongue_selected" id="stumotherTongue_selected" />&nbsp; Mother Tongue</label>
                <label class="row"><input type="checkbox" ${stuaddress_selected_cook} name="stuaddress" value="stuaddress_selected" id="stuaddress_selected" />&nbsp; Address</label>
                <label class="row"><input type="checkbox" ${stucontact_selected_cook} name="stucontact" value="stucontact_selected" id="stucontact_selected" />&nbsp; Contact</label>
                <label class="row"><input type="checkbox" ${stucategory_selected_cook} name="stucategory" value="stucategory_selected" id="stucategory_selected" />&nbsp; Category</label>
                <label class="row"><input type="checkbox" ${stubranch_selected_cook} name="stubranch" value="stubranch_selected" id="stubranch_selected" />&nbsp; Branch</label>
                <label class="row"><input type="checkbox" ${createdstu_selected_cook} name="createdat" value="createdstu_selected" id="createdstu_selected" />&nbsp; Created at Date&Time</label>
                <label class="row"><input type="checkbox" ${updatedstu_selected_cook} name="updatedat" value="updatedstu_selected" id="updatedstu_selected" />&nbsp; Updated at Date&Time</label>
            </form>
        </div>`,  
        confirmButtonText: "Submit", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            let stucourses_col = $("#stucourses_selected").prop("checked")
            let stuteachers_col = $("#stuteachers_selected").prop("checked")
            let stutotalFees_col = $("#stutotalFees_selected").prop("checked")
            let stufeesPaid_col = $("#stufeesPaid_selected").prop("checked")
            let stufeesPending_col = $("#stufeesPending_selected").prop("checked")
            let studob_col = $("#studob_selected").prop("checked")
            let stureligion_col = $("#stureligion_selected").prop("checked")
            let stucaste_col = $("#stucaste_selected").prop("checked")
            let stuaadhaarNo_col = $("#stuaadhaarNo_selected").prop("checked")
            let stumotherName_col = $("#stumotherName_selected").prop("checked")
            let stufatherOccupation_col = $("#stufatherOccupation_selected").prop("checked")
            let stumotherTongue_col = $("#stumotherTongue_selected").prop("checked")
            let stuaddress_col = $("#stuaddress_selected").prop("checked")
            let stucontact_col = $("#stucontact_selected").prop("checked")
            let stucategory_col = $("#stucategory_selected").prop("checked")
            let stubranch_col = $("#stubranch_selected").prop("checked")
            let created_col = $("#createdstu_selected").prop("checked")
            let updated_col = $("#updatedstu_selected").prop("checked")
            setCookie('stucourses_selected',stucourses_col,7)
            setCookie('stuteachers_selected',stuteachers_col,7)
            setCookie('stutotalFees_selected',stutotalFees_col,7)
            setCookie('stufeesPaid_selected',stufeesPaid_col,7)
            setCookie('stufeesPending_selected',stufeesPending_col,7)
            setCookie('studob_selected',studob_col,7)
            setCookie('stureligion_selected',stureligion_col,7)
            setCookie('stucaste_selected',stucaste_col,7)
            setCookie('stuaadhaarNo_selected',stuaadhaarNo_col,7)
            setCookie('stumotherName_selected',stumotherName_col,7)
            setCookie('stufatherOccupation_selected',stufatherOccupation_col,7)
            setCookie('stumotherTongue_selected',stumotherTongue_col,7)
            setCookie('stuaddress_selected',stuaddress_col,7)
            setCookie('stucontact_selected',stucontact_col,7)
            setCookie('stucategory_selected',stucategory_col,7)
            setCookie('stubranch_selected',stubranch_col,7)
            setCookie('createdstu_selected',created_col,7)
            setCookie('updatedstu_selected',updated_col,7)
            
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(studob_col);
            cols.stucourses = stucourses_col
            cols.stuteachers = stuteachers_col
            cols.stutotalFees = stutotalFees_col
            cols.stufeesPaid = stufeesPaid_col
            cols.stufeesPending = stufeesPending_col
            cols.studob = studob_col
            cols.stureligion = stureligion_col
            cols.stucaste = stucaste_col
            cols.stuaadhaarNo = stuaadhaarNo_col
            cols.stumotherName = stumotherName_col
            cols.stufatherOccupation = stufatherOccupation_col
            cols.stumotherTongue = stumotherTongue_col
            cols.stuaddress = stuaddress_col
            cols.stucontact = stucontact_col
            cols.stucategory = stucategory_col
            cols.stubranch = stubranch_col
            cols.created = created_col
            cols.updated = updated_col
            // console.log(cols);
            // console.log('Populate call');
            // console.log(all_students_data);
            // populateTable(all_students_data, cols)
            getFilterCount()
            // callAllFunctions()
        }
    })
}
$('#modify-cols-btn').click(()=>{
    modify_columns()
})

$('#search-student-btn').click(()=>{
    Swal.fire({
        title: "<div>Search Students</div>", 
        html: `
        <table id="search-table">
            <tr>
                <td>
                    <label class="custom-field one">
                    <input type="text" id="firstName" placeholder=" "/>
                    <span class="placeholder">First Name</span>
                    </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label class="custom-field one">
                    <input type="text" id="middleName" placeholder=" "/>
                    <span class="placeholder">Middle Name</span>
                    </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label class="custom-field one">
                    <input type="text" id="lastName" placeholder=" "/>
                    <span class="placeholder">Last Name</span>
                    </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label class="custom-field one">
                    <input type="text" id="dob" placeholder=" "/>
                    <span class="placeholder">Date Of Birth (yyyy-mm-dd)</span>
                    </label>
                </td>
            </tr>
        </table>`,  
        // <td>Date Of Birth <br>(yyyy-mm-dd)</td>
        confirmButtonText: "Search", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        showDenyButton: true,
        denyButtonText: "Clear all", 
        // denyButtonColor: '#0b6fad',
        width: '320px'
    }).then((result) => {
        if (result.isConfirmed) {
            let filter_query = ``
            let firstName = $('#firstName').val()
            let middleName = $('#middleName').val()
            let lastName = $('#lastName').val()
            let dob = $('#dob').val()
            // console.log(firstName, middleName, lastName, dob);
            if (firstName) {
                filter_query += `&firstName=${firstName}`
            } 
            if (middleName) {
                filter_query += `&middleName=${middleName}`
            } 
            if (lastName) {
                filter_query += `&lastName=${lastName}`
            } 
            if (dob) {
                filter_query += `&dob=${dob}`
            } 
            // console.log(filter_query);
            loadAllStudents(filter_query);
        }
    })
})