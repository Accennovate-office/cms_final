
$('#sidebar-fees').trigger("click")
$('#sidebar-fees,#sidebar-fees-view').addClass('active')
$("div#mySidebar").scrollTop(300); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['fee'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/fees')
})

function loadFeesList() {

    $.ajax({
        url: '/sdp/fees',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var fees_list;
                $('#viewfee #fee').text(response.data)

                if (response.data.length == 0) {
                    fees_list += `<option value="">Fee List is empty</option>`;
                } else {
                    fees_list = `<option value="">Select Fee Record</option>`;
                    response.data.forEach(fee => {

                        var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var payDateEnglishIST = new Date(fee.paymentDate).toLocaleDateString("en-IN", date_options)

                        if (fee._id == selected) {

                            fees_list += `
                            <option selected value="${fee._id}">${fee.student.firstName} ${fee.student.lastName} | ${payDateEnglishIST}</option>`;

                        } else {

                            fees_list += `
                            <option value="${fee._id}">${fee.student.firstName} ${fee.student.lastName} | ${payDateEnglishIST}</option>`;

                        }

                    });
                }

                $('#viewfee #fee').html(fees_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Fees Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_fees tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch fees list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_fees tbody .col').html(errorMsg)
                $('#no-fee-selected').html(errorMsg)
            }

        }
    });

}
loadFeesList()

function getFeeDetails() {

    const selectFee = $('#fee').val() ? $('#fee').val() : selected
    // console.log(selectFee);
    if (selectFee == '') {
        $('#no-fee-selected').css('display', 'block')
        $('#fee-selected').css('display', 'none')
    } else {

        $('#no-fee-selected').css('display', 'none')
        $('#fee-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/fees/${selectFee}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewfee #fee-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var payDateEnglishIST = new Date(response.data.paymentDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }


                    var fee_data = `
                    <div class="d-flex mb-3 pl-1">
                        <img src="/images/fees/fee1.png" width="70" alt="">
                        <div align="left" class="ml-4 pt-3">
                            <h2>Fee Record Details</h2>
                        </div>
                    </div>

                    <!-- Basic Details -->
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Basic Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <small>Student Full Name</small>
                            </div>
                            <h4>${response.data.student.firstName} ${response.data.student.middleName}
                                ${response.data.student.lastName}</h4>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Payment Date</small>
                            </div>
                            <h4>${payDateEnglishIST}</h4>

                            <div class="d-flex align-items-center">
                                <i class="fa fa-money-check-alt" aria-hidden="true"></i>
                                <small>Payment Method</small>
                            </div>
                            <h4>${response.data.paymentMethod}</h4>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-2 ml-5">
                        <div align="left" id="width-extend" class="bg-light-s mt-0">
                            <div class="d-flex align-items-center row">
                                <div class="pl-5 col-7">
                                    <i class="fa fa-rupee-sign" aria-hidden="true"></i>
                                    <small>Total Fees</small>
                                </div>
                                <h4 class="col-5 font-weight-bold"><span style="opacity: 0;">-</span> ${response.data.totalFees}</h4>
                            </div>

                            <div class="d-flex align-items-center row">
                                <div class="pl-5 col-7">
                                    <i class="fa fa-rupee-sign" aria-hidden="true"></i>
                                    <small>Paid Fees</small>
                                </div>
                                <h4 class="col-5 font-weight-bold">- ${response.data.feesPaid}</h4>
                            </div>
                            <hr id="hori" class="m-0 p-0">
                            <div class="d-flex align-items-center row">
                                <div class="pl-5 col-7">
                                    <i class="fa fa-rupee-sign" aria-hidden="true"></i>
                                    <small>Pending Fees</small>
                                </div>
                                <h4 class="col-5 font-weight-bold"><span style="opacity: 0;">-</span> ${response.data.pendingFees}</h4>
                            </div>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-file-invoice" aria-hidden="true"></i>
                                <small>Receipt Number</small>
                            </div>
                            <h4>${response.data.receiptNo}</h4>

                            <div class="d-flex align-items-center">
                                <i class="fa fa-user-check" aria-hidden="true"></i>
                                <small>Fees Collected By</small>
                            </div>
                            <h4>${response.data.collectedBy.name} | ${response.data.collectedBy.role} | ${response.data.collectedBy.branch}</h4>
                        </div>
                    </div>


                    <div class="d-flex justify-content-between mt-5">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user-edit" aria-hidden="true"></i>
                                <small>Created By</small>
                            </div>
                            <div>${response.data.createdBy.name} | ${response.data.createdBy.role} | ${response.data.createdBy.branch}</div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-1">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewfee #fee-selected').html(fee_data)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Fee Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_fees tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-fee-card button').attr('disabled', true)
                    $('#fee-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-fee-card button').attr('disabled', true)
                    $('#fee-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch fees list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_fees tbody .col').html(errorMsg)
                    $('#fee-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-fee-selected').css('display', 'block') // block
$('#fee-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getFeeDetails()
}
$('#fee').change(() => {

    getFeeDetails()

})