import { setCookie, getCookie } from "../services/cookie.js";

$('#no-manager-available').fadeOut()
$('#table_managers,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

$('#sidebar-managers').trigger("click")
$('#sidebar-managers,#sidebar-managers-all').addClass('active')
$("div#mySidebar").scrollTop(150); // Ref: https://api.jquery.com/scrolltop/

var all_managers_data
var cols = {branch: false, email: false, dob: false, phone: false, address: false, educationalQualification: false, joiningDate: false, jobTime: false, created: false, updated: false}

$('#new-manager-btn').click(() => {
    document.location.replace('/sdp/admin/addmanager');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllManagers(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllManagers(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllManagers(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllManagers(limit, page + 1)
})
// Page navigator End

function loadAllManagers(limit = 9, page = 1) {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-manager-available').fadeOut()
    $('#table_managers,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/managers?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                all_managers_data = response.data
                $('#error,#loading').css('display', 'none')

                // if (response.data.length == 0) {
                //     var noManager = `
                //     <img src="/images/managers/nomanager.png" width="60" alt="">
                //     <div class="h3 mt-2">
                //         <span class="font-weight-bold">Manager List is empty</span> <br><br>
                //         <span class="h5">Click&nbsp;
                //             <span>
                //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                //                     Manager</button>
                //             </span>
                //             &nbsp;button at top left to get started
                //         </span>
                //     </div>`
                //     $('#no-manager-available').fadeIn()
                //     $('#no-manager-available').html(noManager)

                // } else {
                //     $('#table_managers').fadeIn()
                //     $('#view_note').fadeIn()
                //     var tbody_managers;
                //     // var newelementCount = 0;
                //     response.data.forEach(manager => {

                //         // var utcCreatedDate = new Date(manager.createdAt);
                //         var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                //         // var s = new Date(manager.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                //         var createdHindiIST = new Date(manager.createdAt).toLocaleDateString("hi-IN", options)
                //         var createdEnglishIST = new Date(manager.createdAt).toLocaleDateString("en-IN", options)

                //         // For join Date
                //         var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var joiningEnglishIST = new Date(manager.joiningDate).toLocaleDateString("en-IN", dateOptions)
                //         // var x = new Date(manager.createdAt).getTimezoneOffset();
                //         //Converted UTC to local(IST, etc.,,)
                //         // console.log(utcCreatedDate.toUTCString());

                //         // Check date
                //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var createdCheck = new Date(manager.createdAt).toLocaleDateString("en-IN", optionsCheck)
                //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)
                //         var newElement;
                //         if (createdCheck === today) {
                //             newElement = `<span class="badge badge-noti">New</span>`
                //             // newelementCount += 1
                //         } else {
                //             newElement = ''
                //         }
                //         // if (newelementCount > 0) {
                //         //     $('#sidebar-managers-all').html(`All Managers <span class="badge badge-noti">${newelementCount}</span>`)
                //         // }

                //         var updateValue = manager.updatedAt ? manager.updatedAt : 'Not updated'
                //         // Converting update value from UTC to GMT
                //         if (updateValue != 'Not updated') {
                //             // var utcUpdatedDate = new Date(updateValue);
                //             // updateValue = utcUpdatedDate.toUTCString()

                //             // Hindi Date time
                //             // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                //             updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                //         }

                //         tbody_managers += `
                //         <tr>
                //             <td>
                //                 ${manager.user.name} ${newElement}
                //             </td>
                //             <td>${manager.user.branch}</td>
                //             <td>${joiningEnglishIST}</td>
                //             <td>${manager.phone}</td>
                //             <td>${createdEnglishIST}</td>
                //             <td>${updateValue}</td>
                //         </tr>`;
                //     });
                //     $('#table_managers tbody').html(tbody_managers)

                // }

                if (response.data.length == 0 && response.total_count == 0) {
                    var noManager = `
                    <img src="/images/managers/nomanager.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Manager List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Manager</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-manager-available').fadeIn()
                    $('#no-manager-available').html(noManager)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var nomanager = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-manager-available').fadeIn()
                    $('#no-manager-available').html(nomanager)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        // console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var nomanager = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-manager-available').fadeIn()
                        $('#no-manager-available').html(nomanager)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        // console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var manager = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-manager-available').fadeIn()
                        $('#no-manager-available').html(manager)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        populateTable(response.data, cols)
                        getFilterCount()
                        $('#table_managers,#myInput').fadeIn()
                        // var tbody_managers;
                        // // var newelementCount = 0;
                        // response.data.forEach(manager => {

                        //     // var utcCreatedDate = new Date(manager.createdAt);
                        //     var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                        //     var createdHindiIST = new Date(manager.createdAt).toLocaleDateString("hi-IN", options)
                        //     var createdEnglishIST = new Date(manager.createdAt).toLocaleDateString("en-IN", options)

                        //     // Check date
                        //     optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        //     var createdCheck = new Date(manager.createdAt).toLocaleDateString("en-IN", optionsCheck)
                        //     var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                        //     var managerStartingAt = new Date(manager.startingAt).toLocaleDateString("en-IN", optionsCheck)
                        //     var newElement;
                        //     if (createdCheck === today) {
                        //         newElement = `<span class="badge badge-noti">New</span>`
                        //         // newelementCount += 1
                        //     } else {
                        //         newElement = ''
                        //     }
                        //     // if (newelementCount > 0) {
                        //     //     $('#sidebar-managers-all').html(`All Managers <span class="badge badge-noti">${newelementCount}</span>`)
                        //     // }

                        //     // var updateValue = manager.updatedAt ? manager.updatedAt : 'Not updated'
                        //     // // Converting update value from UTC to GMT
                        //     // if (updateValue != 'Not updated') {
                        //     //     // var utcUpdatedDate = new Date(updateValue);
                        //     //     // updateValue = utcUpdatedDate.toUTCString()

                        //     //     // Hindi Date time
                        //     //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        //     //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                        //     // }

                        //     // For join Date
                        //     var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        //     var joiningEnglishIST = new Date(manager.joiningDate).toLocaleDateString("en-IN", dateOptions)

                        //     var updateValue = manager.updatedAt ? manager.updatedAt : 'Not updated'
                        //     // Converting update value from UTC to GMT
                        //     if (updateValue != 'Not updated') {
                        //         // var utcUpdatedDate = new Date(updateValue);
                        //         // updateValue = utcUpdatedDate.toUTCString()

                        //         // Hindi Date time
                        //         // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        //         updateValue = '#Updated ' + new Date(updateValue).toLocaleDateString("en-IN", options)
                        //     }

                        //     tbody_managers += `
                        //     <tr id="${manager._id}">
                        //         <td>
                        //             ${manager.user.name} ${newElement}
                        //         </td>
                        //         <td>${manager.user.branch}</td>
                        //         <td>${joiningEnglishIST}</td>
                        //         <td>${manager.phone}</td>
                        //         <td>${createdEnglishIST}</td>
                        //         <td>${updateValue}</td>
                        //         <td>
                        //             <div class="hover-container">
                        //                 <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                        //                 <aside class="hover-popup">
                        //                     <a align="center" class="p-1 fontt" href="/sdp/admin/viewmanager?manager=${manager.user.slug}"><i class="fas fa-info"></i><br><span>View</span></a>
                        //                     <a align="center" class="p-1 fontt text-success" href="/sdp/admin/editmanager?manager=${manager.user.slug}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                        //                     <a align="center" class="p-1 fontt text-danger" href="/sdp/admin/deletemanager?manager=${manager.user.slug}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                        //                 </aside>
                        //             </div>
                        //         </td>
                        //     </tr>`;
                        // });
                        // $('#table_managers tbody').html(tbody_managers)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Managers Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

                // if (!getCookie('description_selected') && !getCookie('weeks_selected') && !getCookie('fees_selected') && !getCookie('startingAt_selected') && !getCookie('createdco_selected') && !getCookie('updatedco_selected')) {
                //     setTimeout(() => {
                //         modify_columns()
                //     }, 1500);
                // }else {
                //     cols.branch = getCookie('branch_selected')
                // cols.email = getCookie('email_selected')
                // cols.dob = getCookie('dob_selected')
                // cols.phone = getCookie('phone_selected')
                // cols.address = getCookie('address_selected')
                // cols.educationalQualification = getCookie('educationalQualification_selected')
                // cols.joiningDate = getCookie('joiningDate_selected')
                // cols.jobTime = getCookie('jobTime_selected')
                // cols.created = getCookie('createdmg_selected')
                // cols.updated = getCookie('updatedmg_selected')
                //     // Refresh data
                //     populateTable(all_courses_data, cols)
                //     getFilterCount()
                // }
                cols.branch = getCookie('branch_selected')
                cols.email = getCookie('email_selected')
                cols.dob = getCookie('dob_selected')
                cols.phone = getCookie('phone_selected')
                cols.address = getCookie('address_selected')
                cols.educationalQualification = getCookie('educationalQualification_selected')
                cols.joiningDate = getCookie('joiningDate_selected')
                cols.jobTime = getCookie('jobTime_selected')
                cols.created = getCookie('createdmg_selected')
                cols.updated = getCookie('updatedmg_selected')
                // Refresh data
                populateTable(all_managers_data, cols)
                getFilterCount()
                setTimeout(() => {
                    modify_columns()
                }, 1500);
            } else {

                $('#loading').css('display', 'none');
                $('#table_managers tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-manager-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-manager-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch managers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_managers tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllManagers()

// var cols = {branch: false, email: false, dob: false, phone: false, address: false, educationalQualification: false, joiningDate: false, jobTime: false, created: false, updated: false}
// Feb 2023 update
function populateTable(data, cols) {
    var tbody_managers;
    // Columns add
    var branch_column_head = cols.branch ? `<th id="branch_thead" class="col col-1 remove-borders">Branch</th>` : ``;
    var email_column_head = cols.email ? `<th id="email_thead" class="col col-1 remove-borders">Email</th>` : ``;
    var dob_column_head = cols.dob ? `<th id="dob_thead" class="col col-1 remove-borders">DOB</th>` : ``;
    var phone_column_head = cols.phone ? `<th id="phone_thead" class="col col-1 remove-borders">Phone</th>` : ``;
    var address_column_head = cols.address ? `<th id="address_thead" class="col col-3 remove-borders">Address</th>` : ``;
    var educationalQualification_column_head = cols.educationalQualification ? `<th id="educationalQualification_thead" class="col col-2 remove-borders">Educational Qualification</th>` : ``;
    var joiningDate_column_head = cols.joiningDate ? `<th id="joiningDate_thead" class="col col-1 remove-borders">Joining Date</th>` : ``;
    var jobTime_column_head = cols.jobTime ? `<th id="jobTime_thead" class="col col-1 remove-borders">Job Time</th>` : ``;
    var created_column_head = cols.created ? `<th id="createdat_thead" class="col col-2 remove-borders">Created At</th>` : ``;
    var updated_column_head = cols.updated ? `<th id="updatedat_thead" class="col col-2 remove-borders">Updated At</th>` : ``;
    $('#table_head_managers').html(`
    <th id="name_thead" class="col col-2 remove-borders">Name</th>
    ${branch_column_head}${email_column_head}${dob_column_head}${phone_column_head}${address_column_head}${educationalQualification_column_head}${joiningDate_column_head}${jobTime_column_head}${created_column_head}${updated_column_head}`)
    
    data.forEach(manager => {
        // console.log('manager');
        // var utcCreatedDate = new Date(manager.createdAt);
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

        var createdHindiIST = new Date(manager.createdAt).toLocaleDateString("hi-IN", options)
        var createdEnglishIST = new Date(manager.createdAt).toLocaleDateString("en-IN", options)

        // Check date
        optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var createdCheck = new Date(manager.createdAt).toLocaleDateString("en-IN", optionsCheck)
        var today = new Date().toLocaleDateString("en-IN", optionsCheck)
        var joiningDateEnglishIST = new Date(manager.joiningDate).toLocaleDateString("en-IN", optionsCheck)
        var dobEnglishIST = new Date(manager.dob).toLocaleDateString("en-IN", optionsCheck)

        var newElement;
        if (createdCheck === today) {
            newElement = `<span class="badge badge-noti">New</span>`
            // newelementCount += 1
        } else {
            newElement = ''
        }

        var updateValue = manager.updatedAt ? manager.updatedAt : 'Not updated'
        // Converting update value from UTC to GMT
        if (updateValue != 'Not updated') {
            updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
        }

        if (manager.address.length > 50) {
            var truncated_address = manager.address.slice(0,50)+'...'
        } else {
            var truncated_address = manager.address
        }

        const jobTime = manager.jobTime.split(',')

        var branch_column_data = cols.branch ? `<td class="remove-borders">${manager.user.branch}</td>` : ''
        var email_column_data = cols.email ? `<td class="remove-borders">${manager.user.email}</td>` : ''
        var dob_column_data = cols.dob ? `<td class="remove-borders">${dobEnglishIST}</td>` : ''
        var phone_column_data = cols.phone ? `<td class="remove-borders">${manager.phone}</td>` : ''
        var address_column_data = cols.address ? `<td class="remove-borders">${truncated_address}</td>` : ''
        var educationalQualification_column_data = cols.educationalQualification ? `<td class="remove-borders">${manager.educationalQualification}</td>` : ''
        var joiningDate_column_data = cols.joiningDate ? `<td class="remove-borders">${joiningDateEnglishIST}</td>` : ''
        var jobTime_column_data = cols.jobTime ? `<td class="remove-borders">From ${jobTime[0]} to ${jobTime[1]}</td>` : ''
        var created_column_data = cols.created ? `<td class="remove-borders">${createdEnglishIST}</td>` : ''
        var updated_column_data = cols.updated ? `<td class="remove-borders">${updateValue}</td>` : ''

        tbody_managers += `
        <tr id="${manager._id}">
            <td class="remove-borders"><a href="/sdp/admin/viewmanager?manager=${manager.user.slug}" target="_blank">
                ${manager.user.name} ${newElement}
            </a></td>
            ${branch_column_data}
            ${email_column_data}
            ${dob_column_data}
            ${phone_column_data}
            ${address_column_data}
            ${educationalQualification_column_data}
            ${joiningDate_column_data}
            ${jobTime_column_data}
            ${created_column_data}
            ${updated_column_data}
        </tr>`;
        });
    $('#table_managers tbody').html(tbody_managers)
}

function getFilterCount() {

    let managers_filter_count = 0
    var filtered_branches = all_managers_data
    var filter_managers_weeks = getCookie('filter_managers_weeks') 
    var filter_managers_fees = getCookie('filter_managers_fees')
    if(filter_managers_weeks){
        managers_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        filtered_branches = filtered_branches.filter(
            eachObj => eachObj.weeks === filter_managers_weeks);
        console.log(filtered_branches)
    }
    if(filter_managers_fees){
        managers_filter_count++
        // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
        filtered_branches = filtered_branches.filter(
            eachObj => eachObj.fees === parseInt(filter_managers_fees));
        console.log(filtered_branches)
    }
    $('#applied_filters').html(managers_filter_count)
    populateTable(filtered_branches, cols)
}
// getFilterCount()

$('#filter-btn').click(()=>{
    var filter_managers_weeks_cook = getCookie('filter_managers_weeks') 
    var filter_managers_fees_cook = getCookie('filter_managers_fees')

    Swal.fire({
        title: "<div>Filter managers</div>", 
        html: `
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter branches with duration (weeks) -</b>
            <form class="d-flex align-items-center">
                <label class="row">Enter duration in weeks: </label> &nbsp;&nbsp;&nbsp;
                <input class="col-2 p-1" type="input" name="filter_managers_weeks" value="${filter_managers_weeks_cook}" id="filter_managers_weeks" />
            </form>
        </div>
        <div id="filter_card" class="col card">
            <b class="row mb-2">Filter branches with fees -</b>
            <form class="d-flex align-items-center">
                <label class="row">Enter fees: </label> &nbsp;&nbsp;&nbsp;
                <input class="col-3 p-1" type="input" name="filter_managers_fees" value="${filter_managers_fees_cook}" id="filter_managers_fees" />
            </form>
        </div>`,  
        confirmButtonText: "Apply Filter", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            var filtered_branches = all_managers_data
            let filter_managers_weeks = $("#filter_managers_weeks").val()
            setCookie('filter_managers_weeks',filter_managers_weeks,7)
            let filter_managers_fees = $("#filter_managers_fees").val()
            setCookie('filter_managers_fees',filter_managers_fees,7)

            if(filter_managers_weeks){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                filtered_branches = filtered_branches.filter(
                    eachObj => eachObj.weeks === filter_managers_weeks);
                console.log(filtered_branches)
            }
            if(filter_managers_fees){
                // Ref: https://www.geeksforgeeks.org/how-to-filter-nested-objects-in-javascript/
                filtered_branches = filtered_branches.filter(
                    eachObj => eachObj.fees === parseInt(filter_managers_fees));
                console.log(filtered_branches)
            }
            populateTable(filtered_branches, cols)
            getFilterCount()
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(all_managers_data);
            
        }
    })
})

// Modify columns
function modify_columns() {
    var branch_selected_cook = getCookie('branch_selected') ? 'checked' : ''
    var email_selected_cook = getCookie('email_selected') ? 'checked' : ''
    var dob_selected_cook = getCookie('dob_selected') ? 'checked' : ''
    var phone_selected_cook = getCookie('phone_selected') ? 'checked' : ''
    var address_selected_cook = getCookie('address_selected') ? 'checked' : ''
    var educationalQualification_selected_cook = getCookie('educationalQualification_selected') ? 'checked' : ''
    var joiningDate_selected_cook = getCookie('joiningDate_selected') ? 'checked' : ''
    var jobTime_selected_cook = getCookie('jobTime_selected') ? 'checked' : ''
    var createdmg_selected_cook = getCookie('createdmg_selected') ? 'checked' : ''
    var updatedmg_selected_cook = getCookie('updatedmg_selected') ? 'checked' : ''
    cols.branch = getCookie('branch_selected')
    cols.email = getCookie('email_selected')
    cols.dob = getCookie('dob_selected')
    cols.phone = getCookie('phone_selected')
    cols.address = getCookie('address_selected')
    cols.educationalQualification = getCookie('educationalQualification_selected')
    cols.joiningDate = getCookie('joiningDate_selected')
    cols.jobTime = getCookie('jobTime_selected')
    cols.created = getCookie('createdmg_selected')
    cols.updated = getCookie('updatedmg_selected')
    // Refresh data
    populateTable(all_managers_data, cols)
    getFilterCount()

    Swal.fire({
        title: "<div>Modify Columns</div>", 
        html: `
        <div id="filter_card" class="col card">
            <b class="row">Select columns which you want to display -</b>
            <form>
                <label class="row"><input type="checkbox" checked disabled name="name" value="name_selected" id="name_selected" />&nbsp; Name</label>
                <label class="row"><input type="checkbox" ${branch_selected_cook} name="branch" value="branch_selected" id="branch_selected" />&nbsp; Branch</label>
                <label class="row"><input type="checkbox" ${email_selected_cook} name="email" value="email_selected" id="email_selected" />&nbsp; Email</label>
                <label class="row"><input type="checkbox" ${dob_selected_cook} name="dob" value="dob_selected" id="dob_selected" />&nbsp; DOB</label>
                <label class="row"><input type="checkbox" ${phone_selected_cook} name="phone" value="phone_selected" id="phone_selected" />&nbsp; Phone</label>
                <label class="row"><input type="checkbox" ${address_selected_cook} name="address" value="address_selected" id="address_selected" />&nbsp; Address</label>
                <label class="row"><input type="checkbox" ${educationalQualification_selected_cook} name="educationalQualification" value="educationalQualification_selected" id="educationalQualification_selected" />&nbsp; Educational Qualification</label>
                <label class="row"><input type="checkbox" ${joiningDate_selected_cook} name="joiningDate" value="joiningDate_selected" id="joiningDate_selected" />&nbsp; Joining Date</label>
                <label class="row"><input type="checkbox" ${jobTime_selected_cook} name="jobTime" value="jobTime_selected" id="jobTime_selected" />&nbsp; Job Time</label>
                <label class="row"><input type="checkbox" ${createdmg_selected_cook} name="createdat" value="createdmg_selected" id="createdmg_selected" />&nbsp; Created at Date&Time</label>
                <label class="row"><input type="checkbox" ${updatedmg_selected_cook} name="updatedat" value="updatedmg_selected" id="updatedmg_selected" />&nbsp; Updated at Date&Time</label>
            </form>
        </div>`,  
        confirmButtonText: "Modify", 
        confirmButtonColor: '#0b6fad',
        showCloseButton: true,
        width: '450px'
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            let branch_col = $("#branch_selected").prop("checked")
            let email_col = $("#email_selected").prop("checked")
            let dob_col = $("#dob_selected").prop("checked")
            let phone_col = $("#phone_selected").prop("checked")
            let address_col = $("#address_selected").prop("checked")
            let educationalQualification_col = $("#educationalQualification_selected").prop("checked")
            let joiningDate_col = $("#joiningDate_selected").prop("checked")
            let jobTime_col = $("#jobTime_selected").prop("checked")
            let created_col = $("#createdmg_selected").prop("checked")
            let updated_col = $("#updatedmg_selected").prop("checked")
            setCookie('branch_selected',branch_col,7)
            setCookie('email_selected',email_col,7)
            setCookie('dob_selected',dob_col,7)
            setCookie('phone_selected',phone_col,7)
            setCookie('address_selected',address_col,7)
            setCookie('educationalQualification_selected',educationalQualification_col,7)
            setCookie('joiningDate_selected',joiningDate_col,7)
            setCookie('jobTime_selected',jobTime_col,7)
            setCookie('createdmg_selected',created_col,7)
            setCookie('updatedmg_selected',updated_col,7)
            
            // console.log($("#yes").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log($("#no").prop("checked")) // Ref: https://stackoverflow.com/a/37257751
            // console.log(branch_col);
            cols.branch = branch_col
            cols.email = email_col
            cols.dob = dob_col
            cols.phone = phone_col
            cols.address = address_col
            cols.educationalQualification = educationalQualification_col
            cols.joiningDate = joiningDate_col
            cols.jobTime = jobTime_col
            cols.created = created_col
            cols.updated = updated_col
            // console.log(cols);
            populateTable(all_managers_data, cols)
            getFilterCount()
        }
    })
}
// 15 count to changes
$('#modify-cols-btn').click(()=>{
    modify_columns()
})