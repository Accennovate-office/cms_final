$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-perks').trigger("click")
$('#sidebar-perks,#sidebar-perks-add').addClass('active')
$("div#mySidebar").scrollTop(600); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

const next = $('#new-perk-btn')

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Perk...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

var finalSubmit = 0;
var currentActive = 1;

function update() {

    const user = $('#myDropdown1-1').val()
    const perks = $('#perks').val()
    const comment = $('#perk-comment').text()
    // console.log(user, perks, comment);
    // $('#display-name').html(category ? category : '<span class="text-danger">Name field is empty</span>')
    // $('#display-description').html(subcategory ? subcategory : '<span class="text-danger">Description field is empty</span>')
    // $('#display-startdate').html(details ? details : '<span class="text-danger">Start Date field is empty</span>')

    // console.log(!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !password);
    if (!user || !perks || !comment) {
        // next.disabled = true
        next.attr('disabled', true)
        // console.log('true');
    } else {
        finalSubmit = 1
        // console.log('false');
        next.removeAttr('disabled')
        // next.disabled = false
    }
}

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
// Searchable dropdown end

const category_id_list = []

// Custom slider
const comments_list = ['Inferior', 'Below Average', 'Mediocre', 'Average', 'Great', 'Above Average', 'Splendid', 'Excellent', 'Exceptional', 'Remarkable', 'Sets a new standard of performance']
$('#slide-form').on('input', () => {
    // console.log('form input');
    const perks = $('#perks').val()
    // console.log(perks);
    $('.output').val(perks)
    $('#perk-comment').text(comments_list[perks])
    update()
})
"use strict";

const END = 'change';
const START = 'ontouchstart' in document ? 'touchstart' : 'mousedown';
const INPUT = 'input';
const MAX_ROTATION = 35;
const SOFTEN_FACTOR = 3;

class RangeInput {
    constructor(el) {
        this.el = el;
        this._handleEnd = this._handleEnd.bind(this);
        this._handleStart = this._handleStart.bind(this);
        this._handleInput = this._handleInput.bind(this); //Call the plugin

        $(this.el.querySelector('input[type=range]')).rangeslider({
            polyfill: false,
            //Never use the native polyfill
            rangeClass: 'rangeslider',
            disabledClass: 'rangeslider-disabled',
            horizontalClass: 'rangeslider-horizontal',
            verticalClass: 'rangeslider-vertical',
            fillClass: 'rangeslider-fill-lower',
            handleClass: 'rangeslider-thumb',
            onInit: function () {
                //No args are passed, so we can't change context of this
                const pluginInstance = this; //Move the range-output inside the handle so we can do all the stuff in css

                $(pluginInstance.$element).parents('.range').find('.range-output').appendTo(pluginInstance.$handle);
            }
        });
        this.sliderThumbEl = el.querySelector('.rangeslider-thumb');
        this.outputEl = el.querySelector('.range-output');
        this.inputEl = el.querySelector('input[type=range]');
        this._lastOffsetLeft = 0;
        this._lastTimeStamp = 0;
        this.el.querySelector('.rangeslider').addEventListener(START, this._handleStart);
    }

    _handleStart(e) {
        this._lastTimeStamp = new Date().getTime();
        this._lastOffsetLeft = this.sliderThumbEl.offsetLeft; //Wrap in raf because offsetLeft is updated by the plugin after this fires

        requestAnimationFrame(_ => {
            //Bind through jquery because plugin doesn't fire native event
            $(this.inputEl).on(INPUT, this._handleInput);
            $(this.inputEl).on(END, this._handleEnd);
        });
    }

    _handleEnd(e) {
        //Unbind through jquery because plugin doesn't fire native event
        $(this.inputEl).off(INPUT, this._handleInput);
        $(this.inputEl).off(END, this._handleEnd);
        requestAnimationFrame(_ => this.outputEl.style.transform = 'rotate(0deg)');
    }

    _handleInput(e) {
        let now = new Date().getTime();
        let timeElapsed = now - this._lastTimeStamp || 1;
        let distance = this.sliderThumbEl.offsetLeft - this._lastOffsetLeft;
        let direction = distance < 0 ? -1 : 1;
        let velocity = Math.abs(distance) / timeElapsed; //pixels / millisecond

        let targetRotation = Math.min(Math.abs(distance * velocity) * SOFTEN_FACTOR, MAX_ROTATION);
        requestAnimationFrame(_ => this.outputEl.style.transform = 'rotate(' + targetRotation * -direction + 'deg)');
        this._lastTimeStamp = now;
        this._lastOffsetLeft = this.sliderThumbEl.offsetLeft;
    }

}
/*! rangeslider.js - v2.1.1 | (c) 2016 @andreruffert | MIT license | https://github.com/andreruffert/rangeslider.js */


!function (a) {
    "use strict";

    "function" == typeof define && define.amd ? define(["jquery"], a) : "object" == typeof exports ? module.exports = a(require("jquery")) : a(jQuery);
}(function (a) {
    "use strict";

    function b() {
        var a = document.createElement("input");
        return a.setAttribute("type", "range"), "text" !== a.type;
    }

    function c(a, b) {
        var c = Array.prototype.slice.call(arguments, 2);
        return setTimeout(function () {
            return a.apply(null, c);
        }, b);
    }

    function d(a, b) {
        return b = b || 100, function () {
            if (!a.debouncing) {
                var c = Array.prototype.slice.apply(arguments);
                a.lastReturnVal = a.apply(window, c), a.debouncing = !0;
            }

            return clearTimeout(a.debounceTimeout), a.debounceTimeout = setTimeout(function () {
                a.debouncing = !1;
            }, b), a.lastReturnVal;
        };
    }

    function e(a) {
        return a && (0 === a.offsetWidth || 0 === a.offsetHeight || a.open === !1);
    }

    function f(a) {
        for (var b = [], c = a.parentNode; e(c);) b.push(c), c = c.parentNode;

        return b;
    }

    function g(a, b) {
        function c(a) {
            "undefined" != typeof a.open && (a.open = a.open ? !1 : !0);
        }

        var d = f(a),
            e = d.length,
            g = [],
            h = a[b];

        if (e) {
            for (var i = 0; e > i; i++) g[i] = d[i].style.cssText, d[i].style.setProperty ? d[i].style.setProperty("display", "block", "important") : d[i].style.cssText += ";display: block !important", d[i].style.height = "0", d[i].style.overflow = "hidden", d[i].style.visibility = "hidden", c(d[i]);

            h = a[b];

            for (var j = 0; e > j; j++) d[j].style.cssText = g[j], c(d[j]);
        }

        return h;
    }

    function h(a, b) {
        var c = parseFloat(a);
        return Number.isNaN(c) ? b : c;
    }

    function i(a) {
        return a.charAt(0).toUpperCase() + a.substr(1);
    }

    function j(b, e) {
        if (this.$window = a(window), this.$document = a(document), this.$element = a(b), this.options = a.extend({}, n, e), this.polyfill = this.options.polyfill, this.orientation = this.$element[0].getAttribute("data-orientation") || this.options.orientation, this.onInit = this.options.onInit, this.onSlide = this.options.onSlide, this.onSlideEnd = this.options.onSlideEnd, this.DIMENSION = o.orientation[this.orientation].dimension, this.DIRECTION = o.orientation[this.orientation].direction, this.DIRECTION_STYLE = o.orientation[this.orientation].directionStyle, this.COORDINATE = o.orientation[this.orientation].coordinate, this.polyfill && m) return !1;
        this.identifier = "js-" + k + "-" + l++, this.startEvent = this.options.startEvent.join("." + this.identifier + " ") + "." + this.identifier, this.moveEvent = this.options.moveEvent.join("." + this.identifier + " ") + "." + this.identifier, this.endEvent = this.options.endEvent.join("." + this.identifier + " ") + "." + this.identifier, this.toFixed = (this.step + "").replace(".", "").length - 1, this.$fill = a('<div class="' + this.options.fillClass + '" />'), this.$handle = a('<div class="' + this.options.handleClass + '" />'), this.$range = a('<div class="' + this.options.rangeClass + " " + this.options[this.orientation + "Class"] + '" id="' + this.identifier + '" />').insertAfter(this.$element).prepend(this.$fill, this.$handle), this.$element.css({
            position: "absolute",
            width: "1px",
            height: "1px",
            overflow: "hidden",
            opacity: "0"
        }), this.handleDown = a.proxy(this.handleDown, this), this.handleMove = a.proxy(this.handleMove, this), this.handleEnd = a.proxy(this.handleEnd, this), this.init();
        var f = this;
        this.$window.on("resize." + this.identifier, d(function () {
            c(function () {
                f.update(!1, !1);
            }, 300);
        }, 20)), this.$document.on(this.startEvent, "#" + this.identifier + ":not(." + this.options.disabledClass + ")", this.handleDown), this.$element.on("change." + this.identifier, function (a, b) {
            if (!b || b.origin !== f.identifier) {
                var c = a.target.value,
                    d = f.getPositionFromValue(c);
                f.setPosition(d);
            }
        });
    }

    Number.isNaN = Number.isNaN || function (a) {
        return "number" == typeof a && a !== a;
    };

    var k = "rangeslider",
        l = 0,
        m = b(),
        n = {
            polyfill: !0,
            orientation: "horizontal",
            rangeClass: "rangeslider",
            disabledClass: "rangeslider--disabled",
            horizontalClass: "rangeslider--horizontal",
            verticalClass: "rangeslider--vertical",
            fillClass: "rangeslider__fill",
            handleClass: "rangeslider__handle",
            startEvent: ["mousedown", "touchstart", "pointerdown"],
            moveEvent: ["mousemove", "touchmove", "pointermove"],
            endEvent: ["mouseup", "touchend", "pointerup"]
        },
        o = {
            orientation: {
                horizontal: {
                    dimension: "width",
                    direction: "left",
                    directionStyle: "left",
                    coordinate: "x"
                },
                vertical: {
                    dimension: "height",
                    direction: "top",
                    directionStyle: "bottom",
                    coordinate: "y"
                }
            }
        };
    return j.prototype.init = function () {
        this.update(!0, !1), this.onInit && "function" == typeof this.onInit && this.onInit();
    }, j.prototype.update = function (a, b) {
        a = a || !1, a && (this.min = h(this.$element[0].getAttribute("min"), 0), this.max = h(this.$element[0].getAttribute("max"), 100), this.value = h(this.$element[0].value, Math.round(this.min + (this.max - this.min) / 2)), this.step = h(this.$element[0].getAttribute("step"), 1)), this.handleDimension = g(this.$handle[0], "offset" + i(this.DIMENSION)), this.rangeDimension = g(this.$range[0], "offset" + i(this.DIMENSION)), this.maxHandlePos = this.rangeDimension - this.handleDimension, this.grabPos = this.handleDimension / 2, this.position = this.getPositionFromValue(this.value), this.$element[0].disabled ? this.$range.addClass(this.options.disabledClass) : this.$range.removeClass(this.options.disabledClass), this.setPosition(this.position, b);
    }, j.prototype.handleDown = function (a) {
        if (this.$document.on(this.moveEvent, this.handleMove), this.$document.on(this.endEvent, this.handleEnd), !((" " + a.target.className + " ").replace(/[\n\t]/g, " ").indexOf(this.options.handleClass) > -1)) {
            var b = this.getRelativePosition(a),
                c = this.$range[0].getBoundingClientRect()[this.DIRECTION],
                d = this.getPositionFromNode(this.$handle[0]) - c,
                e = "vertical" === this.orientation ? this.maxHandlePos - (b - this.grabPos) : b - this.grabPos;
            this.setPosition(e), b >= d && b < d + this.handleDimension && (this.grabPos = b - d);
        }
    }, j.prototype.handleMove = function (a) {
        a.preventDefault();
        var b = this.getRelativePosition(a),
            c = "vertical" === this.orientation ? this.maxHandlePos - (b - this.grabPos) : b - this.grabPos;
        this.setPosition(c);
    }, j.prototype.handleEnd = function (a) {
        a.preventDefault(), this.$document.off(this.moveEvent, this.handleMove), this.$document.off(this.endEvent, this.handleEnd), this.$element.trigger("change", {
            origin: this.identifier
        }), this.onSlideEnd && "function" == typeof this.onSlideEnd && this.onSlideEnd(this.position, this.value);
    }, j.prototype.cap = function (a, b, c) {
        return b > a ? b : a > c ? c : a;
    }, j.prototype.setPosition = function (a, b) {
        var c, d;
        void 0 === b && (b = !0), c = this.getValueFromPosition(this.cap(a, 0, this.maxHandlePos)), d = this.getPositionFromValue(c), this.$fill[0].style[this.DIMENSION] = d + this.grabPos + "px", this.$handle[0].style[this.DIRECTION_STYLE] = d + "px", this.setValue(c), this.position = d, this.value = c, b && this.onSlide && "function" == typeof this.onSlide && this.onSlide(d, c);
    }, j.prototype.getPositionFromNode = function (a) {
        for (var b = 0; null !== a;) b += a.offsetLeft, a = a.offsetParent;

        return b;
    }, j.prototype.getRelativePosition = function (a) {
        var b = i(this.COORDINATE),
            c = this.$range[0].getBoundingClientRect()[this.DIRECTION],
            d = 0;
        return "undefined" != typeof a["page" + b] ? d = a["client" + b] : "undefined" != typeof a.originalEvent["client" + b] ? d = a.originalEvent["client" + b] : a.originalEvent.touches && a.originalEvent.touches[0] && "undefined" != typeof a.originalEvent.touches[0]["client" + b] ? d = a.originalEvent.touches[0]["client" + b] : a.currentPoint && "undefined" != typeof a.currentPoint[this.COORDINATE] && (d = a.currentPoint[this.COORDINATE]), d - c;
    }, j.prototype.getPositionFromValue = function (a) {
        var b, c;
        return b = (a - this.min) / (this.max - this.min), c = Number.isNaN(b) ? 0 : b * this.maxHandlePos;
    }, j.prototype.getValueFromPosition = function (a) {
        var b, c;
        return b = a / (this.maxHandlePos || 1), c = this.step * Math.round(b * (this.max - this.min) / this.step) + this.min, Number(c.toFixed(this.toFixed));
    }, j.prototype.setValue = function (a) {
        (a !== this.value || "" === this.$element[0].value) && this.$element.val(a).trigger("input", {
            origin: this.identifier
        });
    }, j.prototype.destroy = function () {
        this.$document.off("." + this.identifier), this.$window.off("." + this.identifier), this.$element.off("." + this.identifier).removeAttr("style").removeData("plugin_" + k), this.$range && this.$range.length && this.$range[0].parentNode.removeChild(this.$range[0]);
    }, a.fn[k] = function (b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return this.each(function () {
            var d = a(this),
                e = d.data("plugin_" + k);
            e || d.data("plugin_" + k, e = new j(this, b)), "string" == typeof b && e[b].apply(e, c);
        });
    }, "rangeslider.js is available in jQuery context e.g $(selector).rangeslider(options);";
});
new RangeInput(document.querySelector('.range'));
// Custom slider End

function createPerk() {

    const user = $('#myDropdown1-1').val()
    var category_id = ''
    category_id_list.forEach(sub => {
        // console.log('Log - ' + sub);
        if ($(`#${sub}`).val() == category) {
            category_id = sub
            // console.log(category_id);
        }
    });

    const perks = $('#perks').val()
    const comment = $('#perk-comment').text()

    if (!user || !perks || !comment) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in perk form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Creating Perk...',
            showConfirmButton: false
        });

        $.ajax({
            url: '/sdp/perks',
            method: 'post',
            dataType: 'json',
            data: {
                details: details,
                category: category,
                subcategory: subcategory,
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    Swal.fire({
                        icon: 'success',
                        title: `<div class="text-success">Perk Created</div>`,
                        confirmButtonText: 'Okay',
                        confirmButtonColor: '#0b6fad',
                        allowOutsideClick: false
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Redirecting...',
                                timer: 1000,
                                showConfirmButton: false
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/admin/perks');
                            }, 1000);
                        }
                    })

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

function loadCategorys() {

    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    var tbody_users = ``;
    var catg_data;
    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length == 0) {

                    tbody_users += `
                        <option value="">No Users available</option>`;
                } else {
                    catg_data = true
                    // $('#table_users').fadeIn()
                    // var newelementCount = 0;
                    response.data.forEach(user => {

                        if (user.role != 'admin') {

                            tbody_users += `
                            <option id="${user._id}" value="${user.name}">${user.name} (${user.role})</option>`;
                            category_id_list.push(user._id)
                        }

                    })
                }
                // console.log(category_id_list);
                $('#myDropdown1-1').html(tbody_users)
                category_id_list.forEach(cat => {
                    $(`#${cat}`).click(() => {

                        const category = $('#myDropdown1-1').val()
                        if (category != '') {
                            // console.log(category);
                            $('#category_selected').text(category)
                            document.getElementById('category_selected').classList.add('c_selected')
                            update()
                        }

                        document.getElementById("myDropdown1").classList.remove("show");

                    })
                });

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Users fetched successfully',
                    showConfirmButton: false,
                    timer: 3000
                });

            } else {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            $('#loading').css('display', 'none');
            console.log(response);
            $('#error').text(response.responseJSON.error);
            $('#error').fadeIn();
            $('#error').css('display', 'block');
            $('#add-branch-card button').attr('disabled', true)

        }
    });

}
loadCategorys()


$('#new-perk-btn').click(async () => {
    // alert('Submit')
    const userInput = $('#myDropdown1-1')
    const user = $('#myDropdown1-1').val()
    var user_id = ''
    category_id_list.forEach(sub => {
        // console.log('Log - ' + sub);
        if ($(`#${sub}`).val() == user) {
            user_id = sub
            console.log(user_id);
        }
    });
    var user_branch
    await $.ajax({
        url: `/sdp/users`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                const users = response.data
                console.log(users);

                users.forEach(user => {

                    if (user._id == user_id) {
                        console.log('wwwwwwwwwwwwwwww');
                        user_branch = user.branch
                    }

                });

            }
        }
    })

    const perksInput = $('#perks')
    const perks = $('#perks').val()

    const commentInput = $('#perk-comment')
    const comment = $('#perk-comment').text()

    if (!perks) {
        perksInput.css('border', '2px solid red')
    } else if (!user_id) {
        userInput.css('border', '2px solid red')
    } else if (!comment) {
        commentInput.css('border', '2px solid red')
    } else {

        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Adding Perk...',
            showConfirmButton: false
        });

        $.ajax({
            url: '/sdp/perks',
            method: 'post',
            dataType: 'json',
            data: {
                user: user_id,
                points: perks,
                comment: comment,
                branch: user_branch
            },
            success: function (response) {
                if (response.success) {

                    $('#new-perk-btn').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Perk Added Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        document.location.replace('/sdp/admin/perks');
                    }, 2500);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-perk-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            }
        });

    }
})