
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-admissions').trigger("click")
$('#sidebar-admissions,#sidebar-admissions-edit').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

var teacherID;
const courses_all_list = []

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['admission'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/admissions')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Admission Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function disableInputs() {

    $('#studentname').val('')
    $('#rollno').val('Roll Number here')
    $('#coursename').val('')
    $('#coursefees').val('Course Fees here')
    $('#enrollno').val('Enrollment Number here')
    $('#enrollmonth').val('Enrollment Month here')
    $('#enrollpay').val('')
    $('#admissiondate').val('')
    $('#batchtime').val('')
    $('#teachername').val('')
    $('#installment').val('')
    $('#installdate').val('')

    $('#studentname,#rollno,#coursename,#coursefees,#enrollno,#enrollmonth,#enrollpay,#admissiondate,#batchtime,#teachername,#installment,#installdate').attr('disabled', true)
}

function checkInputs() {
    // Normalize the border color of inputs
    var studentnameInput = $('#studentname').css('border', '1px solid initial')
    var coursenameInput = $('#coursename').css('border', '1px solid initial')
    var coursefeesInput = $('#coursefees').css('border', '1px solid initial')
    var admissiondateInput = $('#admissiondate').css('border', '1px solid initial')
    var batchtimeInput = $('#batchtime').css('border', '1px solid initial')
    var teachernameInput = $('#teachername').css('border', '1px solid initial')

    var studentname = $('#studentname').val()
    var admissiondate = $('#admissiondate').val()
    var coursename = $('#coursename').val()
    var coursefees = $('#coursefees').val()

    var batchtime = $('#batchtime').val()
    var teachername = $('#teachername').val()
    // var installment = $('#installment1').val()
    const installment = $("input[type='radio'][name='installment1']:checked").val();
    // console.log(installment);
    var installmentdate = $('#installdate').val()
    console.log('check 1');
    if (studentname || batchtime || coursename || coursefees || teachername || admissiondate) {
        console.log('check 2');
        $('#editadmission button').attr('disabled', true)
        if (studentname && batchtime && coursename && coursefees && teachername && admissiondate) {
            console.log('check 3');
            console.log(installment);
            console.log(installmentdate);
            if ((installment == 'true' && installmentdate) || installment == 'false') {
                console.log('check 4');
                $('#editadmission button').attr('disabled', false)
            } else {
                console.log('check 5');
                $('#editadmission button').attr('disabled', true)
            }
        } else {
            console.log('check 6');
            $('#editadmission button').attr('disabled', true)
        }
    }
}

$('#editadmission #studentname,#editadmission #rollno,#editadmission #coursename,#editadmission #coursefees,#editadmission #enrollno,#editadmission #enrollmonth,#editadmission #admissiondate,#editadmission #admissionbranch,#editadmission input,#editadmission #batchtime,#editadmission #teachername,#editadmission #installment,#editadmission #installdate').change(() => {
    console.log('triggered change');
    checkInputs();
})
$('#editadmission #studentname,#editadmission #rollno,#editadmission #coursename,#editadmission #coursefees,#editadmission #enrollno,#editadmission #enrollmonth,#editadmission #admissiondate,#editadmission #admissionbranch,#editadmission input,#editadmission #batchtime,#editadmission #teachername,#editadmission #installment,#editadmission #installdate').keyup(() => {
    console.log('triggered change');
    checkInputs();
})

function loadAdmissionsList(studentname = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading admissions list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/admissions',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var admissions_list;
                $('#editadmission #admission').text(response.data)

                if (response.data.length == 0) {
                    admissions_list += `<option value="">Admission List is empty</option>`;
                } else {
                    admissions_list = `<option value="">Select Admission Name</option>`;
                    response.data.forEach(admission => {
                        var select;
                        if ((studentname == `${admission.student.firstName} ${admission.student.lastName}`) || (admission._id == selected)) {
                            select = 'selected'
                        } else {
                            select = ''
                        }

                        admissions_list += `
                        <option ${select} value="${admission._id}">${admission.student.firstName} ${admission.student.lastName} Admission</option>`;
                    });
                }
                $('#editadmission #admission').html(admissions_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Admissions Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Admissions',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_admissions tbody .col').html(errorMsg)
                $('#admission-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Admissions',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#admission-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch admissions list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_admissions tbody .col').html(errorMsg)
                $('#admission-selected').html(errorMsg)
            }

        }
    });

}
loadAdmissionsList()

function getTeachersListFromStudent() { 
    const studentname = $('#studentname').val()
    // alert(studentname)
    if (studentname != '') {
        $.ajax({
            url: `/sdp/students/${studentname}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const branch = response.data.branch

                    $.ajax({
                        url: `/sdp/teachers`,
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var teachers_list;
                                if (response.data.length == 0) {
                                    teachers_list += `<option value="">Teachers List is empty</option>`;
                                } else {
                                    teachers_list = `<option value="">Select Teacher Name</option>`;
                                    response.data.forEach(teacher => {
                                        if (teacher.user.branch == branch) {
                                            if (teacher.user._id == teacherID) {

                                                teachers_list += `<option selected value="${teacher.user._id}">${teacher.user.name}</option>`;
                                            } else {

                                                teachers_list += `<option value="${teacher.user._id}">${teacher.user.name}</option>`;
                                            }
                                        }
                                    });

                                }
                                $('#teachername').html(teachers_list)

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch students list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    } else {
        $('#teachername').html(`<option value="">Select Student Name first</option>`)
    }
}
function installmentInputFlip() {
    console.log('inside installmentInputFlip function');
    const installment = $("input[type='radio'][name='installment1']:checked").val();
    if (installment == 'true') {
        $('#inst-date-input').fadeIn()
    } else {
        $('#inst-date-input').fadeOut()
    }
}

function getAdmissionDetails() {

    const selectAdmission = $('#admission').val() ? $('#admission').val() : selected

    $('#editadmission button').attr('disabled', true)
    // console.log(selectAdmission);
    if (selectAdmission == '') {

        disableInputs()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching admission details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#studentname,#rollno,#coursename,#coursefees,#enrollno,#enrollmonth,#enrollpay,#admissiondate,#batchtime,#teachername,#installment,#installdate').attr('disabled', false)

        $.ajax({
            url: `/sdp/admissions/${selectAdmission}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const admissionStudent = `${response.data.student.firstName} ${response.data.student.middleName} ${response.data.student.lastName}`
                    const admissionCourse = response.data.course.name
                    // console.log(coursesAllocated);
                    const batchData = response.data.batch

                    var Installment = ''
                    var One_Time = ''
                    if (response.data.installment == true) {
                        Installment = 'checked'
                    } else if (response.data.installment == false) {
                        One_Time = 'checked'
                    }
                    $('#installment').html(`
                    <input ${One_Time} type="radio" name="installment1" value="false" id="onetime" class="my-2 mr-1 pt-1">
                    <label for="onetime" class="my-2 mr-1 pt-1">One Time</label>
                    <input ${Installment} type="radio" name="installment1" value="true" id="installment1" class="my-2 mr-1 pt-1">
                    <label for="installment1" class="my-2 mr-1 pt-1">Installment</label>`)

                    // Testing
                    // const installmentInput = document.getElementById('installment')
                    // console.log(installmentInput);
                    // const onetimeInput = document.getElementById('onetime')
                    // console.log(onetimeInput);
                    // const installment1Input = document.getElementById('installment1')
                    // console.log(installment1Input);
                    const radios = document.querySelectorAll("input[type='radio'][name='installment1']")
                    // console.log(radios);
                    radios.forEach(radio => {
                        radio.addEventListener('click', () => {
                            console.log('inside listener');
                            installmentInputFlip()
                        })
                    });
                    // Testing End
                    $('#installment1,#onetime').change(() => {
                        console.log('Inside 1');
                        installmentInputFlip()
                    })
                    installmentInputFlip()

                    $('#admissionid').val(response.data._id)
                    $('#coursefees').val(response.data.fees)
                    $('#admissiondate').val(response.data.admissionDate.slice(0, 10))

                    teacherID = response.data.teacher ? response.data.teacher._id : ''
                    $('#installdate').val(response.data.installmentdate ? response.data.installmentdate.slice(0, 10) : '')

                    $('#enrollno').val(response.data.enrollmentNo ? response.data.enrollmentNo : '')
                    $('#enrollmonth').val(response.data.enrollmentMonth ? response.data.enrollmentMonth : '')
                    $('#enrollpay').val(response.data.enrollmentPaymentDate ? response.data.enrollmentPaymentDate.slice(0, 10) : '')
                    $('#rollno').val(response.data.rollNo ? response.data.rollNo : '')

                    $.ajax({
                        url: '/sdp/students/special/data',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var students_list;
                                $('#editadmission #admissionstudent').text(response.data)

                                if (response.data.length == 0) {
                                    students_list += `<option value="">Student List is empty</option>`;
                                } else {
                                    // students_list = `<option value="">Select Student Name</option>`;
                                    response.data.forEach(student => {
                                        const full_name = `${student.firstName} ${student.middleName} ${student.lastName}`

                                        if (admissionStudent == full_name) {
                                            students_list += `
                                        <option selected value="${student._id}">${full_name}</option>`;
                                        } else {
                                            students_list += `
                                        <option value="${student._id}">${full_name}</option>`;
                                        }

                                    });
                                }

                                $('#editadmission #studentname').html(students_list)

                                getTeachersListFromStudent()
                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Students Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Admission Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                disableInputs()

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Students',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            disableInputs()

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Students',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {

                                disableInputs()

                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch students list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#no-student-selected').html(errorMsg)
                            }

                        }
                    });

                    $.ajax({
                        url: '/sdp/courses',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var courses_list = ``;
                                $('#admissioncourses').text(response.data)

                                if (response.count == 0) {
                                    courses_list += `<span class="badge badge-light">Course list is empty</span>`;
                                } else {
                                    // courses_list = `
                                    // <input type="checkbox" name="default-batches" id="default-batches" class="mt-0">
                                    // <label for="default-batches">Add default batches</label>`;
                                    response.data.forEach(course => {

                                        if (admissionCourse == course.name) {
                                            courses_list += `
                                            <option selected value="${course._id}">${course.name}</option>`;
                                            // New batch time
                                            const batchTimings = course.batchTiming.split(',')
                                            var batches_list;

                                            if (batchTimings.length == 0) {
                                                batches_list += `<option value="">Batch Timing List is empty</option>`;
                                            } else {
                                                batches_list = `<option value="">Select Batch Time</option>`;
                                                batchTimings.forEach(batch => {

                                                    if (batchData == batch) {
                                                        batches_list += `
                                                        <option selected value="${batch}">${batch}</option>`;
                                                    } else {
                                                        batches_list += `
                                                        <option value="${batch}">${batch}</option>`;
                                                    }

                                                });
                                            }

                                            $('#batchtime').html(batches_list)
                                        } else {
                                            courses_list += `
                                        <option value="${course._id}">${course.name}</option>`;
                                        }

                                    });
                                    // console.log(courses_list);
                                    $('#editadmission #coursename').html(courses_list)
                                    for (let course = 0; course < courses_all_list.length; course++) {
                                        var element = document.getElementById(courses_all_list[course][0])
                                        element.addEventListener('click', () => {
                                            // alert('Update')
                                            checkInputs();
                                        })

                                    }

                                }

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Courses Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_courses tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-course-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-course-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch courses list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_courses tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    disableInputs()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Admissions',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_admissions tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-admission-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                disableInputs()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Admissions',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-admission-card button').attr('disabled', true)

                } else {
                    disableInputs()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch admission details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_admissions tbody .col').html(errorMsg)
                    $('#no-admission-selected').html(errorMsg)
                }

            }
        });
    }

}
if (selected != undefined) {
    // console.log('inside');
    getAdmissionDetails()
}
$('#admission').change(() => {

    getAdmissionDetails()

})

$('#edit-admission-btn').click(() => {
    // Extra security code
    var admissionid = $('#admissionid').val()
    // console.log(admissionid);
    var studentnameInput = $('#studentname')
    var studentname = $('#studentname').val()

    var coursenameInput = $('#coursename')
    var coursename = $('#coursename').val()

    var coursefeesInput = $('#coursefees')
    var coursefees = $('#coursefees').val()

    var admissiondateInput = $('#admissiondate')
    var admissiondate = $('#admissiondate').val()

    var batchtimeInput = $('#batchtime')
    var batchtime = $('#batchtime').val()

    var teachernameInput = $('#teachername')
    var teachername = $('#teachername').val()

    var installmentInput = $('#installment1')
    // var installment = $('#installment1').val()
    const installment = $("input[type='radio'][name='installment1']:checked").val();

    var installmentdate = $('#installdate').val()

    // Optional fields
    var enrollno = $('#enrollno').val()
    var enrollmonth = $('#enrollmonth').val()
    var enrollpay = $('#enrollpay').val()
    var rollno = $('#rollno').val()

    if (!studentname) {
        studentnameInput.css('border', '2px solid red')
    } else if (!coursename) {
        coursenameInput.css('border', '2px solid red')
    } else if (!coursefees) {
        coursefeesInput.css('border', '2px solid red')
        coursefeesInput.attr('placeholder', 'Please add Course Fees')
    } else if (!admissiondate) {
        admissiondateInput.css('border', '2px solid red')
    } else if (!batchtime) {
        batchtimeInput.css('border', '2px solid red')
    } else if (!teachername) {
        teachernameInput.css('border', '2px solid red')
    } else if (!installment) {
        installmentInput.css('border', '2px solid red')
    } else {

        $('#editadmission button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // const data = {
        //     student: studentname,
        //     course: coursename,
        //     fees: coursefees,
        //     admissionDate: admissiondate,
        //     batch: batchtime,
        //     teacher: teachername,
        //     installment,
        //     installmentdate,
        //     rollNo: rollno,
        //     enrollmentMonth: enrollmonth,
        //     enrollmentNo: enrollno,
        //     enrollmentPaymentDate: enrollpay
        // }
        // console.log(data);

        // Update admission
        $.ajax({
            url: `/sdp/admissions/${admissionid}`,
            method: 'put',
            dataType: 'json',
            data: {
                student: studentname,
                course: coursename,
                fees: coursefees,
                admissionDate: admissiondate,
                batch: batchtime,
                teacher: teachername,
                installment,
                installmentdate,
                rollNo: rollno,
                enrollmentMonth: enrollmonth,
                enrollmentNo: enrollno,
                enrollmentPaymentDate: enrollpay
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-admission-card button').attr('disabled', true)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Admission Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        loadAdmissionsList(studentname)
                    }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-admission-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            }
        });

    }
})

$('#studentname').change(() => {
    getTeachersListFromStudent()
})
$('#coursename').change(() => {
    const coursename = $('#coursename').val()
    // alert(coursename)
    if (coursename != '') {
        $('#coursefees').val('Calculating...')

        $.ajax({
            url: `/sdp/courses/${coursename}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#coursefees').val(response.data.fees)

                    const batchTimings = response.data.batchTiming.split(',')
                    var batches_list;

                    if (batchTimings.length == 0) {
                        batches_list += `<option value="">Batch Timing List is empty</option>`;
                    } else {
                        batches_list = `<option value="">Select Batch Time</option>`;
                        batchTimings.forEach(batch => {

                            batches_list += `
                            <option value="${batch}">${batch}</option>`;
                        });
                    }

                    $('#batchtime').html(batches_list)

                    // Success
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Course Fees Calculated',
                        timer: 3000,
                        showConfirmButton: false
                    });



                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    } else {
        $('#coursefees').val('Course Fees here')
    }
})
