
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-attendances').trigger("click")
$('#sidebar-attendances,#sidebar-attendances-edit').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['attendance'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/attendances')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Attendance Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#editattendance #attendancename,#editattendance #attendancedescription,#editattendance #attendancestartdate,#editattendance #attendanceduration,#editattendance #attendancefees,#editattendance #attendancebatches').change(() => {

    var attendancename = $('#attendancename').val()
    var attendancedescription = $('#attendancedescription').val()
    var attendancestartdate = $('#attendancestartdate').val()
    var attendanceduration = $('#attendanceduration').val()
    var attendancefees = $('#attendancefees').val()
    var attendancebatches = $('#attendancebatches').val()

    if (attendancename || attendancedescription || attendancestartdate || attendanceduration || attendancefees || attendancebatches) {
        $('#editattendance button').attr('disabled', true)
        if (attendancename && attendancedescription && attendancestartdate && attendanceduration && attendancefees && attendancebatches) {
            $('#editattendance button').attr('disabled', false)
        } else {
            $('#editattendance button').attr('disabled', true)
        }
    }
})

function loadAttendancesList(attendancename = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading attendances list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/attendances',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var attendances_list;
                $('#editattendance #attendance').text(response.data)

                if (response.data.length == 0) {
                    attendances_list += `<option value="">Attendance List is empty</option>`;
                } else {
                    attendances_list = `<option value="">Select Attendance Name</option>`;
                    response.data.forEach(attendance => {

                        if ((attendancename == attendance.name) || (attendance._id == selected)) {
                            select = 'selected'
                        } else {
                            select = ''
                        }

                        attendances_list += `
                        <option ${select} value="${attendance._id}">${attendance.name}</option>`;
                    });
                }
                $('#editattendance #attendance').html(attendances_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Attendances Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Attendances',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_attendances tbody .col').html(errorMsg)
                $('#attendance-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Attendances',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#attendance-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-attendance-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch attendances list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_attendances tbody .col').html(errorMsg)
                $('#attendance-selected').html(errorMsg)
            }

        }
    });

}
loadAttendancesList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing attendance details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#attendance-selected').css('display', 'block')

function getAttendanceDetails() {

    const selectAttendance = $('#attendance').val() ? $('#attendance').val() : selected

    $('#editattendance button').attr('disabled', true)
    // console.log(selectAttendance);
    if (selectAttendance == '') {

        $('#attendancename').val('Attendance Name here')
        $('#attendancename').attr('disabled', true)

        $('#attendancedescription').val('Attendance Description here')
        $('#attendancedescription').attr('disabled', true)

        $('#attendancestartdate').val('')
        $('#attendancestartdate').attr('disabled', true)

        $('#attendanceduration').val('')
        $('#attendanceduration').attr('disabled', true)

        $('#attendancefees').val('')
        $('#attendancefees').attr('disabled', true)

        $('#attendancebatches').val('Attendance Batches here')
        $('#attendancebatches').attr('disabled', true)

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching attendance details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#attendancename').attr('disabled', false)
        $('#attendancedescription').attr('disabled', false)
        $('#attendancestartdate').attr('disabled', false)
        $('#attendanceduration').attr('disabled', false)
        $('#attendancefees').attr('disabled', false)
        $('#attendancebatches').attr('disabled', false)

        $.ajax({
            url: `/sdp/attendances/${selectAttendance}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#attendanceid').val(response.data._id)
                    $('#attendancename').val(response.data.name)
                    $('#attendancedescription').val(response.data.description)
                    $('#attendancestartdate').val(response.data.startingAt.slice(0, 10))
                    $('#attendanceduration').val(response.data.weeks)
                    $('#attendancefees').val(response.data.fees)
                    $('#attendancebatches').val(response.data.batchTiming)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Attendance Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Attendances',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_attendances tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-attendance-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Attendances',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-attendance-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch attendance details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_attendances tbody .col').html(errorMsg)
                    $('#no-attendance-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getAttendanceDetails()
}
$('#attendance').change(() => {

    getAttendanceDetails()

})

$('#edit-attendance-btn').click(() => {
    // Extra security code
    var attendanceid = $('#attendanceid').val()
    // console.log(attendanceid);
    var nameInput = $('#attendancename')
    var attendancename = $('#attendancename').val()

    var descriptionInput = $('#attendancedescription')
    var attendancedescription = $('#attendancedescription').val()

    var startdateInput = $('#attendancestartdate')
    var attendancestartdate = $('#attendancestartdate').val()

    var durationInput = $('#attendanceduration')
    var attendanceduration = $('#attendanceduration').val()

    var feesInput = $('#attendancefees')
    var attendancefees = $('#attendancefees').val()

    if (!attendancename) {
        nameInput.css('border', '2px solid red')
        nameInput.attr('placeholder', 'Please add attendance name')
    } else if (!attendancedescription) {
        descriptionInput.css('border', '2px solid red')
        descriptionInput.attr('placeholder', 'Please add attendance description')
    } else if (!attendancestartdate) {
        startdateInput.css('border', '2px solid red')
    } else if (!attendanceduration) {
        durationInput.css('border', '2px solid red')
        durationInput.attr('placeholder', 'Please add attendance duration')
    } else if (!attendancefees) {
        feesInput.css('border', '2px solid red')
        feesInput.attr('placeholder', 'Please add attendance fees')
    } else {

        $('#editattendance button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // Update attendance
        $.ajax({
            url: `/sdp/attendances/${attendanceid}`,
            method: 'put',
            dataType: 'json',
            data: {
                name: attendancename,
                description: attendancedescription,
                startingAt: attendancestartdate,
                weeks: attendanceduration,
                fees: attendancefees
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-attendance-card button').attr('disabled', true)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Attendance Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        loadAttendancesList(attendancename)
                    }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-attendance-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-attendance-card button').attr('disabled', true)

            }
        });

    }
})
