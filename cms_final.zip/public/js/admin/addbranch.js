$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-branches').trigger("click")
$('#sidebar-branches,#sidebar-branches-add').addClass('active')
$('#add-branch-card button').attr('disabled', true)

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Branch...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#add-branch-card input,#add-branch-card textarea').keyup(() => {
    var branchname = $('#branchname').val()
    var branchaddress = $('#branchaddress').val()
    var branchemail = $('#branchemail').val()
    const progress = $('#progress')

    // console.log(branchname, branchaddress);

    if (branchname || branchaddress || branchemail) {
        // progress.css('width', '50%')
        $('#add-branch-card button').attr('disabled', true)
        if (branchname && branchaddress && branchemail) {
            progress.css('width', '100%')
            $('#add-branch-card button').attr('disabled', false)
        } else if (branchname && branchaddress) {
            progress.css('width', '66%')
            $('#add-branch-card button').attr('disabled', true)
        } else if (branchname && branchemail) {
            progress.css('width', '66%')
            $('#add-branch-card button').attr('disabled', true)
        } else if (branchaddress && branchemail) {
            progress.css('width', '66%')
            $('#add-branch-card button').attr('disabled', true)
        } else {
            progress.css('width', '33%')
            $('#add-branch-card button').attr('disabled', true)
        }
    } else {
        progress.css('width', '0%')
    }
})

$('#new-branch-btn').click(() => {
    var nameInput = $('#branchname')
    var branchname = $('#branchname').val()

    var addressInput = $('#branchaddress')
    var branchaddress = $('#branchaddress').val()

    var emailInput = $('#branchemail')
    var branchemail = $('#branchemail').val()

    if (!branchname) {
        nameInput.css('border', '2px solid red')
        nameInput.attr('placeholder', 'Please add branch name')
    } else if (!branchaddress) {
        addressInput.css('border', '2px solid red')
        addressInput.attr('placeholder', 'Please add branch address')
    } else if (!branchemail) {
        emailInput.css('border', '2px solid red')
        emailInput.attr('placeholder', 'Please add branch email')
    } else {

        loading()

        $.ajax({
            url: '/sdp/branches',
            method: 'post',
            dataType: 'json',
            data: {
                name: branchname,
                address: branchaddress,
                email: branchemail
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    nameInput.val(null)
                    addressInput.val(null)
                    $('#add-branch-card button').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Branch Added Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        document.location.replace('/sdp/admin/branches');
                    }, 2500);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
})