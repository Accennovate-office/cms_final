$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-managers').trigger("click")
$('#sidebar-managers,#sidebar-managers-add').addClass('active')
$("div#mySidebar").scrollTop(150); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Manager...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;

function createManager() {
    // Form 1
    const name = $('#managername').val()
    const email = $('#manageremail').val()
    const dob = $('#managerdob').val()
    const phone = $('#managerphone').val()
    const address = $('#manageraddress').val()
    // Form 2
    const qualifications = $('#managerqualifications').val()
    // Form 3
    const joiningDate = $('#managerjd').val()
    const branch = $('#managerbranch').val()
    const jobStartTime = $('#managerjobtimestart').val()
    const jobEndTime = $('#managerjobtimeend').val()
    // Form 4
    const password = $('#managerpassword').val()

    var jobTime = `${jobStartTime},${jobEndTime}`
    // console.log(jobTime);

    if (!name || !email || !dob || !phone || !address || !qualifications || !joiningDate || !branch || !jobStartTime || !jobEndTime || !password) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in manager form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Create Manager Login
        loading()

        $.ajax({
            url: '/sdp/users',
            method: 'post',
            dataType: 'json',
            data: {
                name,
                dob,
                branch,
                email,
                role: 'manager',
                password
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)
                    loading()
                    const new_user = response.data;
                    // console.log('User added successfully');
                    // Save Manager details
                    $.ajax({
                        url: '/sdp/managers',
                        method: 'post',
                        dataType: 'json',
                        data: {
                            dob,
                            phone,
                            address,
                            educationalQualification: qualifications,
                            joiningDate,
                            jobTime,
                            user: new_user._id
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                // nameInput.val(null)
                                // addressInput.val(null)
                                loading()
                                $('#add-branch-card button').attr('disabled', true)
                                // console.log('Welcome message sent successfully');

                                // Send Welcome message
                                $.ajax({
                                    url: '/sdp/whatsapp/welcome',
                                    method: 'post',
                                    dataType: 'json',
                                    data: {
                                        name,
                                        branch,
                                        email,
                                        role: 'manager',
                                        password,
                                        phone
                                    },
                                    success: function (response) {
                                        if (response.success) {

                                            // Implement a mail template function to send mail if told by admin

                                            $('#error,#loading').css('display', 'none')
                                            // nameInput.val(null)
                                            // addressInput.val(null)
                                            $('#add-branch-card button').attr('disabled', true)

                                            Swal.fire({
                                                icon: 'success',
                                                title: `<div class="text-success">Manager Created</div>`,
                                                html: `<h5>We have sent a welcome message to the manager's <img src="/images/managers/whatsapp.png" height="25" alt=""> WhatsApp number, including login credentials.</h5> 
                                                <div class="text-danger"><small>Please confirm with the manager that they have received the welcome message and remind them to keep their credentials safe.</small></div>`,
                                                confirmButtonText: 'Got it',
                                                confirmButtonColor: '#0b6fad',
                                                allowOutsideClick: false,
                                                width: '50rem'
                                            }).then((result) => {
                                                /* Read more about isConfirmed, isDenied below */
                                                if (result.isConfirmed) {
                                                    Swal.fire({
                                                        toast: true,
                                                        position: 'top-right',
                                                        icon: 'success',
                                                        title: 'Redirecting...',
                                                        timer: 1000,
                                                        showConfirmButton: false
                                                    });
                                                    setTimeout(() => {
                                                        document.location.replace('/sdp/admin/managers');
                                                    }, 1000);
                                                }
                                            })


                                        } else {

                                            $('#loading').css('display', 'none');
                                            $('#error').text(response.responseJSON.error);
                                            $('#error').fadeIn();
                                            $('#error').css('display', 'block');
                                            $('#add-branch-card button').attr('disabled', true)

                                        }
                                    },
                                    error: function (response) {

                                        $('#loading').css('display', 'none');
                                        // $('#error').text(response.responseJSON.error);
                                        $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                                        $('#error').fadeIn();
                                        $('#error').css('display', 'block');
                                        $('#add-branch-card button').attr('disabled', true)

                                    }
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            // $('#error').text(response.responseJSON.error);
                            $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-branch-card button').attr('disabled', true)

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New manager trigger
        createManager()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addmanager-form1,#addmanager-form2,#addmanager-form3,#addmanager-form4,#addmanager-form5').removeClass('active')
    $(`#addmanager-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 4) {
        $('#next').text('Review')
    } else if (actives.length === 5) {

        $('#next').text('Submit')
        // Form 1
        const name = $('#managername').val()
        const email = $('#manageremail').val()
        const dob = $('#managerdob').val()
        const phone = $('#managerphone').val()
        const address = $('#manageraddress').val()
        // Form 2
        const qualifications = $('#managerqualifications').val()
        // Form 3
        const joindate = $('#managerjd').val()
        const branch = $('#managerbranch').val()
        const jobStartTime = $('#managerjobtimestart').val()
        const jobEndTime = $('#managerjobtimeend').val()
        // Form 4
        var pass = null
        var password = $('#managerpassword').val()
        const passwordConfirm = $('#managerpasswordconfirm').val()
        if (password.length < 6) {
            password = '<span class="text-danger">Password length must be atleast 6</span>'
        } else if (passwordConfirm.length < 6) {
            password = '<span class="text-danger">Confirm Password length must be atleast 6</span>'
        } else if (password != passwordConfirm) {
            password = '<span class="text-danger">Password and Confirm Password are not same</span>'
        } else if (password.length >= 6 && passwordConfirm.length >= 6 && (password === passwordConfirm)) {
            pass = 1
        }

        $('#display-name').html(name ? name : '<span class="text-danger">Name field is empty</span>')
        $('#display-email').html(email ? email : '<span class="text-danger">Email field is empty</span>')
        $('#display-dob').html(dob ? dob : '<span class="text-danger">Date of Birth field is empty</span>')
        $('#display-phone').html(phone ? phone : '<span class="text-danger">Phone field is empty</span>')
        $('#display-address').html(address ? address : '<span class="text-danger">Address field is empty</span>')
        $('#display-qualifications').html(qualifications ? qualifications : '<span class="text-danger">Educational Qualifications field is empty</span>')
        $('#display-joindate').html(joindate ? joindate : '<span class="text-danger">Join Date field is empty</span>')
        $('#display-branch').html(branch ? branch : '<span class="text-danger">Branch field is empty</span>')
        $('#display-jobStartTime').html(jobStartTime ? jobStartTime : '<span class="text-danger">Job Start Time field is empty</span>')
        $('#display-jobEndTime').html(jobEndTime ? jobEndTime : '<span class="text-danger">Job End Time field is empty</span>')
        $('#display-password').html(password ? password : '<span class="text-danger">Password field is empty</span>')

        // console.log(!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !password);
        if (!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !pass) {
            next.disabled = true
        } else {
            finalSubmit = 1
            next.disabled = false
        }
    }
}
// Progress Steps JS End

$('#managerpassword').change(() => {

    const password = $('#managerpassword').val()
    const confirmPassword = $('#managerpasswordconfirm').val()

    if (password.length >= 6) {
        $('#passSuccessContainer').css('display', 'block')
        $('#passSuccess').html(`<li>Password length is 6 characters</li>`)

        $('#passErrorsContainer').css('display', 'none')
        if (confirmPassword.length >= 6) {
            if (password === confirmPassword) {
                $('#passSuccessContainer').css('display', 'block')
                $('#passSuccess').html(`<li>Password length is 6 characters</li><li>Password and Confirm Password matches</li>`)

                $('#passErrorsContainer').css('display', 'none')
            }
        }
    } else {
        $('#passErrorsContainer').css('display', 'block')
        $('#passErrors').html(`<li>Password length must be at least 6 characters</li>`)

        $('#passSuccessContainer').css('display', 'none')
    }
})

function loadBranchesList() {

    $.ajax({
        url: '/sdp/branches',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var branches_list;
                $('#managerbranch').text(response.data)

                if (response.data.length == 0) {
                    branches_list += `<option value="">Branch List is empty</option>`;
                } else {
                    branches_list = `<option value="">Select Branch Name</option>`;
                    response.data.forEach(branch => {

                        branches_list += `
                        <option value="${branch.name}">${branch.name}</option>`;
                    });
                }

                $('#managerbranch').html(branches_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Branches Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadBranchesList()

$('#managerpasswordconfirm').change(() => {
    const password = $('#managerpassword').val()
    const confirmPassword = $('#managerpasswordconfirm').val()

    if (password.length >= 6) {
        if (confirmPassword.length >= 6) {
            $('#passSuccessContainer').css('display', 'block')
            $('#passSuccess').html(`<li>Password length is 6 characters</li>`)

            $('#passErrorsContainer').css('display', 'none')
            if (password === confirmPassword) {
                $('#passSuccessContainer').css('display', 'block')
                $('#passSuccess').html(`<li>Password length is 6 characters</li><li>Password and Confirm Password matches</li>`)

                $('#passErrorsContainer').css('display', 'none')
            } else {
                $('#passErrorsContainer').css('display', 'block')
                $('#passErrors').html(`<li>Password and Confirm Password does not match</li>`)

                $('#passSuccessContainer').css('display', 'none')
            }
        } else {
            $('#passErrorsContainer').css('display', 'block')
            $('#passErrors').html(`<li>Confirm Password length must be at least 6 characters</li>`)

            $('#passSuccessContainer').css('display', 'none')
        }
    } else {
        $('#passErrorsContainer').css('display', 'block')
        $('#passErrors').html(`<li>Password length must be at least 6 characters</li>`)

        $('#passSuccessContainer').css('display', 'none')
    }
})


// $('.addNewManager').click(() => {
//     alert('Submit')
//     // var nameInput = $('#managername')
//     // var managername = $('#managername').val()

//     // var addressInput = $('#manageraddress')
//     // var manageraddress = $('#manageraddress').val()

//     // if (!managername) {
//     //     nameInput.css('border', '2px solid red')
//     //     nameInput.attr('placeholder', 'Please add manager name')
//     // } else if (!manageraddress) {
//     //     addressInput.css('border', '2px solid red')
//     //     addressInput.attr('placeholder', 'Please add manager address')
//     // } else {

//     //     loading()

//     //     $.ajax({
//     //         url: '/sdp/managers',
//     //         method: 'post',
//     //         dataType: 'json',
//     //         data: {
//     //             name: managername,
//     //             address: manageraddress
//     //         },
//     //         success: function (response) {
//     //             if (response.success) {

//     //                 $('#error,#loading').css('display', 'none')
//     //                 nameInput.val(null)
//     //                 addressInput.val(null)
//     //                 $('#add-manager-card button').attr('disabled', true)
//     //                 Swal.fire({
//     //                     toast: true,
//     //                     position: 'top-right',
//     //                     icon: 'success',
//     //                     title: 'Manager Added Successfully',
//     //                     timer: 3000,
//     //                     showConfirmButton: false
//     //                 });
//     //                 setTimeout(() => {
//     //                     document.location.replace('/sdp/admin/managers');
//     //                 }, 2500);

//     //             } else {

//     //                 $('#loading').css('display', 'none');
//     //                 $('#error').text(response.responseJSON.error);
//     //                 $('#error').fadeIn();
//     //                 $('#error').css('display', 'block');
//     //                 $('#add-manager-card button').attr('disabled', true)

//     //             }
//     //         },
//     //         error: function (response) {

//     //             $('#loading').css('display', 'none');
//     //             $('#error').text(response.responseJSON.error);
//     //             $('#error').fadeIn();
//     //             $('#error').css('display', 'block');
//     //             $('#add-manager-card button').attr('disabled', true)

//     //         }
//     //     });

//     // }
// })