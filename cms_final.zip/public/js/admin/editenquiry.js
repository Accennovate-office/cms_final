import { loadCoursesList, loadUsersList } from "../services/loadList.js";

$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-enquiries').trigger("click")
$('#sidebar-enquiries,#sidebar-enquiries-edit').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

// Reference forms toggle
$('#ref2,#ref3').fadeOut()
document.getElementById('btn-ref1').classList.remove('no-ref')
$('#btn-ref1').click(() => {
    $('#ref1').fadeIn(250)
    document.getElementById('btn-ref1').classList.remove('no-ref')
    $('#ref2,#ref3').fadeOut(100)
    document.getElementById('btn-ref2').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref2').click(() => {
    $('#ref2').fadeIn(250)
    document.getElementById('btn-ref2').classList.remove('no-ref')
    $('#ref1,#ref3').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref3').click(() => {
    $('#ref3').fadeIn(250)
    document.getElementById('btn-ref3').classList.remove('no-ref')
    $('#ref1,#ref2').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref2').classList.add('no-ref')

})

// Social media icon color
$('#enquirysocialmedia-facebook').keyup(() => {
    const facebook = $('#enquirysocialmedia-facebook').val()
    if (facebook != '') {
        $('#facebook-icon').attr('src', '/images/enquiries/facebook-yes.png')
    } else {
        $('#facebook-icon').attr('src', '/images/enquiries/facebook-no.png')
    }
})
$('#enquirysocialmedia-instagram').keyup(() => {
    const instagram = $('#enquirysocialmedia-instagram').val()
    if (instagram != '') {
        $('#instagram-icon').attr('src', '/images/enquiries/instagram-yes.png')
    } else {
        $('#instagram-icon').attr('src', '/images/enquiries/instagram-no.png')
    }
})
$('#enquirysocialmedia-youtube').keyup(() => {
    const youtube = $('#enquirysocialmedia-youtube').val()
    if (youtube != '') {
        $('#youtube-icon').attr('src', '/images/enquiries/youtube-yes.png')
    } else {
        $('#youtube-icon').attr('src', '/images/enquiries/youtube-no.png')
    }
})
$('#enquirysocialmedia-twitter').keyup(() => {
    const twitter = $('#enquirysocialmedia-twitter').val()
    if (twitter != '') {
        $('#twitter-icon').attr('src', '/images/enquiries/twitter-yes.png')
    } else {
        $('#twitter-icon').attr('src', '/images/enquiries/twitter-no.png')
    }
})
$('#enquirysocialmedia-linkedin').keyup(() => {
    const linkedin = $('#enquirysocialmedia-linkedin').val()
    if (linkedin != '') {
        $('#linkedin-icon').attr('src', '/images/enquiries/linkedin-yes.png')
    } else {
        $('#linkedin-icon').attr('src', '/images/enquiries/linkedin-no.png')
    }
})

// Aadhaar validation start - https://stackoverflow.com/a/47428241
$('[data-type="adhaar-number"]').keyup(function () {
    var value = $(this).val();
    value = value.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
    $(this).val(value);
});

// $('[data-type="adhaar-number"]').on("change, blur", function () {
//     var value = $(this).val();
//     var maxLength = $(this).attr("maxLength");
//     if (value.length != maxLength) {
//         $(this).addClass("highlight-error");
//     } else {
//         $(this).removeClass("highlight-error");
//     }
// });
// Aadhaar validation end

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['enquiry'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/enquiries')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Enquiry Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function disableInputs() {

    $('#firstname').val('First Name')
    $('#middlename').val('Middle Name')
    $('#lastname').val('Last Name')

    $('#enquirydob').val('')
    $('#enquirygender').val('')
    $('#enquiryaadhaar').val('Enquiry Aadhaar here')
    $('#enquiryreligion').val('Enquiry Religion here')
    $('#enquirycaste').val('Enquiry Caste here')

    $('#enquiryfatheroccupation').val('Enquiry Father Occupation here')
    $('#enquirymothername').val('Mother Name here')
    $('#enquirymothertongue').val('Mother Tongue here')

    $('#enquiryphone1').val('Enquiry Phone 1 here')
    $('#enquiryphone2').val('Enquiry Phone 2 here')
    $('#enquiryparentphone').val('Parent Phone here')
    $('#enquiryemail').val('Enquiry Email here')
    $('#enquiryaddress').val('Enquiry Address here')

    $('#enquiryquali').val('Enquiry Qualifications here')
    $('#enquirieschool').val('Enquiry Scholl or College Name here')
    $('#enquiryclass').val('Enquiry Class or Tuition Name here')

    $('#enquirybranch').val('')
    $('#enquirycategory').val('')
    // $('#enquiryreference').val('enquiry Reference here')
    // $('#enquiriesocial').val('enquiry Social Media here')

    $('#enquirysocialmedia-facebook,#enquirysocialmedia-instagram,#enquirysocialmedia-youtube,#enquirysocialmedia-twitter,#enquirysocialmedia-linkedin').val('')

    $('#ref1_name,#ref1_phone,#ref1_category,#ref1_area,#ref2_name,#ref2_phone,#ref2_category,#ref2_area,#ref3_name,#ref3_phone,#ref3_category,#ref3_area').val('')

    $('#firstname,#middlename,#lastname,#enquirydob,#enquirygender,#enquiryaadhaar,#enquiryreligion,#enquirycaste,#enquiryfatheroccupation,#enquirymothername,#enquirymothertongue,#enquiryphone1,#enquiryphone2,#enquiryparentphone,#enquiryemail,#enquiryaddress,#enquiryquali,#enquirieschool,#enquiryclass,#enquirybranch,#enquirycategory,#enquiryreference,#enquiriesocial,#enquirysocialmedia-facebook,#enquirysocialmedia-instagram,#enquirysocialmedia-youtube,#enquirysocialmedia-twitter,#enquirysocialmedia-linkedin,#ref1_name,#ref1_phone,#ref1_category,#ref1_area,#ref2_name,#ref2_phone,#ref2_category,#ref2_area,#ref3_name,#ref3_phone,#ref3_category,#ref3_area').attr('disabled', true)

}

function checkInputs() {
    var firstname = $('#firstname').val()
    // var middlename = $('#middlename').val()
    // var lastname = $('#lastname').val()

    // var enquirydob = $('#enquirydob').val()
    var enquirygender = $('#enquirygender').val()
    // var enquiryaadhaar = $('#enquiryaadhaar').val()
    // var enquiryreligion = $('#enquiryreligion').val()
    // var enquirycaste = $('#enquirycaste').val()

    // var enquiryfatheroccupation = $('#enquiryfatheroccupation').val()
    // var enquirymothername = $('#enquirymothername').val()
    // var enquirymothertongue = $('#enquirymothertongue').val()

    var enquiryphone1 = $('#enquiryphone1').val()
    // var enquiryphone2 = $('#enquiryphone2').val()
    // var enquiryparentphone = $('#enquiryparentphone').val()
    // var enquiryemail = $('#enquiryemail').val()
    var enquiryarea = $('#enquiryarea').val()
    // var enquiryaddress = $('#enquiryaddress').val()

    // var enquiryquali = $('#enquiryquali').val()
    // var enquirieschool = $('#enquirieschool').val()
    // var enquiryclass = $('#enquiryclass').val()

    var enquirybranch = $('#enquirybranch').val()
    // var enquirycategory = $('#enquirycategory').val()
    // var enquiryreference = $('#enquiryreference').val()
    // var enquiriesocial = $('#enquiriesocial').val()
    var username = $('#username').val()
    var takenbyother = $('#takenbyother').val()
    
    var coursesContent = selectedCoursesIDs[0]
    // console.log(selectedCoursesIDs);

    if (firstname || enquirygender || enquiryphone1 || enquiryarea || enquirybranch || coursesContent || username) {
        $('#editenquiry button').attr('disabled', true)
        if (firstname && enquirygender && enquiryphone1 && enquiryarea && enquirybranch && coursesContent && username) {
            if (username == 'other') {
                if (takenbyother) {
                    $('#editenquiry button').attr('disabled', false)
                } else {
                    $('#editenquiry button').attr('disabled', true)
                }
            } else {
                $('#editenquiry button').attr('disabled', false)
            }
        } else {
            $('#editenquiry button').attr('disabled', true)
        }
    }
}

$('#editenquiry #firstname,#editenquiry #middlename,#editenquiry #lastname,#editenquiry #enquirydob,#editenquiry #enquiryaadhaar,#editenquiry #enquiryreligion,#editenquiry #enquirycaste,#editenquiry #enquiryfatheroccupation,#editenquiry #enquirymothername,#editenquiry #enquirymothertongue,#editenquiry #enquiryphone1,#editenquiry #enquiryphone2,#editenquiry #enquiryparentphone,#editenquiry #enquiryemail,#editenquiry #enquiryarea,#editenquiry #enquiryaddress,#editenquiry #enquiryquali,#editenquiry #enquirieschool,#editenquiry #enquiryclass,#editenquiry #enquiryreference,#editenquiry input').keyup(() => {checkInputs();})

$('#editenquiry #enquirygender,#editenquiry #enquirybranch,#editenquiry #enquirycategory,#editenquiry #ref1_category,#editenquiry #ref2_category,#editenquiry #ref3_category').change(()=>{checkInputs();})

$('#editenquiry #username').change(()=>{
    
    var username = $('#username').val()
    if (username == 'other') {
        $('#takenbyother').css('display','')
        $('#label-takenbyother').css('display','')
    } else {
        $('#takenbyother').css('display','none')
        $('#label-takenbyother').css('display','none')
    }
    checkInputs();
})

// function loadenquiriesList(enquiryname = null) {

//     Swal.fire({
//         toast: true,
//         position: 'top-right',
//         icon: 'info',
//         title: 'Loading...',
//         showConfirmButton: false
//     });

//     $.ajax({
//         url: '/sdp/enquiries',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var enquiries_list;
//                 $('#editenquiry #enquiry').text(response.data)

//                 if (response.data.length == 0) {
//                     enquiries_list += `<option value="">Enquiry List is empty</option>`;
//                 } else {
//                     enquiries_list = `<option value="">Select Enquiry Name</option>`;
//                     response.data.forEach(enquiry => {
//                         var select
//                         if ((enquiryname == `${enquiry.firstName} ${enquiry.lastName}`) || (enquiry._id == selected)) {
//                             select = 'selected'
//                         } else {
//                             select = ''
//                         }

//                         enquiries_list += `
//                         <option ${select} value="${enquiry._id}">${enquiry.firstName} ${enquiry.lastName}</option>`;
//                     });
//                 }
//                 $('#editenquiry #enquiry').html(enquiries_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Enquiries Loaded Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'error',
//                     title: 'Error Loading Enquiries',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Request Success: ${response.success} <br>
//                     Data Received: ${JSON.stringify(response.data)}
//                 </h4>
//                 <h5>We were unable to process the request</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_enquiries tbody .col').html(errorMsg)
//                 $('#enquiry-selected').html(errorMsg)

//             }
//         },
//         error: function (response) {

//             Swal.fire({
//                 toast: true,
//                 position: 'top-right',
//                 icon: 'error',
//                 title: 'Error Loading Enquiries',
//                 timer: 3000,
//                 showConfirmButton: false
//             });

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#enquiry-selected').html(response.responseJSON.error)
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-enquiry-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch enquiries list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_enquiries tbody .col').html(errorMsg)
//                 $('#enquiry-selected').html(errorMsg)
//             }

//         }
//     });

// }
// loadenquiriesList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing enquiry details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#enquiry-selected').css('display', 'block')

var enquiryID = ''
var takenby = ''
var takenbyother = ''
function getEnquiryDetails() {

    const selectenquiry = $('#enquiry').val() ? $('#enquiry').val() : selected

    $('#editenquiry button').attr('disabled', true)
    // console.log(selectenquiry);
    if (selectenquiry == '') {

        disableInputs()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching enquiry details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#firstname,#middlename,#lastname').attr('disabled', false)

        $('#firstname,#middlename,#lastname,#enquirydob,#enquirygender,#enquiryaadhaar,#enquiryreligion,#enquirycaste,#enquiryfatheroccupation,#enquirymothername,#enquirymothertongue,#enquiryphone1,#enquiryphone2,#enquiryparentphone,#enquiryemail,#enquiryarea,#enquiryaddress,#enquiryquali,#enquirieschool,#enquiryclass,#enquirybranch,#enquirycategory,#enquiryreference,#enquiriesocial,#enquirysocialmedia-facebook,#enquirysocialmedia-instagram,#enquirysocialmedia-youtube,#enquirysocialmedia-twitter,#enquirysocialmedia-linkedin,#ref1_name,#ref1_phone,#ref1_category,#ref1_area,#ref2_name,#ref2_phone,#ref2_category,#ref2_area,#ref3_name,#ref3_phone,#ref3_category,#ref3_area').attr('disabled', false)

        $.ajax({
            url: `/sdp/enquiries/${selectenquiry}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const enquiryBranch = response.data.branch.name
                    enquiryID = response.data._id
                    selectedCoursesIDs = response.data.courses.split(',')
                    createCoursesUI()
                    console.log(selectedCoursesIDs);
                    if (response.data.takenby) {
                        // console.log(response.data.takenby._id);
                        takenby = response.data.takenby._id
                        $(`#username option[value='${takenby}']`).attr("selected","selected");
                        
                    } else {
                        // console.log(response.data.takenbyother);
                        takenbyother = response.data.takenbyother
                    }

                    $('#edit-enquiry').text(`${response.data.firstName} ${response.data.middleName} ${response.data.lastName}`)
                    $('#enquiryid').val(response.data._id)
                    $('#firstname').val(response.data.firstName)
                    $('#middlename').val(response.data.middleName)
                    $('#lastname').val(response.data.lastName)

                    response.data.dob ? $('#enquirydob').val(response.data.dob.slice(0, 10)) : ''

                    var genders_list;
                    const genders = ['Male', 'Female', 'Other']
                    genders.forEach(gender => {
                        if (gender == response.data.gender) {
                            genders_list += `
                        <option selected value="${gender}">${gender}</option>`;
                        } else {
                            genders_list += `
                        <option value="${gender}">${gender}</option>`;
                        }
                    });
                    $('#editenquiry #enquirygender').html(genders_list)

                    // // Aadhaar number
                    // var aNo = response.data.aadhaarNo.toString()
                    // const aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    // Aadhaar number validation if available or not
                    var aadhaarNumber = ''
                    if (response.data.aadhaarNo) {

                        var aNo = response.data.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    }
                    // else {
                    //     aadhaarNumber = 'No Aadhaar card added'
                    // }

                    $('#enquiryaadhaar').val(aadhaarNumber)
                    $('#enquiryreligion').val(response.data.religion)
                    $('#enquirycaste').val(response.data.caste)

                    $('#enquiryfatheroccupation').val(response.data.fatherOccupation)
                    $('#enquirymothername').val(response.data.motherName)
                    $('#enquirymothertongue').val(response.data.motherTongue)

                    $('#enquiryphone1').val(response.data.phone1)
                    $('#enquiryphone2').val(response.data.phone2)
                    $('#enquiryparentphone').val(response.data.parentPhone)
                    $('#enquiryemail').val(response.data.email)
                    $('#enquiryarea').val(response.data.area)
                    $('#enquiryaddress').val(response.data.address)

                    $('#enquiryquali').val(response.data.qualification)
                    $('#enquirieschool').val(response.data.schoolOrCollegeName)
                    $('#enquiryclass').val(response.data.classOrTuitionName)

                    // // Social media
                    // $('#enquirysocialmedia-facebook').val(response.data.facebook)
                    // response.data.facebook ? $('#facebook-icon').attr('src', '/images/enquiries/facebook-yes.png') : ''

                    // $('#enquirysocialmedia-instagram').val(response.data.instagram)
                    // response.data.instagram ? $('#instagram-icon').attr('src', '/images/enquiries/instagram-yes.png') : ''

                    // $('#enquirysocialmedia-youtube').val(response.data.youtube)
                    // response.data.youtube ? $('#youtube-icon').attr('src', '/images/enquiries/youtube-yes.png') : ''

                    // $('#enquirysocialmedia-twitter').val(response.data.twitter)
                    // response.data.twitter ? $('#twitter-icon').attr('src', '/images/enquiries/twitter-yes.png') : ''

                    // $('#enquirysocialmedia-linkedin').val(response.data.linkedin)
                    // response.data.linkedin ? $('#linkedin-icon').attr('src', '/images/enquiries/linkedin-yes.png') : ''

                    // $('#referenceid').val(response.data.reference._id)
                    // // Reference 1
                    // $('#ref1_name').val(response.data.reference.ref1Name)
                    // $('#ref1_phone').val(response.data.reference.ref1Phone)
                    // $('#ref1_category').val(response.data.reference.ref1Category)
                    // $('#ref1_area').val(response.data.reference.ref1Area)
                    // // Reference 2
                    // $('#ref2_name').val(response.data.reference.ref2Name)
                    // $('#ref2_phone').val(response.data.reference.ref2Phone)
                    // $('#ref2_category').val(response.data.reference.ref2Category)
                    // $('#ref2_area').val(response.data.reference.ref2Area)
                    // // Reference 3
                    // $('#ref3_name').val(response.data.reference.ref3Name)
                    // $('#ref3_phone').val(response.data.reference.ref3Phone)
                    // $('#ref3_category').val(response.data.reference.ref3Category)
                    // $('#ref3_area').val(response.data.reference.ref3Area)

                    var categorys_list;
                    const categorys = ['Student', 'Service', 'HomeMaker']
                    categorys.forEach(category => {
                        if (category == response.data.category) {
                            categorys_list += `
                        <option selected value="${category}">${category}</option>`;
                        } else {
                            categorys_list += `
                        <option value="${category}">${category}</option>`;
                        }
                    });
                    $('#editenquiry #enquirycategory').html(categorys_list)

                    $('#enquiryreference').val(response.data.reference)
                    $('#enquiriesocial').val(response.data.socialMedia)

                    $.ajax({
                        url: '/sdp/branches',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var branches_list;
                                $('#editenquiry #enquirybranch').text(response.data)

                                if (response.data.length == 0) {
                                    branches_list += `<option value="">Branch List is empty</option>`;
                                } else {
                                    // branches_list = `<option value="">Select Branch Name</option>`;
                                    response.data.forEach(branch => {

                                        if (enquiryBranch == branch.name) {
                                            branches_list += `
                                        <option selected value="${branch._id}">${branch.name}</option>`;
                                        } else {
                                            branches_list += `
                                        <option value="${branch._id}">${branch.name}</option>`;
                                        }

                                    });
                                }

                                $('#editenquiry #enquirybranch').html(branches_list)

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Branches Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Enquiry Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                disableInputs()

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Branches',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                $('#table_branches tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            disableInputs()

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Branches',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            } else {

                                disableInputs()

                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch branches list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_branches tbody .col').html(errorMsg)
                                $('#no-branch-selected').html(errorMsg)
                            }

                        }
                    });

                    // Social media
                    $('#enquirysocialmedia-facebook').val(response.data.facebook)
                    response.data.facebook ? $('#facebook-icon').attr('src', '/images/enquiries/facebook-yes.png') : ''

                    $('#enquirysocialmedia-instagram').val(response.data.instagram)
                    response.data.instagram ? $('#instagram-icon').attr('src', '/images/enquiries/instagram-yes.png') : ''

                    $('#enquirysocialmedia-youtube').val(response.data.youtube)
                    response.data.youtube ? $('#youtube-icon').attr('src', '/images/enquiries/youtube-yes.png') : ''

                    $('#enquirysocialmedia-twitter').val(response.data.twitter)
                    response.data.twitter ? $('#twitter-icon').attr('src', '/images/enquiries/twitter-yes.png') : ''

                    $('#enquirysocialmedia-linkedin').val(response.data.linkedin)
                    response.data.linkedin ? $('#linkedin-icon').attr('src', '/images/enquiries/linkedin-yes.png') : ''

                    if (response.data.reference) {
                        $('#referenceid').val(response.data.reference ? response.data.reference._id : '')
                        // Reference 1
                        $('#ref1_name').val(response.data.reference.ref1Name ? response.data.reference.ref1Name : '')
                        $('#ref1_phone').val(response.data.reference.ref1Phone ? response.data.reference.ref1Phone : '')
                        $('#ref1_category').val(response.data.reference.ref1Category ? response.data.reference.ref1Category : '')
                        $('#ref1_area').val(response.data.reference.ref1Area ? response.data.reference.ref1Area : '')
                        // Reference 2
                        $('#ref2_name').val(response.data.reference.ref2Name ? response.data.reference.ref2Name : '')
                        $('#ref2_phone').val(response.data.reference.ref2Phone ? response.data.reference.ref2Phone : '')
                        $('#ref2_category').val(response.data.reference.ref2Category ? response.data.reference.ref2Category : '')
                        $('#ref2_area').val(response.data.reference.ref2Area ? response.data.reference.ref2Area : '')
                        // Reference 3
                        $('#ref3_name').val(response.data.reference.ref3Name ? response.data.reference.ref3Name : '')
                        $('#ref3_phone').val(response.data.reference.ref3Phone ? response.data.reference.ref3Phone : '')
                        $('#ref3_category').val(response.data.reference.ref3Category ? response.data.reference.ref3Category : '')
                        $('#ref3_area').val(response.data.reference.ref3Area ? response.data.reference.ref3Area : '')
                    }

                } else {

                    disableInputs()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Enquiries',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_enquiries tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-enquiry-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                disableInputs()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Enquiries',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-enquiry-card button').attr('disabled', true)

                } else {
                    disableInputs()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch enquiry details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_enquiries tbody .col').html(errorMsg)
                    $('#no-enquiry-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getEnquiryDetails()
}
$('#enquiry').change(() => {

    getEnquiryDetails()

})

$('#edit-enquiry-btn').click(() => {
    // Extra security code
    var enquiryid = $('#enquiryid').val()
    var referenceid = $('#referenceid').val()
    // console.log(enquiryid);

    // Inputs
    var Inputfirstname = $('#firstname')
    var Inputmiddlename = $('#middlename')
    var Inputlastname = $('#lastname')

    var Inputenquirydob = $('#enquirydob')
    var Inputenquirygender = $('#enquirygender')
    var Inputenquiryaadhaar = $('#enquiryaadhaar')
    var Inputenquiryreligion = $('#enquiryreligion')
    var Inputenquirycaste = $('#enquirycaste')

    var Inputenquiryfatheroccupation = $('#enquiryfatheroccupation')
    var Inputenquirymothername = $('#enquirymothername')
    var Inputenquirymothertongue = $('#enquirymothertongue')

    var Inputenquiryphone1 = $('#enquiryphone1')
    var Inputenquiryphone2 = $('#enquiryphone2')
    var Inputenquiryparentphone = $('#enquiryparentphone')
    var Inputenquiryemail = $('#enquiryemail')
    var Inputenquiryarea = $('#enquiryarea')
    var Inputenquiryaddress = $('#enquiryaddress')

    var Inputenquiryquali = $('#enquiryquali')
    var Inputenquirieschool = $('#enquirieschool')
    var Inputenquiryclass = $('#enquiryclass')

    var Inputenquirybranch = $('#enquirybranch')
    var Inputenquirycategory = $('#enquirycategory')
    // var Inputenquiryreference = $('#enquiryreference')
    // var Inputenquiriesocial = $('#enquiriesocial')

    // Values
    var firstname = $('#firstname').val()
    var middlename = $('#middlename').val()
    var lastname = $('#lastname').val()

    var enquirydob = $('#enquirydob').val()
    var enquirygender = $('#enquirygender').val()
    var enquiryaadhaar = $('#enquiryaadhaar').val()
    var enquiryreligion = $('#enquiryreligion').val()
    var enquirycaste = $('#enquirycaste').val()

    var enquiryfatheroccupation = $('#enquiryfatheroccupation').val()
    var enquirymothername = $('#enquirymothername').val()
    var enquirymothertongue = $('#enquirymothertongue').val()

    var enquiryphone1 = $('#enquiryphone1').val()
    var enquiryphone2 = $('#enquiryphone2').val()
    var enquiryparentphone = $('#enquiryparentphone').val()
    var enquiryemail = $('#enquiryemail').val()
    var enquiryarea = $('#enquiryarea').val()
    var enquiryaddress = $('#enquiryaddress').val()

    var enquiryquali = $('#enquiryquali').val()
    var enquirieschool = $('#enquirieschool').val()
    var enquiryclass = $('#enquiryclass').val()

    var enquirybranch = $('#enquirybranch').val()
    var enquirycategory = $('#enquirycategory').val()
    // var enquiryreference = $('#enquiryreference').val()
    // var enquiriesocial = $('#enquiriesocial').val()

    // Social Media
    const facebook = $('#enquirysocialmedia-facebook').val() || null
    const instagram = $('#enquirysocialmedia-instagram').val() || null
    const youtube = $('#enquirysocialmedia-youtube').val() || null
    const twitter = $('#enquirysocialmedia-twitter').val() || null
    const linkedin = $('#enquirysocialmedia-linkedin').val() || null

    // Reference 1
    const ref1_name = $('#ref1_name').val()
    const ref1_phone = $('#ref1_phone').val()
    const ref1_category = $('#ref1_category').val()
    const ref1_area = $('#ref1_area').val()
    // Reference 2
    const ref2_name = $('#ref2_name').val()
    const ref2_phone = $('#ref2_phone').val()
    const ref2_category = $('#ref2_category').val()
    const ref2_area = $('#ref2_area').val()
    // Reference 3
    const ref3_name = $('#ref3_name').val()
    const ref3_phone = $('#ref3_phone').val()
    const ref3_category = $('#ref3_category').val()
    const ref3_area = $('#ref3_area').val()

    var username = $('#username').val()
    var takenbyother = $('#takenbyother').val()

    if (!firstname) {
        Inputfirstname.css('border', '2px solid red')
        Inputfirstname.attr('placeholder', 'Please add first name')
    } else if (!enquirygender) {
        Inputenquirygender.css('border', '2px solid red')
    } else if (!enquiryphone1) {
        Inputenquiryphone1.css('border', '2px solid red')
    } else if (!enquiryarea) {
        Inputenquiryarea.css('border', '2px solid red')
    } else if (!enquirybranch) {
        Inputenquirybranch.css('border', '2px solid red')
    } else {
        var enquiryaadhaar_final = enquiryaadhaar.split('-').join('')

        $('#editenquiry button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        if (username == 'other') {
            username = undefined
        }else{
            takenbyother = ''
        }
        // console.log(selectedCoursesIDs);
        // console.log(selectedCoursesIDs.toString());

        // Update enquiry
        $.ajax({
            url: `/sdp/enquiries/${enquiryid}`,
            method: 'put',
            dataType: 'json',
            data: {
                firstName: firstname,
                middleName: middlename,
                lastName: lastname,
                dob: enquirydob,
                gender: enquirygender,
                aadhaarNo: enquiryaadhaar_final,
                religion: enquiryreligion,
                caste: enquirycaste,
                fatherOccupation: enquiryfatheroccupation,
                motherName: enquirymothername,
                motherTongue: enquirymothertongue,
                phone1: enquiryphone1,
                phone2: enquiryphone2,
                parentPhone: enquiryparentphone,
                email: enquiryemail,
                area: enquiryarea,
                address: enquiryaddress,
                qualification: enquiryquali,
                schoolOrCollegeName: enquirieschool,
                classOrTuitionName: enquiryclass,
                category: enquirycategory,
                branch: enquirybranch,
                courses: selectedCoursesIDs.toString(),
                facebook: facebook,
                instagram: instagram,
                youtube: youtube,
                twitter: twitter,
                linkedin: linkedin,
                takenby: username,
                takenbyother: takenbyother
            },
            success: function (response) {
                if (response.success) {

                    $.ajax({
                        url: `/sdp/enqreferences/${referenceid}`,
                        method: 'put',
                        dataType: 'json',
                        data: {
                            ref1Name: ref1_name,
                            ref1Phone: ref1_phone,
                            ref1Category: ref1_category,
                            ref1Area: ref1_area,

                            ref2Name: ref2_name,
                            ref2Phone: ref2_phone,
                            ref2Category: ref2_category,
                            ref2Area: ref2_area,

                            ref3Name: ref3_name,
                            ref3Phone: ref3_phone,
                            ref3Category: ref3_category,
                            ref3Area: ref3_area,

                            branch: enquirybranch
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                $('#edit-enquiry-card button').attr('disabled', true)
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Enquiry Updated Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });
                                // setTimeout(() => {
                                //     loadenquiriesList(`${firstname} ${lastname}`)
                                // }, 3000);

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-enquiry-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-enquiry-card button').attr('disabled', true)

                        }
                    });

                    $('#error,#loading').css('display', 'none')
                    $('#edit-enquiry-card button').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Enquiry Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    // setTimeout(() => {
                    //     loadenquiriesList(`${firstname} ${lastname}`)
                    // }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-enquiry-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-enquiry-card button').attr('disabled', true)

            }
        });

    }
})

$('#edit-enquiry').click(() => {
    document.location.replace(`/sdp/admin/viewenquiry?enquiry=${enquiryID}`)
})

// New fields
var selectedCoursesIDs = []
function createCoursesUI() {
    var courseUI = ''
    selectedCoursesIDs.forEach(oneCourse => {
        var course_text = $(`#coursename option[value='${oneCourse}']`).text();
        courseUI += `<span id="course">
                        ${course_text}
                        <span id="${oneCourse}">
                            <img src="/images/enquiries/cancel.png" width="30" alt="">
                        </span>
                    </span>`
    });
    if (selectedCoursesIDs.length == 0) {
        courseUI = "No course selected"
    }
    $('#courses_list').html(courseUI)
    $("#course span").click(function () {
        // alert($(this).attr("id"));
        // Ref: https://stackoverflow.com/a/54893802
        selectedCoursesIDs = selectedCoursesIDs.filter(course => course !== $(this).attr("id"));
        if (selectedCoursesIDs.length == 0) {
            $('#coursename').val('')
        } else {
            $('#coursename').val(selectedCoursesIDs.slice(-1)[0]);
        }
        createCoursesUI()
    });
    checkInputs();
}
$('#coursename').change(() => {
    var coursename = $('#coursename').val()
    if (jQuery.inArray(coursename, selectedCoursesIDs) != -1) { // Ref: https://stackoverflow.com/a/18867652
        // alert('already in list')
        Swal.fire({
            position: 'top-right',
            icon: 'error',
            title: 'Course already selected',
            timer: 3000,
            showConfirmButton: false,
            timerProgressBar: true
        });
    } else {
        // alert('not in list')
        if (coursename!='') {
            selectedCoursesIDs.push(coursename)
        }
    }
    createCoursesUI()
})

// Functions imported
loadCoursesList()
loadUsersList()

setTimeout(() => {
    if (takenby) {
        $(`#username option[value='${takenby}']`).attr("selected","selected");
        $('#takenbyother').css('display','none')
        $('#label-takenbyother').css('display','none')
    } else {
        $(`#username option[value='other']`).attr("selected","selected");
        $('#takenbyother').val(takenbyother)
    }
}, 3000);
