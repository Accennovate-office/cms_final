
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-branches').trigger("click")
$('#sidebar-branches,#sidebar-branches-edit').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

var selected = ''
if (getUrlVars()['branch'] != undefined) {

    selected = getUrlVars()['branch'].replace(/%20/g, " ") // Ref: https://stackoverflow.com/a/4656873
}

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/branches')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Branch Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#editbranch #branchname,#editbranch #branchaddress,#editbranch #branchemail').keyup(() => {

    var branchname = $('#branchname').val()
    var branchaddress = $('#branchaddress').val()
    var branchemail = $('#branchemail').val()

    if (branchname || branchaddress || branchemail) {
        $('#editbranch button').attr('disabled', true)
        if (branchname && branchaddress && branchemail) {
            $('#editbranch button').attr('disabled', false)
        } else {
            $('#editbranch button').attr('disabled', true)
        }
    }
})

// function loadBranchesList(branchname = null) {

//     $.ajax({
//         url: '/sdp/branches',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var branches_list;
//                 $('#editbranch #branch').text(response.data)

//                 if (response.data.length == 0) {
//                     branches_list += `<option value="">Branch List is empty</option>`;
//                 } else {
//                     branches_list = `<option value="">Select Branch Name</option>`;
//                     response.data.forEach(branch => {

//                         if ((branchname == branch.name) || (branch.name == selected)) {
//                             select = 'selected'
//                         } else {
//                             select = ''
//                         }

//                         branches_list += `
//                         <option ${select} value="${branch.name}">${branch.name}</option>`;
//                     });
//                 }
//                 $('#editbranch #branch').html(branches_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Branches Fetched Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Request Success: ${response.success} <br>
//                     Data Received: ${JSON.stringify(response.data)}
//                 </h4>
//                 <h5>We were unable to process the request</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_branches tbody .col').html(errorMsg)
//                 $('#branch-selected').html(errorMsg)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#branch-selected').html(response.responseJSON.error)
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-branch-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch branches list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_branches tbody .col').html(errorMsg)
//                 $('#branch-selected').html(errorMsg)
//             }

//         }
//     });

// }
// loadBranchesList()

var branchName = ''
function getBranchDetails() {

    const selectBranch = $('#branch').val() ? $('#branch').val() : selected
    $('#editbranch button').attr('disabled', true)
    // console.log(selectBranch);
    if (selectBranch == '') {

        $('#branchname').val('Branch Name here')
        $('#branchaddress').val('Branch Address here')
        $('#branchemail').val('Branch Email here')
        $('#branchname').attr('disabled', true)
        $('#branchaddress').attr('disabled', true)
        $('#branchemail').attr('disabled', true)
    } else {

        $('#branchname').attr('disabled', false)
        $('#branchaddress').attr('disabled', false)
        $('#branchemail').attr('disabled', false)

        $.ajax({
            url: `/sdp/branches/${selectBranch}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#branchid').val(response.data._id)
                    $('#branchname').val(response.data.name)
                    $('#edit-branch').text(response.data.name)
                    branchName = response.data.name
                    $('#branchaddress').val(response.data.address)
                    $('#branchemail').val(response.data.email)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Branch Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_branches tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch branch details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_branches tbody .col').html(errorMsg)
                    $('#no-branch-selected').html(errorMsg)
                }

            }
        });
    }

}

// $('#branch-selected').css('display', 'block')
if (selected != undefined) {
    // console.log('inside');
    getBranchDetails()
}
$('#branch').change(() => {

    getBranchDetails()

})

$('#edit-branch-btn').click(() => {
    var branchid = $('#branchid').val()
    // console.log(branchid);
    var nameInput = $('#branchname')
    var branchname = $('#branchname').val()

    var addressInput = $('#branchaddress')
    var branchaddress = $('#branchaddress').val()

    var emailInput = $('#branchemail')
    var branchemail = $('#branchemail').val()

    if (!branchname) {
        nameInput.css('border', '2px solid red')
        nameInput.attr('placeholder', 'Please add branch name')
    } else if (!branchaddress) {
        addressInput.css('border', '2px solid red')
        addressInput.attr('placeholder', 'Please add branch address')
    } else if (!branchemail) {
        emailInput.css('border', '2px solid red')
        emailInput.attr('placeholder', 'Please add branch email')
    } else {

        loading()

        $.ajax({
            url: `/sdp/branches/${branchid}`,
            method: 'put',
            dataType: 'json',
            data: {
                name: branchname,
                address: branchaddress,
                email: branchemail
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#edit-branch-card button').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Branch Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        loadBranchesList(branchname)
                    }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
})

$('#edit-branch').click(() => {
    document.location.replace(`/sdp/admin/viewbranch?branch=${branchName}`)
})
