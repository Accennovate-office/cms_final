
$('#sidebar-branches').trigger("click")
$('#sidebar-branches,#sidebar-branches-delete').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

var selected = ''
if (getUrlVars()['branch'] != undefined) {

    selected = getUrlVars()['branch'].replace(/%20/g, " ") // Ref: https://stackoverflow.com/a/4656873
}

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/branches')
})

// function loadBranchesList() {

//     $.ajax({
//         url: '/sdp/branches',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var branches_list;
//                 $('#deletebranch #branch').text(response.data)

//                 if (response.data.length == 0) {
//                     branches_list += `<option value="">Branch List is empty</option>`;
//                 } else {
//                     branches_list = `<option value="">Select Branch Name</option>`;
//                     response.data.forEach(branch => {

//                         if (branch.name == selected) {

//                             branches_list += `
//                             <option selected value="${branch.name}">${branch.name}</option>`;

//                         } else {

//                             branches_list += `
//                             <option value="${branch.name}">${branch.name}</option>`;

//                         }
//                     });
//                 }

//                 $('#deletebranch #branch').html(branches_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Branches Fetched Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_branches tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-branch-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-branch-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch branches list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_branches tbody .col').html(errorMsg)
//                 $('#no-branch-selected').html(errorMsg)
//             }

//         }
//     });

// }
// loadBranchesList()

const branchname = $('#delete-branchname')
const branchaddress = $('#delete-branchaddress')
const branchemail = $('#delete-branchemail')
const createdat = $('#delete-branchcreatedat')
const updatedat = $('#delete-branchupdatedat')
const branchid = $('#delete-branchid')

// function getBranchDetails() {

//     const selectBranch = $('#branch').val() ? $('#branch').val() : selected
//     // console.log(selectBranch);
//     if (selectBranch == '') {
//         $('#no-branch-selected').css('display', 'block')
//         $('#branch-selected').css('display', 'none')
//     } else {

//         $('#no-branch-selected').css('display', 'none')
//         $('#branch-selected').css('display', 'block')

//         $.ajax({
//             url: `/sdp/branches/${selectBranch}`,
//             method: 'get',
//             success: function (response) {
//                 if (response.success) {

//                     // $('#deletebranch #branch-selected').html(`<h2>Loading...</h2>`)

//                     var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

//                     var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
//                     var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

//                     var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
//                     // Converting update value from UTC to GMT
//                     if (updateValue != 'Not updated') {
//                         // Hindi Date time
//                         // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
//                         updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
//                     }

//                     branchname.text(response.data.name)
//                     branchaddress.text(response.data.address)
//                     branchemail.text(response.data.email)
//                     createdat.text(createdEnglishIST)
//                     updatedat.text(updateValue)
//                     branchid.val(response.data._id)

//                     Swal.fire({
//                         toast: true,
//                         position: 'top-right',
//                         icon: 'success',
//                         title: 'Branch Fetched Successfully',
//                         timer: 3000,
//                         showConfirmButton: false
//                     });

//                 } else {

//                     $('#loading').css('display', 'none');
//                     $('#table_branches tbody tr').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#error').fadeIn();
//                     $('#error').css('display', 'block');
//                     $('#add-branch-card button').attr('disabled', true)

//                 }
//             },
//             error: function (response) {

//                 if (response.responseJSON) {
//                     $('#loading').css('display', 'none');
//                     $('#error').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#error').fadeIn();
//                     $('#error').css('display', 'block');
//                     $('#add-branch-card button').attr('disabled', true)

//                 } else {
//                     var errorMsg = `
//                     <center>
//                     <h2>Oops! Something went wrong</h2>
//                     <h4 class="text-danger">
//                         Error Code: ${response.status} <br>
//                         Error Message: ${response.statusText}
//                     </h4>
//                     <h5>We were unable to fetch branches list</h5>
//                     <h6>
//                         Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                     </h6>
//                     </center>`
//                     console.log(`something went wrong ${JSON.stringify(response)}`);
//                     // console.log(response.statusText);
//                     // $('#table_branches tbody .col').html(errorMsg)
//                     $('#no-branch-selected').html(errorMsg)
//                 }

//             }
//         });
//     }

// }

// $('#no-branch-selected').css('display', 'block')
// $('#branch-selected').css('display', 'none')
// if (selected != undefined) {
//     // console.log('inside');
//     getBranchDetails()
// }
// $('#branch').change(() => {

//     getBranchDetails()

// })

$('#delete-branch-btn').click(() => {
    var delbranchid = $('#delete-branchid').val()
    var name = branchname.text()
    // console.log(delbranchid);
    swal.fire({
        title: 'Are you sure?',
        html: `You want to delete <span class="text-danger font-weight-bold">${name}</span> branch details!`,
        type: 'warning',
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!',
        focusConfirm: false
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: `/sdp/branches/${delbranchid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Branch Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-branch-selected').css('display', 'block')
                        $('#branch-selected').css('display', 'none')
                        loadBranchesList()

                        // setTimeout(() => {
                        //     document.location.replace('/sdp/auth/login');
                        // }, 1500);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });

                }
            });

        }
    })
})
