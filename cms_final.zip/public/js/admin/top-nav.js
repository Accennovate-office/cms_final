/* Get the element you want displayed in fullscreen mode (a video in this example): */
var elem = document.documentElement;
$('.exits').css('display', 'none')
$('.fulls').click(() => {
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.webkitRequestFullscreen) { /* Safari */
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { /* IE11 */
        elem.msRequestFullscreen();
    }
    $('.fulls').css('display', 'none')
    $('.exits').css('display', 'block')
})

$('.exits').click(() => {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
    }
    $('.exits').css('display', 'none')
    $('.fulls').css('display', 'block')
})

async function updatePassword() {
    // console.log('change password');

    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    const { value: formValues } = await Swal.fire({
        title: `<h3 style="color:#0b6fad;"><i class="fa fa-key" aria-hidden="true"></i> Update password </h3>`,
        html: `
        <div class="d-flex align-items-center row">
            <label class="col" for="swal-input1">Enter current password</label>
            <input id="swal-input1" type="password" class="swal2-input col" name="swal-input1">
        </div>
        <div class="d-flex align-items-center row">
            <label class="col" for="swal-input2">Enter new password</label>
            <input id="swal-input2" type="password" class="swal2-input col" name="swal-input2">
        </div>
        <div class="d-flex align-items-center row">
            <label class="col" for="swal-input3">Confirm new password</label>
            <input id="swal-input3" type="password" class="swal2-input col" name="swal-input3">
        </div>`,
        focusConfirm: false,
        showCloseButton: true,
        confirmButtonText: 'Update Password',
        confirmButtonColor: '#0b6fad',
        width: 'fit-content',
        preConfirm: () => {
            const currentPassword = document.getElementById('swal-input1').value
            const newPassword = document.getElementById('swal-input2').value
            const newPasswordConfirm = document.getElementById('swal-input3').value
            if (!currentPassword) {
                // Ref: https://stackoverflow.com/a/54582551
                Swal.showValidationMessage('Please enter current password')
            } else if (!newPassword) {
                // Ref: https://stackoverflow.com/a/54582551
                Swal.showValidationMessage('Please enter new password')
            } else if (!newPasswordConfirm) {
                // Ref: https://stackoverflow.com/a/54582551
                Swal.showValidationMessage('Please enter new password again')
            } else if (newPassword != newPasswordConfirm) {
                // Ref: https://stackoverflow.com/a/54582551
                Swal.showValidationMessage('New password & Confirm password are not same')
            } else if (newPassword.length < 6 || newPasswordConfirm < 6) {
                // Ref: https://stackoverflow.com/a/54582551
                Swal.showValidationMessage('Password should be at least 6 characters')
            } else {
                return [currentPassword, newPassword]
            }
        }
    });
    if (formValues) {
        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Loading...',
            showConfirmButton: false
        });
        if (formValues[0] != formValues[1]) {
            $.ajax({
                url: "/sdp/auth/updatepassword",
                type: "PUT",
                data: `currentPassword=${formValues[0]}&newPassword=${formValues[1]}`,
                success: function (data) {
                    // Swal.fire("Password Updated Successfully!");

                    // After password update popup
                    Swal.fire({
                        title: 'Password Updated!',
                        html: `
                        <img src="/images/extra/lock_key.gif" width="220">
                        <br> Please login again to continue`,
                        confirmButtonText: 'Login',
                        confirmButtonColor: '#0b6fad',
                        allowOutsideClick: false
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Logout user to login using updated password
                            $.ajax({
                                url: `/sdp/auth/logout`,
                                method: 'get',
                                success: function (response) {
                                    if (response.success) {

                                        Swal.fire({
                                            toast: true,
                                            position: 'bottom-right',
                                            icon: 'success',
                                            title: 'Logged out Successfully',
                                            timer: 3000,
                                            showConfirmButton: false
                                        });

                                        setTimeout(() => {
                                            document.location.replace('/sdp/auth/login');
                                        }, 1500);

                                    } else {

                                        Swal.fire({
                                            icon: 'danger',
                                            title: 'Something went wrong',
                                            text: response.responseJSON.error
                                        });
                                        console.log(response);

                                    }
                                },
                                error: function (response) {

                                    Swal.fire({
                                        icon: 'danger',
                                        title: 'Server error',
                                        text: response.responseJSON.error
                                    });
                                    console.log(response);

                                }
                            });
                        }
                    })
                },
                error: function (error) {
                    // Swal.fire("Password is incorrect");
                    // console.log(error)
                    if (error.status == 401) {

                        // Wrong current password popup
                        Swal.fire({
                            title: 'Oops!',
                            html: `
                            <img src="/images/extra/wrong_pass.png" width="100"><br>
                            <br> Current password is incorrect. Please try again`,
                            confirmButtonText: 'Try again',
                            confirmButtonColor: '#0b6fad',
                            showCancelButton: true,
                            cancelButtonText: 'Cancel',
                            allowOutsideClick: false,
                            showCloseButton: true
                        }).then((result) => {
                            if (result.isConfirmed) {
                                updatePassword()
                            }
                        })
                    } else {
                        // Error popup
                        Swal.fire({
                            title: 'Oops!',
                            html: `
                            <img src="/images/extra/general_error.png" width="100"><br>
                            <br> ${error.statusText} Please try again`,
                            confirmButtonText: 'Try again',
                            confirmButtonColor: '#0b6fad',
                            showCancelButton: true,
                            cancelButtonText: 'Cancel',
                            allowOutsideClick: false,
                            showCloseButton: true
                        }).then((result) => {
                            if (result.isConfirmed) {
                                updatePassword()
                            }
                        })
                    }
                },
            });
        } else {
            // Swal.fire("New password is same as old password");

            // Same password error popup
            Swal.fire({
                title: 'Oops!',
                html: `
                <img src="/images/extra/same_pass.png" width="100"><br>
                <br> New password is same as old password. Please try again`,
                confirmButtonText: 'Try again',
                confirmButtonColor: '#0b6fad',
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                allowOutsideClick: false,
                showCloseButton: true
            }).then((result) => {
                if (result.isConfirmed) {
                    updatePassword()
                }
            })
        }
    }
}

$('#change_password').click(async () => {
    updatePassword()
})