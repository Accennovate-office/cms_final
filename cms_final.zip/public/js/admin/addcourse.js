$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-courses').trigger("click")
$('#sidebar-courses,#sidebar-courses-add').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Course...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#default-batches').change(() => {
    if ($('#default-batches').is(':checked')) {
        $('#coursebatches').val('7-8am,8-9am,9-10am,10-11am,11-12pm,12-1pm,1-2pm,2-3pm,3-4pm,4-5pm,5-6pm,6-7pm,7-8pm,8-9pm,9-10pm')
    } else {
        $('#coursebatches').val('')
    }
})

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;

function createCourse() {
    // Form 1
    const name = $('#coursename').val()
    const description = $('#coursedescription').val()
    // Form 2
    const startDate = $('#coursejd').val()
    const weeks = $('#courseduration').val()
    const fees = $('#coursefees').val()
    const batches = $('#coursebatches').val()

    if (!name || !description || !startDate || !weeks || !fees || !batches) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in course form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Create Course
        loading()

        $.ajax({
            url: '/sdp/courses',
            method: 'post',
            dataType: 'json',
            data: {
                name: name,
                description: description,
                weeks: weeks,
                fees: fees,
                startingAt: startDate,
                batchTiming: batches
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    Swal.fire({
                        icon: 'success',
                        title: `<div class="text-success">Course Created</div>`,
                        confirmButtonText: 'Okay',
                        confirmButtonColor: '#0b6fad',
                        allowOutsideClick: false
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Redirecting...',
                                timer: 1000,
                                showConfirmButton: false
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/admin/courses');
                            }, 1000);
                        }
                    })

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New course trigger
        createCourse()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addcourse-form1,#addcourse-form2,#addcourse-form3,#addcourse-form4,#addcourse-form5').removeClass('active')
    $(`#addcourse-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 2) {
        $('#next').text('Review')
    } else if (actives.length === 3) {

        $('#next').text('Submit')
        // Form 1
        const name = $('#coursename').val()
        const description = $('#coursedescription').val()
        // Form 2
        const startDate = $('#coursejd').val()
        const weeks = $('#courseduration').val()
        const fees = $('#coursefees').val()
        const batches = $('#coursebatches').val()

        $('#display-name').html(name ? name : '<span class="text-danger">Name field is empty</span>')
        $('#display-description').html(description ? description : '<span class="text-danger">Description field is empty</span>')
        $('#display-startdate').html(startDate ? startDate : '<span class="text-danger">Start Date field is empty</span>')
        $('#display-weeks').html(weeks ? weeks : '<span class="text-danger">Duration field is empty</span>')
        $('#display-fees').html(fees ? fees : '<span class="text-danger">Fees field is empty</span>')
        $('#display-batches').html(batches ? batches : '<span class="text-danger">Batches field is empty</span>')

        // console.log(!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !password);
        if (!name || !description || !startDate || !weeks || !fees || !batches) {
            next.disabled = true
        } else {
            finalSubmit = 1
            next.disabled = false
        }
    }
}
// Progress Steps JS End

// $('#coursepassword').change(() => {

//     const password = $('#coursepassword').val()
//     const confirmPassword = $('#coursepasswordconfirm').val()

//     if (password.length >= 6) {
//         $('#passSuccessContainer').css('display', 'block')
//         $('#passSuccess').html(`<li>Password length is 6 characters</li>`)

//         $('#passErrorsContainer').css('display', 'none')
//         if (confirmPassword.length >= 6) {
//             if (password === confirmPassword) {
//                 $('#passSuccessContainer').css('display', 'block')
//                 $('#passSuccess').html(`<li>Password length is 6 characters</li><li>Password and Confirm Password matches</li>`)

//                 $('#passErrorsContainer').css('display', 'none')
//             }
//         }
//     } else {
//         $('#passErrorsContainer').css('display', 'block')
//         $('#passErrors').html(`<li>Password length must be at least 6 characters</li>`)

//         $('#passSuccessContainer').css('display', 'none')
//     }
// })

// function loadBranchesList() {

//     $.ajax({
//         url: '/sdp/branches',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var branches_list;
//                 $('#coursebranch').text(response.data)

//                 if (response.data.length == 0) {
//                     branches_list += `<option value="">Branch List is empty</option>`;
//                 } else {
//                     branches_list = `<option value="">Select Branch Name</option>`;
//                     response.data.forEach(branch => {

//                         branches_list += `
//                         <option value="${branch.name}">${branch.name}</option>`;
//                     });
//                 }

//                 $('#coursebranch').html(branches_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Branches Fetched Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_branches tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#errors').fadeIn();
//                 $('#errors').css('display', 'block');
//                 $('#add-branch-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#errors').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#errors').fadeIn();
//                 // $('#errors').css('display', 'block');
//                 $('#add-branch-card button').attr('disabled', true)

//             } else {
//                 $('#errors').fadeIn();
//                 var errorMsg = `
//                 <center class="text-danger">
//                 <h2>Oops! Something went wrong</h2>
//                 <h4>
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch branches list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_branches tbody .col').html(errorMsg)
//                 $('#errors').html(errorMsg)
//             }

//         }
//     });

// }
// loadBranchesList()

// $('#coursepasswordconfirm').change(() => {
//     const password = $('#coursepassword').val()
//     const confirmPassword = $('#coursepasswordconfirm').val()

//     if (password.length >= 6) {
//         if (confirmPassword.length >= 6) {
//             $('#passSuccessContainer').css('display', 'block')
//             $('#passSuccess').html(`<li>Password length is 6 characters</li>`)

//             $('#passErrorsContainer').css('display', 'none')
//             if (password === confirmPassword) {
//                 $('#passSuccessContainer').css('display', 'block')
//                 $('#passSuccess').html(`<li>Password length is 6 characters</li><li>Password and Confirm Password matches</li>`)

//                 $('#passErrorsContainer').css('display', 'none')
//             } else {
//                 $('#passErrorsContainer').css('display', 'block')
//                 $('#passErrors').html(`<li>Password and Confirm Password does not match</li>`)

//                 $('#passSuccessContainer').css('display', 'none')
//             }
//         } else {
//             $('#passErrorsContainer').css('display', 'block')
//             $('#passErrors').html(`<li>Confirm Password length must be at least 6 characters</li>`)

//             $('#passSuccessContainer').css('display', 'none')
//         }
//     } else {
//         $('#passErrorsContainer').css('display', 'block')
//         $('#passErrors').html(`<li>Password length must be at least 6 characters</li>`)

//         $('#passSuccessContainer').css('display', 'none')
//     }
// })


// $('.addNewCourse').click(() => {
//     alert('Submit')
//     // var nameInput = $('#coursename')
//     // var coursename = $('#coursename').val()

//     // var addressInput = $('#courseaddress')
//     // var courseaddress = $('#courseaddress').val()

//     // if (!coursename) {
//     //     nameInput.css('border', '2px solid red')
//     //     nameInput.attr('placeholder', 'Please add course name')
//     // } else if (!courseaddress) {
//     //     addressInput.css('border', '2px solid red')
//     //     addressInput.attr('placeholder', 'Please add course address')
//     // } else {

//     //     loading()

//     //     $.ajax({
//     //         url: '/sdp/courses',
//     //         method: 'post',
//     //         dataType: 'json',
//     //         data: {
//     //             name: coursename,
//     //             address: courseaddress
//     //         },
//     //         success: function (response) {
//     //             if (response.success) {

//     //                 $('#error,#loading').css('display', 'none')
//     //                 nameInput.val(null)
//     //                 addressInput.val(null)
//     //                 $('#add-course-card button').attr('disabled', true)
//     //                 Swal.fire({
//     //                     toast: true,
//     //                     position: 'top-right',
//     //                     icon: 'success',
//     //                     title: 'Course Added Successfully',
//     //                     timer: 3000,
//     //                     showConfirmButton: false
//     //                 });
//     //                 setTimeout(() => {
//     //                     document.location.replace('/sdp/admin/courses');
//     //                 }, 2500);

//     //             } else {

//     //                 $('#loading').css('display', 'none');
//     //                 $('#error').text(response.responseJSON.error);
//     //                 $('#error').fadeIn();
//     //                 $('#error').css('display', 'block');
//     //                 $('#add-course-card button').attr('disabled', true)

//     //             }
//     //         },
//     //         error: function (response) {

//     //             $('#loading').css('display', 'none');
//     //             $('#error').text(response.responseJSON.error);
//     //             $('#error').fadeIn();
//     //             $('#error').css('display', 'block');
//     //             $('#add-course-card button').attr('disabled', true)

//     //         }
//     //     });

//     // }
// })