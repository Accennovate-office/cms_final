
$('#sidebar-courses').trigger("click")
$('#sidebar-courses,#sidebar-courses-delete').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['course'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/courses')
})

function loadCoursesList() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var courses_list;
                $('#deletecourse #course').text(response.data)

                if (response.data.length == 0) {
                    courses_list += `<option value="">Course List is empty</option>`;
                } else {
                    courses_list = `<option value="">Select Course Name</option>`;
                    response.data.forEach(course => {

                        if (course._id == selected) {

                            courses_list += `
                            <option selected value="${course._id}">${course.name}</option>`;

                        } else {

                            courses_list += `
                            <option value="${course._id}">${course.name}</option>`;

                        }
                    });
                }

                $('#deletecourse #course').html(courses_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Courses Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_courses tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_courses tbody .col').html(errorMsg)
                $('#no-course-selected').html(errorMsg)
            }

        }
    });

}
loadCoursesList()

const coursename = $('#delete-coursename')
const coursedescription = $('#delete-coursedescription')

const coursestart = $('#delete-coursestart')
const courseweeks = $('#delete-courseweeks')
const coursefees = $('#delete-coursefees')
const coursebatches = $('#delete-coursebatches')

const createbyname = $('#course-createbyname')
const createbyemail = $('#course-createbyemail')
const createbybranch = $('#course-createbybranch')

const createdat = $('#delete-coursecreatedat')
const updatedat = $('#delete-courseupdatedat')
const courseid = $('#delete-courseid')

function getCourseDetails() {

    const selectCourse = $('#course').val() ? $('#course').val() : selected
    // console.log(selectCourse);
    if (selectCourse == '') {
        $('#no-course-selected').css('display', 'block')
        $('#course-selected').css('display', 'none')
    } else {

        $('#no-course-selected').css('display', 'none')
        $('#course-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/courses/${selectCourse}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deletecourse #course-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var courseStartingAt = new Date(response.data.startingAt).toLocaleDateString("en-IN", optionsCheck)

                    coursename.text(response.data.name)
                    coursedescription.text(response.data.description)

                    coursestart.text(courseStartingAt)
                    courseweeks.text(`${response.data.weeks} weeks`)
                    coursefees.text(`₹ ${response.data.fees}`)

                    var batches = ''
                    const batches_string = response.data.batchTiming.split(',')
                    // console.log(response.data.batchTiming);
                    batches_string.forEach(batch => {
                        batches += `<span class="badge badge-light">${batch}</span>`
                    });
                    coursebatches.html(batches)
                    createbyname.text(response.data.createdBy.name)
                    createbyemail.text(response.data.createdBy.email)
                    createbybranch.text(`${response.data.createdBy.branch} Branch`)

                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    courseid.val(response.data._id)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Course Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_courses tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-course-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-course-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch courses list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_courses tbody .col').html(errorMsg)
                    $('#no-course-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-course-selected').css('display', 'block')
$('#course-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getCourseDetails()
}
$('#course').change(() => {

    getCourseDetails()

})

$('#delete-course-btn').click(() => {
    var delcourseid = $('#delete-courseid').val()
    var name = coursename.text()
    // console.log(delcourseid);
    swal.fire({
        title: 'Are you sure?',
        html: `You want to delete <span class="text-danger font-weight-bold">${name}</span> course details!`,
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({ 
                url: `/sdp/courses/${delcourseid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Course Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-course-selected').css('display', 'block')
                        $('#course-selected').css('display', 'none')
                        loadCoursesList()

                        setTimeout(() => {
                            document.location.replace('/sdp/admin/deletecourse');
                        }, 3000);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });

                }
            });

        }
    })
})
