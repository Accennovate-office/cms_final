
$('#no-admission-available').fadeOut()
$('#table_admissions,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

$('#sidebar-admissions').trigger("click")
$('#sidebar-admissions,#sidebar-admissions-all').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

$('#new-admission-btn').click(() => {
    document.location.replace('/sdp/admin/addadmission');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllAdmissions(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllAdmissions(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllAdmissions(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllAdmissions(limit, page + 1)
})
// Page navigator End

function loadAllAdmissions(limit = 10, page = 1) {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-admission-available').fadeOut()
    $('#table_admissions,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/admissions?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#error,#loading').css('display', 'none')

                // if (response.data.length == 0) {
                //     var noAdmission = `
                //     <img src="/images/admissions/noadmission.png" width="60" alt="">
                //     <div class="h3 mt-2">
                //         <span class="font-weight-bold">Admission List is empty</span> <br><br>
                //         <span class="h5">Click&nbsp;
                //             <span>
                //                 <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                //                     Admission</button>
                //             </span>
                //             &nbsp;button at top left to get started
                //         </span>
                //     </div>`
                //     $('#no-admission-available').fadeIn()
                //     $('#no-admission-available').html(noAdmission)

                // } else {
                //     $('#table_admissions').fadeIn()
                //     $('#view_note').fadeIn()
                //     var tbody_admissions;
                //     // var newelementCount = 0;
                //     response.data.forEach(admission => {

                //         // // var utcCreatedDate = new Date(admission.createdAt);
                //         // var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                //         // // var s = new Date(admission.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                //         // var createdHindiIST = new Date(admission.createdAt).toLocaleDateString("hi-IN", options)
                //         // var createdEnglishIST = new Date(admission.createdAt).toLocaleDateString("en-IN", options)

                //         // For join Date
                //         var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var admissionDateEnglishIST = new Date(admission.admissionDate).toLocaleDateString("en-IN", dateOptions)
                //         // var x = new Date(admission.createdAt).getTimezoneOffset();
                //         //Converted UTC to local(IST, etc.,,)
                //         // console.log(utcCreatedDate.toUTCString());

                //         // Check date
                //         optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                //         var createdCheck = new Date(admission.createdAt).toLocaleDateString("en-IN", optionsCheck)
                //         var today = new Date().toLocaleDateString("en-IN", optionsCheck)
                //         var newElement;
                //         if (createdCheck === today) {
                //             newElement = `<span class="badge badge-noti">New</span>`
                //             // newelementCount += 1
                //         } else {
                //             newElement = ''
                //         }
                //         // if (newelementCount > 0) {
                //         //     $('#sidebar-admissions-all').html(`All Admissions <span class="badge badge-noti">${newelementCount}</span>`)
                //         // }

                //         // Code for Update Date
                //         // var updateValue = admission.updatedAt ? admission.updatedAt : 'Not updated'
                //         // // Converting update value from UTC to GMT
                //         // if (updateValue != 'Not updated') {
                //         //     // var utcUpdatedDate = new Date(updateValue);
                //         //     // updateValue = utcUpdatedDate.toUTCString()

                //         //     // Hindi Date time
                //         //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                //         //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                //         // }

                //         tbody_admissions += `
                //         <tr>
                //             <td>
                //                 ${admission.student.firstName} ${admission.student.middleName} ${admission.student.lastName} ${newElement}
                //             </td>
                //             <td>${admission.course.name}</td>
                //             <td>${admissionDateEnglishIST}</td>
                //             <td>${admission.rollNo}</td>
                //             <td>${admission.fees}</td>
                //         </tr>`;
                //     });
                //     $('#table_admissions tbody').html(tbody_admissions)

                // }

                if (response.data.length == 0 && response.total_count == 0) {
                    var noAdmission = `
                    <img src="/images/admissions/noadmission.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Admission List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Admission</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-admission-available').fadeIn()
                    $('#no-admission-available').html(noAdmission)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var noadmission = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-admission-available').fadeIn()
                    $('#no-admission-available').html(noadmission)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var noadmission = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-admission-available').fadeIn()
                        $('#no-admission-available').html(noadmission)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var admission = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-admission-available').fadeIn()
                        $('#no-admission-available').html(admission)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_admissions,#myInput').fadeIn()
                        var tbody_admissions;
                        // var newelementCount = 0;
                        response.data.forEach(admission => {

                            // var utcCreatedDate = new Date(admission.createdAt);
                            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                            var createdHindiIST = new Date(admission.createdAt).toLocaleDateString("hi-IN", options)
                            var createdEnglishIST = new Date(admission.createdAt).toLocaleDateString("en-IN", options)

                            // Check date
                            optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var createdCheck = new Date(admission.createdAt).toLocaleDateString("en-IN", optionsCheck)
                            var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                            var admissionStartingAt = new Date(admission.startingAt).toLocaleDateString("en-IN", optionsCheck)
                            var newElement;
                            if (createdCheck === today) {
                                newElement = `<span class="badge badge-noti">New</span>`
                                // newelementCount += 1
                            } else {
                                newElement = ''
                            }

                            // For join Date
                            var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var admissionDateEnglishIST = new Date(admission.admissionDate).toLocaleDateString("en-IN", dateOptions)

                            // if (newelementCount > 0) {
                            //     $('#sidebar-admissions-all').html(`All Admissions <span class="badge badge-noti">${newelementCount}</span>`)
                            // }

                            // var updateValue = admission.updatedAt ? admission.updatedAt : 'Not updated'
                            // // Converting update value from UTC to GMT
                            // if (updateValue != 'Not updated') {
                            //     // var utcUpdatedDate = new Date(updateValue);
                            //     // updateValue = utcUpdatedDate.toUTCString()

                            //     // Hindi Date time
                            //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                            //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                            // }

                            tbody_admissions += `
                            <tr id="${admission._id}">
                                <td>
                                ${admission.student.firstName} ${admission.student.middleName} ${admission.student.lastName} ${newElement}
                                </td>
                                <td>${admission.course.name}</td>
                                <td>${admissionDateEnglishIST}</td>
                                <td>${admission.rollNo}</td>
                                <td>${createdEnglishIST}</td>
                                <td>
                                    <div class="hover-container">
                                        <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                                        <aside class="hover-popup">
                                            <a align="center" class="p-1 fontt" href="/sdp/admin/viewadmission?admission=${admission._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                                            <a align="center" class="p-1 fontt text-success" href="/sdp/admin/editadmission?admission=${admission._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                                            <a align="center" class="p-1 fontt text-danger" href="/sdp/admin/deleteadmission?admission=${admission._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                                        </aside>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        $('#table_admissions tbody').html(tbody_admissions)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Admissions Fetched Successfully',
                    timer: 5000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_admissions tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch admissions list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_admissions tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllAdmissions()
