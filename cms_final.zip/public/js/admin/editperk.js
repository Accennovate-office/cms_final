$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-perks').trigger("click")
$('#sidebar-perks,#sidebar-perks-edit').addClass('active')
$("div#mySidebar").scrollTop(600); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

const next = $('#new-perk-btn')

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const category_id_list = []
const selected = getUrlVars()['perk'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/perks')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Perk...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function update() {

    const user = $('#myDropdown1-1').val()
    const perks = $('#perks').val()
    const comment = $('#perk-comment').text()
    // console.log(category, subcategory, details);
    // $('#display-name').html(category ? category : '<span class="text-danger">Name field is empty</span>')
    // $('#display-description').html(subcategory ? subcategory : '<span class="text-danger">Description field is empty</span>')
    // $('#display-startdate').html(details ? details : '<span class="text-danger">Start Date field is empty</span>')

    // console.log(!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !password);
    if (!user || !perks || !comment) {
        // next.disabled = true
        next.attr('disabled', true)
        // console.log('true');
    } else {
        finalSubmit = 1
        // console.log('false');
        next.removeAttr('disabled')
        // next.disabled = false
    }
}

function loadUsers(user) {
    // console.log('inside category');
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    var tbody_perks = ``;

    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length == 0) {

                    tbody_perks += `
                        <option value="">No User available</option>`;
                } else {
                    catg_data = true
                    // $('#table_perks').fadeIn()
                    // var newelementCount = 0;
                    response.data.forEach(perk => {

                        if (perk._id == user) {

                            tbody_perks += `
                            <option selected id="${perk._id}" value="${perk.name}">${perk.name} (${perk.role})</option>`;
                            $('#category_selected').text(perk.name)
                            document.getElementById('category_selected').classList.add('c_selected')
                        } else {

                            tbody_perks += `
                            <option id="${perk._id}" value="${perk.name}">${perk.name} (${perk.role})</option>`;
                        }

                        category_id_list.push(perk._id)
                    })
                }
                // console.log(category_id_list);
                $('#myDropdown1-1').html(tbody_perks)
                category_id_list.forEach(cat => {
                    $(`#${cat}`).click(async () => {

                        const category = $('#myDropdown1-1').val()
                        if (category != '') {
                            // console.log(category);
                            $('#category_selected').text(category)
                            document.getElementById('category_selected').classList.add('c_selected')
                            update()
                        }

                        document.getElementById("myDropdown1").classList.remove("show");

                    })
                });

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Users fetched successfully',
                    showConfirmButton: false,
                    timer: 3000
                });

            } else {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            $('#loading').css('display', 'none');
            console.log(response);
            $('#error').text(response.responseJSON.error);
            $('#error').fadeIn();
            $('#error').css('display', 'block');
            $('#add-branch-card button').attr('disabled', true)

        }
    });
}

function loadPerksList(perkname = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading perks list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/perks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var perks_list;
                $('#editperk #perk').text(response.data)

                if (response.data.length == 0) {
                    perks_list += `<option value="">Perk List is empty</option>`;
                } else {
                    perks_list = `<option value="">Select Perk Name</option>`;
                    response.data.forEach(perk => {

                        if (perkname == perk._id || selected == perk._id) {
                            // console.log('selected');
                            select = 'selected'
                        } else {
                            select = ''
                        }

                        perks_list += `
                        <option ${select} value="${perk._id}">${perk.user.name} [${perk.points}]</option>`;
                    });
                }
                $('#editperk #perk').html(perks_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Perks Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Perks',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_perks tbody .col').html(errorMsg)
                $('#perk-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Perks',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#perk-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch perks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_perks tbody .col').html(errorMsg)
                $('#perk-selected').html(errorMsg)
            }

        }
    });

}
loadPerksList()

function loadPerkDetails() {

    const selectPerk = $('#perk').val() ? $('#perk').val() : selected

    $('#editperk button').attr('disabled', true)
    // console.log(selectPerk);
    if (selectPerk == '') {

        // $('#perkdetails').attr('disabled', true)
        $('#dropbtn1').attr('disabled', true)
        $('#perks').attr('disabled', true)
        update()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching perk details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#new-perk-btn').attr('disabled', true)
        $('#dropbtn1').removeAttr('disabled')

        $.ajax({
            url: `/sdp/perks/${selectPerk}`,
            method: 'get',
            success: function (response) {
                if (response.success) {
                    // console.log(response.data);
                    $('#perkid').val(response.data._id)

                    // Edit perk slider
                    $('input[type="range"]').val(response.data.points).change() // Credit: Soumya Joy

                    $('.output').text(response.data.points)
                    $('#perk-comment').text(response.data.comment)
                    const user_id = response.data.user._id
                    loadUsers(user_id)

                } else {

                    update()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Perks',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_perks tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-perk-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                update()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Perks',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-perk-card button').attr('disabled', true)

                } else {
                    update()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch perk details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_perks tbody .col').html(errorMsg)
                    $('#no-perk-selected').html(errorMsg)
                }

            }
        })

    }

}

// Custom slider
const comments_list = ['Inferior', 'Below Average', 'Mediocre', 'Average', 'Great', 'Above Average', 'Splendid', 'Excellent', 'Exceptional', 'Remarkable', 'Sets a new standard of performance']
$('#slide-form').on('input', () => {
    // console.log('form input');
    const perks = $('#perks').val()
    // console.log(perks);
    $('.output').val(perks)
    $('#perk-comment').text(comments_list[perks])
    update()
})
"use strict";

const END = 'change';
const START = 'ontouchstart' in document ? 'touchstart' : 'mousedown';
const INPUT = 'input';
const MAX_ROTATION = 35;
const SOFTEN_FACTOR = 3;

class RangeInput {
    constructor(el) {
        this.el = el;
        this._handleEnd = this._handleEnd.bind(this);
        this._handleStart = this._handleStart.bind(this);
        this._handleInput = this._handleInput.bind(this); //Call the plugin

        $(this.el.querySelector('input[type=range]')).rangeslider({
            polyfill: false,
            //Never use the native polyfill
            rangeClass: 'rangeslider',
            disabledClass: 'rangeslider-disabled',
            horizontalClass: 'rangeslider-horizontal',
            verticalClass: 'rangeslider-vertical',
            fillClass: 'rangeslider-fill-lower',
            handleClass: 'rangeslider-thumb',
            onInit: function () {
                //No args are passed, so we can't change context of this
                const pluginInstance = this; //Move the range-output inside the handle so we can do all the stuff in css

                $(pluginInstance.$element).parents('.range').find('.range-output').appendTo(pluginInstance.$handle);
            }
        });
        this.sliderThumbEl = el.querySelector('.rangeslider-thumb');
        this.outputEl = el.querySelector('.range-output');
        this.inputEl = el.querySelector('input[type=range]');
        this._lastOffsetLeft = 0;
        this._lastTimeStamp = 0;
        this.el.querySelector('.rangeslider').addEventListener(START, this._handleStart);
    }

    _handleStart(e) {
        this._lastTimeStamp = new Date().getTime();
        this._lastOffsetLeft = this.sliderThumbEl.offsetLeft; //Wrap in raf because offsetLeft is updated by the plugin after this fires

        requestAnimationFrame(_ => {
            //Bind through jquery because plugin doesn't fire native event
            $(this.inputEl).on(INPUT, this._handleInput);
            $(this.inputEl).on(END, this._handleEnd);
        });
    }

    _handleEnd(e) {
        //Unbind through jquery because plugin doesn't fire native event
        $(this.inputEl).off(INPUT, this._handleInput);
        $(this.inputEl).off(END, this._handleEnd);
        requestAnimationFrame(_ => this.outputEl.style.transform = 'rotate(0deg)');
    }

    _handleInput(e) {
        let now = new Date().getTime();
        let timeElapsed = now - this._lastTimeStamp || 1;
        let distance = this.sliderThumbEl.offsetLeft - this._lastOffsetLeft;
        let direction = distance < 0 ? -1 : 1;
        let velocity = Math.abs(distance) / timeElapsed; //pixels / millisecond

        let targetRotation = Math.min(Math.abs(distance * velocity) * SOFTEN_FACTOR, MAX_ROTATION);
        requestAnimationFrame(_ => this.outputEl.style.transform = 'rotate(' + targetRotation * -direction + 'deg)');
        this._lastTimeStamp = now;
        this._lastOffsetLeft = this.sliderThumbEl.offsetLeft;
    }

}
/*! rangeslider.js - v2.1.1 | (c) 2016 @andreruffert | MIT license | https://github.com/andreruffert/rangeslider.js */


!function (a) {
    "use strict";

    "function" == typeof define && define.amd ? define(["jquery"], a) : "object" == typeof exports ? module.exports = a(require("jquery")) : a(jQuery);
}(function (a) {
    "use strict";

    function b() {
        var a = document.createElement("input");
        return a.setAttribute("type", "range"), "text" !== a.type;
    }

    function c(a, b) {
        var c = Array.prototype.slice.call(arguments, 2);
        return setTimeout(function () {
            return a.apply(null, c);
        }, b);
    }

    function d(a, b) {
        return b = b || 100, function () {
            if (!a.debouncing) {
                var c = Array.prototype.slice.apply(arguments);
                a.lastReturnVal = a.apply(window, c), a.debouncing = !0;
            }

            return clearTimeout(a.debounceTimeout), a.debounceTimeout = setTimeout(function () {
                a.debouncing = !1;
            }, b), a.lastReturnVal;
        };
    }

    function e(a) {
        return a && (0 === a.offsetWidth || 0 === a.offsetHeight || a.open === !1);
    }

    function f(a) {
        for (var b = [], c = a.parentNode; e(c);) b.push(c), c = c.parentNode;

        return b;
    }

    function g(a, b) {
        function c(a) {
            "undefined" != typeof a.open && (a.open = a.open ? !1 : !0);
        }

        var d = f(a),
            e = d.length,
            g = [],
            h = a[b];

        if (e) {
            for (var i = 0; e > i; i++) g[i] = d[i].style.cssText, d[i].style.setProperty ? d[i].style.setProperty("display", "block", "important") : d[i].style.cssText += ";display: block !important", d[i].style.height = "0", d[i].style.overflow = "hidden", d[i].style.visibility = "hidden", c(d[i]);

            h = a[b];

            for (var j = 0; e > j; j++) d[j].style.cssText = g[j], c(d[j]);
        }

        return h;
    }

    function h(a, b) {
        var c = parseFloat(a);
        return Number.isNaN(c) ? b : c;
    }

    function i(a) {
        return a.charAt(0).toUpperCase() + a.substr(1);
    }

    function j(b, e) {
        if (this.$window = a(window), this.$document = a(document), this.$element = a(b), this.options = a.extend({}, n, e), this.polyfill = this.options.polyfill, this.orientation = this.$element[0].getAttribute("data-orientation") || this.options.orientation, this.onInit = this.options.onInit, this.onSlide = this.options.onSlide, this.onSlideEnd = this.options.onSlideEnd, this.DIMENSION = o.orientation[this.orientation].dimension, this.DIRECTION = o.orientation[this.orientation].direction, this.DIRECTION_STYLE = o.orientation[this.orientation].directionStyle, this.COORDINATE = o.orientation[this.orientation].coordinate, this.polyfill && m) return !1;
        this.identifier = "js-" + k + "-" + l++, this.startEvent = this.options.startEvent.join("." + this.identifier + " ") + "." + this.identifier, this.moveEvent = this.options.moveEvent.join("." + this.identifier + " ") + "." + this.identifier, this.endEvent = this.options.endEvent.join("." + this.identifier + " ") + "." + this.identifier, this.toFixed = (this.step + "").replace(".", "").length - 1, this.$fill = a('<div class="' + this.options.fillClass + '" />'), this.$handle = a('<div class="' + this.options.handleClass + '" />'), this.$range = a('<div class="' + this.options.rangeClass + " " + this.options[this.orientation + "Class"] + '" id="' + this.identifier + '" />').insertAfter(this.$element).prepend(this.$fill, this.$handle), this.$element.css({
            position: "absolute",
            width: "1px",
            height: "1px",
            overflow: "hidden",
            opacity: "0"
        }), this.handleDown = a.proxy(this.handleDown, this), this.handleMove = a.proxy(this.handleMove, this), this.handleEnd = a.proxy(this.handleEnd, this), this.init();
        var f = this;
        this.$window.on("resize." + this.identifier, d(function () {
            c(function () {
                f.update(!1, !1);
            }, 300);
        }, 20)), this.$document.on(this.startEvent, "#" + this.identifier + ":not(." + this.options.disabledClass + ")", this.handleDown), this.$element.on("change." + this.identifier, function (a, b) {
            if (!b || b.origin !== f.identifier) {
                var c = a.target.value,
                    d = f.getPositionFromValue(c);
                f.setPosition(d);
            }
        });
    }

    Number.isNaN = Number.isNaN || function (a) {
        return "number" == typeof a && a !== a;
    };

    var k = "rangeslider",
        l = 0,
        m = b(),
        n = {
            polyfill: !0,
            orientation: "horizontal",
            rangeClass: "rangeslider",
            disabledClass: "rangeslider--disabled",
            horizontalClass: "rangeslider--horizontal",
            verticalClass: "rangeslider--vertical",
            fillClass: "rangeslider__fill",
            handleClass: "rangeslider__handle",
            startEvent: ["mousedown", "touchstart", "pointerdown"],
            moveEvent: ["mousemove", "touchmove", "pointermove"],
            endEvent: ["mouseup", "touchend", "pointerup"]
        },
        o = {
            orientation: {
                horizontal: {
                    dimension: "width",
                    direction: "left",
                    directionStyle: "left",
                    coordinate: "x"
                },
                vertical: {
                    dimension: "height",
                    direction: "top",
                    directionStyle: "bottom",
                    coordinate: "y"
                }
            }
        };
    return j.prototype.init = function () {
        this.update(!0, !1), this.onInit && "function" == typeof this.onInit && this.onInit();
    }, j.prototype.update = function (a, b) {
        a = a || !1, a && (this.min = h(this.$element[0].getAttribute("min"), 0), this.max = h(this.$element[0].getAttribute("max"), 100), this.value = h(this.$element[0].value, Math.round(this.min + (this.max - this.min) / 2)), this.step = h(this.$element[0].getAttribute("step"), 1)), this.handleDimension = g(this.$handle[0], "offset" + i(this.DIMENSION)), this.rangeDimension = g(this.$range[0], "offset" + i(this.DIMENSION)), this.maxHandlePos = this.rangeDimension - this.handleDimension, this.grabPos = this.handleDimension / 2, this.position = this.getPositionFromValue(this.value), this.$element[0].disabled ? this.$range.addClass(this.options.disabledClass) : this.$range.removeClass(this.options.disabledClass), this.setPosition(this.position, b);
    }, j.prototype.handleDown = function (a) {
        if (this.$document.on(this.moveEvent, this.handleMove), this.$document.on(this.endEvent, this.handleEnd), !((" " + a.target.className + " ").replace(/[\n\t]/g, " ").indexOf(this.options.handleClass) > -1)) {
            var b = this.getRelativePosition(a),
                c = this.$range[0].getBoundingClientRect()[this.DIRECTION],
                d = this.getPositionFromNode(this.$handle[0]) - c,
                e = "vertical" === this.orientation ? this.maxHandlePos - (b - this.grabPos) : b - this.grabPos;
            this.setPosition(e), b >= d && b < d + this.handleDimension && (this.grabPos = b - d);
        }
    }, j.prototype.handleMove = function (a) {
        a.preventDefault();
        var b = this.getRelativePosition(a),
            c = "vertical" === this.orientation ? this.maxHandlePos - (b - this.grabPos) : b - this.grabPos;
        this.setPosition(c);
    }, j.prototype.handleEnd = function (a) {
        a.preventDefault(), this.$document.off(this.moveEvent, this.handleMove), this.$document.off(this.endEvent, this.handleEnd), this.$element.trigger("change", {
            origin: this.identifier
        }), this.onSlideEnd && "function" == typeof this.onSlideEnd && this.onSlideEnd(this.position, this.value);
    }, j.prototype.cap = function (a, b, c) {
        return b > a ? b : a > c ? c : a;
    }, j.prototype.setPosition = function (a, b) {
        var c, d;
        void 0 === b && (b = !0), c = this.getValueFromPosition(this.cap(a, 0, this.maxHandlePos)), d = this.getPositionFromValue(c), this.$fill[0].style[this.DIMENSION] = d + this.grabPos + "px", this.$handle[0].style[this.DIRECTION_STYLE] = d + "px", this.setValue(c), this.position = d, this.value = c, b && this.onSlide && "function" == typeof this.onSlide && this.onSlide(d, c);
    }, j.prototype.getPositionFromNode = function (a) {
        for (var b = 0; null !== a;) b += a.offsetLeft, a = a.offsetParent;

        return b;
    }, j.prototype.getRelativePosition = function (a) {
        var b = i(this.COORDINATE),
            c = this.$range[0].getBoundingClientRect()[this.DIRECTION],
            d = 0;
        return "undefined" != typeof a["page" + b] ? d = a["client" + b] : "undefined" != typeof a.originalEvent["client" + b] ? d = a.originalEvent["client" + b] : a.originalEvent.touches && a.originalEvent.touches[0] && "undefined" != typeof a.originalEvent.touches[0]["client" + b] ? d = a.originalEvent.touches[0]["client" + b] : a.currentPoint && "undefined" != typeof a.currentPoint[this.COORDINATE] && (d = a.currentPoint[this.COORDINATE]), d - c;
    }, j.prototype.getPositionFromValue = function (a) {
        var b, c;
        return b = (a - this.min) / (this.max - this.min), c = Number.isNaN(b) ? 0 : b * this.maxHandlePos;
    }, j.prototype.getValueFromPosition = function (a) {
        var b, c;
        return b = a / (this.maxHandlePos || 1), c = this.step * Math.round(b * (this.max - this.min) / this.step) + this.min, Number(c.toFixed(this.toFixed));
    }, j.prototype.setValue = function (a) {
        (a !== this.value || "" === this.$element[0].value) && this.$element.val(a).trigger("input", {
            origin: this.identifier
        });
    }, j.prototype.destroy = function () {
        this.$document.off("." + this.identifier), this.$window.off("." + this.identifier), this.$element.off("." + this.identifier).removeAttr("style").removeData("plugin_" + k), this.$range && this.$range.length && this.$range[0].parentNode.removeChild(this.$range[0]);
    }, a.fn[k] = function (b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return this.each(function () {
            var d = a(this),
                e = d.data("plugin_" + k);
            e || d.data("plugin_" + k, e = new j(this, b)), "string" == typeof b && e[b].apply(e, c);
        });
    }, "rangeslider.js is available in jQuery context e.g $(selector).rangeslider(options);";
});
new RangeInput(document.querySelector('.range'));
// Custom slider End

if (selected != undefined) {
    // console.log('inside');
    next.attr('disabled', true)
    loadPerkDetails()
}
$('#perk').change(() => {

    next.attr('disabled', true)
    loadPerkDetails()

})

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
$('#myInput1,#myInput2').focusout(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.png')
})
// Searchable dropdown end

$('input[type="range"]').change(() => {
    update()
})

$('#new-perk-btn').click(() => {
    // alert('Submit')
    const id = $('#perkid').val()
    // console.log(id);
    const userInput = $('#myDropdown1-1')
    const user = $('#myDropdown1-1').val()

    const perksInput = $('#perks')
    const perks = $('#perks').val()

    const commentInput = $('#perk-comment')
    const comment = $('#perk-comment').text()
    var user_id = ''
    category_id_list.forEach(sub => {
        // console.log('Log - ' + sub);
        if ($(`#${sub}`).val() == user) {
            user_id = sub
            // console.log(category_id);
        }
    });

    if (!user) {
        userInput.css('border', '2px solid red')
    } else if (!perks) {
        perksInput.css('border', '2px solid red')
    } else if (!comment) {
        commentInput.css('border', '2px solid red')
    } else {

        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Saving Perk...',
            showConfirmButton: false
        });

        $.ajax({
            url: `/sdp/perks/${id}`,
            method: 'put',
            dataType: 'json',
            data: {
                user: user_id,
                points: perks,
                comment: comment
            },
            success: function (response) {
                if (response.success) {

                    $('#new-perk-btn').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Perk Edited Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    setTimeout(() => {
                        loadPerksList(id)
                        // document.location.replace('/sdp/admin/perks');
                    }, 2500);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-perk-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-perk-card button').attr('disabled', true)

            }
        });

    }
})