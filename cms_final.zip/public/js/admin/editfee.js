
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-fees').trigger("click")
$('#sidebar-fees,#sidebar-fees-edit').addClass('active')
$("div#mySidebar").scrollTop(300); // Ref: https://api.jquery.com/scrolltop/

const courses_all_list = []

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['fee'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/fees')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Fee Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function disableInputs() {

    $('#studentname').val('')
    $('#totalFees').val('Total Fees in ₹')
    $('#feesPaid').val('Paid Fees here')
    $('#pendingFees').val('Pending Fees here')
    $('#payMethod').val('Payment Method here')
    $('#paymentdate').val('')
    $('#receiptNo').val('Receipt Number here')
    $('#collectedBy').val('')

    $('#studentname,#totalFees,#feesPaid,#pendingFees,#payMethod,#paymentdate,#receiptNo,#collectedBy').attr('disabled', true)
}

function checkInputs() {
    var studentname = $('#studentname').val()
    var totalFees = $('#totalFees').val()
    var feesPaid = $('#feesPaid').val()
    var pendingFees = $('#pendingFees').val()
    var payMethod = $('#payMethod').val()
    var paymentdate = $('#paymentdate').val()
    var receiptNo = $('#receiptNo').val()
    var collectedBy = $('#collectedBy').val()

    if (studentname || totalFees || feesPaid || pendingFees || payMethod || paymentdate || receiptNo || collectedBy) {
        $('#editfee button').attr('disabled', true)
        if (studentname && totalFees && feesPaid && pendingFees && payMethod && paymentdate && receiptNo && collectedBy) {
            $('#editfee button').attr('disabled', false)
        } else {
            $('#editfee button').attr('disabled', true)
        }
    }
}

$('#editfee #studentname,#editfee #totalFees,#editfee #feesPaid,#editfee #pendingFees,#editfee #payMethod,#editfee #paymentdate,#editfee #collectedBy,#editfee #receiptNo,#editfee input').change(() => {

    checkInputs();
})

function loadFeesList(studentname = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading fees list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/fees',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var fees_list;
                $('#editfee #fee').text(response.data)
                
                if (response.data.length == 0) {
                    fees_list += `<option value="">Fee List is empty</option>`;
                } else {
                    fees_list = `<option value="">Select Fee Record</option>`;
                    response.data.forEach(fee => {
                        var select;

                        if ((studentname == `${fee.student.firstName} ${fee.student.lastName}`) || (fee._id == selected)) {
                            select = 'selected'
                        } else {
                            select = ''
                        }

                        var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var payDateEnglishIST = new Date(fee.paymentDate).toLocaleDateString("en-IN", date_options)

                        fees_list += `
                        <option ${select} value="${fee._id}">${fee.student.firstName} ${fee.student.lastName} | ${payDateEnglishIST}</option>`;
                    });
                }
                $('#editfee #fee').html(fees_list)

                // Swal.fire({
                //     toast: true,
                //     position: 'top-right',
                //     icon: 'success',
                //     title: 'Fee Records Loaded Successfully',
                //     timer: 3000,
                //     showConfirmButton: false
                // });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Fees',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_fees tbody .col').html(errorMsg)
                $('#fee-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Fees',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#fee-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch fees list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_fees tbody .col').html(errorMsg)
                $('#fee-selected').html(errorMsg)
            }

        }
    });

}
loadFeesList()

// Swal.fire({
//     imageUrl: '/images/loading/sdp_logo_loading.gif',
//     title: `Fetching testing fee details`,
//     showConfirmButton: false,
//     allowOutsideClick: false
// });
// $('#fee-selected').css('display', 'block')
function getFeeDetails() {

    const selectFee = $('#fee').val() ? $('#fee').val() : selected

    $('#editfee button').attr('disabled', true)
    // console.log(selectFee);
    if (selectFee == '') {

        disableInputs()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching fee details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#studentname,#feesPaid,#payMethod,#paymentdate,#receiptNo,#collectedBy').attr('disabled', false)

        $.ajax({
            url: `/sdp/fees/${selectFee}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const feeStudent = `${response.data.student.firstName} ${response.data.student.middleName} ${response.data.student.lastName}`
                    const feeCollectedby = response.data.collectedBy.name
                    // console.log(coursesAllocated);

                    $('#feeid').val(response.data._id)
                    $('#totalFees').val(response.data.totalFees)
                    $('#feesPaid').val(response.data.feesPaid)
                    $('#pendingFees').val(response.data.pendingFees)
                    $('#payMethod').val(response.data.paymentMethod)
                    $('#paymentdate').val(response.data.paymentDate.slice(0, 10))
                    $('#receiptNo').val(response.data.receiptNo)
                    // $('#collectedBy').val(response.data.collectedBy.slice(0, 10))

                    $.ajax({
                        url: '/sdp/students/special/data',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var students_list;
                                $('#editfee #studentname').text(response.data)

                                if (response.data.length == 0) {
                                    students_list += `<option value="">Student List is empty</option>`;
                                } else {
                                    // students_list = `<option value="">Select Student Name</option>`;
                                    response.data.forEach(student => {
                                        const full_name = `${student.firstName} ${student.middleName} ${student.lastName}`

                                        if (feeStudent == full_name) {
                                            students_list += `
                                        <option selected value="${student._id}">${full_name}</option>`;
                                        } else {
                                            students_list += `
                                        <option value="${student._id}">${full_name}</option>`;
                                        }

                                    });
                                }

                                $('#editfee #studentname').html(students_list)

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Students Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Fee Record Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                disableInputs()

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Students',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            disableInputs()

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Students',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {

                                disableInputs()

                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch students list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#no-student-selected').html(errorMsg)
                            }

                        }
                    });

                    $.ajax({
                        url: '/sdp/users',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var users_list = ``;
                                $('#collectedBy').text(response.data)

                                if (response.count == 0) {
                                    users_list += `<span class="badge badge-light">User list is empty</span>`;
                                } else {

                                    response.data.forEach(user => {

                                        if (feeCollectedby == user.name) {
                                            users_list += `
                                        <option selected value="${user._id}">${user.name} | ${user.role} | ${user.branch}</option>`;
                                        } else {
                                            users_list += `
                                        <option value="${user._id}">${user.name} | ${user.role} | ${user.branch}</option>`;
                                        }

                                    });
                                    // console.log(users_list);
                                    $('#editfee #collectedBy').html(users_list)
                                    // for (let user = 0; user < users_all_list.length; user++) {
                                    //     var element = document.getElementById(users_all_list[user][0])
                                    //     element.addEventListener('click', () => {
                                    //         // alert('Update')
                                    //         checkInputs();
                                    //     })

                                    // }

                                }

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Users Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_users tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-user-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-user-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch users list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_users tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    disableInputs()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Fees',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_fees tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-fee-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                disableInputs()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Fees',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-fee-card button').attr('disabled', true)

                } else {
                    disableInputs()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch fee details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_fees tbody .col').html(errorMsg)
                    $('#no-fee-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getFeeDetails()
}
$('#fee').change(() => {

    getFeeDetails()

})

$('#studentname').change(() => {

    $('#feesPaid').attr('disabled', false)
    const studentname = $('#studentname').val()
    // alert(studentname)
    if (studentname != '') {
        $('#totalFees').val('Calculating...')

        $.ajax({
            url: `/sdp/admissions`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    var total_fees = 0
                    const data = response.data
                    data.forEach(admission => {
                        if (studentname == admission.student._id) {
                            total_fees += admission.fees
                        }
                    });

                    if (total_fees == 0) {
                        $('#totalFees').val('')
                        $('#feesPaid').attr('disabled', true)
                        Swal.fire({
                            icon: 'info',
                            title: `<div style="color:#0b6fad;">First add admission details before adding fee details</div>`,
                            confirmButtonText: 'Add Admission',
                            confirmButtonColor: '#0b6fad',
                            showCancelButton: true,
                            cancelButtonText: 'I Got it',
                            allowOutsideClick: false
                        }).then((result) => {
                            /* Read more about isConfirmed, isDenied below */
                            if (result.isConfirmed) {
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Redirecting...',
                                    timer: 1000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    document.location.replace('/sdp/admin/addadmission');
                                }, 1000);
                            }
                        })
                        checkInputs();
                    } else {

                        // $('#totalFees').val(total_fees)

                        $.ajax({
                            url: `/sdp/fees`,
                            method: 'get',
                            success: function (response) {
                                if (response.success) {

                                    var paid_fees = 0
                                    const data = response.data
                                    data.forEach(fee => {
                                        if (studentname == fee.student._id) {
                                            paid_fees += fee.feesPaid
                                        }
                                    });

                                    const pending_fees = total_fees - paid_fees

                                    if (pending_fees == 0) {
                                        $('#feesPaid').attr('disabled', true)
                                        $('#totalFees').val('')

                                        Swal.fire({
                                            icon: 'success',
                                            title: `<div class="text-success">All Fees are paid</div>`,
                                            html: `<div class="text-secondary">No Fees are pending</div>`,
                                            confirmButtonText: 'Okay',
                                            confirmButtonColor: '#0b6fad',
                                            allowOutsideClick: false
                                        })
                                        checkInputs();
                                    } else {
                                        $('#totalFees').val(pending_fees)

                                        // Success
                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'Total Fees Calculated',
                                            timer: 3000,
                                            showConfirmButton: false
                                        });

                                    }

                                } else {

                                    $('#loading').css('display', 'none');
                                    $('#table_students tbody tr').text(response.responseJSON.error);
                                    console.log(response.responseJSON.error);
                                    $('#errors').fadeIn();
                                    $('#errors').css('display', 'block');
                                    $('#add-student-card button').attr('disabled', true)

                                }
                            },
                            error: function (response) {

                                if (response.responseJSON) {
                                    $('#loading').css('display', 'none');
                                    $('#errors').text(response.responseJSON.error);
                                    console.log(response.responseJSON.error);
                                    $('#errors').fadeIn();
                                    // $('#errors').css('display', 'block');
                                    $('#add-student-card button').attr('disabled', true)

                                } else {
                                    $('#errors').fadeIn();
                                    var errorMsg = `
                                    <center class="text-danger">
                                    <h2>Oops! Something went wrong</h2>
                                    <h4>
                                        Error Code: ${response.status} <br>
                                        Error Message: ${response.statusText}
                                    </h4>
                                    <h5>We were unable to fetch students list</h5>
                                    <h6>
                                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                    </h6>
                                    </center>`
                                    console.log(`something went wrong ${JSON.stringify(response)}`);
                                    // console.log(response.statusText);
                                    // $('#table_students tbody .col').html(errorMsg)
                                    $('#errors').html(errorMsg)
                                }

                            }
                        });

                    }




                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    } else {
        $('#totalFees').val('')
        checkInputs();
    }
})

$('#feesPaid').change(() => {
    const feespaid = Number($('#feesPaid').val())
    const totalfees = Number($('#totalFees').val())
    if (feespaid > 0 && feespaid <= totalfees) {
        $('#pendingFees').val(totalfees - feespaid)
    } else {
        Swal.fire({
            icon: 'warning',
            title: `<div class="text-danger">Warning</div>`,
            html: `Enter value between 1 and ${totalfees}`,
            confirmButtonText: 'Okay, got it',
            confirmButtonColor: '#0b6fad',
            allowOutsideClick: false
        })
        $('#pendingFees').val(``)
    }
    checkInputs();
})

$('#edit-fee-btn').click(() => {
    // Extra security code
    var feeid = $('#feeid').val()
    // console.log(feeid);
    var studentnameInput = $('#studentname')
    var studentname = $('#studentname').val()

    var totalFeesInput = $('#totalFees')
    var totalFees = $('#totalFees').val()

    var feesPaidInput = $('#feesPaid')
    var feesPaid = $('#feesPaid').val()

    var pendingFeesInput = $('#pendingFees')
    var pendingFees = $('#pendingFees').val()

    var payMethodInput = $('#payMethod')
    var payMethod = $('#payMethod').val()

    var paymentdateInput = $('#paymentdate')
    var paymentdate = $('#paymentdate').val()

    var receiptNoInput = $('#receiptNo')
    var receiptNo = $('#receiptNo').val()

    var collectedByInput = $('#collectedBy')
    var collectedBy = $('#collectedBy').val()

    if (!studentname) {
        studentnameInput.css('border', '2px solid red')
    } else if (!totalFees) {
        totalFeesInput.css('border', '2px solid red')
        totalFeesInput.attr('placeholder', 'Please add total fees')
    } else if (!feesPaid) {
        feesPaidInput.css('border', '2px solid red')
        totalFeesInput.attr('placeholder', 'Please add fees paid')
    } else if (!pendingFees) {
        pendingFeesInput.css('border', '2px solid red')
        pendingFeesInput.attr('placeholder', 'Please add pending fees')
    } else if (!payMethod) {
        payMethodInput.css('border', '2px solid red')
        payMethodInput.attr('placeholder', 'Please add payment method')
    } else if (!paymentdate) {
        paymentdateInput.css('border', '2px solid red')
    } else if (!receiptNo) {
        receiptNoInput.css('border', '2px solid red')
        paymentdateInput.attr('placeholder', 'Please add receipt number')
    } else if (!collectedBy) {
        collectedByInput.css('border', '2px solid red')
    } else {

        if (feesPaid > totalFees) {
            Swal.fire({
                icon: 'warning',
                title: `<div class="text-danger">Warning</div>`,
                html: `Enter value between 1 and ${totalFees}`,
                confirmButtonText: 'Okay, got it',
                confirmButtonColor: '#0b6fad',
                allowOutsideClick: false
            })
            $('#editfee button').attr('disabled', true)
        } else {

            $('#editfee button').attr('disabled', true)
            document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

            loading()

            // Update fee
            $.ajax({
                url: `/sdp/fees/${feeid}`,
                method: 'put',
                dataType: 'json',
                data: {
                    student: studentname,
                    totalFees: totalFees,
                    feesPaid: feesPaid,
                    pendingFees: pendingFees,
                    paymentMethod: payMethod,
                    paymentDate: paymentdate,
                    receiptNo: receiptNo,
                    collectedBy: collectedBy
                },
                success: function (response) {
                    if (response.success) {

                        $('#error,#loading').css('display', 'none')
                        $('#edit-fee-card button').attr('disabled', true)

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Fee Record Updated Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });
                        setTimeout(() => {
                            loadFeesList(studentname)
                        }, 3000);

                    } else {

                        $('#loading').css('display', 'none');
                        $('#error').text(response.responseJSON.error);
                        $('#error').fadeIn();
                        $('#error').css('display', 'block');
                        $('#add-fee-card button').attr('disabled', true)

                    }
                },
                error: function (response) {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-fee-card button').attr('disabled', true)

                }
            });
        }
    }
})

// $('#feesPaid').change(() => {
//     const feesPaid = $('#feesPaid').val()
//     // alert(feesPaid)
//     if (feesPaid != '') {
//         $('#pendingFees').val('Calculating...')

//         $.ajax({
//             url: `/sdp/fees/${feesPaid}`,
//             method: 'get',
//             success: function (response) {
//                 if (response.success) {

//                     $('#pendingFees').val(response.data.fees)

//                     // Success
//                     Swal.fire({
//                         toast: true,
//                         position: 'top-right',
//                         icon: 'success',
//                         title: 'Course Fees Calculated',
//                         timer: 3000,
//                         showConfirmButton: false
//                     });



//                 } else {

//                     $('#loading').css('display', 'none');
//                     $('#table_students tbody tr').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#errors').fadeIn();
//                     $('#errors').css('display', 'block');
//                     $('#add-student-card button').attr('disabled', true)

//                 }
//             },
//             error: function (response) {

//                 if (response.responseJSON) {
//                     $('#loading').css('display', 'none');
//                     $('#errors').text(response.responseJSON.error);
//                     console.log(response.responseJSON.error);
//                     $('#errors').fadeIn();
//                     // $('#errors').css('display', 'block');
//                     $('#add-student-card button').attr('disabled', true)

//                 } else {
//                     $('#errors').fadeIn();
//                     var errorMsg = `
//                     <center class="text-danger">
//                     <h2>Oops! Something went wrong</h2>
//                     <h4>
//                         Error Code: ${response.status} <br>
//                         Error Message: ${response.statusText}
//                     </h4>
//                     <h5>We were unable to fetch students list</h5>
//                     <h6>
//                         Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                     </h6>
//                     </center>`
//                     console.log(`something went wrong ${JSON.stringify(response)}`);
//                     // console.log(response.statusText);
//                     // $('#table_students tbody .col').html(errorMsg)
//                     $('#errors').html(errorMsg)
//                 }

//             }
//         });

//     } else {
//         $('#pendingFees').val('Course Fees here')
//     }
// })
