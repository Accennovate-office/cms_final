// Graph code

// Ref: https://codepen.io/SitePoint/pen/WGeGNE
// var ctx = document.getElementById('myChart').getContext('2d');
// var myChart = new Chart(ctx, {
//     type: 'line',
//     data: {
//         labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
//         datasets: [{
//             label: 'apples',
//             data: [12, 19, 3, 17, 6, 3, 7],
//             backgroundColor: "rgba(153,255,51,0.6)"
//         }, {
//             label: 'oranges',
//             data: [2, 29, 5, 5, 2, 3, 10],
//             backgroundColor: "rgba(255,153,0,0.6)"
//         }]
//     }
// });

// THIS IS WHERE THE ERROR OCCURS
new Chartist.Line('.ct-chart', {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    series: [
        [2, 3, 2, 4, 5],
        [0, 2.5, 3, 2, 3],
        [1, 2, 2.5, 3.5, 4]
    ]
}, {
    width: 500,
    height: 300
});

const labels = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
];

const data = {
    labels: labels,
    datasets: [{
        label: 'My First dataset',
        backgroundColor: 'rgb(255, 99, 132)',
        borderColor: 'rgb(255, 99, 132)',
        data: [0, 10, 5, 2, 20, 30, 45],
    }]
};

const config = {
    type: 'line',
    data: data,
    options: {}
};

const myChart = new Chart(
    document.getElementById('attendanceChart'),
    config
);
// Graph code end