
$('#sidebar-students').trigger("click")
$('#sidebar-students,#sidebar-students-delete').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['student'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/admin/students')
})

function loadstudentsList() {

    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $.ajax({
        url: '/sdp/students/special/data',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var students_list;
                $('#deletestudent #student').text(response.data)

                if (response.data.length == 0) {
                    students_list += `<option value="">Student List is empty</option>`;
                } else {
                    students_list = `<option value="">Select student Name</option>`;
                    response.data.forEach(student => {

                        if (student._id == selected) {

                            students_list += `
                            <option selected value="${student._id}">${student.firstName} ${student.lastName}</option>`;

                        } else {

                            students_list += `
                            <option value="${student._id}">${student.firstName} ${student.lastName}</option>`;

                        }
                    });
                }

                $('#deletestudent #student').html(students_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Students Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_students tbody .col').html(errorMsg)
                $('#no-student-selected').html(errorMsg)
            }

        }
    });

}
loadstudentsList()

const studentname = $('#delete-studentname')
const studentdob = $('#delete-studentdob')
const studentgender = $('#delete-studentgender')
const studentaadhar = $('#delete-studentaadhar')
const studentreligion = $('#delete-studentreligion')
const studentcaste = $('#delete-studentcaste')

const fatheroccupation = $('#delete-fatheroccupation')
const mothername = $('#delete-mothername')
const mothertongue = $('#delete-mothertongue')

const studentphone1 = $('#delete-studentphone1')
const studentphone2 = $('#delete-studentphone2')
const parentphone = $('#delete-parentphone')
const studentemail = $('#delete-studentemail')
const studentaddress = $('#delete-studentaddress')

const studentedu = $('#delete-studentedu')
const schoolOrCollegeName = $('#delete-schoolOrCollegeName')
const classOrTuitionName = $('#delete-classOrTuitionName')

const studentbranch = $('#delete-studentbranch')
const studentcategory = $('#delete-studentcategory')
const socialmedia = $('#delete-socialmedia')
const reference = $('#delete-reference')

const createdat = $('#delete-studentcreatedat')
const updatedat = $('#delete-studentupdatedat')
const studentid = $('#delete-studentid')
const referenceid = $('#delete-referenceid')

function getStudentDetails() {

    const selectstudent = $('#student').val() ? $('#student').val() : selected
    // console.log(selectstudent);
    if (selectstudent == '') {
        $('#no-student-selected').css('display', 'block')
        $('#student-selected').css('display', 'none')
    } else {

        $('#no-student-selected').css('display', 'none')
        $('#student-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/students/${selectstudent}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deletestudent #student-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", date_options)
                    var joindateEnglishIST = new Date(response.data.joiningDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var edu_details = ''
                    const edu_string = response.data.qualification.split(',')
                    // console.log(response.data.qualification);
                    edu_string.forEach(edu => {
                        edu_details += `<span class="badge badge-light">${edu}</span>`
                    });

                    // Social media details
                    var social_details = ''

                    const facebook = response.data.facebook
                    facebook ? social_details += `<div class="col col-6 mb-2"><img id="facebook-icon" src="/images/students/facebook-yes.png" width="25" alt=""> &nbsp;${facebook}</div>` : ''

                    const instagram = response.data.instagram
                    instagram ? social_details += `<div class="col col-6 mb-2"><img id="instagram-icon" src="/images/students/instagram-yes.png" width="25" alt="">&nbsp; ${instagram}</div>` : ''

                    const youtube = response.data.youtube
                    youtube ? social_details += `<div class="col col-6 mb-2"><img id="youtube-icon" src="/images/students/youtube-yes.png" width="25" alt=""> &nbsp;${youtube}</div>` : ''

                    const twitter = response.data.twitter
                    twitter ? social_details += `<div class="col col-6 mb-2"><img id="twitter-icon" src="/images/students/twitter-yes.png" width="25" alt=""> &nbsp;${twitter}</div>` : ''

                    const linkedin = response.data.linkedin
                    linkedin ? social_details += `<div class="col col-6 mb-2"><img id="linkedin-icon" src="/images/students/linkedin-yes.png" width="25" alt=""> &nbsp;${linkedin}</div>` : ''

                    if (!facebook && !instagram && !youtube && !twitter && !linkedin) {
                        social_details = 'No social media links added'
                    }

                    // Reference Details
                    var reference_details = ''
                    if (response.data.reference) {
                        if (response.data.reference.ref1Name || response.data.reference.ref1Phone || response.data.reference.ref1Category || response.data.reference.ref1Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref1Name ? response.data.reference.ref1Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref1Phone ? response.data.reference.ref1Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref1Category ? response.data.reference.ref1Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref1Area ? response.data.reference.ref1Area : ''}
                            </div>`
                        }
                        if (response.data.reference.ref2Name || response.data.reference.ref2Phone || response.data.reference.ref2Category || response.data.reference.ref2Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref2Name ? response.data.reference.ref2Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref2Phone ? response.data.reference.ref2Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref2Category ? response.data.reference.ref2Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref2Area ? response.data.reference.ref2Area : ''}
                            </div>`
                        }
                        if (response.data.reference.ref3Name || response.data.reference.ref3Phone || response.data.reference.ref3Category || response.data.reference.ref3Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref3Name ? response.data.reference.ref3Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref3Phone ? response.data.reference.ref3Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref3Category ? response.data.reference.ref3Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref3Area ? response.data.reference.ref3Area : ''}
                            </div>`
                        }
                    } else {
                        reference_details = 'No reference detials added'
                    }

                    // Aadhaar number validation if available or not
                    var aadhaarNumber
                    if (response.data.aadhaarNo) {

                        var aNo = response.data.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    } else {
                        aadhaarNumber = 'No Aadhaar card added'
                    }

                    studentname.text(`${response.data.firstName} ${response.data.middleName} ${response.data.lastName}`)
                    studentdob.text(dobEnglishIST)
                    studentgender.text(response.data.gender)
                    studentaadhar.text(aadhaarNumber)
                    studentreligion.text(response.data.religion)
                    studentcaste.text(response.data.caste)

                    fatheroccupation.text(response.data.fatherOccupation)
                    mothername.text(response.data.motherName)
                    mothertongue.text(response.data.motherTongue)

                    studentphone1.text(response.data.phone1)
                    studentphone2.text(response.data.phone2)
                    parentphone.text(response.data.parentPhone)
                    studentemail.text(response.data.email)
                    studentaddress.text(response.data.address)

                    studentedu.html(edu_details)
                    schoolOrCollegeName.html(response.data.schoolOrCollegeName)
                    classOrTuitionName.html(response.data.classOrTuitionName)

                    studentbranch.text(response.data.branch)
                    studentcategory.text(response.data.category)
                    socialmedia.html(social_details)
                    reference.html(reference_details)

                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue) 
                    studentid.val(response.data._id)
                    referenceid.val(response.data.reference._id ? response.data.reference._id : '')
                    // console.log(response.data.reference._id);

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'student Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)
                    $('#student-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)
                    $('#student-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#no-student-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-student-selected').css('display', 'block')
$('#student-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getStudentDetails()
}
$('#student').change(() => {

    getStudentDetails()

})

$('#delete-student-btn').click(() => {
    var delstudentid = $('#delete-studentid').val()
    var delreferenceid = $('#delete-referenceid').val()
    // console.log(delreferenceid);
    var name = studentname.text()
    var email = studentemail.text()
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${name}</span> student details!</h4>
            <h5>References will also be deleted along with students data</h5>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            if (delreferenceid != '') {

                // Delete reference data
                $.ajax({
                    url: `/sdp/references/${delreferenceid}`, // Also delete reference with students
                    method: 'delete',
                    success: function (response) {
                        if (response.success) {

                            $.ajax({
                                url: `/sdp/students/${delstudentid}`, // Delete students data
                                method: 'delete',
                                success: function (response) {
                                    if (response.success) {

                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'student Deleted Successfully',
                                            timer: 3000,
                                            showConfirmButton: false
                                        });

                                        $('#no-student-selected').css('display', 'block')
                                        $('#student-selected').css('display', 'none')
                                        loadstudentsList()

                                    } else {

                                        Swal.fire({
                                            icon: 'danger',
                                            title: 'Something went wrong',
                                            text: response.responseJSON.error
                                        });
                                        console.log(response);

                                    }
                                },
                                error: function (response) {

                                    Swal.fire({
                                        icon: 'danger',
                                        title: 'Server error',
                                        text: response.responseJSON.error
                                    });
                                    console.log(response);

                                }
                            });

                            // Swal.fire({
                            //     toast: true,
                            //     position: 'top-right',
                            //     icon: 'success',
                            //     title: 'student Deleted Successfully',
                            //     timer: 3000,
                            //     showConfirmButton: false
                            // });

                        } else {

                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });
                            console.log(response);

                        }
                    },
                    error: function (response) {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Server error',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                });

            } else {

                // Delete only student data
                $.ajax({
                    url: `/sdp/students/${delstudentid}`, // Delete students info
                    method: 'delete',
                    success: function (response) {
                        if (response.success) {

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'student Deleted Successfully',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            $('#no-student-selected').css('display', 'block')
                            $('#student-selected').css('display', 'none')
                            loadstudentsList()

                        } else {

                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });
                            console.log(response);

                        }
                    },
                    error: function (response) {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Server error',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                });

            }


        }
    })
})
