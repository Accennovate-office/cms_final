$('.btn-success').prop('disabled', true);
$('#error').css('display', 'none');
$('#success').css('display', 'none');
$('#loading').css('display', 'none');

$('#emoji').fadeIn();
$('#emoji').attr('src', '/images/emoji-think.gif');

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;
    $('#error,#success').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

$('#email').on('input', function () {
    const email = $('#email').val();
    if (email) {
        $('.btn-success').prop('disabled', false);
    } else {
        $('.btn-success').prop('disabled', true);
    }
});

$('#loginMe').click(() => {

    $('#error').fadeOut();
    loading();
    const email = $('#email').val();
    $.ajax({
        url: '/sdp/auth/forgotpassword',
        method: 'post',
        dataType: 'json',
        data: {
            email: email
        },
        success: function (response) {
            if (response.success) {

                const message = response.data
                // console.log(response.resetLink);
                const resetLink = response.resetLink
                const apiKey = response.apiKey
                // const apiKey = '';
                const subject = 'Important: Password Reset Request Received';
                const from = 'support@smartbytecomputer.com';
                const to = response.to; // Comma-separated list of recipients

                const apiUrl = 'https://api.elasticemail.com/v2/email/send';

                const bodyHtml = `
                <div class="container" style="font-family: Arial, sans-serif;max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 20px;">
                    <div class="header" style="text-align: center;">
                        <img src="http://testing-cms-env.eba-m3ab5e5p.ap-south-1.elasticbeanstalk.com/images/smartbyte_logo.png" alt="SmartByte Logo" style="max-width: 150px; height: auto;">
                        <h1>Password Reset Confirmation</h1>
                        <p>Thank you for using our service. If you requested to reset your password, please click the button below.</p>
                    </div>
                    <img src="https://plus.unsplash.com/premium_photo-1681487746049-c39357159f69?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cGFzc3dvcmRzfGVufDB8fDB8fHww" alt="Reset Password" style="width: 100%;">
                    <div class="content" style="margin-top: 20px; text-align: center;">
                        <a href="${resetLink}" class="button" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #ffffff; text-decoration: none; border-radius: 5px;">Reset Password</a>
                        <p>If the button above doesn't work, you can <a href="${resetLink}" style="color: #4CAF50; text-decoration: none;">click here to reset your password</a>. Please note that this link is valid for 10 minutes.</p>
                        <p>If you didn't request a password reset, you can ignore this email.</p>
                    </div>
                    <div style="margin-top: 20px; text-align: center;">
                        <br>
                        <p>Sincerely,</p>
                        <p>SmartByte Computer Education Team</p>
                    </div>
                    <div class="header" style="text-align: center;">
                        <img src="http://testing-cms-env.eba-m3ab5e5p.ap-south-1.elasticbeanstalk.com/images/smartbyte_logo.png" alt="SmartByte Logo" style="width: 70%; margin: 0 auto;">
                    </div>
                    <footer class="footer" style="text-align: center; color: gray; margin-top: 20px;">
                        <i>Copyright (C) 2023 SmartByte Computer Education. All rights reserved.</i>
                    </footer>
                </div>`

                $.ajax({
                    url: apiUrl,
                    type: 'POST',
                    data: {
                        apikey: apiKey,
                        subject: subject,
                        from: from,
                        to: to, // Comma-separated list of recipients
                        bodyHtml: bodyHtml, // Optional
                        // bodyText: bodyText, // Optional
                        isTransactional: true, // Set to true for transactional email, false for marketing
                    },
                    dataType: 'json',
                    success: function (response) {
                        console.log('Email sent successfully:');
                        // console.log(response);
                        // form.reset(); // Reset the form
                        // document.location.replace('/u23eyey-u9lRtKw-eKpA3G-e283ye-gyt45yt-vzN7jP2-QtVtRb-g8u#thankyou');
                        // Handle the success response here
                        let x = $('#success').text(message);
                        $('#success').fadeIn();
                        $('#success').css('font-weight', 'bold');
                        $('#success').css('display', 'block');

                        $('#emoji').fadeIn();
                        $('#emoji').attr('src', '/images/emoji-happy.gif');

                        $('#error,#loading').css('display', 'none');
                        $('#email').val(null);
                        $('.btn-success').prop('disabled', true);
                    },
                    error: function (response) {
                        console.log('Error sending email:', response);
                        // form.reset(); // Reset the form
                        // document.location.replace('/u23eyey-u9lRtKw-eKpA3G-e283ye-gyt45yt-vzN7jP2-QtVtRb-g8u#thankyou');
                        // Handle the error response here

                        $('#emoji').fadeIn();
                        $('#emoji').attr('src', '/images/emoji-sad.gif');

                        $('#loading,#success').css('display', 'none');
                        $('#error').text(response);
                        $('#error').fadeIn();
                        $('#error').css('display', 'block');
                        $('.btn-success').prop('disabled', true);
                        console.log(response);
                    }
                });

                

            } else {

                $('#emoji').fadeIn();
                $('#emoji').attr('src', '/images/emoji-sad.gif');

                $('#loading,#success').css('display', 'none');
                $('#error').text(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('.btn-success').prop('disabled', true);
                console.log(response);

            }
        },
        error: function (response) {

            $('#emoji').fadeIn();
            $('#emoji').attr('src', '/images/emoji-sad.gif');
            let errorMessage = response.responseText.split('Error:')[1].split('<br>')[0];
            $('#loading,#success').css('display', 'none');
            $('#error').text(`Error: ${errorMessage}`);
            $('#error').fadeIn();
            $('#error').css('display', 'block');
            $('.btn-success').prop('disabled', true);
            console.log(response);

        }
    });
});