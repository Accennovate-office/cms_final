$('.btn-success').prop('disabled', true);
$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#emoji').css('display', 'none');

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

setTimeout(() => {
    $('#emoji').fadeIn();
}, 5000);


$('#email,#password').on('input', function () {
    const email = $('#email').val();
    const password = $('#password').val();
    if (password) {
        $('#emoji').fadeIn();
        $('#emoji').attr('src', '/images/emoji-quite.gif');
    }
    if (email && password) {
        $('.btn-success').prop('disabled', false);
    } else {
        $('.btn-success').prop('disabled', true);
    }
});

$('#loginMe').click(() => {

    $('#error').fadeOut();
    loading();
    const email = $('#email').val();
    const password = $('#password').val();
    $.ajax({
        url: '/sdp/auth/login',
        method: 'post',
        dataType: 'json',
        data: {
            email: email,
            password: password
        },
        success: function (response) {
            if (response.success) {

                $('#emoji').fadeIn();
                $('#emoji').attr('src', '/images/emoji-happy.gif');

                Swal.fire({
                    toast: true,
                    position: 'bottom-right',
                    icon: 'success',
                    title: 'Logged In Successfully',
                    timer: 2000,
                    showConfirmButton: false
                });
                $('#email').val(null);
                $('#password').val(null);
                $('.btn-success').prop('disabled', true);

                // Get user to find role
                $.ajax({
                    url: '/sdp/auth/me',
                    method: 'get',
                    success: function (response) {
                        if (response.success) {

                            $('#error,#loading').css('display', 'none');
                            $('#email').val(null);
                            $('#password').val(null);
                            $('.btn-success').prop('disabled', true);

                            if(response.data.role === 'teacher'){

                                setTimeout(() => {
                                    // window.location.href = '/sdp/teacher/dashboard'; // Avoid this
                                    document.location.replace('/sdp/teacher/dashboard'); // Use this(see reference point-30)
                                }, 1500);
                            } else if (response.data.role === 'admin') {
                                document.location.replace('/sdp/admin/dashboard');
                            } else if (response.data.role === 'manager') {
                                document.location.replace('/sdp/manager/dashboard');
                            } else if (response.data.role === 'teacher') {
                                document.location.replace('/sdp/teacher/dashboard');
                            }

                        } else {

                            $('#loading').css('display', 'none');
                            $('#error').text(response);
                            // $('#error').text(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('.btn-success').prop('disabled', true);

                        }
                    },
                    error: function (response) {

                        $('#loading').css('display', 'none');
                        $('#error').text(response.responseJSON.error);
                        $('#error').fadeIn();
                        $('#error').css('display', 'block');
                        $('.btn-success').prop('disabled', true);

                    }
                });

            } else {

                $('#emoji').fadeIn();
                $('#emoji').attr('src', '/images/emoji-think.gif');

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#password').val(null);
                $('.btn-success').prop('disabled', true);

            }
        },
        error: function (response) {

            $('#emoji').fadeIn();
            $('#emoji').attr('src', '/images/emoji-think.gif');

            $('#loading').css('display', 'none');
            // console.log(response);
            // console.log(response.status);
            // console.log(response.statusText);
            if (response.status == 401 && response.statusText == 'Unauthorized') {
                $('#error').text('Email or Password is incorrect');
            } else {
                $('#error').text(response.statusText);
            }
            $('#error').fadeIn();
            $('#error').css('display', 'block');
            $('#password').val(null);
            $('.btn-success').prop('disabled', true);

        }
    });
});