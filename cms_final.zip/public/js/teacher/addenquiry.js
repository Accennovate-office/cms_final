import { loadCoursesList, loadUsersList } from "../services/loadList.js";

$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

// Random enquiry image
// const enq_img = ['/images/enquiries/enquiry_girl.png','/images/enquiries/enquiry_boy.png']
// const randomImg = enq_img[Math.floor(Math.random() * enq_img.length)];
// $('#enquiry_img').attr('src',randomImg)

$('#sidebar-enquiries').trigger("click")
$('#sidebar-enquiries,#sidebar-enquiries-add').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

// Reference forms toggle
$('#ref1,#ref2,#ref3').fadeOut()
$('#btn-ref1').click(() => {
    $('#ref1').fadeIn(250)
    document.getElementById('btn-ref1').classList.remove('no-ref')
    $('#ref2,#ref3').fadeOut(100)
    document.getElementById('btn-ref2').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref2').click(() => {
    $('#ref2').fadeIn(250)
    document.getElementById('btn-ref2').classList.remove('no-ref')
    $('#ref1,#ref3').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref3').click(() => {
    $('#ref3').fadeIn(250)
    document.getElementById('btn-ref3').classList.remove('no-ref')
    $('#ref1,#ref2').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref2').classList.add('no-ref')

})

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

// Aadhaar validation start - https://stackoverflow.com/a/47428241
$('[data-type="adhaar-number"]').keyup(function () {
    var value = $(this).val();
    value = value.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
    $(this).val(value);
});

// Social media icon color
$('#enquirysocialmedia-facebook').keyup(() => {
    const facebook = $('#enquirysocialmedia-facebook').val()
    if (facebook != '') {
        $('#facebook-icon').attr('src', '/images/enquiries/facebook-yes.png')
    } else {
        $('#facebook-icon').attr('src', '/images/enquiries/facebook-no.png')
    }
})
$('#enquirysocialmedia-instagram').keyup(() => {
    const instagram = $('#enquirysocialmedia-instagram').val()
    if (instagram != '') {
        $('#instagram-icon').attr('src', '/images/enquiries/instagram-yes.png')
    } else {
        $('#instagram-icon').attr('src', '/images/enquiries/instagram-no.png')
    }
})
$('#enquirysocialmedia-youtube').keyup(() => {
    const youtube = $('#enquirysocialmedia-youtube').val()
    if (youtube != '') {
        $('#youtube-icon').attr('src', '/images/enquiries/youtube-yes.png')
    } else {
        $('#youtube-icon').attr('src', '/images/enquiries/youtube-no.png')
    }
})
$('#enquirysocialmedia-twitter').keyup(() => {
    const twitter = $('#enquirysocialmedia-twitter').val()
    if (twitter != '') {
        $('#twitter-icon').attr('src', '/images/enquiries/twitter-yes.png')
    } else {
        $('#twitter-icon').attr('src', '/images/enquiries/twitter-no.png')
    }
})
$('#enquirysocialmedia-linkedin').keyup(() => {
    const linkedin = $('#enquirysocialmedia-linkedin').val()
    if (linkedin != '') {
        $('#linkedin-icon').attr('src', '/images/enquiries/linkedin-yes.png')
    } else {
        $('#linkedin-icon').attr('src', '/images/enquiries/linkedin-no.png')
    }
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Enquiry...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;
const courses_all_list = [];

function createEnquiry() {
    // Form 1
    const firstname = $('#firstname').val()
    const middlename = $('#middlename').val()
    const lastname = $('#lastname').val()
    const enquirydob = $('#enquirydob').val()
    const enquirygender = $('#enquirygender').val()
    const enquiryaadhaar = $('#enquiryaadhaar').val()
    const enquiryreligion = $('#enquiryreligion').val()
    const enquirycaste = $('#enquirycaste').val()

    // Form 2
    const fatheroccupation = $('#fatheroccupation').val()
    const mothername = $('#mothername').val()
    const mothertongue = $('#mothertongue').val()

    // Form 3
    const phone1 = $('#phone1').val()
    const phone2 = $('#phone2').val()
    const parentphone = $('#parentphone').val()
    const enquiryemail = $('#enquiryemail').val()
    const enquiryaddress = $('#enquiryaddress').val()

    // Form 4
    const enquiryqualifications = $('#enquiryqualifications').val()
    const enquirycollegename = $('#enquirycollegename').val()
    const enquirytuitionname = $('#enquirytuitionname').val()

    // Form 5
    var enquirycategory = $('#enquirycategory').val()
    if (enquirycategory == '') {
        enquirycategory = undefined
    }
    const enquirybranch = $('#enquirybranch').val()

    // Social Media
    const facebook = $('#enquirysocialmedia-facebook').val() || null
    const instagram = $('#enquirysocialmedia-instagram').val() || null
    const youtube = $('#enquirysocialmedia-youtube').val() || null
    const twitter = $('#enquirysocialmedia-twitter').val() || null
    const linkedin = $('#enquirysocialmedia-linkedin').val() || null

    // Reference 1
    const ref1_name = $('#ref1_name').val()
    const ref1_phone = $('#ref1_phone').val()
    const ref1_category = $('#ref1_category').val()
    const ref1_area = $('#ref1_area').val()
    // Reference 2
    const ref2_name = $('#ref2_name').val()
    const ref2_phone = $('#ref2_phone').val()
    const ref2_category = $('#ref2_category').val()
    const ref2_area = $('#ref2_area').val()
    // Reference 3
    const ref3_name = $('#ref3_name').val()
    const ref3_phone = $('#ref3_phone').val()
    const ref3_category = $('#ref3_category').val()
    const ref3_area = $('#ref3_area').val()

    var enquiryaadhaar_final = enquiryaadhaar.split('-').join('')
    // console.log(enquiryaadhaar_final);

    // New fields
    const area = $('#area').val()
    var username = $('#username').val()
    const takenbyother = $('#takenbyother').val()
    const courses = selectedCoursesIDs
    var courseUI = ''
    courseUI = selectedCoursesIDs[0]
    var enquiryby = ''
        if (username != '') {
            enquiryby = $(`#username option[value='${username}']`).text();
            if (username == 'other') {
                username = undefined
                enquiryby = takenbyother
            }
        }

    if (!firstname || !enquirygender || !phone1 || !enquirybranch || !courseUI || !area || !enquiryby) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in enquiry form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Create Enquiry Record
        loading()

        $.ajax({
            url: '/sdp/enquiries',
            method: 'post',
            dataType: 'json',
            data: {
                firstName: firstname,
                middleName: middlename,
                lastName: lastname,
                dob: enquirydob,
                gender: enquirygender,
                aadhaarNo: enquiryaadhaar_final,
                religion: enquiryreligion,
                caste: enquirycaste,
                fatherOccupation: fatheroccupation,
                motherName: mothername,
                motherTongue: mothertongue,
                phone1: phone1,
                phone2: phone2,
                parentPhone: parentphone,
                email: enquiryemail,
                address: enquiryaddress,
                area: area,
                qualification: enquiryqualifications,
                schoolOrCollegeName: enquirycollegename,
                classOrTuitionName: enquirytuitionname,
                category: enquirycategory,
                branch: enquirybranch,
                courses: courses.toString(),
                facebook: facebook,
                instagram: instagram,
                youtube: youtube,
                twitter: twitter,
                linkedin: linkedin,
                takenby: username,
                takenbyother: takenbyother
            },
            success: function (response) {
                if (response.success) {

                    const new_enquiry_id = response.data._id
                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    // if (ref1_name || ref1_phone || ref1_category || ref1_area || ref2_name || ref2_phone || ref2_category || ref2_area || ref3_name || ref3_phone || ref3_category || ref3_area) {

                    // Reference available
                    $.ajax({
                        url: '/sdp/enqreferences',
                        method: 'post',
                        dataType: 'json',
                        data: {
                            ref1Name: ref1_name,
                            ref1Phone: ref1_phone,
                            ref1Category: ref1_category,
                            ref1Area: ref1_area,

                            ref2Name: ref2_name,
                            ref2Phone: ref2_phone,
                            ref2Category: ref2_category,
                            ref2Area: ref2_area,

                            ref3Name: ref3_name,
                            ref3Phone: ref3_phone,
                            ref3Category: ref3_category,
                            ref3Area: ref3_area,

                            branch: enquirybranch,
                            enquiry: new_enquiry_id
                        },
                        success: function (response) {
                            if (response.success) {

                                const new_reference_id = response.data._id

                                // Update enquiry
                                $.ajax({
                                    url: `/sdp/enquiries/${new_enquiry_id}`,
                                    method: 'put',
                                    dataType: 'json',
                                    data: {
                                        reference: new_reference_id
                                    },
                                    success: function (response) {
                                        if (response.success) {

                                            // Send Enquiry message
                                            $.ajax({
                                                url: '/sdp/whatsapp/enquiry',
                                                method: 'post',
                                                dataType: 'json',
                                                data: {
                                                    phone: phone1
                                                },
                                                success: function (response) {
                                                    if (response.success) {

                                                        // Implement a mail template function to send mail if told by admin

                                                        $('#error,#loading').css('display', 'none')
                                                        // nameInput.val(null)
                                                        // addressInput.val(null)
                                                        $('#add-branch-card button').attr('disabled', true)

                                                        // Enquiry data added
                                                        Swal.fire({
                                                            icon: 'success',
                                                            title: `<div class="text-success">Enquiry Details Added</div>`,
                                                            html: `<h5>We have sent a thank you enquiry message on the student's <img src="/images/managers/whatsapp.png" height="25" alt=""> WhatsApp number`,
                                                            confirmButtonText: `<div class="text-dark">Enquiries List</div>`,
                                                            confirmButtonColor: '#fff',
                                                            allowOutsideClick: false,
                                                            showDenyButton: true,
                                                            denyButtonText: 'New admission',
                                                            denyButtonColor: '#0b6fad',
                                                            focusConfirm: false
                                                        }).then((result) => {
                                                            /* Read more about isConfirmed, isDenied below */
                                                            if (result.isConfirmed) {
                                                                Swal.fire({
                                                                    toast: true,
                                                                    position: 'top-right',
                                                                    icon: 'success',
                                                                    title: 'Redirecting...',
                                                                    timer: 1000,
                                                                    showConfirmButton: false
                                                                });
                                                                setTimeout(() => {
                                                                    document.location.replace('/sdp/teacher/enquiries');
                                                                }, 1000);
                                                            } else if (result.isDenied) {
                                                                Swal.fire({
                                                                    toast: true,
                                                                    position: 'top-right',
                                                                    icon: 'success',
                                                                    title: 'Redirecting...',
                                                                    timer: 1000,
                                                                    showConfirmButton: false
                                                                });
                                                                setTimeout(() => {
                                                                    document.location.replace('/sdp/teacher/addadmission');
                                                                }, 1000);
                                                            }
                                                        })

                                                    } else {

                                                        $('#loading').css('display', 'none');
                                                        $('#error').text(response.responseJSON.error);
                                                        $('#error').fadeIn();
                                                        $('#error').css('display', 'block');
                                                        $('#add-branch-card button').attr('disabled', true)

                                                    }
                                                },
                                                error: function (response) {

                                                    $('#loading').css('display', 'none');
                                                    // $('#error').text(response.responseJSON.error);
                                                    $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                                                    $('#error').fadeIn();
                                                    $('#error').css('display', 'block');
                                                    $('#add-branch-card button').attr('disabled', true)

                                                }
                                            });

                                        } else {

                                            $('#loading').css('display', 'none');
                                            $('#error').text(response.responseJSON.error);
                                            $('#error').fadeIn();
                                            $('#error').css('display', 'block');
                                            $('#add-enquiry-card button').attr('disabled', true)

                                        }
                                    },
                                    error: function (response) {

                                        $('#loading').css('display', 'none');
                                        $('#error').text(response.responseJSON.error);
                                        $('#error').fadeIn();
                                        $('#error').css('display', 'block');
                                        $('#add-enquiry-card button').attr('disabled', true)

                                    }
                                });

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_branches tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                    <center class="text-danger">
                                    <h2>Oops! Something went wrong</h2>
                                    <h4>
                                        Error Code: ${response.status} <br>
                                        Error Message: ${response.statusText}
                                    </h4>
                                    <h5>We were unable to fetch branches list</h5>
                                    <h6>
                                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                    </h6>
                                    </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_branches tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });
                    // } else {
                    //     Swal.fire({
                    //         icon: 'success',
                    //         title: `<div class="text-success">enquiry Added</div>`,
                    //         confirmButtonText: 'Okay',
                    //         confirmButtonColor: '#0b6fad',
                    //         allowOutsideClick: false,
                    //         // width: '45rem'
                    //     }).then((result) => {
                    //         /* Read more about isConfirmed, isDenied below */
                    //         if (result.isConfirmed) {
                    //             Swal.fire({
                    //                 toast: true,
                    //                 position: 'top-right',
                    //                 icon: 'success',
                    //                 title: 'Redirecting...',
                    //                 timer: 1000,
                    //                 showConfirmButton: false
                    //             });
                    //             setTimeout(() => {
                    //                 document.location.replace('/sdp/teacher/enquiries');
                    //             }, 1000);
                    //         }
                    //     })
                    // }

                } else {

                    $('#loading').css('display', 'none');
                    console.log(response);
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                // $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New enquiry trigger
        createEnquiry()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    if (currentActive === 1 && $('#prev').text() === 'Submit quick enquiry') {
        // New enquiry trigger
        createEnquiry()
    }
    update();
})

// console.log(circles);
function update() {
    $('#prev').addClass('w-25')
    $('#prev').css('color','#fff')
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addenquiry-form1,#addenquiry-form2,#addenquiry-form3,#addenquiry-form4,#addenquiry-form5,#addenquiry-form6,#addenquiry-form7').removeClass('active')
    $(`#addenquiry-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#prev').text('Prev')
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 1) {
        $('#prev').css('color','#8d959e')
        $('#prev').text('Submit quick enquiry')
        $('#prev').removeClass('w-25')
        $('#next').text('Add more details')
        checkInquiryForm()
    } else if (actives.length === 6) {
        $('#next').text('Review')
    } else if (actives.length === 7) {

        $('#next').text('Submit')
        // Form 1
        const firstname = $('#firstname').val()
        const middlename = $('#middlename').val()
        const lastname = $('#lastname').val()
        const enquirydob = $('#enquirydob').val()
        const enquirygender = $('#enquirygender').val()
        const enquiryaadhaar = $('#enquiryaadhaar').val()
        const enquiryreligion = $('#enquiryreligion').val()
        const enquirycaste = $('#enquirycaste').val()

        // Form 2
        const fatheroccupation = $('#fatheroccupation').val()
        const mothername = $('#mothername').val()
        const mothertongue = $('#mothertongue').val()

        // Form 3
        const phone1 = $('#phone1').val()
        const phone2 = $('#phone2').val()
        const parentphone = $('#parentphone').val()
        const enquiryemail = $('#enquiryemail').val()
        const enquiryaddress = $('#enquiryaddress').val()

        // Form 4
        const enquiryqualifications = $('#enquiryqualifications').val()
        const enquirycollegename = $('#enquirycollegename').val()
        const enquirytuitionname = $('#enquirytuitionname').val()

        // Form 5
        const enquirycategory = $('#enquirycategory').val()
        const enquirybranch = $('#enquirybranch').val()

        // Social Media
        const facebook = $('#enquirysocialmedia-facebook').val()
        const instagram = $('#enquirysocialmedia-instagram').val()
        const youtube = $('#enquirysocialmedia-youtube').val()
        const twitter = $('#enquirysocialmedia-twitter').val()
        const linkedin = $('#enquirysocialmedia-linkedin').val()
        var socialmedia = ``
        facebook ? socialmedia += `<div><img id="facebook-icon" src="/images/enquiries/facebook-yes.png" width="30" alt=""> ${facebook}</div><br>` : ''
        instagram ? socialmedia += `<div><img id="instagram-icon" src="/images/enquiries/instagram-yes.png" width="30" alt=""> ${instagram}</div><br>` : ''
        youtube ? socialmedia += `<div><img id="youtube-icon" src="/images/enquiries/youtube-yes.png" width="30" alt=""> ${youtube}</div><br>` : ''
        twitter ? socialmedia += `<div><img id="twitter-icon" src="/images/enquiries/twitter-yes.png" width="30" alt=""> ${twitter}</div><br>` : ''
        linkedin ? socialmedia += `<div><img id="linkedin-icon" src="/images/enquiries/linkedin-yes.png" width="30" alt=""> ${linkedin}</div>` : ''

        var references = ``
        // Reference 1
        const ref1_name = $('#ref1_name').val()
        const ref1_phone = $('#ref1_phone').val()
        const ref1_category = $('#ref1_category').val()
        const ref1_area = $('#ref1_area').val()
        if (ref1_name || ref1_phone || ref1_category || ref1_area) {
            references += `
            <div class="card p-1" style="background-color:#B2D57A;width:fit-content;">
                <div><b>Reference 1 Details</b></div>
                <div>Name: ${ref1_name}</div>
                <div>Contact: ${ref1_phone}</div>
                <div>Category: ${ref1_category}</div>
                <div>Area: ${ref1_area}</div>
            </div>`
        }
        // Reference 2
        const ref2_name = $('#ref2_name').val()
        const ref2_phone = $('#ref2_phone').val()
        const ref2_category = $('#ref2_category').val()
        const ref2_area = $('#ref2_area').val()
        if (ref2_name || ref2_phone || ref2_category || ref2_area) {
            references += `
            <div class="card p-1 mt-2" style="background-color:#B2D57A;width:fit-content;">
                <div><b>Reference 2 Details</b></div>
                <div>Name: ${ref2_name}</div>
                <div>Contact: ${ref2_phone}</div>
                <div>Category: ${ref2_category}</div>
                <div>Area: ${ref2_area}</div>
            </div>`
        }
        // Reference 3
        const ref3_name = $('#ref3_name').val()
        const ref3_phone = $('#ref3_phone').val()
        const ref3_category = $('#ref3_category').val()
        const ref3_area = $('#ref3_area').val()
        if (ref3_name || ref3_phone || ref3_category || ref3_area) {
            references += `
            <div class="card p-1 mt-2" style="background-color:#B2D57A;width:fit-content;">
                <div><b>Reference 3 Details</b></div>
                <div>Name: ${ref3_name}</div>
                <div>Contact: ${ref3_phone}</div>
                <div>Category: ${ref3_category}</div>
                <div>Area: ${ref3_area}</div>
            </div>`
        }

        // New fields
        const area = $('#area').val()
        const username = $('#username').val()
        const takenbyother = $('#takenbyother').val()
        var enquiryby = ''
        if (username != '') {
            enquiryby = $(`#username option[value='${username}']`).text();
            if (username == 'other') {
                enquiryby = takenbyother
            }
        }
        // console.log(enquiryby);
        var courseUI = ''
        if (selectedCoursesIDs.length > 0) {
            selectedCoursesIDs.forEach(course => {
                var course_text = $(`#coursename option[value='${course}']`).text()
                courseUI += `<div id="course" style="padding: 3px 10px;width:fit-content;">${course_text}</div>`
            });
        }

        const brnch = document.getElementById('enquirybranch')
        // console.log(brnch);
        const branch_text = brnch.options[brnch.selectedIndex].text;
        // console.log(desc);

        $('#display-firstname').html(firstname ? firstname : '<span class="text-danger">First Name field is empty</span>')
        $('#display-middlename').html(middlename ? middlename : '<span class="text-dark">Middle Name field is empty</span>')
        $('#display-lastname').html(lastname ? lastname : '<span class="text-dark">Last Name field is empty</span>')
        $('#display-enquirydob').html(enquirydob ? enquirydob : '<span class="text-dark">Date of Birth field is empty</span>')
        $('#display-enquirygender').html(enquirygender ? enquirygender : '<span class="text-danger">Please select Gender</span>')
        $('#display-enquiryaadhaar').html(enquiryaadhaar ? enquiryaadhaar : '<span class="text-dark">Aadhaar field is empty</span>')
        $('#display-enquiryreligion').html(enquiryreligion ? enquiryreligion : '<span class="text-dark">Religion field is empty</span>')
        $('#display-enquirycaste').html(enquirycaste ? enquirycaste : '<span class="text-dark">Caste field is empty</span>')
        $('#display-fatheroccupation').html(fatheroccupation ? fatheroccupation : '<span class="text-dark">Father Occupation field is empty</span>')
        $('#display-mothername').html(mothername ? mothername : '<span class="text-dark">Mother Name field is empty</span>')
        $('#display-mothertongue').html(mothertongue ? mothertongue : '<span class="text-dark">Mother Tongue field is empty</span>')
        $('#display-phone1').html(phone1 ? phone1 : '<span class="text-danger">Enquiry Phone 1 field is empty</span>')
        $('#display-phone2').html(phone2 ? phone2 : '<span class="text-dark">Enquiry Phone 2 field is empty</span>')
        $('#display-parentphone').html(parentphone ? parentphone : '<span class="text-dark">Parent Phone field is empty</span>')
        $('#display-enquiryemail').html(enquiryemail ? enquiryemail : '<span class="text-dark">Enquiry Email field is empty</span>')
        $('#display-enquiryaddress').html(enquiryaddress ? enquiryaddress : '<span class="text-dark">Enquiry Address field is empty</span>')
        $('#display-enquiryqualifications').html(enquiryqualifications ? enquiryqualifications : '<span class="text-dark">Enquiry Qualification field is empty</span>')
        $('#display-enquirycollegename').html(enquirycollegename ? enquirycollegename : '<span class="text-dark">Enquiry College Name field is empty</span>')
        $('#display-enquirytuitionname').html(enquirytuitionname ? enquirytuitionname : '<span class="text-dark">Enquiry Tuition Name field is empty</span>')
        $('#display-enquirycategory').html(enquirycategory ? enquirycategory : '<span class="text-dark">Please select Category</span>')
        $('#display-enquirybranch').html(enquirybranch ? branch_text : '<span class="text-danger">Please select Branch</span>')
        $('#display-enquirysocialmedia').html(socialmedia ? socialmedia : '<span class="text-dark">Enquiry Social Media field is empty</span>')
        $('#display-enquiryreference').html(references ? references : '<span class="text-dark">Enquiry Reference field is empty</span>')
        $('#display-enquirycourses').html(courseUI ? courseUI : '<span class="text-danger">No course selected</span>')
        $('#display-enquiryarea').html(area ? area : '<span class="text-danger">Area field is empty</span>')
        $('#display-enquiryenquiryby').html(enquiryby ? enquiryby : '<span class="text-danger">Enquiry taken by field is empty</span>')


        if (!firstname || !enquirygender || !phone1 || !enquirybranch || !courseUI || !area || !enquiryby) {
            next.disabled = true
        } else {
            finalSubmit = 1
            next.disabled = false
        }
    }
}
// Progress Steps JS End

function loadBranchesList() {

    $.ajax({
        url: '/sdp/auth/me',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var branches_list;
                console.log(response.data);
                $('#enquirybranch').text(response.data)

                if (response.data.length == 0) {
                    branches_list += `<option value="">Branch List is empty</option>`;
                } else {
                    branches_list = `<option value="">Select Branch Name</option>`;
                    branches_list += `<option selected value="${response.data.branch}">${response.data.branch}</option>`;
                }

                // $('#enquirybranch').html(branches_list)
                document.getElementsByName('enquirybranch')[0].innerHTML = branches_list
                document.getElementsByName('enquirybranch')[1].innerHTML = branches_list

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Branches Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_branches tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch branches list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_branches tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadBranchesList()

// Feb 2023 update
function checkPhoneNo(ph) {
    // alert('phone changed to ' + ph)
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Checking phone number...',
        showConfirmButton: false
    });

    $.ajax({
        url: `/sdp/enquiries/${ph}`,
        method: 'post',
        success: function (response) {
            if (response.success) {
                // alert(response.data.firstName)
                Swal.fire({
                    icon: 'warning',
                    title: `<div style="color: #dfa878;"><i class='fas fa-check-double'></i>Duplicate phone number
                    </div>
                    <div style="font-size: 20px;">Phone number <span class="text-danger">${ph}</span> is already allocated to <span style="color: #17a2b8;">${response.data.firstName} ${response.data.middleName} ${response.data.lastName}</span> of branch <span style="color: #91C442;">${response.data.branch}</span></div>`,
                    confirmButtonText: `<div class="text-dark">I don't want to add enquiry</div>`,
                    confirmButtonColor: '#fff',
                    allowOutsideClick: false,
                    showDenyButton: true,
                    denyButtonText: 'I want to add duplicate phone number',
                    denyButtonColor: '#c6956b',
                    focusConfirm: false
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Refreshing page...',
                            timer: 1500,
                            showConfirmButton: false
                        });
                        setTimeout(() => {
                            document.location.replace('/sdp/teacher/addenquiry');
                        }, 1000);
                    }
                })
            } else {
                Swal.fire({
                    icon: 'success',
                    title: `<div class="text-success"><i class='fas fa-check-double'></i>Unique phone number
                    </div>
                    <div style="font-size: 20px;">${response.data}</div>`,
                    confirmButtonText: `<div class="text-dark">Okay</div>`,
                    confirmButtonColor: '#fff',
                    allowOutsideClick: false,
                    focusConfirm: false
                })

            }
        },
        error: function (response) {
            console.log(response);
            // alert(response)
        }
    })
}
$('#phone1').change(() => {
    var ph = $('#phone1').val()
    if (ph != '') {
        checkPhoneNo(ph)
    }
})
$('#phone2').change(() => {
    var ph = $('#phone2').val()
    if (ph != '') {
        checkPhoneNo(ph)
    }
})
$('#parentphone').change(() => {
    var ph = $('#parentphone').val()
    if (ph != '') {
        checkPhoneNo(ph)
    }
})

$('#username').change(() => {
    var username = $('#username').val()
    if (username == 'other') {
        $('#other_user_field').css('opacity', 1)
    } else {
        $('#other_user_field').css('opacity', 0)
    }
})

var selectedCoursesIDs = []
function createCoursesUI() {
    var courseUI = ''
    selectedCoursesIDs.forEach(oneCourse => {
        var course_text = $(`#coursename option[value='${oneCourse}']`).text();
        courseUI += `<span id="course">
                        ${course_text}
                        <span id="${oneCourse}">
                            <img src="/images/enquiries/cancel.png" width="30" alt="">
                        </span>
                    </span>`
    });
    if (selectedCoursesIDs.length == 0) {
        courseUI = "No course selected"
    }
    $('#courses_list').html(courseUI)
    $("#course span").click(function () {
        // alert($(this).attr("id"));
        // Ref: https://stackoverflow.com/a/54893802
        selectedCoursesIDs = selectedCoursesIDs.filter(course => course !== $(this).attr("id"));
        if (selectedCoursesIDs.length == 0) {
            $('#coursename').val('')
        } else {
            $('#coursename').val(selectedCoursesIDs.slice(-1)[0]);
        }
        createCoursesUI()
    });
    checkInquiryForm()
}
$('#coursename').change(() => {
    var coursename = $('#coursename').val()
    if (jQuery.inArray(coursename, selectedCoursesIDs) != -1) { // Ref: https://stackoverflow.com/a/18867652
        // alert('already in list')
        Swal.fire({
            position: 'top-right',
            icon: 'error',
            title: 'Course already selected',
            timer: 3000,
            showConfirmButton: false,
            timerProgressBar: true
        });
    } else {
        // alert('not in list')
        if (coursename!='') {
            selectedCoursesIDs.push(coursename)
        }
    }
    createCoursesUI()
})

// Functions imported
loadCoursesList()
loadUsersList()

function checkInquiryForm() {
    const firstName = $('#firstname').val()
    const firstNameElements = document.getElementsByName('firstname')
    firstNameElements[1].value = firstNameElements[0].value
    // console.log(firstName);
    const area = $('#area').val()
    // console.log(area);
    const coursesContent = selectedCoursesIDs[0]
    // console.log(coursesContent);
    const phone1 = $('#phone1').val()
    const phone1Elements = document.getElementsByName('phone1')
    phone1Elements[1].value = phone1Elements[0].value
    // console.log(phone1);
    const userName = $('#username').val()
    // console.log(userName);
    const takenbyother = $('#takenbyother').val()
    // console.log(takenbyother);
    const enquirygender = $('#enquirygender').val()
    const enquirygenderElements = document.getElementsByName('enquirygender')
    enquirygenderElements[1].value = enquirygenderElements[0].value
    
    const enquirybranch = $('#enquirybranch').val()
    const enquirybranchElements = document.getElementsByName('enquirybranch')
    enquirybranchElements[1].value = enquirybranchElements[0].value
    // if (enquirygender == 'Male') {
    //     $('#enquiry_img').fadeOut(10)
    //     $('#enquiry_img').attr('src','/images/enquiries/enquiry_boy.png')
    //     $('#enquiry_img').fadeIn(1000)
    // } else if (enquirygender == 'Female') {
    //     $('#enquiry_img').fadeOut(10)
    //     $('#enquiry_img').attr('src','/images/enquiries/enquiry_girl.png')
    //     $('#enquiry_img').fadeIn(1000)
    // }
    // console.log(enquirygender);

    if (!firstName || !area || !coursesContent || !phone1 || !userName || !enquirygender || !enquirybranch) {
        // Incomplete form submitted
        if ($('#prev').text() == 'Submit quick enquiry'){
            // console.log('Invalid Case 1');
            prev.disabled = true
            $('#prev').css('color','#8d959e')
        }
    } else {
        if (userName == 'other') {
            if (takenbyother) {
                //Valid case 1
                if ($('#prev').text() == 'Submit quick enquiry'){
                    // console.log('Valid Case 1');
                    prev.disabled = false
                    $('#prev').css('color','#91C442')
                }
            } else {
                //Invalid case 2
                if ($('#prev').text() == 'Submit quick enquiry'){
                    // console.log('Invalid Case 2');
                    prev.disabled = true
                    $('#prev').css('color','#8d959e')
                }
            }
        } else {
            //Valid case 2
            if ($('#prev').text() == 'Submit quick enquiry'){
                // console.log('Valid Case 2');
                prev.disabled = false
                $('#prev').css('color','#91C442')
            }
        }
    }
    
}

$('#addenquiry-form1 input').keyup(()=>{
    // alert('input')
    checkInquiryForm()
})
$('#addenquiry-form1 select').change(()=>{
    // alert('select')
    checkInquiryForm()
})
