
$('#sidebar-fees').trigger("click")
$('#sidebar-fees,#sidebar-fees-delete').addClass('active')
$("div#mySidebar").scrollTop(300); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['fee'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/fees')
})

function loadFeesList() {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading fees list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/fees',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var fees_list;
                $('#deletefee #fee').text(response.data)

                if (response.data.length == 0) {
                    fees_list += `<option value="">Fee List is empty</option>`;
                } else {
                    fees_list = `<option value="">Select Fee Record</option>`;
                    response.data.forEach(fee => {

                        var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        var payDateEnglishIST = new Date(fee.paymentDate).toLocaleDateString("en-IN", date_options)

                        if (fee._id == selected) {

                            fees_list += `
                            <option selected value="${fee._id}">${fee.student.firstName} ${fee.student.lastName} | ${payDateEnglishIST}</option>`;

                        } else {

                            fees_list += `
                            <option value="${fee._id}">${fee.student.firstName} ${fee.student.lastName} | ${payDateEnglishIST}</option>`;

                        }
                    });
                }

                $('#deletefee #fee').html(fees_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Fee Record Deleted Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_fees tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch fees list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_fees tbody .col').html(errorMsg)
                $('#no-fee-selected').html(errorMsg)
            }

        }
    });

}
loadFeesList()

const studentname = $('#delete-studentname')
const paydate = $('#delete-paydate')
const paymethod = $('#delete-paymethod')
const totalfees = $('#delete-totalfees')
const paidfees = $('#delete-paidfees')
const pendingfees = $('#delete-pendingfees')
const receiptno = $('#delete-receiptno')
const collectedby = $('#delete-collectedby')

const createdby = $('#delete-feecreatedby')
const createdat = $('#delete-feecreatedat')
const updatedat = $('#delete-feeupdatedat')
const feeid = $('#delete-feeid')

function getFeeDetails() {

    const selectFee = $('#fee').val() ? $('#fee').val() : selected
    // console.log(selectFee);
    if (selectFee == '') {
        $('#no-fee-selected').css('display', 'block')
        $('#fee-selected').css('display', 'none')
    } else {

        $('#no-fee-selected').css('display', 'none')
        $('#fee-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/fees/${selectFee}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deletefee #fee-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var payDateEnglishIST = new Date(response.data.paymentDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    studentname.text(`${response.data.student.firstName} ${response.data.student.middleName} ${response.data.student.lastName}`)
                    paydate.text(payDateEnglishIST)
                    paymethod.text(response.data.paymentMethod)
                    totalfees.text(response.data.totalFees)
                    paidfees.text(response.data.feesPaid)
                    pendingfees.html(response.data.pendingFees)
                    receiptno.html(response.data.receiptNo)
                    collectedby.text(`${response.data.collectedBy.name} | ${response.data.collectedBy.role} | ${response.data.collectedBy.branch}`)

                    createdby.text(`${response.data.createdBy.name} | ${response.data.createdBy.role} | ${response.data.createdBy.branch}`)
                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    feeid.val(response.data._id)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Fee Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_fees tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-fee-card button').attr('disabled', true)
                    $('#fee-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-fee-card button').attr('disabled', true)
                    $('#fee-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch fees list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_fees tbody .col').html(errorMsg)
                    $('#no-fee-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-fee-selected').css('display', 'block')
$('#fee-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getFeeDetails()
}
$('#fee').change(() => {

    getFeeDetails()

})

$('#delete-fee-btn').click(() => {
    var delfeeid = $('#delete-feeid').val()
    var name = studentname.text()
    // console.log(delfeeid);
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${name}</span> fee record details!</h4>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: `/sdp/fees/${delfeeid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Fee Record Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-fee-selected').css('display', 'block')
                        $('#fee-selected').css('display', 'none')
                        loadFeesList()

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });
                    console.log(response);

                }
            });

        }
    })
})
