
$('#sidebar-admissions').trigger("click")
$('#sidebar-admissions,#sidebar-admissions-delete').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['admission'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/admissions')
})

function loadAdmissionsList() {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading admissions list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/admissions',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var admissions_list;
                $('#deleteadmission #admission').text(response.data)

                if (response.data.length == 0) {
                    admissions_list += `<option value="">Admission List is empty</option>`;
                } else {
                    admissions_list = `<option value="">Select Admission Name</option>`;
                    response.data.forEach(admission => {

                        if (admission._id == selected) {

                            admissions_list += `
                            <option selected value="${admission._id}">${admission.student.firstName} ${admission.student.lastName} > ${admission.course.name} Admission</option>`;

                        } else {

                            admissions_list += `
                            <option value="${admission._id}">${admission.student.firstName} ${admission.student.lastName} > ${admission.course.name} Admission</option>`;

                        }
                    });
                }

                $('#deleteadmission #admission').html(admissions_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Admissions Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_admissions tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-admission-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch admissions list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_admissions tbody .col').html(errorMsg)
                $('#no-admission-selected').html(errorMsg)
            }

        }
    });

}
loadAdmissionsList()

const studentname = $('#delete-studentname')
const coursename = $('#delete-coursename')
const admissiondate = $('#delete-admissiondate')
const coursefees = $('#delete-coursefees')

const batchtime = $('#delete-batchtime')
const teacher = $('#delete-teacher')
const installment = $('#delete-installment')
const installdate = $('#delete-installdate')

const enrollno = $('#delete-enrollno')
const rollno = $('#delete-rollno')
const enrollmonth = $('#delete-enrollmonth')
const enrollpay = $('#delete-enrollpay')

const createdby = $('#delete-admissioncreatedby')
const createdat = $('#delete-admissioncreatedat')
const updatedat = $('#delete-admissionupdatedat')
const admissionid = $('#delete-admissionid')

function getAdmissionDetails() {

    const selectAdmission = $('#admission').val() ? $('#admission').val() : selected
    // console.log(selectAdmission);
    if (selectAdmission == '') {
        $('#no-admission-selected').css('display', 'block')
        $('#admission-selected').css('display', 'none')
    } else {

        $('#no-admission-selected').css('display', 'none')
        $('#admission-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/admissions/${selectAdmission}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deleteadmission #admission-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var enrollpayEnglishIST = new Date(response.data.enrollmentPaymentDate).toLocaleDateString("en-IN", date_options)
                    var admissionEnglishIST = new Date(response.data.admissionDate).toLocaleDateString("en-IN", date_options)
                    var installmentEnglishIST = new Date(response.data.installmentdate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }
                    // Installment type
                    var installmentType;
                    if (response.data.installment) {
                        installmentType = 'Installment'
                    } else if (response.data.installment == false) {
                        installmentType = 'One Time'
                    }
                    $('#installmentDate').fadeIn()

                    studentname.text(`${response.data.student.firstName} ${response.data.student.middleName} ${response.data.student.lastName}`)
                    rollno.text(response.data.rollNo)
                    coursename.text(response.data.course.name)
                    coursefees.text(response.data.fees)
                    enrollno.text(response.data.enrollmentNo)
                    enrollmonth.html(response.data.enrollmentMonth)
                    enrollpay.html(enrollpayEnglishIST)
                    admissiondate.text(admissionEnglishIST)

                    batchtime.text(response.data.batch ? response.data.batch : 'Not added')
                    teacher.text(response.data.teacher ? response.data.teacher.name : 'Not added')
                    installment.text(installmentType ? installmentType : 'Not added')
                    installdate.text(installmentEnglishIST ? installmentEnglishIST : 'Not added')

                    rollno.text(response.data.rollNo ? response.data.rollNo : 'Not added')
                    enrollno.text(response.data.enrollmentNo ? response.data.enrollmentNo : 'Not added')
                    enrollmonth.html(response.data.enrollmentMonth ? response.data.enrollmentMonth : 'Not added')
                    enrollpay.html(enrollpayEnglishIST ? enrollpayEnglishIST : 'Not added')

                    createdby.text(`${response.data.createdBy.name} (${response.data.createdBy.role})`)
                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    admissionid.val(response.data._id)

                    if (!response.data.installment) {
                        $('#installmentDate').fadeOut()
                    }

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Admission Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_admissions tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-admission-card button').attr('disabled', true)
                    $('#admission-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-admission-card button').attr('disabled', true)
                    $('#admission-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch admissions list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_admissions tbody .col').html(errorMsg)
                    $('#no-admission-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-admission-selected').css('display', 'block')
$('#admission-selected').css('display', 'none')
if (selected != undefined) {
    // console.log('inside');
    getAdmissionDetails()
}
$('#admission').change(() => {

    getAdmissionDetails()

})

$('#delete-admission-btn').click(() => {
    var deladmissionid = $('#delete-admissionid').val()
    var name = studentname.text()
    // console.log(deladmissionid);
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${name}</span> admission details!</h4>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!',
        showCloseButton: true,
        focusConfirm: false
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: `/sdp/admissions/${deladmissionid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Admission Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-admission-selected').css('display', 'block')
                        $('#admission-selected').css('display', 'none')
                        loadAdmissionsList()

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });
                    console.log(response);

                }
            });

        }
    })
})
