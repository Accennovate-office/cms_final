
$('#sidebar-tasks').trigger("click")
$('#sidebar-tasks,#sidebar-tasks-delete').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['task'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/tasks')
})

function loadTasksList() {

    $.ajax({
        url: '/sdp/tasks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var tasks_list;
                $('#deletetask #task').text(response.data)

                if (response.data.length == 0) {
                    tasks_list += `<option value="">Task List is empty</option>`;
                } else {
                    tasks_list = `<option value="">Select Task Name</option>`;
                    response.data.forEach(task => {

                        if (task._id == selected) {

                            tasks_list += `
                            <option selected value="${task._id}">${task.details}</option>`;

                        } else {

                            tasks_list += `
                            <option value="${task._id}">${task.details}</option>`;

                        }
                    });
                }

                $('#deletetask #task').html(tasks_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Tasks Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_tasks tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch tasks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_tasks tbody .col').html(errorMsg)
                $('#no-task-selected').html(errorMsg)
            }

        }
    });

}
loadTasksList()

const taskdetails = $('#delete-taskdetails')
const taskcategory = $('#delete-taskcategory')
const tasksubcategory = $('#delete-tasksubcategory')

const createbyname = $('#task-createbyname')
const createbyemail = $('#task-createbyemail')
const createbybranch = $('#task-createbybranch')

const createdat = $('#delete-taskcreatedat')
const updatedat = $('#delete-taskupdatedat')
const taskid = $('#delete-taskid')
$('#no-task-selected').css('display', 'block')
$('#task-selected').css('display', 'none')

function getTaskDetails() {

    const selectTask = $('#task').val() ? $('#task').val() : selected
    // console.log(selectTask);
    if (selectTask == '') {
        $('#no-task-selected').css('display', 'block')
        $('#task-selected').css('display', 'none')
    } else {

        $('#no-task-selected').css('display', 'none')
        $('#task-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/tasks/${selectTask}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    // $('#deletetask #task-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    // Check date
                    optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    var taskStartingAt = new Date(response.data.startingAt).toLocaleDateString("en-IN", optionsCheck)

                    taskdetails.text(response.data.details)
                    taskcategory.html(`${response.data.category.title}  <span class="badge badge-freq">${response.data.category.frequency}</span>`)
                    tasksubcategory.text(response.data.subcategory.title)

                    createbyname.text(response.data.createdBy.name)
                    createbyemail.text(response.data.createdBy.email)
                    createbybranch.text(`${response.data.createdBy.branch} Branch`)

                    createdat.text(createdEnglishIST)
                    updatedat.text(updateValue)
                    taskid.val(response.data._id)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Task Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_tasks tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-task-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-task-card button').attr('disabled', true)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch tasks list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_tasks tbody .col').html(errorMsg)
                    $('#no-task-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getTaskDetails()
}

$('#task').change(() => {

    getTaskDetails()

})

$('#delete-task-btn').click(() => {
    var deltaskid = $('#delete-taskid').val()
    var name = taskdetails.text()
    // console.log(deltaskid);
    swal.fire({
        title: 'Are you sure?',
        html: `You want to delete <span class="text-danger font-weight-bold">${name}</span> task details!`,
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!',
        showCloseButton: true
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({                    // Delete task route pending #########################
                url: `/sdp/tasks/${deltaskid}`,
                method: 'delete',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'top-right',
                            icon: 'success',
                            title: 'Task Deleted Successfully',
                            timer: 3000,
                            showConfirmButton: false
                        });

                        $('#no-task-selected').css('display', 'block')
                        $('#task-selected').css('display', 'none')
                        loadTasksList()

                        setTimeout(() => {
                            document.location.replace('/sdp/teacher/deletetask');
                        }, 3000);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });

                }
            });

        }
    })
})
