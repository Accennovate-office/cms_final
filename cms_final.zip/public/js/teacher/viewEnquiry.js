import { loadCoursesList } from "../services/loadList.js";
import { getUrlVars } from "../services/getData.js";
import { addFollowup, createFollowupUI } from "../services/followup.js";

// Functions imported
loadCoursesList()

$('#sidebar-enquiries').trigger("click")
$('#sidebar-enquiries,#sidebar-enquiries-view').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

const selected = getUrlVars()['enquiry'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/enquiries')
})

// function loadEnquiriesList() {

//     $.ajax({
//         url: '/sdp/enquiries',
//         method: 'get',
//         success: function (response) {
//             if (response.success) {

//                 var enquiries_list;
//                 $('#viewenquiry #enquiry').text(response.data)

//                 if (response.data.length == 0) {
//                     enquiries_list += `<option value="">Enquiry List is empty</option>`;
//                 } else {
//                     enquiries_list = `<option value="">Select Enquiry Name</option>`;
//                     response.data.forEach(enquiry => {

//                         if (enquiry._id == selected) {

//                             enquiries_list += `
//                             <option selected value="${enquiry._id}">${enquiry.firstName} ${enquiry.lastName}</option>`;

//                         } else {

//                             enquiries_list += `
//                             <option value="${enquiry._id}">${enquiry.firstName} ${enquiry.lastName}</option>`;

//                         }

//                     });
//                 }

//                 $('#viewenquiry #enquiry').html(enquiries_list)

//                 Swal.fire({
//                     toast: true,
//                     position: 'top-right',
//                     icon: 'success',
//                     title: 'Enquiries Fetched Successfully',
//                     timer: 3000,
//                     showConfirmButton: false
//                 });

//             } else {

//                 $('#loading').css('display', 'none');
//                 $('#table_enquiries tbody tr').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-enquiry-card button').attr('disabled', true)

//             }
//         },
//         error: function (response) {

//             if (response.responseJSON) {
//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 console.log(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-enquiry-card button').attr('disabled', true)

//             } else {
//                 var errorMsg = `
//                 <center>
//                 <h2>Oops! Something went wrong</h2>
//                 <h4 class="text-danger">
//                     Error Code: ${response.status} <br>
//                     Error Message: ${response.statusText}
//                 </h4>
//                 <h5>We were unable to fetch enquiries list</h5>
//                 <h6>
//                     Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
//                 </h6>
//                 </center>`
//                 console.log(`something went wrong ${JSON.stringify(response)}`);
//                 // console.log(response.statusText);
//                 // $('#table_enquiries tbody .col').html(errorMsg)
//                 $('#no-enquiry-selected').html(errorMsg)
//             }

//         }
//     });

// }
// loadEnquiriesList()

var editenquiry = ''
var enquiryname = ''
var enquiryrefname = ''
var enquiryID = ''
function getEnquiryDetails() {


    const selectenquiry = $('#enquiry').val() ? $('#enquiry').val() : selected
    // console.log(selectenquiry);
    if (selectenquiry == '') {
        $('#no-enquiry-selected').css('display', 'block')
        $('#enquiry-selected').css('display', 'none')
    } else {

        $('#no-enquiry-selected').css('display', 'none')
        $('#enquiry-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/enquiries/${selectenquiry}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewenquiry #enquiry-selected').html(`<h2>Loading...</h2>`)
                    enquiryname = `${response.data.firstName} ${response.data.middleName} ${response.data.lastName}`
                    enquiryID = response.data._id
                    enquiryrefname = response.data.reference ? response.data.reference._id : ''

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)

                    var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    // var dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", date_options)
                    var dobEnglishIST = ''
                    if (response.data.dob) {
                        dobEnglishIST = new Date(response.data.dob).toLocaleDateString("en-IN", optionsCheck)
                    }
                    var joindateEnglishIST = new Date(response.data.joiningDate).toLocaleDateString("en-IN", date_options)

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var edu_details = ''
                    if (response.data.qualification != '') {
                        const edu_string = response.data.qualification.split(',')
                        // console.log(response.data.qualification);
                        edu_string.forEach(edu => {
                            edu_details += `<span class="badge badge-light mt-0">${edu}</span>`
                        });
                    }
                    var courses = response.data.courses
                    selectedCoursesIDs = response.data.courses.split(',')

                    // Social media details
                    var social_details = ''

                    const facebook = response.data.facebook
                    facebook ? social_details += `<div class="col col-6 mb-2"><img id="facebook-icon" src="/images/enquiries/facebook-yes.png" width="25" alt=""> &nbsp;${facebook}</div>` : ''

                    const instagram = response.data.instagram
                    instagram ? social_details += `<div class="col col-6 mb-2"><img id="instagram-icon" src="/images/enquiries/instagram-yes.png" width="25" alt="">&nbsp; ${instagram}</div>` : ''

                    const youtube = response.data.youtube
                    youtube ? social_details += `<div class="col col-6 mb-2"><img id="youtube-icon" src="/images/enquiries/youtube-yes.png" width="25" alt=""> &nbsp;${youtube}</div>` : ''

                    const twitter = response.data.twitter
                    twitter ? social_details += `<div class="col col-6 mb-2"><img id="twitter-icon" src="/images/enquiries/twitter-yes.png" width="25" alt=""> &nbsp;${twitter}</div>` : ''

                    const linkedin = response.data.linkedin
                    linkedin ? social_details += `<div class="col col-6 mb-2"><img id="linkedin-icon" src="/images/enquiries/linkedin-yes.png" width="25" alt=""> &nbsp;${linkedin}</div>` : ''

                    if (!facebook && !instagram && !youtube && !twitter && !linkedin) {
                        social_details = 'No social media links added'
                    }

                    // Reference Details
                    var reference_details = ''
                    if (response.data.reference) {
                        if (response.data.reference.ref1Name || response.data.reference.ref1Phone || response.data.reference.ref1Category || response.data.reference.ref1Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref1Name ? response.data.reference.ref1Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref1Phone ? response.data.reference.ref1Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref1Category ? response.data.reference.ref1Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref1Area ? response.data.reference.ref1Area : ''}
                            </div>`
                        }
                        if (response.data.reference.ref2Name || response.data.reference.ref2Phone || response.data.reference.ref2Category || response.data.reference.ref2Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref2Name ? response.data.reference.ref2Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref2Phone ? response.data.reference.ref2Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref2Category ? response.data.reference.ref2Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref2Area ? response.data.reference.ref2Area : ''}
                            </div>`
                        }
                        if (response.data.reference.ref3Name || response.data.reference.ref3Phone || response.data.reference.ref3Category || response.data.reference.ref3Area) {
                            reference_details += `
                            <div class="col col-4 px-1 py-2" style="height:fit-content;border-left:2px solid #0b6fad;border-radius:10px;">
                                <b>Name:</b> ${response.data.reference.ref3Name ? response.data.reference.ref3Name : ''}<br>
                                <b>Phone:</b> ${response.data.reference.ref3Phone ? response.data.reference.ref3Phone : ''}<br>
                                <b>Category:</b> ${response.data.reference.ref3Category ? response.data.reference.ref3Category : ''}<br>
                                <b>Area:</b> ${response.data.reference.ref3Area ? response.data.reference.ref3Area : ''}
                            </div>`
                        }
                        if (!response.data.reference.ref1Name && !response.data.reference.ref1Phone && !response.data.reference.ref1Category && !response.data.reference.ref1Area && !response.data.reference.ref2Name && !response.data.reference.ref2Phone && !response.data.reference.ref2Category && !response.data.reference.ref2Area && !response.data.reference.ref3Name && !response.data.reference.ref3Phone && !response.data.reference.ref3Category && !response.data.reference.ref3Area) {
                            reference_details = 'No reference detials added'
                        }
                    } else {
                        reference_details = 'No reference detials added'
                    }

                    // Aadhaar number validation if available or not
                    var aadhaarNumber = ''
                    if (response.data.aadhaarNo) {

                        var aNo = response.data.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    }
                    // console.log(response.data.takenby);
                    if (response.data.takenby) {
                        // console.log('hide');
                        var other = `style="opacity:0;"`
                    } else {
                        // console.log('visible');
                        var other = ''
                    }

                    var enquiry_data = `
                    <div class="d-flex mb-3 pl-1">
                        <img src="/images/enquiries/enquiry2.png" width="70" alt="">
                        <div align="left" class="ml-4">
                            <small>Enquiry Name (Firstname Middlename Lastname)</small>
                            <h2>${response.data.firstName} ${response.data.middleName} ${response.data.lastName}</h2>
                        </div>
                    </div>

                    <!-- Personal Details --><span id="personal-details">
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Personal Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div id="dobEnglishIST" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Date of Birth</small>
                            </div>
                            <div>${dobEnglishIST}</div>
                        </div>
                        <div id="gender" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-venus-mars"></i>
                                <small>Gender</small>
                            </div>
                            <div>${response.data.gender}</div>
                        </div>
                        <div id="aadhaarNumber" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card"></i>
                                <small>Aadhaar No.</small>
                            </div>
                            <div>${aadhaarNumber}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div id="religion" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-dove"></i>
                                <small>Religion</small>
                            </div>
                            <div>${response.data.religion}</div>
                        </div>
                        <div id="caste" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-podcast"></i>
                                <small>Caste</small>
                            </div>
                            <div>${response.data.caste}</div>
                        </div>
                        <div id="rel_cas_extra" class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card"></i>
                                <small>Aadhaar</small>
                            </div>
                            <div>1234-5678-2</div>
                        </div>
                    </div></span>

                    <!-- Family Details --><span id="family-details">
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Family Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div id="fatherOccupation" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-briefcase"></i>
                            <small>Father Occupation</small>
                        </div>
                        <div>${response.data.fatherOccupation}</div>
                    </div>

                    <div class="d-flex justify-content-between mt-2">
                        <div id="motherName" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-female"></i>
                                <small>Mother Name</small>
                            </div>
                            <div>${response.data.motherName}</div>
                        </div>
                        <div id="motherTongue" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-language"></i>
                                <small>Mother Tongue</small>
                            </div>
                            <div>${response.data.motherTongue}</div>
                        </div>
                        <div class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card"></i>
                                <small>Aadhaar</small>
                            </div>
                            <div>1234-</div>
                        </div>
                    </div></span>

                    <!-- Contact Details --><span id="contact-details">
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Contact Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div id="phone1" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <small>Phone 1</small>
                            </div>
                            <div>${response.data.phone1}</div>
                        </div>
                        <div id="phone2" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-phone"></i>
                                <small>Phone 2</small>
                            </div>
                            <div>${response.data.phone2}</div>
                        </div>
                        <div id="parentPhone" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-phone"></i>
                                <small>Parent Phone</small>
                            </div>
                            <div>${response.data.parentPhone}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <div id="email" class="mt-2">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                <small>Email</small>
                            </div>
                            <div>${response.data.email}</div>
                        </div>
                    </div>

                    <div id="area" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <small>Area</small>
                        </div>
                        <h5>${response.data.area}</h5>
                    </div>

                    <div id="address" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <small>Full Address</small>
                        </div>
                        <h5>${response.data.address}</h5>
                    </div>
                    </span>

                    <!-- Educational Details --><span id="educational-details">
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Educational Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div id="courses" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-graduate" aria-hidden="true"></i>
                            <small>Course(s)</small>
                        </div>
                        <h4 id="courses_list">${courses}</h4>
                    </div>

                    <div id="edu_details" align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-graduate" aria-hidden="true"></i>
                            <small>Educational Qualification(s)</small>
                        </div>
                        <h4>${edu_details}</h4>
                    </div>

                    <div class="d-flex justify-content-between mt-3 row">
                        <div id="schoolOrCollegeName" align="left" class="mt-0 col col-8">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-school"></i>
                                <small>School or College Name</small>
                            </div>
                            <div>${response.data.schoolOrCollegeName}</div>
                        </div>
                        <div id="classOrTuitionName" align="left" class="mt-0 col col-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-building"></i>
                                <small>Class or Tuition Name</small>
                            </div>
                            <div>${response.data.classOrTuitionName}</div>
                        </div>
                    </div></span>

                    <!-- Other Details -->
                    <h5 align="left" class="text-success bg-dark mt-4 mb-0 py-2 pl-2">Other Details</h5>
                    <hr class="bg-success mt-0 mb-2">
                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-address-card" aria-hidden="true"></i>
                                <small>Enquiry taken by staff</small>
                            </div>
                            <div>${response.data.takenby ? response.data.takenby.name : 'Other'}</div>
                        </div>
                        <div id="otherstaff" align="left" class="mt-0" ${other}>
                            <div class="d-flex align-items-center">
                                <i class="fas fa-id-badge"></i>
                                <small>Other staff</small>
                            </div>
                            <div>${response.data.takenbyother}</div>
                        </div>
                        <div align="left" class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-people-arrows"></i>
                                <small>Ref</small>
                            </div>
                            <div></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-building" aria-hidden="true"></i>
                                <small>Branch</small>
                            </div>
                            <div>${response.data.branch}</div>
                        </div>
                        <div id="category" align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-user-tag"></i>
                                <small>Category</small>
                            </div>
                            <div>${response.data.category ? response.data.category : ''}</div>
                        </div>
                        <div align="left" class="mt-0" style="opacity:0;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-people-arrows"></i>
                                <small>Ref</small>
                            </div>
                            <div></div>
                        </div>
                    </div>
                    <div align="left" class="mt-2 w-100">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-share-alt"></i>
                            <small>Social Media</small>
                        </div>
                        <div class="ml-3 row">${social_details}</div>
                    </div>
                    <div align="left" class="mt-2 w-100">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-people-arrows"></i>
                            <small>Reference</small>
                        </div>
                        <div class="ml-3 row">${reference_details}</div>
                    </div>

                    <div id="followup-list"></div>

                    <div id="hidden_note" class="mt-3" style="color:#c84648;">
                    <span style="color:#2a2829;background-color:#eff2f6;padding:1px 3px;border-radius:4px"><b>NOTE</span> 
                    Empty fields are hidden. Kindly click on edit button to add those fields.</b></div>

                    <div class="d-flex justify-content-between mt-3">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                        <div class="mt-3 ml-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewenquiry #enquiry-selected').html(enquiry_data)

                    createFollowupUI(selected)

                    var hidden = 0
                    editenquiry = `/sdp/teacher/editenquiry?enquiry=${enquiryID}`

                    // Hide personal detials
                    if (!dobEnglishIST && !response.data.gender && !aadhaarNumber && !response.data.religion && !response.data.caste) {
                        // All fields blank
                        hidden = 1
                        $('#personal-details').css('display','none')
                    } else {
                        // Some fields are present
                        dobEnglishIST ? '' : $('#dobEnglishIST').css('display','none')
                        response.data.gender ? '' : $('#gender').css('display','none')
                        aadhaarNumber ? '' : $('#aadhaarNumber').css('display','none')
                        response.data.religion ? '' : $('#religion').css('display','none')
                        response.data.caste ? '' : $('#caste').css('display','none')
                        if (!response.data.religion && !response.data.caste) {
                            $('#rel_cas_extra').css('display','none')
                        }
                    }

                    // Hide empty family details
                    if (!response.data.fatherOccupation && !response.data.motherName && !response.data.motherTongue) {
                        // All fields blank
                        hidden = 1
                        $('#family-details').css('display','none')
                    } else {
                        // Some fields are present
                        response.data.fatherOccupation ? '' : $('#fatherOccupation').css('display','none')
                        response.data.motherName ? '' : $('#motherName').css('display','none')
                        response.data.motherTongue ? '' : $('#motherTongue').css('display','none')
                    }

                    // Hide empty contact details
                    if (!response.data.phone1 && !response.data.phone2 && !response.data.parentPhone && !response.data.email && !response.data.address) {
                        // All fields blank
                        hidden = 1
                        $('#contact-details').css('display','none');
                    } else {
                        // Some fields are present
                        response.data.phone1 ? '' : $('#phone1').css('display','none')
                        response.data.phone2 ? '' : $('#phone2').css('display','none')
                        response.data.parentPhone ? '' : $('#parentPhone').css('display','none')
                        response.data.email ? '' : $('#email').css('display','none')
                        response.data.address ? '' : $('#address').css('display','none')
                    }

                    // Hide empty educational details
                    // console.log(edu_details);
                    if (!courses && !edu_details && !response.data.schoolOrCollegeName && !response.data.classOrTuitionName) {
                        // All fields blank
                        hidden = 1
                        $('#educational-details').css('display','none')
                    } else {
                        // Some fields are present
                        edu_details ? '' : $('#edu_details').css('display','none')
                        response.data.schoolOrCollegeName ? '' : $('#schoolOrCollegeName').css('display','none')
                        response.data.classOrTuitionName ? '' : $('#classOrTuitionName').css('display','none')
                    }

                    response.data.category ? '' : $('#category').css('display','none')

                    if (hidden === 0) {
                        $('#hidden_note').css('display','none')
                    }

                    createCoursesUI()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Enquiry Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_enquiries tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-enquiry-card button').attr('disabled', true)
                    $('#enquiry-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-enquiry-card button').attr('disabled', true)
                    $('#enquiry-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch enquiries list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_enquiries tbody .col').html(errorMsg)
                    $('#enquiry-selected').html(errorMsg)
                }

            }
        });
    }
}

$('#no-enquiry-selected').css('display', 'block') // block
$('#enquiry-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getEnquiryDetails()
}
// $('#enquiry').change(() => {

//     getEnquiryDetails()
// })
$('#edit-enquiry').click(()=>{
    document.location.replace(editenquiry)
})

// Delete enquiry function
$('#delete-enquiry-btn').click(() => {
    // var delinquiryid = $('#delete-inquiryid').val()
    // var delreferenceid = $('#delete-referenceid').val()
    // console.log(delreferenceid);
    // var name = inquiryname.text()
    // var email = inquiryemail.text()
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${enquiryname}</span> enquiry details!</h4>
            <h5>References will also be deleted along with inquiries data</h5>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            if (enquiryrefname != '') {
                // console.log('Delete inquiry & reference');

                // Delete reference data
                $.ajax({
                    url: `/sdp/enqreferences/${enquiryrefname}`, // Also delete reference with inquiries
                    method: 'delete',
                    success: function (response) {
                        if (response.success) {

                            $.ajax({
                                url: `/sdp/enquiries/${enquiryID}`, // Delete inquiries data
                                method: 'delete',
                                success: function (response) {
                                    if (response.success) {

                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'Enquiry Deleted Successfully',
                                            timer: 3000,
                                            showConfirmButton: false
                                        });
                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'Redirecting...',
                                            timer: 2000,
                                            showConfirmButton: false
                                        });
                                        setTimeout(() => {
                                            document.location.replace('/sdp/teacher/enquiries');
                                        }, 2000);

                                        $('#no-inquiry-selected').css('display', 'block')
                                        $('#inquiry-selected').css('display', 'none')

                                    } else {

                                        Swal.fire({
                                            icon: 'danger',
                                            title: 'Something went wrong',
                                            text: response.responseJSON.error
                                        });
                                        // console.log(response);

                                    }
                                },
                                error: function (response) {

                                    Swal.fire({
                                        icon: 'danger',
                                        title: 'Server error',
                                        text: response.responseJSON.error
                                    });
                                    // console.log(response);

                                }
                            });

                            // Swal.fire({
                            //     toast: true,
                            //     position: 'top-right',
                            //     icon: 'success',
                            //     title: 'inquiry Deleted Successfully',
                            //     timer: 3000,
                            //     showConfirmButton: false
                            // });

                        } else {

                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });
                            // console.log(response);

                        }
                    },
                    error: function (response) {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Server error',
                            text: response.responseJSON.error
                        });
                        // console.log(response);

                    }
                });

            } else {
                // console.log('Delete only inquiry');
                // Delete only inquiry data
                $.ajax({
                    url: `/sdp/enquiries/${enquiryID}`, // Delete inquiries info
                    method: 'delete',
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {

                            // Swal.fire({
                            //     toast: true,
                            //     position: 'top-right',
                            //     icon: 'success',
                            //     title: 'Enquiry Deleted Successfully',
                            //     timer: 3000,
                            //     showConfirmButton: false
                            // });
                            Swal.fire({
                                // toast: true,
                                // position: 'top-right',
                                icon: 'success',
                                title: 'Enquiry Deleted Successfully',
                                html: '<div id="redirectmessage">Redirecting to enquiries list</div>',
                                allowOutsideClick: false,
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/teacher/enquiries');
                            }, 4000);

                            $('#no-inquiry-selected').css('display', 'block')
                            $('#inquiry-selected').css('display', 'none')

                        } else {

                            console.log(response);
                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });

                        }
                    },
                    error: function (response) {

                        console.log(response);
                        Swal.fire({
                            icon: 'danger',
                            title: 'Server error',
                            text: response.responseJSON.error
                        });

                    }
                });

            }


        }
    })
    
})
// setTimeout(() => {
//     Swal.fire({
//         // toast: true,
//         // position: 'top-right',
//         icon: 'success',
//         title: 'Enquiry Deleted Successfully',
//         html: '<div id="redirectmessage">Redirecting to enquiries list</div>',
//         allowOutsideClick: false,
//         showConfirmButton: false,
//         timer: 4000,
//         timerProgressBar: true
//     });
//     setTimeout(() => {
//         document.location.replace('/sdp/teacher/enquiries');
//     }, 4000);
// }, 3000);

var selectedCoursesIDs = []
function createCoursesUI() {
    var courseUI = ''
    selectedCoursesIDs.forEach(oneCourse => {
        var course_text = $(`#coursename option[value='${oneCourse}']`).text();
        courseUI += `<span id="course">
                        ${course_text}
                    </span>`
    });
    if (selectedCoursesIDs.length == 0) {
        courseUI = "No course selected"
    }
    $('#courses_list').html(courseUI)
}