$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-fees').trigger("click")
$('#sidebar-fees,#sidebar-fees-add').addClass('active')
$("div#mySidebar").scrollTop(300); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

function loading(msg = 'Adding New Fee...') {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">${msg}</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;
const courses_all_list = [];
var fee_branch;

function createFee() {
    // Form 1
    const studentname = $('#studentname').val()
    const totalfees = $('#totalfees').val()
    const feespaid = $('#feespaid').val()
    const pendingfees = $('#pendingfees').val()
    // Form 2
    const paymethod = $('#paymethod').val()
    const paydate = $('#paydate').val()
    const receiptno = $('#receiptno').val()
    const collectedby = $('#collectedby').val()


    if (!studentname || !totalfees || !feespaid || !pendingfees || !paymethod || !paydate || !receiptno || !collectedby) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in fee form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Create New Fee
        loading()

        $.ajax({
            url: `/sdp/users/${collectedby}`,
            method: 'get',
            dataType: 'json',
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    const collecteby_userid = response.data._id

                    $.ajax({
                        url: '/sdp/fees',
                        method: 'post',
                        dataType: 'json',
                        data: {
                            student: studentname,
                            totalFees: totalfees,
                            feesPaid: feespaid,
                            pendingFees: pendingfees,
                            paymentMethod: paymethod,
                            paymentDate: paydate,
                            receiptNo: receiptno,
                            collectedBy: collecteby_userid,
                            branch: fee_branch
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                $('#add-branch-card button').attr('disabled', true)

                                // Fee data added
                                Swal.fire({
                                    icon: 'success',
                                    title: `<div class="text-success">Fee Details Added</div>`,
                                    confirmButtonText: `<div class="text-dark">Fees List</div>`,
                                    confirmButtonColor: '#fff',
                                    allowOutsideClick: false,
                                    showDenyButton: true,
                                    denyButtonText: 'New fee record',
                                    denyButtonColor: '#0b6fad',
                                    showCloseButton: true,
                                    focusConfirm: false
                                }).then((result) => {
                                    /* Read more about isConfirmed, isDenied below */
                                    if (result.isConfirmed) {
                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'Redirecting...',
                                            timer: 1000,
                                            showConfirmButton: false
                                        });
                                        setTimeout(() => {
                                            document.location.replace('/sdp/teacher/fees');
                                        }, 1000);
                                    } else if (result.isDenied) {
                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'Redirecting...',
                                            timer: 1000,
                                            showConfirmButton: false
                                        });
                                        setTimeout(() => {
                                            document.location.replace('/sdp/teacher/addfee');
                                        }, 1000);
                                    }
                                })

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            console.log(response);
                            $('#error').text(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-branch-card button').attr('disabled', true)

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New fee trigger
        createFee()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addfee-form1,#addfee-form2,#addfee-form3').removeClass('active')
    $(`#addfee-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 2) {
        $('#next').text('Review')
    } else if (actives.length === 3) {

        next.disabled = true
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page
        loading('Calculating...')

        $('#next').text('Submit')

        const studentname_id = $('#studentname').val()
        // Find student name
        $.ajax({
            url: `/sdp/students/${studentname_id}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    var studentname
                    response.data.firstName ? studentname = response.data.firstName + ' ' + response.data.middleName + ' ' + response.data.lastName : studentname = undefined
                    fee_branch = response.data.branch

                    // Find course name
                    const collectedby_id = $('#collectedby').val()
                    $.ajax({
                        url: `/sdp/users/${collectedby_id}`,
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                $('#loading').css('display', 'none');

                                var collectedby
                                response.data.name ? collectedby = `${response.data.name} | ${response.data.role} | ${response.data.branch} Branch` : collectedby = undefined

                                const totalfees = $('#totalfees').val()
                                const feespaid = $('#feespaid').val()
                                // Form 2
                                var pendingfees = $('#pendingfees').val()
                                const paymethod = $('#paymethod').val()
                                const paydate = $('#paydate').val()
                                const receiptno = $('#receiptno').val()

                                $('#display-studentname').html(studentname ? studentname : '<span class="text-danger">Student Name field is empty</span>')
                                $('#display-totalfees').html(totalfees ? totalfees : '<span class="text-danger">Total Fees field is empty</span>')
                                $('#display-feespaid').html(feespaid ? feespaid : '<span class="text-danger">Fees Paid field is empty</span>')
                                if (pendingfees == `Enter value between 1 and ${totalfees}`) {
                                    $('#display-pendingfees').html(`<span class="text-danger">${pendingfees}</span>`)
                                    pendingfees = ''
                                } else {
                                    $('#display-pendingfees').html(pendingfees ? pendingfees : '<span class="text-danger">Pending Fees field is empty</span>')
                                }
                                $('#display-paymethod').html(paymethod ? paymethod : '<span class="text-danger">Payment Method field is empty</span>')
                                $('#display-paydate').html(paydate ? paydate : '<span class="text-danger">Payment Date field is empty</span>')
                                $('#display-receiptno').html(receiptno ? receiptno : '<span class="text-danger">Receipt Number field is empty</span>')
                                $('#display-collectedby').html(collectedby ? collectedby : '<span class="text-danger">Collected By field is empty</span>')

                                if (!studentname || !collectedby || !totalfees || !feespaid || !pendingfees || !paymethod || !paydate || !receiptno) {
                                    next.disabled = true
                                } else {
                                    finalSubmit = 1
                                    next.disabled = false
                                }

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch course name</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch student name</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    }
}
// Progress Steps JS End

$('#studentname').change(() => {

    $('#feespaid').attr('disabled', false)
    const studentname = $('#studentname').val()
    if (studentname != '') {
        $('#totalfees').val('Calculating...')

        $.ajax({
            url: `/sdp/admissions`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    var total_fees = 0
                    const data = response.data
                    data.forEach(admission => {
                        if (admission.student != null && admission.student != undefined) {

                            if (studentname == admission.student._id) {
                                total_fees += admission.fees
                            }
                        }
                    });

                    if (total_fees == 0) {
                        $('#totalfees').val('')
                        $('#feespaid').attr('disabled', true)
                        Swal.fire({
                            icon: 'info',
                            title: `<div style="color:#0b6fad;">First add admission details before adding fee details</div>`,
                            confirmButtonText: 'Add Admission',
                            confirmButtonColor: '#0b6fad',
                            showCancelButton: true,
                            cancelButtonText: 'I Got it',
                            allowOutsideClick: false
                        }).then((result) => {
                            /* Read more about isConfirmed, isDenied below */
                            if (result.isConfirmed) {
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Redirecting...',
                                    timer: 1000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    document.location.replace('/sdp/teacher/addadmission');
                                }, 1000);
                            }
                        })
                    } else {

                        // $('#totalfees').val(total_fees)

                        $.ajax({
                            url: `/sdp/fees`,
                            method: 'get',
                            success: function (response) {
                                if (response.success) {

                                    var paid_fees = 0
                                    const data = response.data
                                    data.forEach(fee => {
                                        if (fee.student != null && fee.student != undefined) {

                                            if (studentname == fee.student._id) {
                                                paid_fees += fee.feesPaid
                                            }
                                        }
                                    });

                                    const pending_fees = total_fees - paid_fees

                                    if (pending_fees == 0) {
                                        $('#feespaid').attr('disabled', true)
                                        $('#totalfees').val('')

                                        Swal.fire({
                                            icon: 'success',
                                            title: `<div class="text-success">All Fees are paid</div>`,
                                            html: `<div class="text-secondary">No Fees are pending</div>`,
                                            confirmButtonText: 'Okay',
                                            confirmButtonColor: '#0b6fad',
                                            allowOutsideClick: false
                                        })

                                    } else {
                                        $('#totalfees').val(pending_fees)

                                        // Success
                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'Total Fees Calculated',
                                            timer: 3000,
                                            showConfirmButton: false
                                        });

                                    }

                                } else {

                                    $('#loading').css('display', 'none');
                                    $('#table_students tbody tr').text(response.responseJSON.error);
                                    console.log(response.responseJSON.error);
                                    $('#errors').fadeIn();
                                    $('#errors').css('display', 'block');
                                    $('#add-student-card button').attr('disabled', true)

                                }
                            },
                            error: function (response) {

                                if (response.responseJSON) {
                                    $('#loading').css('display', 'none');
                                    $('#errors').text(response.responseJSON.error);
                                    console.log(response.responseJSON.error);
                                    $('#errors').fadeIn();
                                    // $('#errors').css('display', 'block');
                                    $('#add-student-card button').attr('disabled', true)

                                } else {
                                    $('#errors').fadeIn();
                                    var errorMsg = `
                                    <center class="text-danger">
                                    <h2>Oops! Something went wrong</h2>
                                    <h4>
                                        Error Code: ${response.status} <br>
                                        Error Message: ${response.statusText}
                                    </h4>
                                    <h5>We were unable to fetch students list</h5>
                                    <h6>
                                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                    </h6>
                                    </center>`
                                    console.log(`something went wrong ${JSON.stringify(response)}`);
                                    // console.log(response.statusText);
                                    // $('#table_students tbody .col').html(errorMsg)
                                    $('#errors').html(errorMsg)
                                }

                            }
                        });

                    }




                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    } else {
        $('#totalfees').val('')
    }
})

$('#feespaid').keyup(() => {
    const feespaid = Number($('#feespaid').val())
    const totalfees = Number($('#totalfees').val())
    if (feespaid > 0 && feespaid <= totalfees) {
        $('#pendingfees').val(totalfees - feespaid)
    } else {
        $('#pendingfees').val(`Enter value between 1 and ${totalfees}`)
    }
})
$('#feespaid').change(() => {
    const feespaid = Number($('#feespaid').val())
    const totalfees = Number($('#totalfees').val())
    if (feespaid > 0 && feespaid <= totalfees) {
        $('#pendingfees').val(totalfees - feespaid)
    } else {
        $('#pendingfees').val(`Enter value between 1 and ${totalfees}`)
    }
})

function loadStudentsList() {

    $.ajax({
        url: '/sdp/students/special/data',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var students_list;
                $('#feestudent').text(response.data)

                if (response.data.length == 0) {
                    students_list += `<option value="">Student List is empty</option>`;
                } else {
                    students_list = `<option value="">Select Student Name</option>`;
                    response.data.forEach(student => {
                        students_list += `
                        <option value="${student._id}">${student.firstName} ${student.middleName} ${student.lastName}</option>`;
                    });
                }

                $('#studentname').html(students_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Students Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_students tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadStudentsList()

function loadUsersList() {

    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var users_list = ``;
                $('#collectedby').text(response.data)

                if (response.data.length == 0) {
                    users_list += `<option value="">User List is empty</option>`;
                } else {
                    users_list = `<option value="">Select User Name</option>`;
                    response.data.forEach(user => {

                        users_list += `
                        <option value="${user.slug}">${user.name} | ${user.role} | ${user.branch} Branch</option>`;
                    });
                }
                $('#collectedby').html(users_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Users Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_users tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-user-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch users list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_users tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadUsersList()
