
$('#no-birthday-available').fadeOut()
$('#table_birthdays,#myInput').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

// $('#sidebar-birthdays').trigger("click")
$('#sidebar-birthday-book').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

$('#new-birthday-btn').click(() => {
    document.location.replace('/sdp/admin/addbirthday');
})

const birthday_list = []
const message_list = [
    "Today is a great day to get started on another 365-day journey. It's a fresh start to new beginnings, new hopes, and great endeavors. Besides, be sure to have adventures along the way. Wishing you the best of today and every day in the future!",

    'This day is momentous, considering that you circumvented the sun once more. May this signify a series of greats for you- a great day, a great year, a great life. Thus, put on a smile and enjoy this day to the fullest. Happy Birthday!',

    'Be sure to wear a seat belt because your life is about to gear up and blast off into space. The warmest birthday greetings! Enjoy this day to your fullest!',

    "It's your birthday, and putting up a great smile on your face is warranted. It is crucial because nothing less is allowed on your birthday. Don't worry, we are not going to ask you for a treat.",

    "People say that you are the sum total of your experiences in your life. Well, your sum total must be pretty amazing because you are a great person. Wish you a great year filled with happiness ahead!",

    "Happy birthday to a wonderful person who means so many different things to our company!",

    "The warmest wishes to a great member of our team. May your special day be full of happiness, fun and cheer!",

    "Thank you for all your hard work during the past year. Wishing you a happy birthday and a great year to come!",

    "The time with you has been nothing much amazing. The way you inspire optimism and enthusiasm in all of us every day is miraculous. I only hope the best of things for you today and forever. Wish you a happy birthday.",

    "In this cut-throat completion, thank you for putting your trust on us. We hope we have been good on our part and promise to continue doing so. Wish you a happy birthday."
]

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

var isEmpty = true

function loadAllBirthdays() {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    var birthday_mails = null

    // Fetch users birthday mails
    $.ajax({
        url: '/sdp/users/birthdays',
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length != 0) {
                    birthday_mails = response.data
                }

            } else {

                $('#loading').css('display', 'none');
                $('#table_birthdays tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch birthdays list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_birthdays tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    })

    // Fetch birthdays
    $.ajax({
        url: '/sdp/users',
        method: 'get',
        success: function (response) {
            if (response.success) {
                // console.log(response.data);
                $('#table_birthdays tbody').html('<tr>Loading...</tr>')
                // console.log(response.data.length);
                // console.log(response.data[0]);
                $('#error,#loading').css('display', 'none')

                var tbody_birthdays;
                if (response.data.length == 0) {
                    var noBirthday = `
                    <img src="/images/birthdays/nobirthday.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Birthday List is empty</span> <br><br>
                        <span class="h5">Add Manager / Teacher / Student to get started
                        </span>
                    </div>`
                    $('#no-birthday-available').fadeIn()
                    $('#no-birthday-available').html(noBirthday)

                } else {
                    isEmpty = false
                    $('#table_birthdays,#myInput').fadeIn()
                    $('#view_note').fadeIn()
                    // var newelementCount = 0;
                    response.data.forEach(birthday => {

                        // // var utcCreatedDate = new Date(birthday.createdAt);
                        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                        // // var s = new Date(birthday.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                        // var createdHindiIST = new Date(birthday.createdAt).toLocaleDateString("hi-IN", options)
                        var createdEnglishIST = new Date(birthday.createdAt).toLocaleDateString("en-IN", options)

                        // For join Date
                        var dateOptions = { month: 'long', day: 'numeric' };
                        var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                        var today = new Date().toLocaleDateString("en-IN", dateOptions)
                        // var x = new Date(birthday.createdAt).getTimezoneOffset();
                        //Converted UTC to local(IST, etc.,,)
                        // console.log(utcCreatedDate.toUTCString());

                        // Check date
                        // optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        // var createdCheck = new Date(birthday.createdAt).toLocaleDateString("en-IN", optionsCheck)
                        var newElement;
                        if (birthdayDateEnglishIST === today) {
                            newElement = `<span class="badge badge-noti">Today</span>`
                            var msg = message_list[Math.floor(Math.random() * message_list.length)];
                            const subject = msg.slice(0, 90) + '...'
                            birthday_list.push([birthday.name, birthday.email, msg, subject])
                        } else {
                            newElement = ''
                        }

                        // Check mails sent
                        var mail_sent = ``;
                        if (birthday_mails != undefined) {

                            birthday_mails.forEach(mail => {
                                if (mail.email == birthday.email) {
                                    // Converting Date-Time to IST
                                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                                    var sentEnglishIST = new Date(mail.emailSendOn).toLocaleDateString("en-IN", options)

                                    mail_sent += `${sentEnglishIST} (By ${mail.createdBy.name})<br>`
                                }
                            })
                        }
                        if (mail_sent == ``) {
                            mail_sent = 'Not Send'
                        }

                        tbody_birthdays += `
                        <tr>
                            <td>
                                ${birthday.name} ${newElement}
                            </td>
                            <td>${birthdayDateEnglishIST}</td>
                            <td>${birthday.role}</td>
                            <td>${birthday.branch}</td>
                            <td>${mail_sent}</td>
                        </tr>`;
                    });

                    $('#table_birthdays tbody').html(tbody_birthdays)
                    $('#send-birthday-btn').removeAttr('disabled')

                }

                // Fetch students birthdays
                $.ajax({
                    url: '/sdp/students/birthday/data?select=dob,firstName,middleName,lastName,branch',
                    method: 'get',
                    success: function (response) {
                        if (response.success) {
                            // console.log(response.data);
                            // $('#table_birthdays tbody').text(response.data)
                            // console.log(response.data.length);
                            // console.log(response.data[0]);
                            $('#error,#loading').css('display', 'none')

                            if (response.data.length == 0 && isEmpty) {
                                var noBirthday = `
                                <img src="/images/birthdays/nobirthday.png" width="60" alt="">
                                <div class="h3 mt-2">
                                    <span class="font-weight-bold">Birthday List is empty</span> <br><br>
                                    <span class="h5">Add Manager / Teacher / Student to get started
                                    </span>
                                </div>`
                                $('#no-birthday-available').fadeIn()
                                $('#no-birthday-available').html(noBirthday)

                            } else {
                                isEmpty = false
                                $('#table_birthdays,#myInput').fadeIn()
                                $('#view_note').fadeIn()
                                // var newelementCount = 0;
                                response.data.forEach(birthday => {
                                    // // var utcCreatedDate = new Date(birthday.createdAt);
                                    // var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                                    // // var s = new Date(birthday.createdAt).toLocaleString(undefined, { timeZone: 'Asia/Kolkata' });
                                    // var createdHindiIST = new Date(birthday.createdAt).toLocaleDateString("hi-IN", options)
                                    // var createdEnglishIST = new Date(birthday.createdAt).toLocaleDateString("en-IN", options)

                                    // For join Date
                                    var dateOptions = { month: 'long', day: 'numeric' };
                                    var birthdayDateEnglishIST = new Date(birthday.dob).toLocaleDateString("en-IN", dateOptions)
                                    var today = new Date().toLocaleDateString("en-IN", dateOptions)
                                    // var x = new Date(birthday.createdAt).getTimezoneOffset();
                                    //Converted UTC to local(IST, etc.,,)
                                    // console.log(utcCreatedDate.toUTCString());

                                    // Check date
                                    // optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                                    // var createdCheck = new Date(birthday.createdAt).toLocaleDateString("en-IN", optionsCheck)
                                    var newElement;
                                    if (birthdayDateEnglishIST === today) {
                                        newElement = `<span class="badge badge-noti">Today</span>`
                                        var msg = message_list[Math.floor(Math.random() * message_list.length)];
                                        const subject = msg.slice(0, 90) + '...'
                                        birthday_list.push([birthday.firstName, birthday.email, msg, subject])
                                    } else {
                                        newElement = ''
                                    }

                                    // Check mails sent
                                    var mail_sent = ``;
                                    if (birthday_mails != undefined) {

                                        birthday_mails.forEach(mail => {
                                            if (mail.email == birthday.email) {
                                                // Converting Date-Time to IST
                                                var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                                                var sentEnglishIST = new Date(mail.emailSendOn).toLocaleDateString("en-IN", options)

                                                mail_sent += `${sentEnglishIST} (By ${mail.createdBy.name})<br>`
                                            }
                                        })
                                    }
                                    if (mail_sent == ``) {
                                        mail_sent = 'Not Send'
                                    }

                                    tbody_birthdays += `
                                    <tr>
                                        <td>
                                            ${birthday.firstName} ${birthday.middleName} ${birthday.lastName} ${newElement}
                                        </td>
                                        <td>${birthdayDateEnglishIST}</td>
                                        <td>Student</td>
                                        <td>${birthday.branch}</td>
                                        <td>${mail_sent}</td>
                                    </tr>`;
                                });


                                $('#table_birthdays tbody').html(tbody_birthdays)
                                // $('#table_birthdays tbody').html('Add birthday mail template in birthday book')

                                $('#send-birthday-btn').removeAttr('disabled')
                            }

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Birthdays Fetched Successfully',
                                timer: 5000,
                                showConfirmButton: false
                            });

                        } else {

                            $('#loading').css('display', 'none');
                            $('#table_birthdays tbody tr').text(response.responseJSON.error);
                            console.log(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-birthday-card button').attr('disabled', true)

                        }
                    },
                    error: function (response) {

                        if (response.responseJSON) {
                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            console.log(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-birthday-card button').attr('disabled', true)

                        } else {
                            var errorMsg = `
                            <center>
                            <h2>Oops! Something went wrong</h2>
                            <h4 class="text-danger">
                                Error Code: ${response.status} <br>
                                Error Message: ${response.statusText}
                            </h4>
                            <h5>We were unable to fetch birthdays list</h5>
                            <h6>
                                Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                            </h6>
                            </center>`
                            console.log(`something went wrong ${JSON.stringify(response)}`);
                            // console.log(response.statusText);
                            // $('#table_birthdays tbody .col').html(errorMsg)
                            $('#errorsection').html(errorMsg)
                        }

                    }
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_birthdays tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-birthday-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch birthdays list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_birthdays tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllBirthdays()

// Birthday JS | Ref: https://codepen.io/arcs/pen/XKKYZW
// helper functions
const PI2 = Math.PI * 2
const random = (min, max) => Math.random() * (max - min + 1) + min | 0
const timestamp = _ => new Date().getTime()

// container
class Birthday {
    constructor() {
        this.resize()

        // create a lovely place to store the firework
        this.fireworks = []
        this.counter = 0

    }

    resize() {
        this.width = canvas.width = window.innerWidth
        let center = this.width / 2 | 0
        this.spawnA = center - center / 4 | 0
        this.spawnB = center + center / 4 | 0

        this.height = canvas.height = window.innerHeight
        this.spawnC = this.height * .1
        this.spawnD = this.height * .5

    }

    onClick(evt) {
        let x = evt.clientX || evt.touches && evt.touches[0].pageX
        let y = evt.clientY || evt.touches && evt.touches[0].pageY

        let count = random(3, 5)
        for (let i = 0; i < count; i++) this.fireworks.push(new Firework(
            random(this.spawnA, this.spawnB),
            this.height,
            x,
            y,
            random(0, 260),
            random(30, 110)))

        this.counter = -1

    }

    update(delta) {
        ctx.globalCompositeOperation = 'hard-light'
        ctx.fillStyle = `rgba(20,20,20,${7 * delta})`
        ctx.fillRect(0, 0, this.width, this.height)

        ctx.globalCompositeOperation = 'lighter'
        for (let firework of this.fireworks) firework.update(delta)

        // if enough time passed... create new new firework
        this.counter += delta * 3 // each second
        if (this.counter >= 1) {
            this.fireworks.push(new Firework(
                random(this.spawnA, this.spawnB),
                this.height,
                random(0, this.width),
                random(this.spawnC, this.spawnD),
                random(0, 360),
                random(30, 110)))
            this.counter = 0
        }

        // remove the dead fireworks
        if (this.fireworks.length > 1000) this.fireworks = this.fireworks.filter(firework => !firework.dead)

    }
}

class Firework {
    constructor(x, y, targetX, targetY, shade, offsprings) {
        this.dead = false
        this.offsprings = offsprings

        this.x = x
        this.y = y
        this.targetX = targetX
        this.targetY = targetY

        this.shade = shade
        this.history = []
    }
    update(delta) {
        if (this.dead) return

        let xDiff = this.targetX - this.x
        let yDiff = this.targetY - this.y
        if (Math.abs(xDiff) > 3 || Math.abs(yDiff) > 3) { // is still moving
            this.x += xDiff * 2 * delta
            this.y += yDiff * 2 * delta

            this.history.push({
                x: this.x,
                y: this.y
            })

            if (this.history.length > 20) this.history.shift()

        } else {
            if (this.offsprings && !this.madeChilds) {

                let babies = this.offsprings / 2
                for (let i = 0; i < babies; i++) {
                    let targetX = this.x + this.offsprings * Math.cos(PI2 * i / babies) | 0
                    let targetY = this.y + this.offsprings * Math.sin(PI2 * i / babies) | 0

                    birthday.fireworks.push(new Firework(this.x, this.y, targetX, targetY, this.shade, 0))

                }

            }
            this.madeChilds = true
            this.history.shift()
        }

        if (this.history.length === 0) this.dead = true
        else if (this.offsprings) {
            for (let i = 0; this.history.length > i; i++) {
                let point = this.history[i]
                ctx.beginPath()
                ctx.fillStyle = 'hsl(' + this.shade + ',100%,' + i + '%)'
                ctx.arc(point.x, point.y, 1, 0, PI2, false)
                ctx.fill()
            }
        } else {
            ctx.beginPath()
            ctx.fillStyle = 'hsl(' + this.shade + ',100%,50%)'
            ctx.arc(this.x, this.y, 1, 0, PI2, false)
            ctx.fill()
        }

    }
}

let canvas = document.getElementById('birthday')
let ctx = canvas.getContext('2d')

let then = timestamp()

let birthday = new Birthday
window.onresize = () => birthday.resize()
document.onclick = evt => birthday.onClick(evt)
document.ontouchstart = evt => birthday.onClick(evt)

    ; (function loop() {
        requestAnimationFrame(loop)

        let now = timestamp()
        let delta = now - then

        then = now
        birthday.update(delta / 1000)


    })()
// Birthday JS End

$('#send-birthday-btn').click(() => {

    var data = ``
    if (birthday_list.length > 0) {

        birthday_list.forEach(user => {
            data += `<hr><h5 style="color: #91C442;">${user[0]} (${user[1]})</h5>
            Message: ${user[2]}`
        });
        Swal.fire({
            title: `<span style="color:#7c1131;font-weight:bold;">Today's Birthday List</span>`,
            showCloseButton: true,
            confirmButtonText: 'Send Email to all',
            confirmButtonColor: '#0b6fad',
            showDenyButton: true,
            denyButtonText: 'Randomise Messages',
            denyButtonColor: '#7c1131',
            focusConfirm: false,
            html: `Send Birthday Email with one click<br>${data}`,
            width: 'max-content',
            footer: `With this feature a random birthday message will be sent in the mail from pre-defined messages`
        }).then(async (result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'info',
                    title: 'Sending mail(s)...',
                    showConfirmButton: false
                });
                // console.log('Confirmed');
                var mails_sent = 0
                await birthday_list.forEach(user => {

                    // Send Birthday mail
                    $.ajax({
                        url: '/sdp/users/mail/birthday',
                        method: 'post',
                        dataType: 'json',
                        data: {
                            name: user[0],
                            email: user[1],
                            message: user[2],
                            subject: user[3]
                        },
                        success: function (response) {
                            if (response.success) {
                                mails_sent += 1
                                // console.log('Mails sent' + mails_sent);
                                if (mails_sent == birthday_list.length) {

                                    Swal.fire({
                                        icon: 'success',
                                        title: `Birthday mail(s) sent`,
                                        html: `Birthday mail sent to ${mails_sent} users`,
                                        showCloseButton: true,
                                        confirmButtonText: 'Okay',
                                        confirmButtonColor: '#0b6fad',
                                    }).then(async (result) => {
                                        if (result) {
                                            location.reload();
                                        }
                                    })

                                } else {

                                    Swal.fire({
                                        toast: true,
                                        position: 'top-right',
                                        icon: 'success',
                                        title: `${mails_sent} Birthday mail(s) sent`,
                                        showConfirmButton: false
                                    });

                                }
                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            // $('#error').text(response.responseJSON.error);
                            $('#error').html(`Error:<br>Status: ${JSON.stringify(response.status)} <br> Details: ${JSON.stringify(response.statusText)}`);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-branch-card button').attr('disabled', true)

                        }
                    })

                })

            } else if (result.isDenied) { // Ref: https://www.codegrepper.com/code-examples/javascript/sweet+alert+2+do+action+on+confirm
                // console.log('Denied');
                location.reload();
            }
        })

    } else {

        Swal.fire({
            title: "Today's Birthday List",
            confirmButtonText: 'Okay',
            html: `Send Birthday Email with one click<br><hr><h4>No Birthday Today</h4>`,
            showCloseButton: true
        });

    }

})