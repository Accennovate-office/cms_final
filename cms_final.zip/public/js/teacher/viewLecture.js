
$('#sidebar-lectures').trigger("click")
$('#sidebar-lectures,#sidebar-lectures-view').addClass('active')
$("div#mySidebar").scrollTop(400); // Ref: https://api.jquery.com/scrolltop/

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['lecture'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/lectures')
})

function loadLecturesList() {

    $.ajax({
        url: '/sdp/lectures',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var lectures_list;
                $('#viewlecture #lecture').text(response.data)

                if (response.data.length == 0) {
                    lectures_list += `<option value="">Lecture List is empty</option>`;
                } else {
                    lectures_list = `<option value="">Select Lecture Name</option>`;
                    response.data.forEach(lecture => {

                        // var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
                        // var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString("en-IN", dateOptions)
                        var optionsNew = { timeZone: 'UTC', year: 'numeric', month: 'long', day: 'numeric' };
                        // var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleDateString('en-US', optionsNew) // New Testing
                        // lectureDateTimeEnglishIST += '    -    '
                        var lectureDateTimeEnglishIST = new Date(lecture.dateTime).toLocaleTimeString('en-US', optionsNew) // New Testing

                        if (lecture._id == selected) {

                            lectures_list += `
                            <option selected value="${lecture._id}">${lectureDateTimeEnglishIST} > ${lecture.teacher.name}</option>`;

                        } else {

                            lectures_list += `
                            <option value="${lecture._id}">${lectureDateTimeEnglishIST} > ${lecture.teacher.name}</option>`;

                        }

                    });
                }

                $('#viewlecture #lecture').html(lectures_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Lectures Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_lectures tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-lecture-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch lectures list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_lectures tbody .col').html(errorMsg)
                $('#no-lecture-selected').html(errorMsg)
            }

        }
    });

}
loadLecturesList()

function getLectureDetails() {

    const selectLecture = $('#lecture').val() ? $('#lecture').val() : selected
    // console.log(selectLecture);
    if (selectLecture == '') {
        $('#no-lecture-selected').css('display', 'block')
        $('#lecture-selected').css('display', 'none')
    } else {

        $('#no-lecture-selected').css('display', 'none')
        $('#lecture-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/lectures/${selectLecture}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#viewlecture #lecture-selected').html(`<h2>Loading...</h2>`)

                    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                    var createdHindiIST = new Date(response.data.createdAt).toLocaleDateString("hi-IN", options)
                    var createdEnglishIST = new Date(response.data.createdAt).toLocaleDateString("en-IN", options)
                    // var lectureDateTimeEnglishIST = new Date(response.data.dateTime).toLocaleDateString("en-IN", options) // Previous
                    // var lectureDateTimeEnglishIST = new Date(response.data.dateTime).toLocaleDateString("en-US", options) // New Testing
                    var optionsNew = { timeZone: 'UTC', year: 'numeric', month: 'long', day: 'numeric' };
                    // var lectureDateTimeEnglishIST = new Date(response.data.dateTime).toLocaleDateString('en-US', optionsNew) // New Testing
                    // lectureDateTimeEnglishIST += '    -    '
                    var lectureDateTimeEnglishIST = new Date(response.data.dateTime).toLocaleTimeString('en-US', optionsNew) // New Testing

                    var updateValue = response.data.updatedAt ? response.data.updatedAt : 'Not updated'
                    // Converting update value from UTC to GMT
                    if (updateValue != 'Not updated') {
                        // Hindi Date time
                        // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                        updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                    }

                    var student_details = ''
                    const student_string = response.data.student.split(',')
                    // console.log(response.data.studentcationalQualification);
                    student_string.forEach(student => {
                        student_details += `<span class="badge badge-light mt-2">${student}</span>`
                    });


                    var lecture_data = `
                    <div class="d-flex mb-3 pl-1">
                        <img src="/images/lectures/${response.data.lectureOrExam}.png" width="70" alt="">
                        <div align="left" class="ml-4 pt-3">
                            <h2>${response.data.lectureOrExam} Details</h2>
                            <!-- <small>Lecture Details</small> -->
                        </div>
                    </div>

                    <!-- Basic Details -->
                    <h5 align="left" class="text-success bg-dark mb-0 py-2 pl-2">Basic Details</h5>
                    <hr class="bg-success mt-0 mb-2">

                    <div class="d-flex justify-content-between">
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user-tie" aria-hidden="true"></i>
                                <small>Teacher Name</small>
                            </div>
                            <h4>${response.data.teacher.name}</h4>
                        </div>
                        <div align="left" class="mt-0">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-book" aria-hidden="true"></i>
                                <small>Course Name</small>
                            </div>
                            <h4>${response.data.course.name}</h4>
                        </div>
                    </div>

                    <div align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <small>Students in Lecture</small>
                        </div>
                        <h4>${student_details}</h4>
                    </div>

                    <div align="left" class="d-flex justify-content-between mt-2">
                        <div>
                            <div align="left" class="d-flex mt-2">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Lecture Date & Time</small>
                            </div>
                            <h5 class="d-flex">${lectureDateTimeEnglishIST}</h5>
                        </div>
                    </div>

                    <div align="left" class="mt-2">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-list" aria-hidden="true"></i>
                            <small>Topics Covered</small>
                        </div>
                        <h5>${response.data.topicsCovered}</h5>
                    </div>


                    <div class="d-flex justify-content-between mt-5">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-user-edit" aria-hidden="true"></i>
                                <small>Created By</small>
                            </div>
                            <div>${response.data.createdBy.name} (${response.data.createdBy.role})</div>
                        </div>
                        <div class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Created At</small>
                            </div>
                            <div>${createdEnglishIST}</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-1">
                        <div align="left" class="mt-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <small>Updated At</small>
                            </div>
                            <div>${updateValue}</div>
                        </div>
                    </div>`;

                    $('#viewlecture #lecture-selected').html(lecture_data)

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Lecture Fetched Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_lectures tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-lecture-card button').attr('disabled', true)
                    $('#lecture-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-lecture-card button').attr('disabled', true)
                    $('#lecture-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch lectures list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_lectures tbody .col').html(errorMsg)
                    $('#lecture-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#no-lecture-selected').css('display', 'block') // block
$('#lecture-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getLectureDetails()
}
$('#lecture').change(() => {

    getLectureDetails()

})