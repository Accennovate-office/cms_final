import { getUrlVars } from "../services/getData.js";

$('#sidebar-students').trigger("click")
$('#sidebar-students,#sidebar-students-view').addClass('active')
$("div#mySidebar").scrollTop(250); // Ref: https://api.jquery.com/scrolltop/

const selected = getUrlVars()['student'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);
var ref_id = ''

$('#new-admission-btn').click(() => {
    document.location.replace('/sdp/teacher/addadmission');
})
$('#new-lecture-btn').click(() => {
    document.location.replace('/sdp/teacher/addlecture');
})
$('#new-fee-btn').click(() => {
    document.location.replace('/sdp/teacher/addfee');
})

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/students')
})
$('#edit-student').click(() => {
    document.location.replace(`/sdp/teacher/editstudent?student=${selected}`)
})

// function calculateAge(birthdate) {
//     // Calculate Age // Ref: https://www.javatpoint.com/calculate-age-using-javascript
//     var mdate = birthdate.toString();  
//     var dobYear = parseInt(mdate.substring(0,4), 10);  
//     var dobMonth = parseInt(mdate.substring(5,7), 10);  
//     var dobDate = parseInt(mdate.substring(8,10), 10);
//     // console.log(mdate);
//     // console.log(dobYear, dobMonth, dobDate);
//     //get the current date from system  
//     var today = new Date();  
//     //date string after broking  
//     var birthday = new Date(dobYear, dobMonth-1, dobDate);  

//     //calculate the difference of dates  
//     var diffInMillisecond = today.valueOf() - birthday.valueOf();  

//     //convert the difference in milliseconds and store in day and year variable          
//     var year_age = Math.floor(diffInMillisecond / 31536000000);  
//     var day_age = Math.floor((diffInMillisecond % 31536000000) / 86400000);  

//     //when birth date and month is same as today's date        
//     if ((today.getMonth() == birthday.getMonth()) && (today.getDate() == birthday.getDate())) {  
//             alert("Happy Birthday!");  
//         }  

//     var month_age = Math.floor(day_age/30);
//     return [year_age,month_age]
// }

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

var student_profile;
var courses;
var lectures;
var fees;
// Date options
var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
var short_options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };

$('#admission-close').click(() => {
    // Hide box
    $('#single-course-box').css('display', 'none')
})
$('#lecture-close').click(() => {
    // Hide box
    $('#single-lecture-box').css('display', 'none')
})
$('#fee-close').click(() => {
    // Hide box
    $('#single-fee-box').css('display', 'none')
})

function displayAdmissionDetails(admissionDetails, ID) {
    // alert('ID '+ID)
    // console.log(admissionDetails);
    let newArray = admissionDetails.filter(function (dl) {
        return dl._id == ID;
    });
    // console.log(newArray);
    var singleAdmission = newArray[0]
    // var date_options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    var admission_date = new Date(singleAdmission.admissionDate).toLocaleDateString("en-IN", date_options)
    var enrollment_date = ''
    if (singleAdmission.enrollmentPaymentDate) {
        enrollment_date = new Date(singleAdmission.enrollmentPaymentDate).toLocaleDateString("en-IN", date_options)
    }
    // var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
    var admission_createdat = new Date(singleAdmission.createdAt).toLocaleDateString("en-IN", options)
    var admission_updatedat = singleAdmission.updatedAt ? new Date(singleAdmission.updatedAt).toLocaleDateString("en-IN", options) : 'empty'

    $('#course-title').html(singleAdmission.course ? singleAdmission.course.name : 'Empty');
    $('#admission-date').html(admission_date);
    $('#admission-fees').html(singleAdmission.fees);
    $('#payment-mode').html(singleAdmission.installment ? 'Installment' : 'One-time');
    $('#teacher-allocated').html(singleAdmission.teacher ? singleAdmission.teacher.name : 'Empty');
    $('#batch-time').html(singleAdmission.batch);
    if (singleAdmission.installment) {
        var installment_date = new Date(singleAdmission.installmentdate).toLocaleDateString("en-IN", date_options)
        $('#installment-date').html(installment_date);
        $('#installment-date-box').css('display', 'block');
    } else {
        $('#installment-date-box').css('display', 'none');
    }
    $('#roll-no').html(singleAdmission.rollNo ? singleAdmission.rollNo : 'empty');
    singleAdmission.rollNo ? $('#roll-no').removeClass('empty') : $('#roll-no').addClass('empty');
    // Enrollment Details
    $('#enrollment-number').html(singleAdmission.enrollmentNo ? singleAdmission.enrollmentNo : 'empty');
    singleAdmission.enrollmentNo ? $('#enrollment-number').removeClass('empty') : $('#enrollment-number').addClass('empty');
    $('#enrollment-month').html(singleAdmission.enrollmentMonth ? singleAdmission.enrollmentMonth : 'empty');
    singleAdmission.enrollmentMonth ? $('#enrollment-month').removeClass('empty') : $('#enrollment-month').addClass('empty');
    $('#enrollment-paymentDate').html(enrollment_date ? enrollment_date : 'empty');
    enrollment_date ? $('#enrollment-paymentDate').removeClass('empty') : $('#enrollment-paymentDate').addClass('empty');
    // More Details (Admin)
    $('#admission-createdby').html(`${singleAdmission.createdBy ? singleAdmission.createdBy.name : 'Empty'} (${singleAdmission.createdBy ? singleAdmission.createdBy.branch : 'Empty'} - ${singleAdmission.createdBy ? singleAdmission.createdBy.role : 'Empty'})`);
    $('#admission-createdat').html(admission_createdat);
    $('#admission-updatedat').html(admission_updatedat);
    singleAdmission.updatedAt ? $('#admission-updatedat').removeClass('empty') : $('#admission-updatedat').addClass('empty');
    // Display box
    $('#single-course-box').css('display', 'block')
    window.scrollTo(0, 450);
}

function displayLectureDetails(lectureDetails, ID) {
    let newArray = lectureDetails.filter(function (dl) {
        return dl._id == ID;
    });
    var singleLecture = newArray[0]

    // var date_options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
    var lecture_dateTime = new Date(singleLecture.dateTime).toLocaleDateString("en-IN", short_options)
    // var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };
    var lecture_createdat = singleLecture.createdAt ? new Date(singleLecture.createdAt).toLocaleDateString("en-IN", options) : 'empty'
    var lecture_updatedat = singleLecture.updatedAt ? new Date(singleLecture.updatedAt).toLocaleDateString("en-IN", options) : 'empty'

    $('#lecture-title').html(singleLecture.course ? singleLecture.course.name : 'Empty');
    $('#lecture-datetime').html(lecture_dateTime);
    $('#lecture-topic').html(singleLecture.topicsCovered);
    $('#lecture-takenby').html(singleLecture.teacher ? singleLecture.teacher.name : 'Empty');
    // More details (Admin)
    $('#lecture-createdby').html(`${singleLecture.createdBy ? singleLecture.createdBy.name : 'Empty'} (${singleLecture.createdBy ? singleLecture.createdBy.branch : 'Empty'} - ${singleLecture.createdBy ? singleLecture.createdBy.role : 'Empty'})`);
    $('#lecture-createdat').html(lecture_createdat);
    $('#lecture-updatedat').html(lecture_updatedat);
    singleLecture.updatedAt ? $('#lecture-updatedat').removeClass('empty') : $('#lecture-updatedat').addClass('empty');
    // Display box
    $('#single-lecture-box').css('display', 'block')
    window.scrollTo(0, 450);
}

function displayFeeDetails(feeDetails, ID) {
    let newArray = feeDetails.filter(function (dl) {
        return dl._id == ID;
    });
    var singleFee = newArray[0]
    // console.log(singleFee);
    $('#receipt-amount').html(`₹ ${singleFee.feesPaid}`)
    $('#receipt-number').html(singleFee.receiptNo)
    var fee_dateTime = new Date(singleFee.paymentDate).toLocaleDateString("en-IN", date_options)
    $('#receipt-paymentDate').html(fee_dateTime)
    $('#receipt-amount2').html(`₹ ${singleFee.feesPaid}`)
    $('#receipt-mode').html(capitalizeFirstLetter(singleFee.paymentMethod))

    var studentFullName = `${capitalizeFirstLetter(singleFee.student ? singleFee.student.firstName : 'Empty')} ${capitalizeFirstLetter(singleFee.student ? singleFee.student.middleName : 'Empty')} ${capitalizeFirstLetter(singleFee.student ? singleFee.student.lastName : 'Empty')}`
    $('#receipt-paymentFrom').html(studentFullName)
    $('#receipt-paymentReceived').html(singleFee.collectedBy ? singleFee.collectedBy.name : 'Empty')
    // console.log(`${singleFee.collectedBy.branch} (${singleFee.collectedBy.role})`);
    $('#receipt-paymentReceiveddetails').html(`${singleFee.collectedBy ? singleFee.collectedBy.branch : 'Empty'} (${singleFee.collectedBy ? singleFee.collectedBy.role : 'Empty'})`);
    $('#pendingFees').html(`₹ ${singleFee.pendingFees}`)

    // // More details (Admin)
    var receipt_createdat = singleFee.createdAt ? new Date(singleFee.createdAt).toLocaleDateString("en-IN", options) : 'empty'
    var receipt_updatedat = singleFee.updatedAt ? new Date(singleFee.updatedAt).toLocaleDateString("en-IN", options) : 'empty'

    $('#receipt-createdby').html(`${singleFee.createdBy ? singleFee.createdBy.name : 'Empty'} (${singleFee.createdBy ? singleFee.createdBy.branch : 'Empty'} - ${singleFee.createdBy ? singleFee.createdBy.role : 'Empty'})`);
    $('#receipt-createdat').html(receipt_createdat);
    $('#receipt-updatedat').html(receipt_updatedat);
    singleFee.updatedAt ? $('#receipt-updatedat').removeClass('empty') : $('#receipt-updatedat').addClass('empty');
    // Display box
    $('#single-fee-box').css('display', '')
    window.scrollTo(0, 450);
}

function getStudentDetails() {


    const selectStudent = $('#student').val() ? $('#student').val() : selected
    // console.log(selectStudent);
    if (selectStudent == '') {
        $('#no-student-selected').css('display', 'block')
        $('#student-selected').css('display', 'none')
    } else {

        $('#no-student-selected').css('display', 'none')
        $('#student-selected').css('display', 'block')

        $.ajax({
            url: `/sdp/students/${selectStudent}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    ref_id = response.data.reference._id
                    // New UI Fetching data ###############################################
                    student_profile = response.data // Student profile
                    courses = response.courses // Admission data
                    lectures = response.lectures // Lecture data
                    fees = response.fees // Fees data

                    // Check if student is enrolled for course
                    if (courses.length > 0) {
                        // displayAdmissionDetails(courses) // Temporary display
                        $('#admission-list-title').html(' enrolled for courses')
                        $('#single-course-box').css('display', 'none')
                        $('#admission-list').css('display', '')
                        $('#new-admission-box').css('display', 'none')
                    } else {
                        $('#admission-list-title').html(' is not enrolled for any course')
                        $('#single-course-box').css('display', 'none')
                        $('#admission-list').css('display', 'none')
                        $('#new-admission-box').css('display', 'block')
                    }

                    if (lectures.length > 0) {
                        // displayLectureDetails(lectures) // Temporary display
                        $('#lecture-list-title').html('Lectures attended by ')
                        $('#courses').css('display', 'block')
                        $('#single-lecture-box').css('display', 'none')
                        $('#lecture-list').css('display', '')
                        $('#new-lecture-box').css('display', 'none')
                    } else {
                        $('#lecture-list-title').html('No lectures attended by ')
                        $('#courses').css('display', 'none')
                        $('#single-lecture-box').css('display', 'none')
                        $('#lecture-list').css('display', 'none')
                        $('#new-lecture-box').css('display', 'block')
                    }

                    if (fees.length > 0) {
                        // displayFeeDetails(fees) // Temporary display
                        $('#fee-list-title').html('Fee records of ')
                        $('#single-fee-box').css('display', 'none')
                        $('#fee-list').css('display', '')
                        $('#new-fee-box').css('display', 'none')
                    } else {
                        $('#fee-list-title').html('No fee records of ')
                        $('#single-fee-box').css('display', 'none')
                        $('#fee-list').css('display', 'none')
                        $('#new-fee-box').css('display', 'block')
                    }

                    // Calculating Fees
                    var feesPaid_percentage = 0
                    var feesPaid = 0;
                    var totalFees = 0;
                    courses.forEach(courseTaken => {
                        totalFees += courseTaken.fees;
                    });
                    if (fees.length > 0) {
                        fees.forEach(feeRecord => {
                            feesPaid += feeRecord.feesPaid;
                        });
                        feesPaid_percentage = (feesPaid / totalFees) * 100;
                        // console.log(feesPaid, totalFees);
                    }

                    // Display 4 main cards data
                    // const age = calculateAge(student_profile.dob)  
                    const firstName = capitalizeFirstLetter(student_profile.firstName)
                    const middleName = capitalizeFirstLetter(student_profile.middleName)
                    const lastName = capitalizeFirstLetter(student_profile.lastName)

                    $('#student_name').html(`${firstName} ${middleName} ${lastName}`)
                    $('#courses_count').html(courses.length)
                    $('#lectures_count').html(lectures.length)
                    $('#fees_paid_percentage').html(`${parseInt(feesPaid_percentage)} %`)
                    $('#age').html(student_profile.phone1)

                    $('.firstName').html(firstName)

                    // List all courses
                    var courses_list = ``;
                    var admission_id_list = [];
                    var dropdown_list = `<option selected value="">All</option>`;
                    // console.log(courses);
                    courses.forEach(courseTaken => {

                        // Calculate lectures count
                        var lectures_count = 0;
                        lectures.forEach(lectureData => {
                            if (lectureData.course.name == courseTaken.course.name && lectureData.student == `${firstName} ${middleName} ${lastName}`) {
                                lectures_count++
                            }
                    });

                        // Calculate course fees
                        var course_fees_paid = 0;
                        const course_fees_total = courseTaken.fees;
                        course_fees_paid = (feesPaid_percentage * course_fees_total) / 100;
                        // <td><a id="admission-${courseTaken._id}>${courseTaken.course.name}</a></td>
                        admission_id_list.push(courseTaken._id);
                        courses_list += `
                        <tr id="admission-${courseTaken._id}" class="highlight-row pointer">
                            <td>${courseTaken.course ? courseTaken.course.name : 'Empty'}</td>
                            <td>${lectures_count}</td>
                            <td>${Math.round(course_fees_paid)} / ${course_fees_total} (${parseInt(feesPaid_percentage)}%)</td>
                            <td>${courseTaken.teacher ? courseTaken.teacher.name : 'Empty'}</td>
                        </tr>`

                        // Create admission filter dropdown
                        dropdown_list += `<option value="${courseTaken.course ? courseTaken.course._id : ''}">${courseTaken.course ? courseTaken.course.name : 'Empty'}</option>`
                    });
                    $('#courses').html(dropdown_list);
                    console.log(courses_list);
                    $('#courses_list').html(courses_list);
                    $('#total_lectures').html(lectures.length);
                    $('#total_fees').html(`${feesPaid} / ${totalFees} (${parseInt(feesPaid_percentage)}%)`);
                    // console.log(admission_id_list);
                    admission_id_list.forEach(adm => {
                        $(`#admission-${adm}`).click(() => {
                            // alert(`admission-${adm}`)
                            displayAdmissionDetails(courses, adm)
                        })
                    });

                    // List all lectures
                    var lectures_list = ``;
                    var lectures_id_list = [];
                    // console.log(lectures);
                    lectures.forEach(lectureRecord => {

                        var lecture_datetime = new Date(lectureRecord.dateTime).toLocaleDateString("en-IN", short_options)

                        lectures_id_list.push(lectureRecord._id);
                        lectures_list += `
                        <tr id="lecture-${lectureRecord._id}" class="highlight-row pointer">
                            <td>${lecture_datetime}</td>
                            <td>${lectureRecord.topicsCovered}</td>
                            <td>${lectureRecord.teacher ? lectureRecord.teacher.name : 'Empty'}</td>
                        </tr>`
                    });
                    // console.log(lectures_list);
                    // document.getElementById('lectures_list').innerHTML = lectures_list;
                    $('#lectures_list').html(lectures_list);
                    console.log(lectures_list.length);
                    lectures_id_list.forEach(adm => {
                        $(`#lecture-${adm}`).click(() => {
                            // alert(`admission-${adm}`)
                            displayLectureDetails(lectures, adm)
                        })
                    });

                    // List all fee records
                    var fees_list = ``;
                    var fees_id_list = [];
                    // console.log(fees);
                    fees.forEach(feeRecord => {

                        var feePayment_date = new Date(feeRecord.paymentDate).toLocaleDateString("en-IN", date_options)

                        fees_id_list.push(feeRecord._id);
                        fees_list += `
                        <tr id="fee-${feeRecord._id}" class="highlight-row pointer">
                            <td>${feeRecord.feesPaid}</td>
                            <td>${feeRecord.pendingFees}</td>
                            <td>${feePayment_date}</td>
                            <td>${feeRecord.collectedBy ? feeRecord.collectedBy.name : 'Empty'} (${feeRecord.collectedBy ? feeRecord.collectedBy.branch : 'Empty'} - ${feeRecord.collectedBy ? feeRecord.collectedBy.role : 'Empty'})</td>
                        </tr>`
                    });
                    // console.log(fees_list);
                    // document.getElementById('fees_list').innerHTML = fees_list;
                    $('#fees_list').html(fees_list);
                    fees_id_list.forEach(adm => {
                        $(`#fee-${adm}`).click(() => {
                            // alert(`admission-${adm}`)
                            displayFeeDetails(fees, adm)
                        })
                    });

                    // Display student profile details
                    $('#student-fullName').html(`${firstName} ${middleName} ${lastName}`)
                    $('#student-branch').html(student_profile.branch)
                    $('#student-category').html(student_profile.category)
                    $('#student-categoryPhoto').attr('src',`/images/students/${student_profile.category.toLowerCase()}.png`)
                    $('#student-categoryPhoto').attr('alt',student_profile.category)
                    var dobEnglishIST = new Date(student_profile.dob).toLocaleDateString("en-IN", date_options)
                    $('#student-dob').html(dobEnglishIST)
                    $('#student-gender').html(student_profile.gender)
                    $('#student-religion').html(student_profile.religion)
                    $('#student-caste').html(student_profile.caste)
                    // Aadhaar number validation if available or not
                    var aadhaarNumber
                    if (student_profile.aadhaarNo) {
                        var aNo = student_profile.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                        $('#student-aadhaar').removeClass('empty')
                    } else {
                        aadhaarNumber = 'empty'
                        $('#student-aadhaar').addClass('empty')
                    }
                    $('#student-aadhaar').html(aadhaarNumber)
                    $('#student-college').html(student_profile.schoolOrCollegeName)
                    $('#student-class').html(student_profile.classOrTuitionName)

                    var edu_details = ''
                    // console.log(response.data.qualification);
                    const qualification_string = student_profile.qualification.split(',')
                    qualification_string.forEach(edu => {
                        edu_details += `<span class="badge badge-light mt-0">${edu}</span>`
                    });
                    $('#student-qualification').html(edu_details)
                    $('#student-phone1').html(student_profile.phone1)
                    $('#student-phone2').html(student_profile.phone2 ? student_profile.phone2 : 'empty')
                    student_profile.phone2 ? $('#student-phone2').removeClass('empty') : $('#student-phone2').addClass('empty');
                    $('#student-parentPhone').html(student_profile.parentPhone ? student_profile.parentPhone : 'empty')
                    student_profile.parentPhone ? $('#student-parentPhone').removeClass('empty') : $('#student-parentPhone').addClass('empty');
                    $('#student-email').html(student_profile.email)
                    $('#student-address').html(student_profile.address)
                    $('#student-fatherOccupation').html(student_profile.fatherOccupation)
                    $('#student-motherName').html(student_profile.motherName)
                    $('#student-motherTongue').html(student_profile.motherTongue)

                    $('#student-facebook').html(student_profile.facebook ? student_profile.facebook : 'empty')
                    student_profile.facebook ? $('#student-facebook').removeClass('empty') : $('#student-facebook').addClass('empty');
                    $('#student-instagram').html(student_profile.instagram ? student_profile.instagram : 'empty')
                    student_profile.instagram ? $('#student-instagram').removeClass('empty') : $('#student-instagram').addClass('empty');
                    $('#student-youtube').html(student_profile.youtube ? student_profile.youtube : 'empty')
                    student_profile.youtube ? $('#student-youtube').removeClass('empty') : $('#student-youtube').addClass('empty');
                    $('#student-twitter').html(student_profile.twitter ? student_profile.twitter : 'empty')
                    student_profile.twitter ? $('#student-twitter').removeClass('empty') : $('#student-twitter').addClass('empty');
                    $('#student-linkedin').html(student_profile.linkedin ? student_profile.linkedin : 'empty')
                    student_profile.linkedin ? $('#student-linkedin').removeClass('empty') : $('#student-linkedin').addClass('empty'); 

                    // Reference Details
                    // // Adding dummy data
                    // student_profile.reference.ref1Name = 'Suresh Pawar'
                    // student_profile.reference.ref1Phone = '90232321412'
                    // student_profile.reference.ref1Category = 'Service'
                    // student_profile.reference.ref1Area = 'Gupte Raod, Near station - East'
                    // student_profile.reference.ref2Name = 'Suresh Pawar'
                    // student_profile.reference.ref2Phone = '90232321412'
                    // student_profile.reference.ref2Category = 'HomeMaker'
                    // student_profile.reference.ref2Area = 'Gupte Raod, Near station - East'
                    // student_profile.reference.ref3Name = 'Suresh Pawar'
                    // student_profile.reference.ref3Phone = '90232321412'
                    // student_profile.reference.ref3Category = 'Student'
                    // student_profile.reference.ref3Area = 'Gupte Raod, Near station - East'
                    // // Dummy data end
                    var reference_details = ''
                    if (student_profile.reference) {
                        $('#reference-box').removeClass('empty');
                        if (student_profile.reference.ref1Name || student_profile.reference.ref1Phone || student_profile.reference.ref1Category || student_profile.reference.ref1Area) {
                            reference_details += `
                            <div class="row reference-details">
                                <div class="col col-4">
                                    <img class="profile" src="/images/students/${student_profile.reference.ref1Category ? student_profile.reference.ref1Category : 'profile'}.png" alt="${student_profile.reference.ref1Category ? student_profile.reference.ref1Category : ''}" width="43">
                                    <div style="font-size: 13px;">${student_profile.reference.ref1Category ? student_profile.reference.ref1Category : 'empty'}</div>
                                </div>
                                <div align="left" class="col col-8 p-0">
                                    <div class="ref-name">${student_profile.reference.ref1Name ? student_profile.reference.ref1Name : 'empty'}</div>
                                    <div class="ref-phone">${student_profile.reference.ref1Phone ? student_profile.reference.ref1Phone : 'empty'}</div>
                                    <div class="ref-area">Area: ${student_profile.reference.ref1Area ? student_profile.reference.ref1Area : 'empty'}</div>
                                </div>
                            </div>`
                        }
                        if (student_profile.reference.ref2Name || student_profile.reference.ref2Phone || student_profile.reference.ref2Category || student_profile.reference.ref2Area) {
                            reference_details += `
                            <div class="row reference-details">
                                <div class="col col-4">
                                    <img class="profile" src="/images/students/${student_profile.reference.ref2Category ? student_profile.reference.ref2Category : 'profile'}.png" alt="${student_profile.reference.ref2Category ? student_profile.reference.ref2Category : ''}" width="43">
                                    <div style="font-size: 13px;">${student_profile.reference.ref2Category ? student_profile.reference.ref2Category : 'empty'}</div>
                                </div>
                                <div align="left" class="col col-8 p-0">
                                    <div class="ref-name">${student_profile.reference.ref2Name ? student_profile.reference.ref2Name : 'empty'}</div>
                                    <div class="ref-phone">${student_profile.reference.ref2Phone ? student_profile.reference.ref2Phone : 'empty'}</div>
                                    <div class="ref-area">Area: ${student_profile.reference.ref2Area ? student_profile.reference.ref2Area : 'empty'}</div>
                                </div>
                            </div>`
                        }
                        if (student_profile.reference.ref3Name || student_profile.reference.ref3Phone || student_profile.reference.ref3Category || student_profile.reference.ref3Area) {
                            reference_details += `
                            <div class="row reference-details">
                                <div class="col col-4">
                                    <img class="profile" src="/images/students/${student_profile.reference.ref3Category ? student_profile.reference.ref3Category : 'profile'}.png" alt="${student_profile.reference.ref3Category ? student_profile.reference.ref3Category : ''}" width="43">
                                    <div style="font-size: 13px;">${student_profile.reference.ref3Category ? student_profile.reference.ref3Category : 'empty'}</div>
                                </div>
                                <div align="left" class="col col-8 p-0">
                                    <div class="ref-name">${student_profile.reference.ref3Name ? student_profile.reference.ref3Name : 'empty'}</div>
                                    <div class="ref-phone">${student_profile.reference.ref3Phone ? student_profile.reference.ref3Phone : 'empty'}</div>
                                    <div class="ref-area">Area: ${student_profile.reference.ref3Area ? student_profile.reference.ref3Area : 'empty'}</div>
                                </div>
                            </div>`
                        }
                        if (!student_profile.reference.ref1Name && !student_profile.reference.ref1Phone && !student_profile.reference.ref1Category && !student_profile.reference.ref1Area && !student_profile.reference.ref2Name && !student_profile.reference.ref2Phone && !student_profile.reference.ref2Category && !student_profile.reference.ref2Area && !student_profile.reference.ref3Name && !student_profile.reference.ref3Phone && !student_profile.reference.ref3Category && !student_profile.reference.ref3Area) {
                            reference_details = 'No reference detials added'
                            $('#reference-box').addClass('empty');
                        }
                    } else {
                        reference_details = 'No reference detials added'
                        $('#reference-box').addClass('empty');
                    }
                    $('#reference-box').html(reference_details)

                    // New UI Fetching data end ###############################################

                    // Swal.fire({
                    //     toast: true,
                    //     position: 'top-right',
                    //     icon: 'success',
                    //     title: 'Student Fetched Successfully',
                    //     timer: 3000,
                    //     showConfirmButton: false
                    // });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)
                    $('#student-selected').html(response.responseJSON.error)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)
                    $('#student-selected').html(response.responseJSON.error)

                } else {
                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch students list</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(response);
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#student-selected').html(errorMsg)
                }

            }
        });
    }
}

$('#courses').change(() => {
    var course = $('#courses').val()
    // Add course name to list title after changing dropdown
    if (course) {
        var courseName = $('#courses option:selected').text();
        // console.log(courseName);
        $("#lecture-course").html(` for ${courseName}`)
    } else {
        $("#lecture-course").html(``)
    }
    // console.log(course);
    // List all lectures
    var lectures_list = ``;
    var lectures_id_list = [];
    // console.log(lectures);
    lectures.forEach(lectureRecord => {
        // console.log(lectureRecord.course._id, course);
        if (lectureRecord.course._id == course && course != '') {

            var lecture_datetime = new Date(lectureRecord.dateTime).toLocaleDateString("en-IN", short_options)

            lectures_id_list.push(lectureRecord._id);
            lectures_list += `
            <tr id="lecture-${lectureRecord._id}" class="highlight-row pointer">
                <td>${lecture_datetime}</td>
                <td>${lectureRecord.topicsCovered}</td>
                <td>${lectureRecord.teacher ? lectureRecord.teacher.name : 'Empty'}</td>
            </tr>`
        } else if (course == '') {
            var lecture_datetime = new Date(lectureRecord.dateTime).toLocaleDateString("en-IN", short_options)

            lectures_id_list.push(lectureRecord._id);
            lectures_list += `
            <tr id="lecture-${lectureRecord._id}" class="highlight-row pointer">
                <td>${lecture_datetime}</td>
                <td>${lectureRecord.topicsCovered}</td>
                <td>${lectureRecord.teacher ? lectureRecord.teacher.name : 'Empty'}</td>
            </tr>`
        }
    });
    if (lectures_list === '') {
        lectures_list = `
        <tr>
            <td>No Lectures attended</td>
        </tr>`
    }
    // console.log(lectures_list);
    $('#lectures_list').html(lectures_list);
    // Hide box
    $('#single-lecture-box').css('display', 'none')

    lectures_id_list.forEach(adm => {
        $(`#lecture-${adm}`).click(() => {
            // alert(`admission-${adm}`)
            displayLectureDetails(lectures, adm)
        })
    });


})

$('#no-student-selected').css('display', 'block') // block
$('#student-selected').css('display', 'none') // none
if (selected != undefined) {
    // console.log('inside');
    getStudentDetails()
}

$('#profile-line').css('width', '100%');
$('#course-line,#lecture-line,#fee-line').css('width', '50%');
$('#course-section,#lecture-section,#fee-section').css('display', 'none');
function resetAllArrows() {
    $('#course-line,#lecture-line,#fee-line,#profile-line').css('width', '50%');
    $('#course-section,#lecture-section,#fee-section,#profile-section').css('display', 'none');
}

$('#profile-container').click(() => {
    resetAllArrows()
    $('#profile-line').css('width', '100%');
    $('#profile-section').css('display', 'block');
})
$('#course-container').click(() => {
    resetAllArrows()
    $('#course-line').css('width', '100%');
    $('#course-section').css('display', 'block');
})
$('#lecture-container').click(() => {
    resetAllArrows()
    $('#lecture-line').css('width', '100%');
    $('#lecture-section').css('display', 'block');
})
$('#fee-container').click(() => {
    resetAllArrows()
    $('#fee-line').css('width', '100%');
    $('#fee-section').css('display', 'block');
    window.scrollTo(0, 540);
})

// Delete student function
$('#delete-student-btn').click(() => {
    var delstudentid = selected
    var delreferenceid = ref_id
    // console.log(delreferenceid);
    var name = $('#student_name').html()
    // var email = studentemail.text()
    swal.fire({
        title: `Are you sure?`,
        html: `<h4>You want to delete <span class="text-danger">${name}</span> student details!</h4>
            <h5>References will also be deleted along with students data</h5>
            <h6>Once deleted cannot be recovered</h6>`,
        type: 'warning',
        width: '750px',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete!'
    }).then((result) => {

        if (result.isConfirmed) {

            if (delreferenceid != '') {

                // Delete reference data
                $.ajax({
                    url: `/sdp/references/${delreferenceid}`, // Also delete reference with students
                    method: 'delete',
                    success: function (response) {
                        if (response.success) {

                            $.ajax({
                                url: `/sdp/students/${delstudentid}`, // Delete students data
                                method: 'delete',
                                success: function (response) {
                                    if (response.success) {

                                        Swal.fire({
                                            toast: true,
                                            position: 'top-right',
                                            icon: 'success',
                                            title: 'student Deleted Successfully',
                                            timer: 3000,
                                            showConfirmButton: false
                                        });

                                        $('#no-student-selected').css('display', 'block')
                                        $('#student-selected').css('display', 'none')
                                        loadstudentsList()

                                    } else {

                                        Swal.fire({
                                            icon: 'danger',
                                            title: 'Something went wrong',
                                            text: response.responseJSON.error
                                        });
                                        console.log(response);

                                    }
                                },
                                error: function (response) {

                                    Swal.fire({
                                        icon: 'danger',
                                        title: 'Server error',
                                        text: response.responseJSON.error
                                    });
                                    console.log(response);

                                }
                            });

                            // Swal.fire({
                            //     toast: true,
                            //     position: 'top-right',
                            //     icon: 'success',
                            //     title: 'student Deleted Successfully',
                            //     timer: 3000,
                            //     showConfirmButton: false
                            // });

                        } else {

                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });
                            console.log(response);

                        }
                    },
                    error: function (response) {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Server error',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                });

            } else {

                // Delete only student data
                $.ajax({
                    url: `/sdp/students/${delstudentid}`, // Delete students info
                    method: 'delete',
                    success: function (response) {
                        if (response.success) {

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'student Deleted Successfully',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            $('#no-student-selected').css('display', 'block')
                            $('#student-selected').css('display', 'none')
                            loadstudentsList()

                        } else {

                            Swal.fire({
                                icon: 'danger',
                                title: 'Something went wrong',
                                text: response.responseJSON.error
                            });
                            console.log(response);

                        }
                    },
                    error: function (response) {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Server error',
                            text: response.responseJSON.error
                        });
                        console.log(response);

                    }
                });

            }


        }
    })
})

// Ref: https://codepen.io/designalchemy/pen/WNNmOgP?editors=0010
const canIRun = navigator.mediaDevices.getDisplayMedia

const takeScreenShot = async () => {
    //   const stream = await navigator.mediaDevices.getDisplayMedia({
    //     video: { mediaSource: 'screen' },
    //   })
    // Ref: https://www.codingnepalweb.com/how-to-take-screenshot-vanilla-javascript/
    // Video: https://youtu.be/YTpftUSV1aA
    const stream = await navigator.mediaDevices.getDisplayMedia({
        preferCurrentTab: true,
        video: { mediaSource: 'screen' },
    })
    // get correct video track
    const track = stream.getVideoTracks()[0]
    // init Image Capture and not Video stream
    const imageCapture = new ImageCapture(track)
    // take first frame only
    const bitmap = await imageCapture.grabFrame()
    // destory video track to prevent more recording / mem leak
    track.stop()
    //   console.log(bitmap);
    const canvas = document.getElementById('fake') // Working
    // this could be a document.createElement('canvas') if you want
    // draw weird image type to canvas so we can get a useful image
    canvas.width = bitmap.width // Working
    canvas.height = bitmap.height // Working
    const context = canvas.getContext('2d')
    context.drawImage(bitmap, 0, 0, bitmap.width, bitmap.height)
    const image = canvas.toDataURL()
    //   console.log(image);
    $('#cake2').attr('src', image)

    // var ccanvas = document.createElement("canvas"),
    // cctx = ccanvas.getContext("2d");

    // ccanvas.width = 100;
    // ccanvas.height = 200;

    // // draw with crop arguments
    // cctx.drawImage(image,  10, 10, 100, 200,  0, 0, 100, 200);
    // //                         ^^^^^^^^^^ source region
    // //                                      ^^^^^^^^^^ dest. region

    // // insert cropped image somewhere in the DOM tree:
    // document.body.appendChild(ccanvas);

    // ------ CROP IMAGE CODE START --------------
    // Ref: https://stackoverflow.com/a/28540766
    let imageData = context.getImageData(436, 50, 2000, 3000);

    let canvas1 = document.createElement("canvas");
    canvas1.width = 350;
    canvas1.height = 570;
    let ctx1 = canvas1.getContext("2d");
    ctx1.rect(0, 0, 350, 570);
    ctx1.fillStyle = 'white';
    ctx1.fill();
    ctx1.putImageData(imageData, 0, 0);
    $('#cake3').attr('src', canvas1.toDataURL("application/pdf"))
    // ------ CROP IMAGE CODE END --------------

    // -------------------------------------- work in progress
    // const linkSource = canvas1.toDataURL("application/pdf");
    // const downloadLink = document.createElement("a");
    // const fileName = "convertedPDFFile.pdf";
    // downloadLink.href = linkSource;
    // downloadLink.download = fileName;
    // downloadLink.click();
    // -------------------------------------- work in progress
    // dstImg.src = canvas1.toDataURL("image/png");
    // console.log(ctx1);

    // this turns the base 64 string to a [File] object
    const res = await fetch(image)
    const buff = await res.arrayBuffer()
    // clone so we can rename, and put into array for easy proccessing
    const file = [
        new File([buff], `photo_${new Date()}.jpg`, {
            type: 'image/jpeg',
        }),
    ]
    //   console.log(file);
    return file
}
// const button = document.getElementById('cake').onclick = () => canIRun ? takeScreenShot() : {} // Working code
