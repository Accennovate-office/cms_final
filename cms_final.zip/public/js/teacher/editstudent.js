
$('#error').css('display', 'none');
$('#loading').css('display', 'none');

$('#sidebar-students').trigger("click")
$('#sidebar-students,#sidebar-students-edit').addClass('active')
$("div#mySidebar").scrollTop(240); // Ref: https://api.jquery.com/scrolltop/

// Reference forms toggle
$('#ref2,#ref3').fadeOut()
document.getElementById('btn-ref1').classList.remove('no-ref')
$('#btn-ref1').click(() => {
    $('#ref1').fadeIn(250)
    document.getElementById('btn-ref1').classList.remove('no-ref')
    $('#ref2,#ref3').fadeOut(100)
    document.getElementById('btn-ref2').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref2').click(() => {
    $('#ref2').fadeIn(250)
    document.getElementById('btn-ref2').classList.remove('no-ref')
    $('#ref1,#ref3').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref3').classList.add('no-ref')

})
$('#btn-ref3').click(() => {
    $('#ref3').fadeIn(250)
    document.getElementById('btn-ref3').classList.remove('no-ref')
    $('#ref1,#ref2').fadeOut(100)
    document.getElementById('btn-ref1').classList.add('no-ref')
    document.getElementById('btn-ref2').classList.add('no-ref')

})

// Social media icon color
$('#studentsocialmedia-facebook').keyup(() => {
    const facebook = $('#studentsocialmedia-facebook').val()
    if (facebook != '') {
        $('#facebook-icon').attr('src', '/images/students/facebook-yes.png')
    } else {
        $('#facebook-icon').attr('src', '/images/students/facebook-no.png')
    }
})
$('#studentsocialmedia-instagram').keyup(() => {
    const instagram = $('#studentsocialmedia-instagram').val()
    if (instagram != '') {
        $('#instagram-icon').attr('src', '/images/students/instagram-yes.png')
    } else {
        $('#instagram-icon').attr('src', '/images/students/instagram-no.png')
    }
})
$('#studentsocialmedia-youtube').keyup(() => {
    const youtube = $('#studentsocialmedia-youtube').val()
    if (youtube != '') {
        $('#youtube-icon').attr('src', '/images/students/youtube-yes.png')
    } else {
        $('#youtube-icon').attr('src', '/images/students/youtube-no.png')
    }
})
$('#studentsocialmedia-twitter').keyup(() => {
    const twitter = $('#studentsocialmedia-twitter').val()
    if (twitter != '') {
        $('#twitter-icon').attr('src', '/images/students/twitter-yes.png')
    } else {
        $('#twitter-icon').attr('src', '/images/students/twitter-no.png')
    }
})
$('#studentsocialmedia-linkedin').keyup(() => {
    const linkedin = $('#studentsocialmedia-linkedin').val()
    if (linkedin != '') {
        $('#linkedin-icon').attr('src', '/images/students/linkedin-yes.png')
    } else {
        $('#linkedin-icon').attr('src', '/images/students/linkedin-no.png')
    }
})

// Aadhaar validation start - https://stackoverflow.com/a/47428241
$('[data-type="adhaar-number"]').keyup(function () {
    var value = $(this).val();
    value = value.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
    $(this).val(value);
});

// $('[data-type="adhaar-number"]').on("change, blur", function () {
//     var value = $(this).val();
//     var maxLength = $(this).attr("maxLength");
//     if (value.length != maxLength) {
//         $(this).addClass("highlight-error");
//     } else {
//         $(this).removeClass("highlight-error");
//     }
// });
// Aadhaar validation end

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['student'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/students')
})

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Updating Student Details...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

function disableInputs() {

    $('#firstname').val('First Name')
    $('#middlename').val('Middle Name')
    $('#lastname').val('Last Name')

    $('#studentdob').val('')
    $('#studentgender').val('')
    $('#studentaadhaar').val('Student Aadhaar here')
    $('#studentreligion').val('Student Religion here')
    $('#studentcaste').val('Student Caste here')

    $('#studentfatheroccupation').val('Student Father Occupation here')
    $('#studentmothername').val('Mother Name here')
    $('#studentmothertongue').val('Mother Tongue here')

    $('#studentphone1').val('Student Phone 1 here')
    $('#studentphone2').val('Student Phone 2 here')
    $('#studentparentphone').val('Parent Phone here')
    $('#studentemail').val('Student Email here')
    $('#studentaddress').val('Student Address here')

    $('#studentquali').val('Student Qualifications here')
    $('#studentschool').val('Student Scholl or College Name here')
    $('#studentclass').val('Student Class or Tuition Name here')

    $('#studentbranch').val('')
    $('#studentcategory').val('')
    // $('#studentreference').val('Student Reference here')
    // $('#studentsocial').val('Student Social Media here')

    $('#studentsocialmedia-facebook,#studentsocialmedia-instagram,#studentsocialmedia-youtube,#studentsocialmedia-twitter,#studentsocialmedia-linkedin').val('')

    $('#ref1_name,#ref1_phone,#ref1_category,#ref1_area,#ref2_name,#ref2_phone,#ref2_category,#ref2_area,#ref3_name,#ref3_phone,#ref3_category,#ref3_area').val('')

    $('#firstname,#middlename,#lastname,#studentdob,#studentgender,#studentaadhaar,#studentreligion,#studentcaste,#studentfatheroccupation,#studentmothername,#studentmothertongue,#studentphone1,#studentphone2,#studentparentphone,#studentemail,#studentaddress,#studentquali,#studentschool,#studentclass,#studentbranch,#studentcategory,#studentreference,#studentsocial,#studentsocialmedia-facebook,#studentsocialmedia-instagram,#studentsocialmedia-youtube,#studentsocialmedia-twitter,#studentsocialmedia-linkedin,#ref1_name,#ref1_phone,#ref1_category,#ref1_area,#ref2_name,#ref2_phone,#ref2_category,#ref2_area,#ref3_name,#ref3_phone,#ref3_category,#ref3_area').attr('disabled', true)

}

function checkInputs() {
    var firstname = $('#firstname').val()
    var middlename = $('#middlename').val()
    var lastname = $('#lastname').val()

    var studentdob = $('#studentdob').val()
    var studentgender = $('#studentgender').val()
    // var studentaadhaar = $('#studentaadhaar').val()
    var studentreligion = $('#studentreligion').val()
    var studentcaste = $('#studentcaste').val()

    var studentfatheroccupation = $('#studentfatheroccupation').val()
    var studentmothername = $('#studentmothername').val()
    var studentmothertongue = $('#studentmothertongue').val()

    var studentphone1 = $('#studentphone1').val()
    var studentphone2 = $('#studentphone2').val()
    var studentparentphone = $('#studentparentphone').val()
    var studentemail = $('#studentemail').val()
    var studentaddress = $('#studentaddress').val()

    var studentquali = $('#studentquali').val()
    var studentschool = $('#studentschool').val()
    var studentclass = $('#studentclass').val()

    var studentbranch = $('#studentbranch').val()
    var studentcategory = $('#studentcategory').val()
    // var studentreference = $('#studentreference').val()
    // var studentsocial = $('#studentsocial').val()

    if (firstname || middlename || lastname || studentdob || studentgender || studentreligion || studentcaste || studentfatheroccupation || studentmothername || studentmothertongue || studentphone1 || studentemail || studentaddress || studentquali || studentschool || studentclass || studentbranch || studentcategory) {
        $('#editstudent button').attr('disabled', true)
        if (firstname && middlename && lastname && studentdob && studentgender && studentreligion && studentcaste && studentfatheroccupation && studentmothername && studentmothertongue && studentphone1 && studentemail && studentaddress && studentquali && studentschool && studentclass && studentbranch && studentcategory) {
            $('#editstudent button').attr('disabled', false)
        } else {
            $('#editstudent button').attr('disabled', true)
        }
    }
}

$('#editstudent #firstname,#editstudent #middlename,#editstudent #lastname,#editstudent #studentdob,#editstudent #studentgender,#editstudent #studentaadhaar,#editstudent #studentreligion,#editstudent #studentcaste,#editstudent #studentfatheroccupation,#editstudent #studentmothername,#editstudent #studentmothertongue,#editstudent #studentphone1,#editstudent #studentphone2,#editstudent #studentparentphone,#editstudent #studentemail,#editstudent #studentaddress,#editstudent #studentquali,#editstudent #studentschool,#editstudent #studentclass,#editstudent #studentbranch,#editstudent #studentcategory,#editstudent #studentreference,#editstudent input,#editstudent #ref1_category,#editstudent #ref2_category,#editstudent #ref3_category').change(() => {

    checkInputs();
})

function getStudentDetails() {

    const selectStudent = $('#student').val() ? $('#student').val() : selected

    $('#editstudent button').attr('disabled', true)
    // console.log(selectStudent);
    if (selectStudent == '') {

        disableInputs()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching student details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#firstname,#middlename,#lastname').attr('disabled', false)

        $('#firstname,#middlename,#lastname,#studentdob,#studentgender,#studentaadhaar,#studentreligion,#studentcaste,#studentfatheroccupation,#studentmothername,#studentmothertongue,#studentphone1,#studentphone2,#studentparentphone,#studentemail,#studentaddress,#studentquali,#studentschool,#studentclass,#studentbranch,#studentcategory,#studentreference,#studentsocial,#studentsocialmedia-facebook,#studentsocialmedia-instagram,#studentsocialmedia-youtube,#studentsocialmedia-twitter,#studentsocialmedia-linkedin,#ref1_name,#ref1_phone,#ref1_category,#ref1_area,#ref2_name,#ref2_phone,#ref2_category,#ref2_area,#ref3_name,#ref3_phone,#ref3_category,#ref3_area').attr('disabled', false)

        $.ajax({
            url: `/sdp/students/${selectStudent}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    const studentBranch = response.data.branch
                    // console.log(coursesAllocated);
                    $('#view-student').html(`${response.data.firstName} ${response.data.lastName}`)
                    $('#studentid').val(response.data._id)
                    $('#firstname').val(response.data.firstName)
                    $('#middlename').val(response.data.middleName)
                    $('#lastname').val(response.data.lastName)

                    $('#studentdob').val(response.data.dob.slice(0, 10))

                    var genders_list;
                    const genders = ['Male', 'Female', 'Other']
                    genders.forEach(gender => {
                        if (gender == response.data.gender) {
                            genders_list += `
                        <option selected value="${gender}">${gender}</option>`;
                        } else {
                            genders_list += `
                        <option value="${gender}">${gender}</option>`;
                        }
                    });
                    $('#editstudent #studentgender').html(genders_list)

                    // // Aadhaar number
                    // var aNo = response.data.aadhaarNo.toString()
                    // const aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    // Aadhaar number validation if available or not
                    var aadhaarNumber = ''
                    if (response.data.aadhaarNo) {

                    var aNo = response.data.aadhaarNo.toString()
                        aadhaarNumber = aNo.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
                    }
                // else {
                //     aadhaarNumber = 'No Aadhaar card added'
                // }

                    $('#studentaadhaar').val(aadhaarNumber)
                    $('#studentreligion').val(response.data.religion)
                    $('#studentcaste').val(response.data.caste)

                    $('#studentfatheroccupation').val(response.data.fatherOccupation)
                    $('#studentmothername').val(response.data.motherName)
                    $('#studentmothertongue').val(response.data.motherTongue)

                    $('#studentphone1').val(response.data.phone1)
                    $('#studentphone2').val(response.data.phone2)
                    $('#studentparentphone').val(response.data.parentPhone)
                    $('#studentemail').val(response.data.email)
                    $('#studentaddress').val(response.data.address)

                    $('#studentquali').val(response.data.qualification)
                    $('#studentschool').val(response.data.schoolOrCollegeName)
                    $('#studentclass').val(response.data.classOrTuitionName)

                    // // Social media
                    // $('#studentsocialmedia-facebook').val(response.data.facebook)
                    // response.data.facebook ? $('#facebook-icon').attr('src', '/images/students/facebook-yes.png') : ''

                    // $('#studentsocialmedia-instagram').val(response.data.instagram)
                    // response.data.instagram ? $('#instagram-icon').attr('src', '/images/students/instagram-yes.png') : ''

                    // $('#studentsocialmedia-youtube').val(response.data.youtube)
                    // response.data.youtube ? $('#youtube-icon').attr('src', '/images/students/youtube-yes.png') : ''

                    // $('#studentsocialmedia-twitter').val(response.data.twitter)
                    // response.data.twitter ? $('#twitter-icon').attr('src', '/images/students/twitter-yes.png') : ''

                    // $('#studentsocialmedia-linkedin').val(response.data.linkedin)
                    // response.data.linkedin ? $('#linkedin-icon').attr('src', '/images/students/linkedin-yes.png') : ''

                    // $('#referenceid').val(response.data.reference._id)
                    // // Reference 1
                    // $('#ref1_name').val(response.data.reference.ref1Name)
                    // $('#ref1_phone').val(response.data.reference.ref1Phone)
                    // $('#ref1_category').val(response.data.reference.ref1Category)
                    // $('#ref1_area').val(response.data.reference.ref1Area)
                    // // Reference 2
                    // $('#ref2_name').val(response.data.reference.ref2Name)
                    // $('#ref2_phone').val(response.data.reference.ref2Phone)
                    // $('#ref2_category').val(response.data.reference.ref2Category)
                    // $('#ref2_area').val(response.data.reference.ref2Area)
                    // // Reference 3
                    // $('#ref3_name').val(response.data.reference.ref3Name)
                    // $('#ref3_phone').val(response.data.reference.ref3Phone)
                    // $('#ref3_category').val(response.data.reference.ref3Category)
                    // $('#ref3_area').val(response.data.reference.ref3Area)

                    var categorys_list;
                    const categorys = ['Student', 'Service', 'HomeMaker']
                    categorys.forEach(category => {
                        if (category == response.data.category) {
                            categorys_list += `
                        <option selected value="${category}">${category}</option>`;
                        } else {
                            categorys_list += `
                        <option value="${category}">${category}</option>`;
                        }
                    });
                    $('#editstudent #studentcategory').html(categorys_list)

                    $('#studentreference').val(response.data.reference)
                    $('#studentsocial').val(response.data.socialMedia)

                    $.ajax({
                        url: '/sdp/branches',
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                var branches_list;
                                $('#editstudent #studentbranch').text(response.data)

                                if (response.data.length == 0) {
                                    branches_list += `<option value="">Branch List is empty</option>`;
                                } else {
                                    // branches_list = `<option value="">Select Branch Name</option>`;
                                    response.data.forEach(branch => {

                                        if (studentBranch == branch.name) {
                                            branches_list += `
                                        <option selected value="${branch.name}">${branch.name}</option>`;
                                        } else {
                                            branches_list += `
                                        <option value="${branch.name}">${branch.name}</option>`;
                                        }

                                    });
                                }

                                $('#editstudent #studentbranch').html(branches_list)

                                // Swal.fire({
                                //     toast: true,
                                //     position: 'top-right',
                                //     icon: 'success',
                                //     title: 'Branches Fetched Successfully',
                                //     timer: 3000,
                                //     showConfirmButton: false
                                // });

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Student Fetched Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                            } else {

                                disableInputs()

                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'error',
                                    title: 'Error Loading Branches',
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                $('#loading').css('display', 'none');
                                $('#table_branches tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            disableInputs()

                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'error',
                                title: 'Error Loading Branches',
                                timer: 3000,
                                showConfirmButton: false
                            });

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-branch-card button').attr('disabled', true)

                            } else {

                                disableInputs()

                                var errorMsg = `
                                <center>
                                <h2>Oops! Something went wrong</h2>
                                <h4 class="text-danger">
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch branches list</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_branches tbody .col').html(errorMsg)
                                $('#no-branch-selected').html(errorMsg)
                            }

                        }
                    });

                    // Social media
                    $('#studentsocialmedia-facebook').val(response.data.facebook)
                    response.data.facebook ? $('#facebook-icon').attr('src', '/images/students/facebook-yes.png') : ''

                    $('#studentsocialmedia-instagram').val(response.data.instagram)
                    response.data.instagram ? $('#instagram-icon').attr('src', '/images/students/instagram-yes.png') : ''

                    $('#studentsocialmedia-youtube').val(response.data.youtube)
                    response.data.youtube ? $('#youtube-icon').attr('src', '/images/students/youtube-yes.png') : ''

                    $('#studentsocialmedia-twitter').val(response.data.twitter)
                    response.data.twitter ? $('#twitter-icon').attr('src', '/images/students/twitter-yes.png') : ''

                    $('#studentsocialmedia-linkedin').val(response.data.linkedin)
                    response.data.linkedin ? $('#linkedin-icon').attr('src', '/images/students/linkedin-yes.png') : ''

                    $('#referenceid').val(response.data.reference._id ? response.data.reference._id : '')
                    // Reference 1
                    $('#ref1_name').val(response.data.reference.ref1Name ? response.data.reference.ref1Name : '')
                    $('#ref1_phone').val(response.data.reference.ref1Phone ? response.data.reference.ref1Phone : '')
                    $('#ref1_category').val(response.data.reference.ref1Category ? response.data.reference.ref1Category : '')
                    $('#ref1_area').val(response.data.reference.ref1Area ? response.data.reference.ref1Area : '')
                    // Reference 2
                    $('#ref2_name').val(response.data.reference.ref2Name ? response.data.reference.ref2Name : '')
                    $('#ref2_phone').val(response.data.reference.ref2Phone ? response.data.reference.ref2Phone : '')
                    $('#ref2_category').val(response.data.reference.ref2Category ? response.data.reference.ref2Category : '')
                    $('#ref2_area').val(response.data.reference.ref2Area ? response.data.reference.ref2Area : '')
                    // Reference 3
                    $('#ref3_name').val(response.data.reference.ref3Name ? response.data.reference.ref3Name : '')
                    $('#ref3_phone').val(response.data.reference.ref3Phone ? response.data.reference.ref3Phone : '')
                    $('#ref3_category').val(response.data.reference.ref3Category ? response.data.reference.ref3Category : '')
                    $('#ref3_area').val(response.data.reference.ref3Area ? response.data.reference.ref3Area : '')

                } else {

                    disableInputs()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Students',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                disableInputs()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Students',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    disableInputs()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch student details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#no-student-selected').html(errorMsg)
                }

            }
        });
    }

}

if (selected != undefined) {
    // console.log('inside');
    getStudentDetails()
}
$('#student').change(() => {

    getStudentDetails()

})

$('#edit-student-btn').click(() => { 
    // Extra security code
    var studentid = $('#studentid').val()
    var referenceid = $('#referenceid').val()
    // console.log(studentid);

    // Inputs
    var Inputfirstname = $('#firstname')
    var Inputmiddlename = $('#middlename')
    var Inputlastname = $('#lastname')

    var Inputstudentdob = $('#studentdob')
    var Inputstudentgender = $('#studentgender')
    var Inputstudentaadhaar = $('#studentaadhaar')
    var Inputstudentreligion = $('#studentreligion')
    var Inputstudentcaste = $('#studentcaste')

    var Inputstudentfatheroccupation = $('#studentfatheroccupation')
    var Inputstudentmothername = $('#studentmothername')
    var Inputstudentmothertongue = $('#studentmothertongue')

    var Inputstudentphone1 = $('#studentphone1')
    var Inputstudentphone2 = $('#studentphone2')
    var Inputstudentparentphone = $('#studentparentphone')
    var Inputstudentemail = $('#studentemail')
    var Inputstudentaddress = $('#studentaddress')

    var Inputstudentquali = $('#studentquali')
    var Inputstudentschool = $('#studentschool')
    var Inputstudentclass = $('#studentclass')

    var Inputstudentbranch = $('#studentbranch')
    var Inputstudentcategory = $('#studentcategory')
    // var Inputstudentreference = $('#studentreference')
    // var Inputstudentsocial = $('#studentsocial')

    // Values
    var firstname = $('#firstname').val()
    var middlename = $('#middlename').val()
    var lastname = $('#lastname').val()

    var studentdob = $('#studentdob').val()
    var studentgender = $('#studentgender').val()
    var studentaadhaar = $('#studentaadhaar').val()
    var studentreligion = $('#studentreligion').val()
    var studentcaste = $('#studentcaste').val()

    var studentfatheroccupation = $('#studentfatheroccupation').val()
    var studentmothername = $('#studentmothername').val()
    var studentmothertongue = $('#studentmothertongue').val()

    var studentphone1 = $('#studentphone1').val()
    var studentphone2 = $('#studentphone2').val()
    var studentparentphone = $('#studentparentphone').val()
    var studentemail = $('#studentemail').val()
    var studentaddress = $('#studentaddress').val()

    var studentquali = $('#studentquali').val()
    var studentschool = $('#studentschool').val()
    var studentclass = $('#studentclass').val()

    var studentbranch = $('#studentbranch').val()
    var studentcategory = $('#studentcategory').val()
    // var studentreference = $('#studentreference').val()
    // var studentsocial = $('#studentsocial').val()

    // Social Media
    const facebook = $('#studentsocialmedia-facebook').val() || null
    const instagram = $('#studentsocialmedia-instagram').val() || null
    const youtube = $('#studentsocialmedia-youtube').val() || null
    const twitter = $('#studentsocialmedia-twitter').val() || null
    const linkedin = $('#studentsocialmedia-linkedin').val() || null

    // Reference 1
    const ref1_name = $('#ref1_name').val()
    const ref1_phone = $('#ref1_phone').val()
    const ref1_category = $('#ref1_category').val()
    const ref1_area = $('#ref1_area').val()
    // Reference 2
    const ref2_name = $('#ref2_name').val()
    const ref2_phone = $('#ref2_phone').val()
    const ref2_category = $('#ref2_category').val()
    const ref2_area = $('#ref2_area').val()
    // Reference 3
    const ref3_name = $('#ref3_name').val()
    const ref3_phone = $('#ref3_phone').val()
    const ref3_category = $('#ref3_category').val()
    const ref3_area = $('#ref3_area').val()

    if (!firstname) {
        Inputfirstname.css('border', '2px solid red')
        Inputfirstname.attr('placeholder', 'Please add first name')
    } else if (!middlename) {
        Inputmiddlename.css('border', '2px solid red')
        Inputmiddlename.attr('placeholder', 'Please add middle name')
    } else if (!lastname) {
        Inputlastname.css('border', '2px solid red')
        Inputlastname.attr('placeholder', 'Please add last name')
    } else if (!studentdob) {
        Inputstudentdob.css('border', '2px solid red')
    } else if (!studentgender) {
        Inputstudentgender.css('border', '2px solid red')
    } else if (!studentreligion) {
        Inputstudentreligion.css('border', '2px solid red')
    } else if (!studentcaste) {
        Inputstudentcaste.css('border', '2px solid red')
    } else if (!studentfatheroccupation) {
        Inputstudentfatheroccupation.css('border', '2px solid red')
    } else if (!studentmothername) {
        Inputstudentmothername.css('border', '2px solid red')
    } else if (!studentmothertongue) {
        Inputstudentmothertongue.css('border', '2px solid red')
    } else if (!studentphone1) {
        Inputstudentphone1.css('border', '2px solid red')
    } else if (!studentemail) {
        Inputstudentemail.css('border', '2px solid red')
    } else if (!studentaddress) {
        Inputstudentaddress.css('border', '2px solid red')
    } else if (!studentquali) {
        Inputstudentquali.css('border', '2px solid red')
    } else if (!studentschool) {
        Inputstudentschool.css('border', '2px solid red')
    } else if (!studentclass) {
        Inputstudentclass.css('border', '2px solid red')
    } else if (!studentbranch) {
        Inputstudentbranch.css('border', '2px solid red')
    } else if (!studentcategory) {
        Inputstudentcategory.css('border', '2px solid red')
    } else {
        var studentaadhaar_final = studentaadhaar.split('-').join('')

        $('#editstudent button').attr('disabled', true)
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        loading()

        // Update student
        $.ajax({
            url: `/sdp/students/${studentid}`,
            method: 'put',
            dataType: 'json',
            data: {
                firstName: firstname,
                middleName: middlename,
                lastName: lastname,
                dob: studentdob,
                gender: studentgender,
                aadhaarNo: studentaadhaar_final,
                religion: studentreligion,
                caste: studentcaste,
                fatherOccupation: studentfatheroccupation,
                motherName: studentmothername,
                motherTongue: studentmothertongue,
                phone1: studentphone1,
                phone2: studentphone2,
                parentPhone: studentparentphone,
                email: studentemail,
                address: studentaddress,
                qualification: studentquali,
                schoolOrCollegeName: studentschool,
                classOrTuitionName: studentclass,
                category: studentcategory,
                branch: studentbranch,
                facebook: facebook,
                instagram: instagram,
                youtube: youtube,
                twitter: twitter,
                linkedin: linkedin
            },
            success: function (response) {
                if (response.success) {

                    $.ajax({
                        url: `/sdp/references/${referenceid}`,
                        method: 'put',
                        dataType: 'json',
                        data: {
                            ref1Name: ref1_name,
                            ref1Phone: ref1_phone,
                            ref1Category: ref1_category,
                            ref1Area: ref1_area,

                            ref2Name: ref2_name,
                            ref2Phone: ref2_phone,
                            ref2Category: ref2_category,
                            ref2Area: ref2_area,

                            ref3Name: ref3_name,
                            ref3Phone: ref3_phone,
                            ref3Category: ref3_category,
                            ref3Area: ref3_area,

                            branch: studentbranch
                        },
                        success: function (response) {
                            if (response.success) {

                                $('#error,#loading').css('display', 'none')
                                $('#edit-student-card button').attr('disabled', true)
                                Swal.fire({
                                    toast: true,
                                    position: 'top-right',
                                    icon: 'success',
                                    title: 'Student Updated Successfully',
                                    timer: 3000,
                                    showConfirmButton: false
                                });
                                setTimeout(() => {
                                    loadStudentsList(`${firstname} ${lastname}`)
                                }, 3000);

                            } else {

                                $('#loading').css('display', 'none');
                                $('#error').text(response.responseJSON.error);
                                $('#error').fadeIn();
                                $('#error').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            $('#loading').css('display', 'none');
                            $('#error').text(response.responseJSON.error);
                            $('#error').fadeIn();
                            $('#error').css('display', 'block');
                            $('#add-student-card button').attr('disabled', true)

                        }
                    });

                    $('#error,#loading').css('display', 'none')
                    $('#edit-student-card button').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Student Updated Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(() => {
                        loadStudentsList(`${firstname} ${lastname}`)
                    }, 3000);

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        });

    }
})

$('#view-student').click(() => {
    document.location.replace(`/sdp/teacher/viewstudent?student=${selected}`)
})