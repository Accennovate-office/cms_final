$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-tasks').trigger("click")
$('#sidebar-tasks,#sidebar-tasks-edit').addClass('active')
$("div#mySidebar").scrollTop(100); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

const next = $('#new-task-btn')

$('#span_all').click(() => {
    document.location.replace('/sdp/teacher/tasks')
})

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

const selected = getUrlVars()['task'] // Ref: https://stackoverflow.com/a/4656873
// console.log(selected);

function loading() {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">Adding New Task...</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

var finalSubmit = 0;
var currentActive = 1;

function update() {

    const category = $('#myDropdown1-1').val()
    const subcategory = $('#myDropdown2-1').val()
    const details = $('#taskdetails').val()
    // console.log(category, subcategory, details);
    // $('#display-name').html(category ? category : '<span class="text-danger">Name field is empty</span>')
    // $('#display-description').html(subcategory ? subcategory : '<span class="text-danger">Description field is empty</span>')
    // $('#display-startdate').html(details ? details : '<span class="text-danger">Start Date field is empty</span>')

    // console.log(!name || !email || !dob || !phone || !address || !qualifications || !joindate || !branch || !jobStartTime || !jobEndTime || !password);
    if (!category || !subcategory || !details) {
        // next.disabled = true
        next.attr('disabled', true)
        // console.log('true');
    } else {
        finalSubmit = 1
        // console.log('false');
        next.removeAttr('disabled')
        // next.disabled = false
    }
}

function loadTasksList(taskname = null) {

    // Loading by blocking outsideClick
    Swal.fire({
        imageUrl: '/images/loading/sdp_logo_loading.gif',
        title: `Loading tasks list`,
        showConfirmButton: false,
        allowOutsideClick: false
    });

    $.ajax({
        url: '/sdp/tasks',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var tasks_list;
                $('#edittask #task').text(response.data)

                if (response.data.length == 0) {
                    tasks_list += `<option value="">Task List is empty</option>`;
                } else {
                    tasks_list = `<option value="">Select Task Name</option>`;
                    response.data.forEach(task => {

                        if (taskname == task.details || selected == task._id) {
                            // console.log('selected');
                            select = 'selected'
                        } else {
                            select = ''
                        }

                        tasks_list += `
                        <option ${select} value="${task._id}">${task.details} Task</option>`;
                    });
                }
                $('#edittask #task').html(tasks_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Tasks Loaded Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Tasks',
                    timer: 3000,
                    showConfirmButton: false
                });

                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Request Success: ${response.success} <br>
                    Data Received: ${JSON.stringify(response.data)}
                </h4>
                <h5>We were unable to process the request</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_tasks tbody .col').html(errorMsg)
                $('#task-selected').html(errorMsg)

            }
        },
        error: function (response) {

            Swal.fire({
                toast: true,
                position: 'top-right',
                icon: 'error',
                title: 'Error Loading Tasks',
                timer: 3000,
                showConfirmButton: false
            });

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#task-selected').html(response.responseJSON.error)
                $('#error').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch tasks list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_tasks tbody .col').html(errorMsg)
                $('#task-selected').html(errorMsg)
            }

        }
    });

}
loadTasksList()

function loadTaskDetails() {

    const selectTask = $('#task').val() ? $('#task').val() : selected

    $('#edittask button').attr('disabled', true)
    // console.log(selectTask);
    if (selectTask == '') {

        $('#taskdetails').attr('disabled', true)
        $('#dropbtn1').attr('disabled', true)
        $('#dropbtn2').attr('disabled', true)
        update()

    } else {

        // Loading by blocking outsideClick
        Swal.fire({
            imageUrl: '/images/loading/sdp_logo_loading.gif',
            title: `Fetching task details`,
            showConfirmButton: false,
            allowOutsideClick: false
        });

        $('#taskdetails').attr('disabled', false)
        $('#dropbtn1').removeAttr('disabled')
        $('#dropbtn2').removeAttr('disabled')

        $.ajax({
            url: `/sdp/tasks/${selectTask}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    $('#taskid').val(response.data._id)
                    const cat = response.data.category._id
                    const sub = response.data.subcategory._id
                    const details = response.data.details
                    $('#taskdetails').text(details)
                    loadCategorys(cat, sub)

                } else {

                    update()

                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'error',
                        title: 'Error Loading Tasks',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    $('#loading').css('display', 'none');
                    $('#table_tasks tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#edit-task-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                update()

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'error',
                    title: 'Error Loading Tasks',
                    timer: 3000,
                    showConfirmButton: false
                });

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-task-card button').attr('disabled', true)

                } else {
                    update()

                    var errorMsg = `
                    <center>
                    <h2>Oops! Something went wrong</h2>
                    <h4 class="text-danger">
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch task details</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_tasks tbody .col').html(errorMsg)
                    $('#no-task-selected').html(errorMsg)
                }

            }
        });
    }

}

$('#taskdetails').attr('disabled', true)
if (selected != undefined) {
    console.log('inside');
    loadTaskDetails()
}
$('#task').change(() => {

    loadTaskDetails()

})

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
    document.getElementById("myDropdown2").classList.remove("show");
})
$('#dropbtn2').click(() => {
    document.getElementById("myDropdown2").classList.toggle("show");
    document.getElementById("myDropdown1").classList.remove("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput2').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput2");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown2-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
$('#myInput1,#myInput2').focusout(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.png')
})
// Searchable dropdown end
const category_id_list = []
const category_frequency_list = []
const sub_category_id_list = []

$('#taskdetails').keyup(() => {
    update()
})

function createTask() {

    const category = $('#myDropdown1-1').val()
    const subcategory = $('#myDropdown2-1').val()
    const details = $('#taskdetails').val()

    if (!category || !subcategory || !details) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in task form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Creating Task...',
            showConfirmButton: false
        });

        $.ajax({
            url: '/sdp/tasks',
            method: 'post',
            dataType: 'json',
            data: {
                details: details,
                category: category,
                subcategory: subcategory,
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    Swal.fire({
                        icon: 'success',
                        title: `<div class="text-success">Task Created</div>`,
                        confirmButtonText: 'Okay',
                        confirmButtonColor: '#0b6fad',
                        allowOutsideClick: false
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Redirecting...',
                                timer: 1000,
                                showConfirmButton: false
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/teacher/tasks');
                            }, 1000);
                        }
                    })

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

async function loadSubCategorys(cat, sub) {
    console.log('inside sub-category');
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    var tbody_tasks = ``;
    $('#sub_category_selected').text(`No Sub Category selected`)
    document.getElementById('sub_category_selected').classList.remove('c_selected')

    await $.ajax({
        url: '/sdp/tasksubcategorys',
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length == 0) {

                    tbody_tasks += `
                        <option value="">No Sub-Category available</option>`;
                } else {
                    catg_data = true
                    // $('#table_tasks').fadeIn()
                    // var newelementCount = 0;
                    response.data.forEach(task => {
                        console.log(1);
                        if (task.category._id == cat) {
                            console.log(2);
                            if (task._id == sub) {
                                console.log(3.1);
                                tbody_tasks += `
                                <option selected id="${task._id}" value="${task.title}">${task.title}</option>`;
                                $('#sub_category_selected').text(task.title)
                                document.getElementById('sub_category_selected').classList.add('c_selected')
                            } else {
                                console.log(3.2);
                                tbody_tasks += `
                                <option id="${task._id}" value="${task.title}">${task.title}</option>`;
                            }

                            sub_category_id_list.push(task._id)
                        }

                    })
                    if (tbody_tasks == ``) {
                        let cat_s = $('#myDropdown1-1').val()
                        $('#sub_category_selected').text(`No Sub-Category available for ${cat_s} category`)
                        $('#dropbtn2').attr('disabled', true)
                        document.getElementById('sub_category_selected').classList.remove('c_selected')
                        update()
                    }
                }
                // console.log(sub_category_id_list);
                $('#myDropdown2-1').html(tbody_tasks)
                sub_category_id_list.forEach(cat => {
                    $(`#${cat}`).click(() => {
                        const category = $('#myDropdown1-1').val()
                        if (category != '') {
                            const category = $('#myDropdown2-1').val()
                            if (category != '') {
                                // console.log(category);
                                $('#sub_category_selected').text(category)
                                document.getElementById('sub_category_selected').classList.add('c_selected')
                                update()
                            }
                        } else {

                            $('#dropbtn2').attr('disabled', true)
                        }

                        document.getElementById("myDropdown2").classList.remove("show");
                    })
                });

                // update()

            } else {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                console.log(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            $('#loading').css('display', 'none');
            console.log(response);
            $('#error').text(response.responseJSON.error);
            $('#error').fadeIn();
            $('#error').css('display', 'block');
            $('#add-branch-card button').attr('disabled', true)

        }
    })

    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'success',
        title: 'Sub-Categories fetched successfully',
        showConfirmButton: false,
        timer: 3000
    });

}

async function loadCategorys(cat, sub) {
    console.log('inside category');
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    var tbody_tasks = ``;

    await $.ajax({
        url: '/sdp/taskcategorys',
        method: 'get',
        success: function (response) {
            if (response.success) {

                if (response.data.length == 0) {

                    tbody_tasks += `
                        <option value="">No Category available</option>`;
                } else {
                    catg_data = true
                    // $('#table_tasks').fadeIn()
                    // var newelementCount = 0;
                    response.data.forEach(task => {

                        if (task._id == cat) {

                            tbody_tasks += `
                            <option selected id="${task._id}" value="${task.title}">${task.title}</option>`;
                            // $('#category_selected').text(task.title)
                            $('#category_selected').html(`${task.title} <span class="badge badge-freq mb-1">${task.frequency}</span>`)
                            document.getElementById('category_selected').classList.add('c_selected')
                        } else {

                            tbody_tasks += `
                            <option id="${task._id}" value="${task.title}">${task.title}</option>`;
                        }

                        category_id_list.push(task._id)
                        category_frequency_list.push(task.frequency)
                    })
                }
                // console.log(category_id_list);
                $('#myDropdown1-1').html(tbody_tasks)
                category_id_list.forEach(cat => {
                    $(`#${cat}`).click(async () => {

                        const category = $('#myDropdown1-1').val()
                        let index = category_id_list.indexOf(cat);
                        if (category != '') {
                            // console.log(category);
                            // $('#category_selected').text(category)
                            $('#category_selected').html(`${category} <span class="badge badge-freq mb-1">${category_frequency_list[index]}</span>`)
                            document.getElementById('category_selected').classList.add('c_selected')
                            $('#dropbtn2').removeAttr('disabled')
                            const data = await loadSubCategorys(cat, sub)
                            console.log(data);
                            console.log('await check');
                            update()
                        }

                        document.getElementById("myDropdown1").classList.remove("show");

                    })
                });

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Categories fetched successfully',
                    showConfirmButton: false,
                    timer: 3000
                });

            } else {

                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            $('#loading').css('display', 'none');
            console.log(response);
            $('#error').text(response.responseJSON.error);
            $('#error').fadeIn();
            $('#error').css('display', 'block');
            $('#add-branch-card button').attr('disabled', true)

        }
    });

    loadSubCategorys(cat, sub)
}


$('#new-task-btn').click(() => {
    // alert('Submit')
    const id = $('#taskid').val()
    const categoryInput = $('#myDropdown1-1')
    const category = $('#myDropdown1-1').val()
    var category_id = ''
    category_id_list.forEach(sub => {
        // console.log('Log - ' + sub);
        if ($(`#${sub}`).val() == category) {
            category_id = sub
            // console.log(category_id);
        }
    });

    const sub_categoryInput = $('#myDropdown2-1')
    const sub_category = $('#myDropdown2-1').val()
    var sub_category_id = ''
    sub_category_id_list.forEach(sub => {
        // console.log('Log - ' + sub);
        if ($(`#${sub}`).val() == sub_category) {
            sub_category_id = sub
            // console.log(sub_category_id);
        }
    });

    const taskdetailsInput = $('#taskdetails')
    const taskdetails = $('#taskdetails').val()

    if (!taskdetails) {
        taskdetailsInput.css('border', '2px solid red')
        taskdetailsInput.attr('placeholder', 'Please add task details')
    } else if (!category_id) {
        categoryInput.css('border', '2px solid red')
    } else if (!sub_category_id) {
        sub_categoryInput.css('border', '2px solid red')
    } else {

        Swal.fire({
            toast: true,
            position: 'top-right',
            icon: 'info',
            title: 'Editing Task...',
            showConfirmButton: false
        });

        $.ajax({
            url: `/sdp/tasks/${id}`,
            method: 'put',
            dataType: 'json',
            data: {
                details: taskdetails,
                category: category_id,
                subcategory: sub_category_id
            },
            success: function (response) {
                if (response.success) {

                    $('#new-task-btn').attr('disabled', true)
                    Swal.fire({
                        toast: true,
                        position: 'top-right',
                        icon: 'success',
                        title: 'Task Edited Successfully',
                        timer: 3000,
                        showConfirmButton: false
                    });

                    loadTasksList(taskdetails)
                    // setTimeout(() => {
                    //     document.location.replace('/sdp/teacher/tasks');
                    // }, 2500);

                } else {

                    console.log(response);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-task-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                Swal.fire({
                    // icon: 'error',
                    title: 'Oops!',
                    html: `
                    <img src="/images/not_authorized.png" width="400" /><br>
                    <span class="font-weight-bold">${response.responseJSON.error}</span>`,
                    showCloseButton: true,
                    confirmButtonText: 'Okay',
                    confirmButtonColor: '#0b6fad'
                });
                console.log(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-task-card button').attr('disabled', true)

            }
        });

    }
})