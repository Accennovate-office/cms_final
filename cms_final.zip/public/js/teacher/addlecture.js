$('#error').css('display', 'none');
$('#loading').css('display', 'none');
$('#errors').css('display', 'none');

$('#sidebar-lectures').trigger("click")
$('#sidebar-lectures,#sidebar-lectures-add').addClass('active')
$("div#mySidebar").scrollTop(400); // Ref: https://api.jquery.com/scrolltop/

$('#passErrorsContainer,#passSuccessContainer').css('display', 'none')

function loading(msg = 'Adding New Lecture...') {
    const colors = ["primary", "success", "danger", "warning", "info"];
    const random = Math.floor(Math.random() * colors.length);
    // console.log(colors[random]);

    var loading = `
    <div class="spinner-border text-${colors[random]}" style="background-color: inherit;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    &nbsp;<span class="text-${colors[random]}">${msg}</span>`;
    $('#error').css('display', 'none');
    $('#loading').css('display', 'block');
    $('#loading').html(loading);
}

// Progress Steps JS
const progress = document.getElementById('progress');
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const circles = document.querySelectorAll('.circle');

var finalSubmit = 0;
var currentActive = 1;
const students_all_list = [];
const student_id_list = [];
var lecture_branch;

// Searchable dropdown
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
$('#dropbtn1').click(() => {
    document.getElementById("myDropdown1").classList.toggle("show");
    // document.getElementById("myDropdown2").classList.remove("show");
})
$('#myInput1').keyup(() => {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    var div = document.getElementById("myDropdown1-1");
    a = div.getElementsByTagName("option");
    for (i = 0; i < a.length; i++) {
        var txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
})
$('#myInput1,#myInput2').focusin(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.gif')
})
$('#myInput1,#myInput2').focusout(() => {
    $('#srch-img1,#srch-img2').attr('src', '/images/search.png')
})
// Searchable dropdown end

function createLecture() { 
    // Form 1
    const teachername = $('#teachername').val()
    const coursename = $('#coursename').val()
    // Students list
    var students_allocated = $('#myDropdown1-1').val().toString()
    if (students_allocated == 'No Course selected') {
        students_allocated = ''
    }
    // Form 2
    const lecturedatetime = $('#lecturedatetime').val()
    const lectureOrExam = $("input[type='radio'][name='lectureOrExam']:checked").val();
    const topics = $('#topics').val()


    if (!teachername || !coursename || !students_allocated || !lecturedatetime || !lectureOrExam || !topics) {
        Swal.fire({
            icon: 'error',
            title: 'Incomplete Form Submitted',
            text: 'Some fields in lecture form are empty. Please check the form and submit again.',
        });
    } else {

        next.disabled = true

        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page

        // Create New Lecture
        loading()

        $.ajax({
            url: '/sdp/lectures',
            method: 'post',
            dataType: 'json',
            data: {
                teacher: teachername,
                course: coursename,
                student: students_allocated,
                dateTime: lecturedatetime,
                lectureOrExam: lectureOrExam,
                topicsCovered: topics,
                branch: lecture_branch
            },
            success: function (response) {
                if (response.success) {

                    $('#error,#loading').css('display', 'none')
                    $('#add-branch-card button').attr('disabled', true)

                    Swal.fire({
                        icon: 'success',
                        title: `<div class="text-success">Lecture Details Added</div>`,
                        confirmButtonText: 'Okay',
                        confirmButtonColor: '#0b6fad',
                        allowOutsideClick: false
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            Swal.fire({
                                toast: true,
                                position: 'top-right',
                                icon: 'success',
                                title: 'Redirecting...',
                                timer: 1000,
                                showConfirmButton: false
                            });
                            setTimeout(() => {
                                document.location.replace('/sdp/teacher/lectures');
                            }, 1000);
                        }
                    })

                } else {

                    $('#loading').css('display', 'none');
                    $('#error').text(response.responseJSON.error);
                    $('#error').fadeIn();
                    $('#error').css('display', 'block');
                    $('#add-branch-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                $('#loading').css('display', 'none');
                console.log(response);
                $('#error').text(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-branch-card button').attr('disabled', true)

            }
        });

    }
}

next.addEventListener('click', () => {
    currentActive++

    if (currentActive > circles.length) {
        currentActive = circles.length
    }
    // Trigger submit script
    if (finalSubmit === 1) {
        // New lecture trigger
        createLecture()
    }
    update();
})

prev.addEventListener('click', () => {
    currentActive--

    if (currentActive < 1) {
        currentActive = 1
    }
    update();
})

// console.log(circles);
function update() {
    circles.forEach((circle, index) => {
        if (index < currentActive) {
            circle.classList.add('active')
        } else {
            circle.classList.remove('active')

        }
    })

    const actives = document.querySelectorAll('.circle.active');
    // console.log(actives);
    $('#addlecture-form1,#addlecture-form2,#addlecture-form3').removeClass('active')
    $(`#addlecture-form${actives.length}`).addClass('active')

    // console.log(actives.length, circles.length);
    progress.style.width = (actives.length - 1) / (circles.length - 1) * 100 + '%'

    if (currentActive === 1) {
        prev.disabled = true
    } else if (currentActive === circles.length) {
        next.disabled = true
    } else {
        prev.disabled = false
        next.disabled = false
    }

    // Custom code
    $('#next').text('Next')
    finalSubmit = 0
    if (actives.length === 2) {
        $('#next').text('Review')
    } else if (actives.length === 3) {

        next.disabled = true
        document.body.scrollTop = document.documentElement.scrollTop = 0; // Scroll to top of page
        loading('Calculating...')

        $('#next').text('Submit')
        // Form 1
        const teachername_id = $('#teachername').val()
        // console.log(teachername_id);
        // Find teacher name
        $.ajax({
            url: `/sdp/teachers/${teachername_id}`,
            method: 'get',
            success: function (response) {
                if (response.success) {

                    var teachername
                    response.data.user ? teachername = response.data.user.name : teachername = undefined
                    lecture_branch = response.data.branch || response.data.user.branch

                    // Find course name
                    const coursename_id = $('#coursename').val()
                    $.ajax({
                        url: `/sdp/courses/${coursename_id}`,
                        method: 'get',
                        success: function (response) {
                            if (response.success) {

                                $('#loading').css('display', 'none');

                                const coursename = response.data.name

                                var students_allocated = $('#myDropdown1-1').val().toString()
                                if (students_allocated == 'No Course selected') {
                                    students_allocated = ''
                                }
                                // Form 2
                                const lecturedatetime = $('#lecturedatetime').val()
                                const lectureOrExam = $("input[type='radio'][name='lectureOrExam']:checked").val();
                                // console.log(`XXX ${lectureOrExam}`);
                                const topics = $('#topics').val()

                                $('#display-teachername').html(teachername ? teachername : '<span class="text-danger">Teacher Name field is empty</span>')
                                $('#display-coursename').html(coursename ? coursename : '<span class="text-danger">Course Name field is empty</span>')
                                $('#display-students').html(students_allocated ? students_allocated : '<span class="text-danger">Please select student(s)</span>')
                                $('#display-lecturedatetime').html(lecturedatetime ? lecturedatetime : '<span class="text-danger">Lecture Date & Time field is empty</span>')
                                $('#display-lectureorexam').html(lectureOrExam ? lectureOrExam : '<span class="text-danger">Lecture / Exam field is empty</span>')
                                $('#display-topics').html(topics ? topics : '<span class="text-danger">Topics Covered field is empty</span>')

                                if (!teachername || !coursename || !students_allocated || !lecturedatetime || !lectureOrExam || !topics) {
                                    next.disabled = true
                                } else {
                                    finalSubmit = 1
                                    next.disabled = false
                                }

                            } else {

                                $('#loading').css('display', 'none');
                                $('#table_students tbody tr').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            }
                        },
                        error: function (response) {

                            if (response.responseJSON) {
                                $('#loading').css('display', 'none');
                                $('#errors').text(response.responseJSON.error);
                                console.log(response.responseJSON.error);
                                $('#errors').fadeIn();
                                // $('#errors').css('display', 'block');
                                $('#add-student-card button').attr('disabled', true)

                            } else {
                                $('#errors').fadeIn();
                                var errorMsg = `
                                <center class="text-danger">
                                <h2>Oops! Something went wrong</h2>
                                <h4>
                                    Error Code: ${response.status} <br>
                                    Error Message: ${response.statusText}
                                </h4>
                                <h5>We were unable to fetch course name</h5>
                                <h6>
                                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                                </h6>
                                </center>`
                                console.log(`something went wrong ${JSON.stringify(response)}`);
                                // console.log(response.statusText);
                                // $('#table_students tbody .col').html(errorMsg)
                                $('#errors').html(errorMsg)
                            }

                        }
                    });

                } else {

                    $('#loading').css('display', 'none');
                    $('#table_students tbody tr').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                }
            },
            error: function (response) {

                if (response.responseJSON) {
                    $('#loading').css('display', 'none');
                    $('#errors').text(response.responseJSON.error);
                    console.log(response.responseJSON.error);
                    $('#errors').fadeIn();
                    // $('#errors').css('display', 'block');
                    $('#add-student-card button').attr('disabled', true)

                } else {
                    $('#errors').fadeIn();
                    var errorMsg = `
                    <center class="text-danger">
                    <h2>Oops! Something went wrong</h2>
                    <h4>
                        Error Code: ${response.status} <br>
                        Error Message: ${response.statusText}
                    </h4>
                    <h5>We were unable to fetch student name</h5>
                    <h6>
                        Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                    </h6>
                    </center>`
                    console.log(`something went wrong ${JSON.stringify(response)}`);
                    // console.log(response.statusText);
                    // $('#table_students tbody .col').html(errorMsg)
                    $('#errors').html(errorMsg)
                }

            }
        });

    }
}
// Progress Steps JS End

function loadTeachersList() {

    $.ajax({
        url: '/sdp/teachers',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var teachers_list;
                $('#teachername').text(response.data)

                if (response.data.length == 0) {
                    teachers_list += `<option value="">Teachers List is empty</option>`;
                } else {
                    teachers_list = `<option value="">Select Teacher Name</option>`;
                    response.data.forEach(teacher => {

                        teachers_list += `
                        <option value="${teacher.user._id}">${teacher.user.name}</option>`;
                    });
                }

                $('#teachername').html(teachers_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Teachers Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-student-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch teachers list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_students tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadTeachersList()

function loadCoursesList() {

    $.ajax({
        url: '/sdp/courses',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var courses_list = ``;
                $('#lecturecourses').text(response.data)

                if (response.data.length == 0) {
                    courses_list += `<option value="">Course List is empty</option>`;
                } else {
                    courses_list = `<option value="">Select Course Name</option>`;
                    response.data.forEach(course => {

                        courses_list += `
                        <option value="${course._id}">${course.name}</option>`;
                    });
                }
                $('#coursename').html(courses_list)

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Courses Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_courses tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch courses list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_courses tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadCoursesList()

function loadStudentsList() {

    $.ajax({
        url: '/sdp/students/special/data',
        method: 'get',
        success: function (response) {
            if (response.success) {

                var students_list = ``;
                $('#studentslist').text(response.data)

                if (response.count == 0) {
                    students_list += `<option value="">No Student available</option>`;
                } else {
                    // students_list = `
                    // <input type="checkbox" name="default-batches" id="default-batches" class="mt-0">
                    // <label for="default-batches">Add default batches</label>`;
                    response.data.forEach(course => {
                        
                        students_list += `
                        <option id="${course._id}" value="${course.firstName} ${course.middleName} ${course.lastName}">${course.firstName} ${course.middleName} ${course.lastName}</option>`;
                        student_id_list.push(course._id)
                        students_all_list.push([course._id, `${course.firstName} ${course.middleName} ${course.lastName}`])
                    });
                }
                $('#myDropdown1-1').html(students_list)
                student_id_list.forEach(cat => {
                    $(`#${cat}`).click(() => {

                        const category = $('#myDropdown1-1').val()
                        if (category != '') {
                            // console.log(category);
                            $('#category_selected').text(category)
                            document.getElementById('category_selected').classList.add('c_selected')
                            update()
                        } else {
                            document.getElementById('category_selected').classList.remove('c_selected')
                            $('#category_selected').text('No Course selected')
                            document.getElementById("myDropdown1").classList.remove("show");
                        }


                    })
                });

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Students Fetched Successfully',
                    timer: 3000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_students tbody tr').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#errors').text(response.responseJSON.error);
                console.log(response.responseJSON.error);
                $('#errors').fadeIn();
                // $('#errors').css('display', 'block');
                $('#add-course-card button').attr('disabled', true)

            } else {
                $('#errors').fadeIn();
                var errorMsg = `
                <center class="text-danger">
                <h2>Oops! Something went wrong</h2>
                <h4>
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch students list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_students tbody .col').html(errorMsg)
                $('#errors').html(errorMsg)
            }

        }
    });

}
loadStudentsList()

// $('.addNewLecture').click(() => {
//     alert('Submit')
//     var nameInput = $('#lecturename')
//     var lecturename = $('#lecturename').val()

//     var addressInput = $('#lectureaddress')
//     var lectureaddress = $('#lectureaddress').val()

//     if (!lecturename) {
//         nameInput.css('border', '2px solid red')
//         nameInput.attr('placeholder', 'Please add lecture name')
//     } else if (!lectureaddress) {
//         addressInput.css('border', '2px solid red')
//         addressInput.attr('placeholder', 'Please add lecture address')
//     } else {

//         loading()

//         $.ajax({
//             url: '/sdp/lectures',
//             method: 'post',
//             dataType: 'json',
//             data: {
//                 name: lecturename,
//                 address: lectureaddress
//             },
//             success: function (response) {
//                 if (response.success) {

//                     $('#error,#loading').css('display', 'none')
//                     nameInput.val(null)
//                     addressInput.val(null)
//                     $('#add-lecture-card button').attr('disabled', true)
//                     Swal.fire({
//                         toast: true,
//                         position: 'top-right',
//                         icon: 'success',
//                         title: 'Lecture Added Successfully',
//                         timer: 3000,
//                         showConfirmButton: false
//                     });
//                     setTimeout(() => {
//                         document.location.replace('/sdp/teacher/lectures');
//                     }, 2500);

//                 } else {

//                     $('#loading').css('display', 'none');
//                     $('#error').text(response.responseJSON.error);
//                     $('#error').fadeIn();
//                     $('#error').css('display', 'block');
//                     $('#add-lecture-card button').attr('disabled', true)

//                 }
//             },
//             error: function (response) {

//                 $('#loading').css('display', 'none');
//                 $('#error').text(response.responseJSON.error);
//                 $('#error').fadeIn();
//                 $('#error').css('display', 'block');
//                 $('#add-lecture-card button').attr('disabled', true)

//             }
//         });

//     }
// })