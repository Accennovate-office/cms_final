
$('#no-fee-available').fadeOut()
$('#table_fees,#myInput').fadeOut()
$('#perPage_main,#pageNo_main').fadeOut()
$('#errorsection').fadeOut()
$('#view_note').fadeOut()

$('#sidebar-fees').trigger("click")
$('#sidebar-fees,#sidebar-fees-all').addClass('active')
$("div#mySidebar").scrollTop(300); // Ref: https://api.jquery.com/scrolltop/

$('#new-fee-btn').click(() => {
    document.location.replace('/sdp/teacher/addfee');
})

// Filter Table // Ref: https://www.w3schools.com/bootstrap/tryit.asp?filename=trybs_filters_table&stacked=h
$("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
});

// Page navigator
$('#perPage').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllFees(limit, page)
})

$('#pageNo').change(() => {
    // alert('Limit change')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllFees(limit, page)
})

$('#prev_page').click(() => {
    // alert('Prev')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllFees(limit, page - 1)
})

$('#next_page').click(() => {
    // alert('Next')
    const limit = parseInt($('#perPage').val())
    const page = parseInt($('#pageNo').val())
    loadAllFees(limit, page + 1)
})
// Page navigator End

function loadAllFees(limit = 10, page = 1) {
    Swal.fire({
        toast: true,
        position: 'top-right',
        icon: 'info',
        title: 'Loading...',
        showConfirmButton: false
    });

    $('#no-fee-available').fadeOut()
    $('#table_fees,#myInput').fadeOut()

    $.ajax({
        url: `/sdp/fees?limit=${limit}&page=${page}`,
        method: 'get',
        success: function (response) {
            if (response.success) {

                $('#error,#loading').css('display', 'none')

                if (response.data.length == 0 && response.total_count == 0) {
                    var noFee = `
                    <img src="/images/fees/nofee.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">Fee List is empty</span> <br><br>
                        <span class="h5">Click&nbsp;
                            <span>
                                <button class="btn btn-dark shadow-none"><i class="fa fa-plus" aria-hidden="true"></i> Add New
                                    Fee</button>
                            </span>
                            &nbsp;button at top left to get started
                        </span>
                    </div>`
                    $('#no-fee-available').fadeIn()
                    $('#no-fee-available').html(noFee)

                } else if (response.count == 0 && response.total_count != 0) {

                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1 || !response.pagination.prev) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages || !response.pagination.next) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    var error
                    if (page < 1) {
                        error = `<span class="text-danger">
                        ${page} page number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (page > max_pages) {
                        error = `<span class="text-danger">
                        ${page} page number exceeded maximum pages <br>
                        Maximum page number is ${max_pages}
                        </span>`
                    } else if (limit < 1) {
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`
                    } else if (limit > response.total_count) {
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`
                    }

                    var nofee = `
                    <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                    <div class="h3 mt-2">
                        <span class="font-weight-bold">No data found</span> <br><br>
                        <span class="h5">${error}</span>
                    </div>`
                    $('#no-fee-available').fadeIn()
                    $('#no-fee-available').html(nofee)

                    var showing_data = 'No Results Found'

                    // Bottom Data
                    $('#view_note').fadeIn()
                    $('#showing').html(showing_data)
                    $('#perPage_main,#pageNo_main').fadeIn()
                    $('#perPage').val(limit)
                    $('#pageNo').val(page)

                } else {
                    // console.log('wow 1');
                    const max_pages = Math.ceil(response.total_count / limit) // Ref: https://stackoverflow.com/a/11187380
                    // console.log(max_pages);
                    if (page == 1) {
                        $('#prev_page').css('display', 'none')
                    } else {
                        $('#prev_page').css('display', 'block')
                    }
                    if (page == max_pages) {
                        $('#next_page').css('display', 'none')
                    } else {
                        $('#next_page').css('display', 'block')
                    }

                    if (limit < 1) {
                        // console.log('wow 1.1');
                        error = `<span class="text-danger">
                        ${limit} record number not allowed <br>
                        Please add positive number
                        </span>`

                        var nofee = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-fee-available').fadeIn()
                        $('#no-fee-available').html(nofee)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else if (limit > response.total_count) {
                        // console.log('wow 1.2');
                        error = `<span class="text-danger">
                        ${limit} record number exceeded maximum records <br>
                        Maximum record number is ${response.total_count}
                        </span>`

                        var fee = `
                        <img src="/images/loginlogs/nodatafound.png" width="60" alt="">
                        <div class="h3 mt-2">
                            <span class="font-weight-bold">No data found</span> <br><br>
                            <span class="h5">${error}</span>
                        </div>`
                        $('#no-fee-available').fadeIn()
                        $('#no-fee-available').html(fee)

                        var showing_data = 'No Results Found'

                        // Bottom Data
                        $('#view_note').fadeIn()
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                    } else {
                        // console.log('wow 1.3');
                        var showing_data
                        if (response.pagination.prev == undefined) {
                            // First Page
                            showing_data = `Results 1 - ${response.count} of ${response.total_count}`
                            // console.log(`Results 1 - ${response.count} of ${response.total_count}`);
                        } else if (response.pagination.next == undefined) {
                            // Last page
                            showing_data = `Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`
                            // console.log(`Results ${response.total_count - response.count} - ${response.total_count} of ${response.total_count}`);
                        } else {
                            // Middle page
                            showing_data = `Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`
                            // console.log(`Results ${(response.pagination.prev.page * response.count) + 1} - ${(response.pagination.prev.page * response.count) + response.count} of ${response.total_count}`);
                        }

                        // Bottom Data
                        $('#showing').html(showing_data)
                        $('#perPage_main,#pageNo_main').fadeIn()
                        $('#perPage').val(limit)
                        $('#pageNo').val(page)

                        $('#table_fees,#myInput').fadeIn()
                        var tbody_fees;
                        var optionsCheck;
                        // var newelementCount = 0;
                        response.data.forEach(fee => {

                            // var utcCreatedDate = new Date(fee.createdAt);
                            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName: 'long' };

                            var createdHindiIST = new Date(fee.createdAt).toLocaleDateString("hi-IN", options)
                            var createdEnglishIST = new Date(fee.createdAt).toLocaleDateString("en-IN", options)

                            // Check date
                            optionsCheck = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var createdCheck = new Date(fee.createdAt).toLocaleDateString("en-IN", optionsCheck)
                            var today = new Date().toLocaleDateString("en-IN", optionsCheck)

                            var feeStartingAt = new Date(fee.startingAt).toLocaleDateString("en-IN", optionsCheck)
                            var newElement;
                            if (createdCheck === today) {
                                newElement = `<span class="badge badge-noti">New</span>`
                                // newelementCount += 1
                            } else {
                                newElement = ''
                            }
                            // if (newelementCount > 0) {
                            //     $('#sidebar-fees-all').html(`All Fees <span class="badge badge-noti">${newelementCount}</span>`)
                            // }

                            // var updateValue = fee.updatedAt ? fee.updatedAt : 'Not updated'
                            // // Converting update value from UTC to GMT
                            // if (updateValue != 'Not updated') {
                            //     // var utcUpdatedDate = new Date(updateValue);
                            //     // updateValue = utcUpdatedDate.toUTCString()

                            //     // Hindi Date time
                            //     // var updatedHindiIST = new Date(updateValue).toLocaleDateString("hi-IN", options)
                            //     updateValue = new Date(updateValue).toLocaleDateString("en-IN", options)
                            // }

                            // For join Date
                            var dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                            var payDateEnglishIST = new Date(fee.paymentDate).toLocaleDateString("en-IN", dateOptions)

                            tbody_fees += `
                            <tr id="${fee._id}">
                                <td>
                                ${fee.student.firstName} ${fee.student.middleName} ${fee.student.lastName} ${newElement}
                                </td>
                                <td>${fee.totalFees}</td>
                                <td>${fee.feesPaid}</td>
                                <td>${fee.pendingFees}</td>
                                <td>${fee.student.phone1} / ${fee.student.phone2} / ${fee.student.parentPhone} (Parent)</td>
                                <td>
                                    <div class="hover-container">
                                        <p class="hover-target d-flex align-items-center" tabindex="0"><i class="fas fa-ellipsis-v"></i> More</p>
                                        <aside class="hover-popup">
                                            <a align="center" class="p-1 fontt" href="/sdp/teacher/viewfee?fee=${fee._id}"><i class="fas fa-info"></i><br><span>View</span></a>
                                            <a align="center" class="p-1 fontt text-success" href="/sdp/teacher/editfee?fee=${fee._id}"><i class="fas fa-edit"></i><br><span>Edit</span></a>
                                            <a align="center" class="p-1 fontt text-danger" href="/sdp/teacher/deletefee?fee=${fee._id}"><i class="fas fa-trash"></i><br><span>Delete</span></a>
                                        </aside>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        $('#table_fees tbody').html(tbody_fees)

                    }

                }

                Swal.fire({
                    toast: true,
                    position: 'top-right',
                    icon: 'success',
                    title: 'Fees Fetched Successfully',
                    timer: 5000,
                    showConfirmButton: false
                });

            } else {

                $('#loading').css('display', 'none');
                $('#table_fees tbody tr').text(response);
                // console.log(response);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            }
        },
        error: function (response) {

            if (response.responseJSON) {
                $('#loading').css('display', 'none');
                $('#error').text(response.responseJSON.error);
                // console.log(response.responseJSON.error);
                $('#error').fadeIn();
                $('#error').css('display', 'block');
                $('#add-fee-card button').attr('disabled', true)

            } else {
                var errorMsg = `
                <center>
                <h2>Oops! Something went wrong</h2>
                <h4 class="text-danger">
                    Error Code: ${response.status} <br>
                    Error Message: ${response.statusText}
                </h4>
                <h5>We were unable to fetch fees list</h5>
                <h6>
                    Please contact administrator for help or mail us <a class="text-dark" href="mailto:support@smartbytecomputer.com">support@smartbytecomputer.com</a>
                </h6>
                </center>`
                console.log(`something went wrong ${JSON.stringify(response)}`);
                // console.log(response.statusText);
                // $('#table_fees tbody .col').html(errorMsg)
                $('#errorsection').html(errorMsg)
            }

        }
    });

}
loadAllFees()
