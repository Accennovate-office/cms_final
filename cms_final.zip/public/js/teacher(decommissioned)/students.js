$('#student-link').addClass('shadow-lg');
$('#student-link').addClass('active');
$('#student-img').css("content", "url('/images/student-color.png')");

const searchStudent = $('#search-student')
const searchStudentInput = $('#search-student input')
const clearSearchText = $('.clear-search')

searchStudent.focusin(() => {
    searchStudent.css('border', '2px solid #B947B1');
});
searchStudent.focusout(() => {
    searchStudent.css('border', '1px solid #555');
});
searchStudentInput.on('input', () => {
    let ans = searchStudentInput.val();
    if (ans != '') {
        clearSearchText.css('display', 'block')
    } else {
        clearSearchText.css('display', 'none')
    }
})
clearSearchText.click(() => {
    searchStudentInput.val('')
    clearSearchText.css('display', 'none')
})


$(".fa-arrow-circle-down").on("click", function () {

    $(".tbody").animate({
        scrollTop: 500
    });
});

$(".fa-arrow-circle-up").on("click", function () {

    $(".tbody").animate({
        scrollTop: -500
    });
});

$(".fa-arrow-circle-up").css('display', 'none');
$(".tbody").scroll(function () {
    var div = $(this);
    $(".fa-arrow-circle-down").css('display', 'block');
    $(".fa-arrow-circle-up").css('display', 'block');
    if (div[0].scrollHeight - div.scrollTop() == div.height()) {
        // alert("Reached the bottom!");
        $(".fa-arrow-circle-down").css('display', 'none');
    }
    else if (div.scrollTop() == 0) {
        // alert("Reached the top!");
        $(".fa-arrow-circle-up").css('display', 'none');
    }
});

const resetFilters = $('#reset-filters')
const nameSort = $('#name-sort')
const courseSort = $('#course-sort')
const courseFilter = $('#course-filter')
const dateSort = $('#date-sort')

resetFilters.click(() => {
    nameSort.prop('selectedIndex', 0);
    nameSort.css('background-color', '#fff')

    courseSort.prop('selectedIndex', 0);
    courseSort.css('background-color', '#fff')

    courseFilter.prop('selectedIndex', 0);
    courseFilter.css('background-color', '#fff')

    dateSort.prop('selectedIndex', 0);
    dateSort.css('background-color', '#fff')
    resetFilters.css('display', 'none')
})

nameSort.change(() => {
    var ans = nameSort.val()
    if (ans == '') {
        nameSort.css('background-color', '#fff')
    } else {
        nameSort.css('background-color', '#f088e9')
        resetFilters.css('display', 'block')
    }
    console.log(ans);

})
courseSort.change(() => {
    var ans = courseSort.val()
    if (ans == '') {
        courseSort.css('background-color', '#fff')
    } else {
        courseSort.css('background-color', '#f088e9')
        resetFilters.css('display', 'block')
    }
    console.log(ans);

})
courseFilter.change(() => {
    var ans = courseFilter.val()
    if (ans == '') {
        courseFilter.css('background-color', '#fff')
    } else {
        courseFilter.css('background-color', '#f088e9')
        resetFilters.css('display', 'block')
    }
    console.log(ans);

})
dateSort.change(() => {
    var ans = dateSort.val()
    if (ans == '') {
        dateSort.css('background-color', '#fff')
    } else {
        dateSort.css('background-color', '#f088e9')
        resetFilters.css('display', 'block')
    }
    console.log(ans);

})