$('#student-link').addClass('shadow-lg');
$('#student-link').addClass('active');
$('#student-img').css("content", "url('/images/student-color.png')");