// Student nav icon
$('#student').mouseenter(() => {
    $('#student').css('cursor', 'pointer');
    // $('#student-content').fadeIn(2500);
    $('#student-content').html('&nbsp;Students');
});
$('#student').mouseleave(() => {
    $('#student-content').html('');
});
// Lecture nav icon
$('#lecture').mouseenter(() => {
    $('#lecture').css('cursor', 'pointer');
    $('#lecture-content').html('&nbsp;Lectures');
});
$('#lecture').mouseleave(() => {
    $('#lecture-content').html('');
});
// Profile nav icon
$('#profile').mouseenter(() => {
    $('#profile').css('cursor', 'pointer');
    $('#profile-content').html('&nbsp;Profile');
});
$('#profile').mouseleave(() => {
    $('#profile-content').html('');
});
// Logout nav icon
$('#logout').mouseenter(() => {
    $('#logout').css('cursor', 'pointer');
    $('#logout-content').html('&nbsp;Logout');
});
$('#logout').mouseleave(() => {
    $('#logout-content').html('');
});


$('#logout').click(() => {
    swal.fire({
        title: 'Are you sure?',
        text: "You want to logout !",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, logout!'
    }).then((result) => {

        if (result.isConfirmed) {

            $.ajax({
                url: '/sdp/auth/logout',
                method: 'get',
                success: function (response) {
                    if (response.success) {

                        Swal.fire({
                            toast: true,
                            position: 'bottom-right',
                            icon: 'success',
                            title: 'Logged Out Successfully',
                            timer: 2000,
                            showConfirmButton: false
                        });

                        setTimeout(() => {
                            document.location.replace('/sdp/auth/login');
                        }, 1500);

                    } else {

                        Swal.fire({
                            icon: 'danger',
                            title: 'Something went wrong',
                            text: response.responseJSON.error
                        });

                    }
                },
                error: function (response) {

                    Swal.fire({
                        icon: 'danger',
                        title: 'Server error',
                        text: response.responseJSON.error
                    });

                }
            });

        }
    })
});

// Search hidden button
const search = document.getElementById('search')
const btn = document.getElementById('search-btn')
const input = document.getElementById('search-input')

btn.addEventListener('click', () => {
    search.classList.toggle('active')
    input.focus()
})
// Search hidden button end
