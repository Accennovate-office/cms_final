$('#profile-link').addClass('shadow-lg');
$('#profile-link').addClass('active');
$('#profile-img').css("content", "url('/images/profile-color.png')");

function iconColor() {

    if ($('#v-pills-basic-tab').hasClass('active')) {
        $('#v-pills-basic-tab img').css('content', 'url("/images/basic-color.png")');
    } else {
        $('#v-pills-basic-tab img').css('content', 'url("/images/basic-nocolor.png")');
    }
    if ($('#v-pills-education-tab').hasClass('active')) {
        $('#v-pills-education-tab img').css('content', 'url("/images/education-color.png")');
    } else {
        $('#v-pills-education-tab img').css('content', 'url("/images/education-nocolor.png")');
    }
    if ($('#v-pills-organization-tab').hasClass('active')) {
        $('#v-pills-organization-tab img').css('content', 'url("/images/organization-color.png")');
    } else {
        $('#v-pills-organization-tab img').css('content', 'url("/images/organization-nocolor.png")');
    }
    if ($('#v-pills-security-tab').hasClass('active')) {
        $('#v-pills-security-tab img').css('content', 'url("/images/security-color.png")');
    } else {
        $('#v-pills-security-tab img').css('content', 'url("/images/security-nocolor.png")');
    }
}
iconColor();

// Basic Tab
$('#v-pills-basic-tab').click(() => {

    $('.nav-pills .nav-link').removeClass('active');
    $('#v-pills-basic-tab').addClass('active');

    $('.tab-content .tab-pane').removeClass('show active');
    $('#v-pills-basic').addClass('show active');
    iconColor();
});

// Education Tab
$('#v-pills-education-tab').click(() => {

    $('.nav-pills .nav-link').removeClass('active');
    $('#v-pills-education-tab').addClass('active');

    $('.tab-content .tab-pane').removeClass('show active');
    $('#v-pills-education').addClass('show active');
    iconColor();
});

// Organization Tab
$('#v-pills-organization-tab').click(() => {

    $('.nav-pills .nav-link').removeClass('active');
    $('#v-pills-organization-tab').addClass('active');

    $('.tab-content .tab-pane').removeClass('show active');
    $('#v-pills-organization').addClass('show active');
    iconColor();
});

// Security Tab
$('#v-pills-security-tab').click(() => {

    $('.nav-pills .nav-link').removeClass('active');
    $('#v-pills-security-tab').addClass('active');

    $('.tab-content .tab-pane').removeClass('show active');
    $('#v-pills-security').addClass('show active');
    iconColor();
});

// Basic
$('#name,#email').click(() => {
    $('#name,#email').attr('disabled', true);
    swal.fire({
        title: 'You cannot update those details',
        text: "Contact your branch manager to change Name or Email",
        type: 'info',
        confirmButtonColor: '#0B6FAD',
        confirmButtonText: 'Ok'
    });
});
$('#profile-basic input').change(() => {
    $('#basic-profile-update').removeClass('disabled');
    $('#profile-basic button').css('cursor', 'pointer');
});
// Education
$('#education-qualification').change(() => {
    $('#education-qualification-update').removeClass('disabled');
    $('#education-qualification-update').css('cursor', 'pointer');
});
$('#computer-skills').change(() => {
    $('#computer-skills-update').removeClass('disabled');
    $('#computer-skills-update').css('cursor', 'pointer');
});

// Security
$('#change-password').click(() => {
    $('#changePassword').toggleClass('collapse');
});

$('#oldpassword,#newpassword,#confirmnewpassword').on('input', () => {
    const oldpass = $('#oldpassword').val();
    const newpass = $('#newpassword').val();
    const cnewpass = $('#confirmnewpassword').val();

    if (oldpass && newpass && cnewpass) {
        $('#security-profile-update').removeClass('disabled');
    } else {
        $('#security-profile-update').addClass('disabled');
    }
});