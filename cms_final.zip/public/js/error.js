$('button').click(() => {
    document.location.replace('/sdp/auth/login');
})