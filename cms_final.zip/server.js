const path = require('path');
const express = require('express');
const dotenv = require('dotenv');
// Custom middleware
const logger = require('./middleware/logger');
// Third party middleware
const morgan = require('morgan');
const colors = require('colors');
const fileupload = require('express-fileupload');
const cookieParser = require('cookie-parser');
const errorHandler = require('./middleware/error');
const connectDB = require('./config/db');
const cors = require('cors');
// Security
const mongoSanitize = require('express-mongo-sanitize');
const helmet = require('helmet');
const xss = require('xss-clean');
const rateLimit = require('express-rate-limit');
const hpp = require('hpp');

// Front-end packages
var $ = require('jquery');

const Swal = require('sweetalert2');
var bodyParser = require('body-parser');
const expressLayouts = require('express-ejs-layouts');

// Load env vars
dotenv.config({ path: './config/config.env' });

// Connect to database
connectDB();

// Route files
// const bootcamps = require('./routes/bootcamps');
const tasks = require('./routes/tasks');
const taskcategorys = require('./routes/taskcategorys');
const tasksubcategorys = require('./routes/tasksubcategorys');
const courses = require('./routes/courses');
const topics = require('./routes/topics');
const auth = require('./routes/auth');
const users = require('./routes/users');
const whatsapp = require('./routes/whatsapp');

// Front-end routes
const admin = require('./routes/admin');
const manager = require('./routes/manager');
const teacher = require('./routes/teacher');

const branches = require('./routes/branches');
const managers = require('./routes/managers');
const teachers = require('./routes/teachers');
const students = require('./routes/students');
const references = require('./routes/references');
const enquiries = require('./routes/enquiries');
const followups = require('./routes/followups');
const enqreferences = require('./routes/enqreferences');
const admissions = require('./routes/admissions');
const attendances = require('./routes/attendances');
const fees = require('./routes/fees');
const lectures = require('./routes/lectures');
const perks = require('./routes/perks');
const loginlogs = require('./routes/loginlogs');
const routelogs = require('./routes/routelogs');
// Custom middleware
// const logger = require('./middleware/logger');

const app = express();

// Body parser = used to read data from front-end (Previously we need to install body parser but now it's included in express)
app.use(express.json());

// Cookie parser
app.use(cookieParser());

app.use(logger);
// Dev logging middleware
if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
}
// app.use(morgan('combined'));

// File uploading middleware
app.use(fileupload());

// Sanitize data
app.use(mongoSanitize()); // To prevent sql injection

// Set security headers
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", "https://code.jquery.com", "https://cdn.jsdelivr.net", "https://stackpath.bootstrapcdn.com"], // Content Security Policy (CSP) Error on AWS
    styleSrc: ["'self'", "'unsafe-inline'", "https://stackpath.bootstrapcdn.com", "https://cdnjs.cloudflare.com", "https://fonts.googleapis.com"], // Allow styles in AWS
    fontSrc: ["'self'", "https://cdnjs.cloudflare.com", "https://fonts.gstatic.com"], // Add font sources here
    connectSrc: ["'self'", "https://api.elasticemail.com"],
}
}));

// Prevent XSS(Cross Site Scripting) Attacks
app.use(xss());

// Rate limiting
const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minutes
    max: 1000 // 1000 requests per 1 mins
});
app.use(limiter);

// Prevent http param pollution
app.use(hpp());

// Enable CORS
app.use(cors());

//set the template engine 
app.use(expressLayouts); // to use layouts package
app.set('layout', './layouts/basic'); // Custom name for layout file
app.set('view engine', 'ejs');

// Fetch data from the request  
app.use(bodyParser.urlencoded({ extended: false }));

//set the path of the jquery file to be used from the node_module jquery package  
app.use('/jquery', express.static(path.join(__dirname + '/node_modules/jquery/dist/')));
app.use('/css', express.static(path.join(__dirname + '/public/css')));
app.use('/js', express.static(path.join(__dirname + '/public/js')));
app.use('/images', express.static(path.join(__dirname + '/public/img')));

//set path for sweetalert2
app.use('/sweetalert2', express.static(path.join(__dirname + '/node_modules/sweetalert2/dist/')));
// app.use('/es6-promise', express.static(path.join(__dirname + '/node_modules/es6-promise/dist/')));

// Set static folder
app.use(express.static(path.join(__dirname, 'public')));
// app.use(express.static(__dirname, 'public'));

// Mount routers
// Using /api to just depict that it's an API
// Using /v1 to show which version, also it makes easy to upgrade to new versions and keep previous versions as it is to used by users.
// Temp
app.use('/sdp/tasks', tasks);
app.use('/sdp/taskcategorys', taskcategorys);
app.use('/sdp/tasksubcategorys', tasksubcategorys);
app.use('/sdp/courses', courses);
app.use('/sdp/topics', topics);
app.use('/sdp/auth', auth);
app.use('/sdp/users', users);
app.use('/sdp/whatsapp', whatsapp);

app.use('/sdp/admin', admin);
app.use('/sdp/manager', manager);
app.use('/sdp/teacher', teacher);

app.use('/sdp/branches', branches);
app.use('/sdp/managers', managers);
app.use('/sdp/teachers', teachers);
app.use('/sdp/students', students);
app.use('/sdp/references', references);
app.use('/sdp/enquiries', enquiries);
app.use('/sdp/followups', followups);
app.use('/sdp/enqreferences', enqreferences);
app.use('/sdp/admissions', admissions);
app.use('/sdp/attendances', attendances);
app.use('/sdp/fees', fees);
app.use('/sdp/lectures', lectures);
app.use('/sdp/perks', perks);
app.use('/sdp/loginlogs', loginlogs);
app.use('/sdp/routelogs', routelogs);
// Temp end 1

// Ajax call using axios
// Ref: https://attacomsian.com/blog/node-http-post-request
const axios = require('axios');

const createUser = async (data) => {
    try {
        const res = await axios.post('http://localhost:5000/sdp/attendances', data);
        console.log(`Status: ${res.status}`);
        console.log('Body: ', res.data);
    } catch (err) {
        console.error(err);
    }
};

// Ajax call using axios end

// Pub-sub subscription Code (Working Code)
const mqtt = require("mqtt");

var client = mqtt.connect("mqtt://broker.hivemq.com");

client.on("connect", function () {

    // var topic = 'VVTest/#'
    const getLiveData = "vvmmqtt/house/id"; // Working
    var topic = getLiveData
    client.subscribe(topic);
    console.log("Client subscribed to " + topic);

    // For enrolling new user
    // console.log("Registering for ID 6 .......")
    // client.publish("/smartbyte/fingerprint/mode/enroll", "6")

    // For deleting user
    // console.log("Deleting ID 78 .....")
    // client.publish("/smartbyte/fingerprint/mode/delete", "78")
});

client.on("message", function (topic, message) {

    // console.log(message);
    const data = JSON.parse(message)
    console.log(data)
    // console.log(data.id)
    // data.attendanceType = 'System'
    // console.log('------------------------------------')
    // console.log(data)
    // console.log(data.attendanceType)


    // Working code
    // const data = {
    //     user: '61d075c481794d1f44cb57cf',
    //     loginOrLogout: 'Logout',
    //     dateTime: '2022-03-04T10:49:56.820Z',
    //     currentJobTime: '8AM - 7PM',
    //     branch: 'Kalyan test'
    // };

    // createUser(data);

});
// Pub-sub subscription Code end

// New code to publish
/* Connect, send a message with QoS 1 (at least once), and disconnect
 */
client.on("connect", function () {
    if (client.connected) {
        client.publish({
            topic: "/smartbyte/fingerprint/mode/enroll",
            payload: "344",
            qos: 1
        }, function (complete) {
            console.log("publish complete with code: " + complete.result);
            client.disconnect();
        }, function (error) {
            console.log("error on publish: " + (error.reason || "unknown"));
            client.disconnect();
        });
    } else {
        console.log("Not connected to broker")
    }
});
// New code to publish end

// const fs = require('fs');
// const {createCanvas, loadImage}= require('canvas');

// // get the base64 string
// const base64String = require("./base64");

// loadImage(Buffer.from(base64String, "base64")).then(async (img) => {
//   const canvas = createCanvas(img.width, img.height, 'pdf');
//   const ctx = canvas.getContext('2d');
//   console.log(`w: ${img.width}, h: ${img.height}`);

//   ctx.drawImage(img, 0, 0, img.width, img.height);
//   const base64image = canvas.toBuffer();
  
//   // write the file to a pdf file
//   fs.writeFile('simple.pdf', base64image, function(err) {
//       console.log('File created');
//   });
// });

// Temp
app.use('/sdp', (req, res) => {
    res.redirect('/sdp/auth/login')
});
// Temp end 2

//The 404 Route (ALWAYS Keep this as the last route)
app.get('*', function (req, res) {
    // res.redirect("https://smartbytecomputer.com/cms")
    res.status(404).render('partials/notfound', { title: 'SDP | Page Not Found', css: 'notfound', js: 'notfound' })
});

// We have to use this below bootcamps if we want to trigger this in controller
// app.use(errorHandler); (working)

const PORT = process.env.PORT || 5000;

const server = app.listen(
    PORT,
    console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`.yellow.bold)
);

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
    console.log(`Error: ${err.message}`.red);
    // Close server and exit process
    server.close(() => process.exit(1));
    // In order to exit application with failure '1' is used in exit call
});
// This error handling is created to crash the app when not connected with database