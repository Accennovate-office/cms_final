const mongoose = require('mongoose');

const FeeSchema = new mongoose.Schema({
    student: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Student', // Reference to another model to connect with
        required: [true, 'Student id is required to create new fee']
    },
    totalFees: {
        type: Number,
        required: [true, 'Please add total fees']
    },
    feesPaid: {
        type: Number,
        required: [true, 'Please add fees paid']
    },
    pendingFees: {
        type: Number,
        required: [true, 'Please add pending fees']
    },
    paymentMethod: {
        type: String,
        required: [true, 'Please add a payment method']
    },
    paymentDate: {
        type: Date,
        required: [true, 'Please add a payment date']
    },
    receiptNo: {
        type: String,
        required: [true, 'Please add a receipt number']
    },
    collectedBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new fee'] // Because every course needs to have a user
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new fee'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    },
    branch: {
        type: String,
        required: [true, 'Branch name is required to create new admission']
    }
});


module.exports = mongoose.model('Fee', FeeSchema);