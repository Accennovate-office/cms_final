const mongoose = require('mongoose');

const RoutelogSchema = new mongoose.Schema({
    dateAndTime: {
        type: String,
        required: [true, 'Date & Time is required to create new routelog']
    },
    requestMethod: {
        type: String,
        required: [true, 'Please add request method']
    },
    requestURL: {
        type: String,
        required: [true, 'Please add request URL']
    },
    statusCode: {
        type: Number,
        required: [true, 'Please add status code']
    },
    user: {
        type: Object // Ref: https://stackoverflow.com/a/17498258
        // required: [true, 'User data is required to create new routelog']
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Routelog', RoutelogSchema);