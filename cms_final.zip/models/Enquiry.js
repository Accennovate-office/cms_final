const mongoose = require('mongoose');

const EnquirySchema = new mongoose.Schema({
    // Personal Details
    firstName: {
        type: String,
        trim: true,
        required: [true, 'Please add a enquiry first name']
    },
    middleName: {
        type: String,
        trim: true,
        // required: [true, 'Please add a enquiry middle name']
    },
    lastName: {
        type: String,
        trim: true,
        // required: [true, 'Please add a enquiry last name']
    },
    dob: {
        type: Date,
        // required: [true, 'Please add a enquiry Date of Birth']
    },
    gender: {
        type: String,
        enum: ['Male', 'Female', 'Other'],
        // required: [true, 'Please add a enquiry gender']
    },
    religion: {
        type: String,
        // required: [true, 'Please add a enquiry religion']
    },
    caste: {
        type: String,
        // required: [true, 'Please add a enquiry caste']
    },
    aadhaarNo: {
        type: Number,
        maxlength: [12, 'Aadhaar number can not be more than 12 digits']
    },
    // Family Details
    motherName: {
        type: String,
        trim: true,
        // required: [true, "Please add a enquiry mother's name"]
    },
    fatherOccupation: {
        type: String,
        // required: [true, "Please add a enquiry father's occupation"]
    },
    motherTongue: {
        type: String,
        // required: [true, 'Please add a enquiry mother tongue']
    },
    // Contact Details 
    address: {
        type: String,
        // required: [true, 'Please add a enquiry address']
    },
    // roomNo: String,
    // building: String,
    area:  {
        type: String,
        required: [true, 'Please add a enquiry area']
    },
    // landmark: String,
    parentPhone: {
        type: Number,
        // required: [true, 'Please add a enquiry parent phone']
    },
    phone1: {
        type: Number,
        required: [true, 'Please add a enquiry phone 1']
    },
    phone2: {
        type: Number,
        // required: [true, 'Please add a enquiry phone 2']
    },
    email: {
        type: String,
        // required: [true, 'Please add a enquiry email'],
        match: [
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            'Please add a valid email'
        ]
    },
    // Educational Details
    qualification: {
        type: String,
        // required: [true, 'Please add a enquiry qualification']
    },
    schoolOrCollegeName: {
        type: String,
        // required: [true, 'Please add a enquiry school or college name']
    },
    classOrTuitionName: {
        type: String,
        // required: [true, 'Please add a enquiry class or tuition name']
    },
    // Other Details
    category: {
        type: String,
        enum: ['Student', 'Service', 'HomeMaker'],
        // required: [true, 'Please add a enquiry category']
    },
    reference: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Enqreference', // Reference to another model to connect with
    },
    facebook: String,
    instagram: String,
    youtube: String,
    twitter: String,
    linkedin: String,
    // Organization Details
    branch: {
        // NEW
        type: String, // This is special type of mongoose i.e. the _id of any document
        // OLD
        // type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        // ref: 'Branch', // Reference to another model to connect with
        required: [true, 'Branch is required to create new enquiry']
    },
    courses: {
        type: String,
        required: [true, 'Course is required to create new enquiry']
    },
    // Admission done / not
    admission: {
        type: Boolean,
        default: false
    },
    takenby: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
    },
    takenbyother: String,
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new enquiry'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Enquiry', EnquirySchema);