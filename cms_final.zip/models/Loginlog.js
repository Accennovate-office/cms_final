const mongoose = require('mongoose');

const LoginlogSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, 'Email is missing']
    },
    password: {
        type: String,
        required: [true, 'Password is missing']
    },
    isSuccess: {
        type: Boolean,
        default: 0
    },
    user: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User'
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    deleted: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('Loginlog', LoginlogSchema);