const mongoose = require('mongoose');

const RegistrationSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User'
    },
    biometricId: {
        type: String,
    },
    createdBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'User'
    },
    name: {
        type: String,
        required: true
    },
    designation: {
        type: String,
        enum: ['Admin', 'Manager', 'Teacher', 'Student', 'Other'],
        required: true
    },
    currentJobTime: {
        type: String,
        required: [true, 'Please add job time']
    },
    branch: {
        type: String,
        required: [true, 'Branch name is required to create new attendance']
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('Registration', RegistrationSchema);