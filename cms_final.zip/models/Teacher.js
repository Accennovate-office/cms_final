const mongoose = require('mongoose');

const TeacherSchema = new mongoose.Schema({
    dob: {
        type: Date,
        required: [true, 'Please add a teacher Date of Birth']
    },
    phone: {
        type: Number,
        required: [true, 'Please add a teacher phone']
    },
    address: {
        type: String,
        required: [true, 'Please add a teacher address']
    },
    educationalQualification: {
        type: String,
        required: [true, 'Please add a teacher educational qualifications']
    },
    computerSkills: {
        type: String,
        required: [true, 'Please add a teacher computer skills']
    },
    coursesAllocated: {
        type: String,
        required: [true, 'Please add a teacher allocated courses']
    },
    joiningDate: {
        type: Date,
        required: [true, 'Please add a teacher Joining Date']
    },
    jobTime: {
        type: String,
        required: [true, 'Please add a teacher Job Time']
    },
    // Bank details
    accountHolderName: {
        type: String,
        // required: [true, 'Please add account holder name']
    },
    accountNumber: {
        type: Number,
        // required: [true, 'Please add account number']
    },
    IFSCcode: {
        type: String,
        // required: [true, 'Please add IFSC code']
    },
    bank: {
        type: String,
        // required: [true, 'Please add bank name']
    },
    bankBranch: {
        type: String,
        // required: [true, 'Please add bank branch name']
    },
    PAN: {
        type: String,
        // required: [true, 'Please add PAN card number']
    },
    user: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to created new teacher'] // Because every teacher needs to have a login credentials
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new task'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    },
    branch: {
        type: String,
        required: [true, 'Please add branch name']
    }
});


module.exports = mongoose.model('Teacher', TeacherSchema);