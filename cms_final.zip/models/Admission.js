const mongoose = require('mongoose');

const AdmissionSchema = new mongoose.Schema({
    student: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Student', // Reference to another model to connect with
        required: [true, 'Student id is required to create new admission']
    },
    course: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Course', // Reference to another model to connect with
        required: [true, 'Course id is required to create new admission']
    },
    fees: {
        type: Number,
        required: [true, 'Please add a course fees']
    },
    admissionDate: {
        type: Date,
        required: [true, 'Please add a admission date']
    },
    batch: {
        type: String,
        required: [true, 'Please add a batch time']
    },
    teacher: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'Teacher id is required to create new admission']
    },
    installment: {
        type: Boolean,
        required: [true, 'Please add installment']
    },
    installmentdate: Date,
    rollNo: {
        type: String,
        // required: [true, 'Please add a admission roll number']
    },
    enrollmentMonth: {
        type: String,
        // required: [true, 'Please add a admission enrollment month']
    },
    enrollmentNo: {
        type: Number,
        // required: [true, 'Please add a admission enrollment number']
    },
    enrollmentPaymentDate: {
        type: Date,
        // required: [true, 'Please add a admission enrollment payment date']
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new admission'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    },
    branch: {
        type: String,
        required: [true, 'Branch name is required to create new admission']
    }
});


module.exports = mongoose.model('Admission', AdmissionSchema);