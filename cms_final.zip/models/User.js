const crypto = require('crypto');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // 'bcrypt' package also exists but it gives some issues on windows
const jwt = require('jsonwebtoken');
// const slugify = require('slugify');

const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add a name']
    },
    dob: {
        type: Date,
        required: [true, 'Please add Date of Birth']
    },
    slug: {
        type: String
    },
    branch: {
        type: String,
        required: [true, 'Please add a branch']
    },
    email: {
        type: String,
        required: [true, 'Please add an email'],
        unique: [true, 'User with email already exists'],
        match: [
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            'Please add a valid email'
        ]
    },
    role: {
        type: String,
        enum: ['teacher', 'manager'], // To make a user admin we have to do it manually in database in order to safety, bcoz only 1 admin will be there
        default: 'teacher'
    },
    password: {
        type: String,
        required: [true, 'Please add a password'],
        minlength: [6, 'Enter minimum 6 characters'],
        select: false // To show on API password will not be returned / shown in data
    },
    passwordUpdated: Date,
    resetPasswordToken: String,
    resetPasswordExpire: Date,
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false,
        select: false
    }
});

// Encrypt password using bcrypt
UserSchema.pre('save', async function (next) {

    // Create user slug from the name
    // this.slug = slugify(this.name, { lower: true }); // Creating slug name with slugify
    this.slug = this.email.split("@")[0];

    // For reset password functionality
    if (!this.isModified('password')) {
        next();
        // so now below 2 lines will run only if password is modified
    }

    const salt = await bcrypt.genSalt(10); // Higher the value secure is the password & more computing power the server needs. 10 is recommended in documentation

    this.password = await bcrypt.hash(this.password, salt); // pretty damn secure
});

// Sign JWT and return
UserSchema.methods.getSignedJwtToken = function () {
    return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE
    });
};

// Match user entered password to hashed password in database
UserSchema.methods.matchPassword = async function(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

// Generate and hash password token
// Its a method because its not called directly on the model but on the user
UserSchema.methods.getResetPasswordToken = function () {
    // Generate token
    const resetToken = crypto.randomBytes(20).toString('hex'); // randomBytes gives buffer so convert it to String

    // Hash token and set to resetPasswordToken field
    this.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');

    // Set expire
    this.resetPasswordExpire = Date.now() + 10 * 60 * 1000; // 10 mins

    return resetToken; // Return token without hash

}

module.exports = mongoose.model('User', UserSchema);