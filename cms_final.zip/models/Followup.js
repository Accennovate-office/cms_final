const mongoose = require('mongoose');
const { followupTypes } = require('../utils/enums')

const FollowupSchema = new mongoose.Schema({
    
    followupNo: {
        type: Number,
        required: true
    },
    type: {
        type: Number,
        enum: followupTypes,
        required: [true, 'Please add a Followup type']
    },
    comment:  {
        type: String,
        required: [true, 'Please add a Followup comment']
    },
    takenby: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
    },
    takenbyother: String,
    takenon: {
        type: Date,
        default: Date.now
    },
    enquiry: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'Enquiry', // Reference to another model to connect with
        required: [true, 'Enquiry id is required to create new Followup']
    },
    converted: {
        type: Boolean,
        required: true
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new Followup'] // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Followup', FollowupSchema);