const mongoose = require('mongoose');

const BirthdaySchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required to create new birthday']
    },
    email: {
        type: String,
        required: [true, 'Email is required to create new birthday']
    },
    emailSendOn: {
        type: Date,
        default: Date.now
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: [true, 'User id is required to create new perk'] // Because every course needs to have a user
    },
    deleted: {
        type: Boolean,
        default: false
    }
});


module.exports = mongoose.model('Birthday', BirthdaySchema);