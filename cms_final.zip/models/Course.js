const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
    name: {
        type: String,
        trim: true,
        required: [true, 'Please add a course name']
    },
    description: {
        type: String,
        required: [true, 'Please add a description']
    },
    weeks: {
        type: String,
        required: [true, 'Please add number of weeks']
    },
    fees: {
        type: Number,
        required: [true, 'Please add course cost']
    },
    startingAt: {
        type: Date,
        required: [true, 'Please add a starting date']
    },
    batchTiming: {
        type: String,
        required: true,
        default: false
    },
    createdBy: {
        type: mongoose.Schema.ObjectId, // This is special type of mongoose i.e. the _id of any document
        ref: 'User', // Reference to another model to connect with
        required: true // Because every course needs to have a user
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: Date,
    deleted: {
        type: Boolean,
        default: 0,
        select: false
    }
});

module.exports = mongoose.model('Course', CourseSchema);