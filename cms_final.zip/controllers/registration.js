const ErrorResponse = require("../utils/errorResponse");
const Registration = require("../models/Registration");
const asyncHandler = require("../middleware/async");

exports.getRegistrations = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

exports.createRegistration = asyncHandler(async (req, res, next) => {
  console.log("inside create registration");
  console.log(req.body);
  const registration = await Registration.create(req.body);
  res.status(201).json({
    success: true,
    data: registration,
  });
});

exports.getRegistration = asyncHandler(async (req, res, next) => {
  await Registration.find({ biometricId: req.params.id })
    .populate("user createdBy")
    .exec(function (err, person) {
      if (err) return console.log(err);
      res.status(200).json({ success: true, data: person });
    });
});
