const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Branch = require('../models/Branch');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// Importing modules
const fs = require('fs')
// import fs from 'fs'

// @desc        Get all branches
// @route       GET /sdp/branches
// @access      Private(admin)
exports.getBranches = asyncHandler(async (req, res, next) => {

    res.status(200).json(res.advancedResults);
})

// @desc        Create new branch
// @route       POST /sdp/branches
// @access      Private(admin)
exports.createBranch = asyncHandler(async (req, res, next) => {

    // Add user to req.user
    req.body.user = req.user.id; // req.user is must for id
    console.log(req.body.user);
    const branch = await Branch.create(req.body);
    res.status(201).json({
        success: true,
        data: branch
    });
});

// @desc        Get single branch
// @route       GET /sdp/branches/:name
// @access      Private(admin) 
exports.getBranch = asyncHandler(async (req, res, next) => {

    const branch = await Branch.find({ name: req.params.name, deleted: false });
    // console.log(branch[0]);
    if (!branch[0]) {
        
        return next(new ErrorResponse(`Branch not found with name ${req.params.name}`, 404)); // Handling if no branchs found with correctly formatted _id
    }
    res.status(200).json({ success: true, data: branch[0] });
});

// @desc        Edit single branch
// @route       PUT /sdp/branches/:id
// @access      Private(admin) 
exports.editBranch = asyncHandler(async (req, res, next) => {

    let branch = await Branch.findById(req.params.id);
    // console.log(branch);
    if (!branch) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Branch does not exists`, 404));
    }

    // Make sure user is branch owner
    // if (branch.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this branch`, 401));
    // }
    req.body.updatedAt = new Date();
    branch = await Branch.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: branch });
});

// @desc        Delete single branch
// @route       DELETE /sdp/branches/:id
// @access      Private(admin) 
exports.deleteBranch = asyncHandler(async (req, res, next) => {

    let branch = await Branch.findById(req.params.id);
    // console.log(branch);
    if (!branch) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Branch does not exists`, 404));
    }

    // Make sure user is branch owner
    // if (branch.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this branch`, 401));
    // }
    req.body.deleted = true;
    branch = await Branch.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: branch });
});
