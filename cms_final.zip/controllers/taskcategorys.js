const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Taskcategory = require('../models/Taskcategory');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// @desc        Get all taskcategorys
// @route       GET /sdp/taskcategorys
// @access      Private(Admin,Manager)
exports.getTaskcategorys = asyncHandler(async (req, res, next) => { // #### DONE ####

    // After using middleware for advanced results
    res.status(200).json(res.advancedResults);

    // const taskcategorys = await query;

    // res.status(200).json({
    //     success: true,
    //     count: taskcategorys.length,
    //     data: taskcategorys
    // });
});

// @desc        Get single taskcategory
// @route       GET /sdp/taskcategorys/:id
// @access      Private(Admin,Manager)
exports.getTaskcategory = asyncHandler(async (req, res, next) => { // #### DONE ####
    const taskcategory = await Taskcategory.findById(req.params.id).populate({
        path: 'createdBy',
        // select: 'name description'
    });

    if (!taskcategory) {
        return next(new ErrorResponse(`No taskcategory with the id ${req.params.id}`), 404);
    }

    res.status(200).json({
        success: true,
        data: taskcategory
    });
});

// @desc        Add taskcategory
// @route       POST /sdp/taskcategorys
// @access      Private(Admin,Manager)
exports.addTaskcategory = asyncHandler(async (req, res, next) => { // #### DONE ####

    req.body.createdBy = req.user.id;

    const taskcategory = await Taskcategory.create(req.body);

    res.status(200).json({
        success: true,
        data: taskcategory
    });
});

// // @desc        Update taskcategory
// // @route       PUT /sdp/taskcategorys/:id
// // @access      Private
// exports.updateTaskcategory = asyncHandler(async (req, res, next) => { // #### DONE ####
//     let taskcategory = await Taskcategory.findById(req.params.id);

//     if (!taskcategory) {
//         return next(new ErrorResponse(`No taskcategory with the id ${req.params.id}`), 404);
//     }

//     // // Make sure user is taskcategory owner
//     // if (taskcategory.user.toString() !== req.user.id && req.user.role !== 'admin') {
//     //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to update taskcategory ${taskcategory._id}`, 401));
//     // }
//     req.body.updatedAt = new Date();
//     taskcategory = await Taskcategory.findByIdAndUpdate(req.params.id, req.body, {
//         new: true,
//         runValidators: true
//     });

//     res.status(200).json({
//         success: true,
//         data: taskcategory
//     });
// });

// @desc        Delete taskcategory
// @route       DELETE /sdp/taskcategorys/:id
// @access      Private(Admin,Manager)
exports.deleteTaskcategory = asyncHandler(async (req, res, next) => { // #### DONE ####
    const taskcategory = await Taskcategory.findById(req.params.id);

    if (!taskcategory) {
        return next(new ErrorResponse(`No taskcategory with the id ${req.params.id}`), 404);
    }

    // // Make sure user is taskcategory owner
    // if (taskcategory.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete taskcategory ${taskcategory._id}`, 401));
    // }

    // await taskcategory.remove(); // Actual delete taskcategory
    req.body.deleted = true; // Fake delete taskcategory
    manager = await Taskcategory.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({
        success: true,
        data: {}
    });
});