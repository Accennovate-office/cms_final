const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Enquiry = require('../models/Enquiry');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');
const { isEmptyObject } = require('jquery');


// @desc        Get all enquiries
// @route       GET /sdp/enquiries
// @access      Private(admin)
exports.getEnquiries = asyncHandler(async (req, res, next) => {

    var month = 0, year = 0

    if (req.user.role == 'admin') {
        console.log('admin')

        // Monthly report
        await Enquiry.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            { $eq: ["$deleted", false] },
                            { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] }
                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                month = result[0].myCount
            }
        })

        // console.log('////////////////////// YEAR ///////////////////////////////')
        // Testing code
        // await Enquiry.aggregate([
        //     {
        //         $match: {
        //             $expr: {
        //                 $and: [
        //                     { $eq: ["$deleted", false] },
        //                     { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
        //                 ]
        //             }
        //         }
        //     },
        //     { $project: { _id: 0, deleted: true } }
        //     // { $group: { _id: null, myCount: { $sum: 1 } } },
        // ]).then((result) => {
        //     console.log(result)
        // })
        // console.log('????????????????????????? YEAR ????????????????????????????')
        // Yearly report
        await Enquiry.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            { $eq: ["$deleted", false] },
                            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            // console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                year = result[0].myCount
            }
        })
    } else {
        // console.log('manager / teacher')
        // console.log(req.user);
        await Enquiry.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            {
                                $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }],
                            }, {
                                $eq: ["$branch", req.user.branch]
                            }

                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            // console.log('Month ------------------------------------------------')
            // console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                month = result[0].myCount
            }
        })

        await Enquiry.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            {
                                $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }],
                            }, {
                                $eq: ["$branch", req.user.branch]
                            }

                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            // console.log('Year ------------------------------------------------')
            // console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                year = result[0].myCount
            }
        })
    }


    let summary = {
        month,
        year
    }
    res.advancedResults.summary = summary
    console.log(req.user);
    var allEnquiriesData
    if (req.user.role === 'admin') {
        allEnquiriesData = await Enquiry.find({ deleted: false }).populate('reference takenby createdBy').sort({ createdAt: -1 });
    } else {
        allEnquiriesData = await Enquiry.find({ deleted: false, branch: req.user.branch }).populate('reference takenby createdBy').sort({ createdAt: -1 });
    }
    // let allEnquiriesData = await Enquiry.find({deleted:false}).populate('reference branch takenby createdBy').sort({createdAt:-1});
    res.advancedResults.alldata = allEnquiriesData
    res.advancedResults.alldatacount = allEnquiriesData.length

    res.status(200).json(res.advancedResults);
})

// @desc        Create new enquiry
// @route       POST /sdp/enquiries
// @access      Private(admin)
exports.createEnquiry = asyncHandler(async (req, res, next) => {

    req.body.createdBy = req.user.id;
    const enquiry = await Enquiry.create(req.body);
    res.status(201).json({
        success: true,
        data: enquiry
    });
});

// @desc        Get single enquiry
// @route       GET /sdp/enquiries/:id
// @access      Private(admin) 
exports.getEnquiry = asyncHandler(async (req, res, next) => {

    // const enquiry = await res.advancedResults.find({ name: req.params.id, deleted: false });
    var enquiry = await Enquiry.findOne({ _id: req.params.id, deleted: false }).populate('reference takenby createdBy');
    // console.log(enquiry);
    // console.log(enquiry.length);
    if (enquiry.length === 0) {
        return next(new ErrorResponse(`Enquiry not found with id ${req.params.id}`, 404)); // Handling if no enquirys found with correctly formatted _id
        // console.log('enquiry not found ->');
    } else {
        res.status(200).json({ success: true, data: enquiry });
    }
    // console.log('Single enquiry found above');
    // let found = 0;
    // const enquiries = res.advancedResults.data
    // // console.log(enquiries);
    // enquiries.forEach(enquiry => {
    //     if ((enquiry._id == req.params.id) && (enquiry.deleted == false)) {
    //         res.status(200).json({ success: true, data: enquiry });
    //         found = 1
    //         // console.log(enquiry)
    //     }
    // });
    // if (found == 0) {
    //     return next(new ErrorResponse(`Enquiry not found with id ${req.params.id}`, 404)); // Handling if no enquiries found with correctly formatted _id
    // }
});

// @desc        Edit single enquiry
// @route       PUT /sdp/enquiries/:id
// @access      Private(admin) 
exports.editEnquiry = asyncHandler(async (req, res, next) => {

    let enquiry = await Enquiry.findById(req.params.id);
    // console.log(enquiry);
    if (!enquiry) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Enquiry does not exists`, 404));
    }

    req.body.updatedAt = new Date();
    enquiry = await Enquiry.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: enquiry });
});

// @desc        Delete single enquiry
// @route       DELETE /sdp/enquiries/:id
// @access      Private(admin) 
exports.deleteEnquiry = asyncHandler(async (req, res, next) => {

    let enquiry = await Enquiry.findById(req.params.id);
    console.log(enquiry);
    if (!enquiry) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Enquiry does not exists`, 404));
    }

    req.body.deleted = true;
    enquiry = await Enquiry.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: enquiry });
    res.status(200).json({ success: true, data: {} });
});
