const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Tasksubcategory = require('../models/Tasksubcategory');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// @desc        Get all tasksubcategorys
// @route       GET /sdp/tasksubcategorys
// @access      Private(Admin,Manager)
exports.getTasksubcategorys = asyncHandler(async (req, res, next) => { // #### DONE ####

    // After using middleware for advanced results
    res.status(200).json(res.advancedResults);

    // const tasksubcategorys = await query;

    // res.status(200).json({
    //     success: true,
    //     count: tasksubcategorys.length,
    //     data: tasksubcategorys
    // });
});

// @desc        Get single tasksubcategory
// @route       GET /sdp/tasksubcategorys/:id
// @access      Private(Admin,Manager)
exports.getTasksubcategory = asyncHandler(async (req, res, next) => { // #### DONE ####
    const tasksubcategory = await Tasksubcategory.findById(req.params.id).populate({
        path: 'createdBy',
        // select: 'name description'
    });

    if (!tasksubcategory) {
        return next(new ErrorResponse(`No tasksubcategory with the id ${req.params.id}`), 404);
    }

    res.status(200).json({
        success: true,
        data: tasksubcategory
    });
});

// @desc        Add tasksubcategory
// @route       POST /sdp/tasksubcategorys
// @access      Private(Admin,Manager)
exports.addTasksubcategory = asyncHandler(async (req, res, next) => { // #### DONE ####

    req.body.createdBy = req.user.id;

    const tasksubcategory = await Tasksubcategory.create(req.body);

    res.status(200).json({
        success: true,
        data: tasksubcategory
    });
});

// // @desc        Update tasksubcategory
// // @route       PUT /sdp/tasksubcategorys/:id
// // @access      Private
// exports.updateTasksubcategory = asyncHandler(async (req, res, next) => { // #### DONE ####
//     let tasksubcategory = await Tasksubcategory.findById(req.params.id);

//     if (!tasksubcategory) {
//         return next(new ErrorResponse(`No tasksubcategory with the id ${req.params.id}`), 404);
//     }

//     // // Make sure user is tasksubcategory owner
//     // if (tasksubcategory.user.toString() !== req.user.id && req.user.role !== 'admin') {
//     //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to update tasksubcategory ${tasksubcategory._id}`, 401));
//     // }
//     req.body.updatedAt = new Date();
//     tasksubcategory = await Tasksubcategory.findByIdAndUpdate(req.params.id, req.body, {
//         new: true,
//         runValidators: true
//     });

//     res.status(200).json({
//         success: true,
//         data: tasksubcategory
//     });
// });

// @desc        Delete tasksubcategory
// @route       DELETE /sdp/tasksubcategorys/:id
// @access      Private(Admin,Manager)
exports.deleteTasksubcategory = asyncHandler(async (req, res, next) => { // #### DONE ####
    const tasksubcategory = await Tasksubcategory.findById(req.params.id);

    if (!tasksubcategory) {
        return next(new ErrorResponse(`No tasksubcategory with the id ${req.params.id}`), 404);
    }

    // // Make sure user is tasksubcategory owner
    // if (tasksubcategory.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete tasksubcategory ${tasksubcategory._id}`, 401));
    // }

    // await tasksubcategory.remove(); // Actual delete tasksubcategory
    req.body.deleted = true; // Fake delete tasksubcategory
    manager = await Tasksubcategory.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({
        success: true,
        data: {}
    });
});