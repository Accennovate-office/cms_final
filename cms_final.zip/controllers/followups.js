const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Followup = require('../models/Followup');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');
const { isEmptyObject } = require('jquery');


// @desc        Get all Followups (Get followups of a enquiry)
// @route       GET /sdp/followups?enquiry=6453488b51bfba15f817a4f9
// @access      Private(admin)
exports.getFollowups = asyncHandler(async (req, res, next) => {

    var month = 0, year = 0

    if (req.user.role == 'admin') {
        console.log('admin')

        // Monthly report
        await Followup.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            { $eq: ["$deleted", false] },
                            { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] }
                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                month = result[0].myCount
            }
        })

        // console.log('////////////////////// YEAR ///////////////////////////////')
        // Testing code
        // await Followup.aggregate([
        //     {
        //         $match: {
        //             $expr: {
        //                 $and: [
        //                     { $eq: ["$deleted", false] },
        //                     { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
        //                 ]
        //             }
        //         }
        //     },
        //     { $project: { _id: 0, deleted: true } }
        //     // { $group: { _id: null, myCount: { $sum: 1 } } },
        // ]).then((result) => {
        //     console.log(result)
        // })
        // console.log('????????????????????????? YEAR ????????????????????????????')
        // Yearly report
        await Followup.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            { $eq: ["$deleted", false] },
                            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            // console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                year = result[0].myCount
            }
        })
    } else {
        // console.log('manager / teacher')
        // console.log(req.user);
        await Followup.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            {
                                $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }],
                            }, {
                                $eq: ["$branch", req.user.branch]
                            }

                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            // console.log('Month ------------------------------------------------')
            // console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                month = result[0].myCount
            }
        })

        await Followup.aggregate([
            {
                $match: {
                    $expr: {
                        $and: [
                            {
                                $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }],
                            }, {
                                $eq: ["$branch", req.user.branch]
                            }

                        ]
                    }
                }
            },
            { $group: { _id: null, myCount: { $sum: 1 } } },
            { $project: { _id: 0 } }
        ]).then((result) => {
            // console.log('Year ------------------------------------------------')
            // console.log(result)
            // console.log(result[0].myCount);
            if (result.length != 0) {
                year = result[0].myCount
            }
        })
    }


    let summary = {
        month,
        year
    }
    res.advancedResults.summary = summary
    console.log(req.user);
    let allFollowupsData = await Followup.find({deleted:false}).populate('takenby enquiry createdBy').sort({createdAt:-1});
    // let allFollowupsData = await Followup.find({deleted:false}).populate('enquiry branch takenby createdBy').sort({createdAt:-1});
    res.advancedResults.alldata = allFollowupsData
    res.advancedResults.alldatacount = allFollowupsData.length

    res.status(200).json(res.advancedResults);
})

// @desc        Create new Followup
// @route       POST /sdp/Followups
// @access      Private(admin)
exports.createFollowup = asyncHandler(async (req, res, next) => {

    req.body.createdBy = req.user.id;
    const followup = await Followup.create(req.body);
    res.status(201).json({
        success: true,
        data: followup
    });
});

// @desc        Get single Followup
// @route       GET /sdp/Followups/:id
// @access      Private(admin) 
exports.getFollowup = asyncHandler(async (req, res, next) => {

    // const Followup = await res.advancedResults.find({ name: req.params.id, deleted: false });
    var followup = await Followup.findOne({ _id: req.params.id, deleted: false }).populate('takenby enquiry createdBy');
    // console.log(Followup);
    // console.log(Followup.length);
    if (followup.length === 0) {
        return next(new ErrorResponse(`Followup not found with id ${req.params.id}`, 404)); // Handling if no Followups found with correctly formatted _id
        // console.log('Followup not found ->');
    } else {
        res.status(200).json({ success: true, data: followup });
    }
    // console.log('Single Followup found above');
    // let found = 0;
    // const Followups = res.advancedResults.data
    // // console.log(Followups);
    // Followups.forEach(Followup => {
    //     if ((Followup._id == req.params.id) && (Followup.deleted == false)) {
    //         res.status(200).json({ success: true, data: Followup });
    //         found = 1
    //         // console.log(Followup)
    //     }
    // });
    // if (found == 0) {
    //     return next(new ErrorResponse(`Followup not found with id ${req.params.id}`, 404)); // Handling if no Followups found with correctly formatted _id
    // }
});

// @desc        Edit single Followup
// @route       PUT /sdp/Followups/:id
// @access      Private(admin) 
exports.editFollowup = asyncHandler(async (req, res, next) => {

    let followup = await Followup.findById(req.params.id);
    // console.log(Followup);
    if (!followup) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Followup does not exists`, 404));
    }

    req.body.updatedAt = new Date();
    followup = await Followup.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: followup });
});

// @desc        Delete single Followup
// @route       DELETE /sdp/Followups/:id
// @access      Private(admin) 
exports.deleteFollowup = asyncHandler(async (req, res, next) => {

    let followup = await Followup.findById(req.params.id);
    console.log(followup);
    if (!followup) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Followup does not exists`, 404));
    }

    req.body.deleted = true;
    followup = await Followup.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: Followup });
    res.status(200).json({ success: true, data: {} });
});

// @desc        Get Followup count
// @route       GET /sdp/followups/count/:id
// @access      Private(admin) 
exports.getCount = asyncHandler(async (req, res, next) => {

    let count = await Followup.find({enquiry: req.params.id, deleted:false}).populate('takenby enquiry createdBy')
    .sort({followupNo:1});
    console.log(count.length);

    // res.status(200).json({ success: true, data: Followup });
    res.status(200).json({ success: true, next: count.length + 1, data: count });
});
