const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Fee = require('../models/Fee');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all fees
// @route       GET /sdp/fees
// @access      Private(admin,manager)
exports.getFees = asyncHandler(async (req, res, next) => {

    res.status(200).json(res.advancedResults);
})

// @desc        Create new fee
// @route       POST /sdp/fees
// @access      Private(admin,manager)
exports.createFee = asyncHandler(async (req, res, next) => {

    // Add user to req.user
    // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
    // console.log(req.body.educationalQualification);
    req.body.createdBy = req.user.id
    const fee = await Fee.create(req.body);
    res.status(201).json({
        success: true,
        data: fee
    });
});

// @desc        Get single fee
// @route       GET /sdp/fees/:id
// @access      Private(admin,manager) 
exports.getFee = asyncHandler(async (req, res, next) => {

    // const fee = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const fees = res.advancedResults.data
    // console.log(fees);
    fees.forEach(fee => {
        if ((fee._id == req.params.id) && (fee.deleted == false)) {
            res.status(200).json({ success: true, data: fee });
            found = 1
            // console.log(fee)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Fee not found with name ${req.params.id}`, 404)); // Handling if no fees found with correctly formatted _id
    }
    // if (!fee[0]) {

    //     return next(new ErrorResponse(`Fee not found with name ${req.params.name}`, 404)); // Handling if no fees found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: fee[0] });
});

// @desc        Edit single fee
// @route       PUT /sdp/fees/:id
// @access      Private(admin,manager) 
exports.editFee = asyncHandler(async (req, res, next) => {

    let fee = await Fee.findById(req.params.id);
    // console.log(fee);
    if (!fee) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Fee does not exists`, 404));
    }

    // Make sure user is fee owner
    // if (fee.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this fee`, 401));
    // }
    req.body.updatedAt = new Date();
    fee = await Fee.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: fee });
});

// @desc        Delete single fee
// @route       DELETE /sdp/fees/:id
// @access      Private(admin,manager) 
exports.deleteFee = asyncHandler(async (req, res, next) => {

    let fee = await Fee.findById(req.params.id);
    // console.log(fee);
    if (!fee) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Fee does not exists`, 404));
    }

    // Make sure user is fee owner
    // if (fee.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this fee`, 401));
    // }
    req.body.deleted = true;
    fee = await Fee.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: fee });
    res.status(200).json({ success: true, data: {} });
});
