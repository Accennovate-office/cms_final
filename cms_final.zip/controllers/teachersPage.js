const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');


// @desc        Dashboard page (Frontend)
// @route       GET /sdp/teacher/dashboard
// @access      Private(Teacher)
exports.dashboardPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/dashboard', { layout: 'layouts/teacherLayout', title: 'SDP | Dashboard', css: 'teacher', js: 'teacher/dashboard', data: req.user });
});

// @desc        Profile page (Frontend)
// @route       GET /sdp/teacher/profile
// @access      Private(Teacher)
exports.profilePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/profile', { layout: 'layouts/teacherLayout', title: 'SDP | Profile', css: 'teacher', js: 'teacher/profile', data: req.user });
});

// @desc        Students page (Frontend)
// @route       GET /sdp/teacher/students
// @access      Private(Teacher)
exports.studentsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/students', { layout: 'layouts/teacherLayout', title: 'SDP | Students', css: 'teacher', js: 'teacher/students', data: req.user });
});

// @desc        Students profile page (Frontend)
// @route       GET /sdp/teacher/students/:slug
// @access      Private(Teacher)
exports.studentsProfilePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/studentsProfile', { layout: 'layouts/teacherLayout', title: `SDP | ${req.params.slug}`, css: 'teacher', js: 'teacher/studentsProfile', data: req.user });
});