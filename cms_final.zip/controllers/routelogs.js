const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Routelog = require('../models/Routelog');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all routelogs
// @route       GET /sdp/routelogs
// @access      Private(admin,manager)
exports.getRoutelogs = asyncHandler(async (req, res, next) => {

    // var today = 0, yesterday = 0, month = 0
    // // Ref: https://stackoverflow.com/a/41157836
    // await Routelog.aggregate(
    //     [
    //         {
    //             // Ref: https://www.mongodb.com/community/forums/t/matching-with-month/5216/2
    //             $match: { $expr: { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] } }
    //         },
    //         {
    //             $group:
    //             {
    //                 _id:
    //                 {
    //                     day: { $dayOfMonth: "$createdAt" },
    //                     month: { $month: "$createdAt" },
    //                     year: { $year: "$createdAt" }
    //                 },
    //                 count: { $sum: 1 },
    //                 date: { $first: "$createdAt" }
    //             }
    //         },
    //         { $sort: { date: -1 } },
    //         {
    //             $project:
    //             {
    //                 date:
    //                 {
    //                     $dateToString: { format: "%Y-%m-%d", date: "$date" },
    //                 },
    //                 count: 1,
    //                 _id: 0
    //             }
    //         }
    //     ]).then((result) => {
    //         // console.log(result[0].count);
    //         // console.log(result[1].count);
    //         if (result.length > 0) {
    //             today = result[0].count
    //             if (result.length > 1) {
    //                 yesterday = result[1].count
    //             }
    //         }
    //     })

    // await Routelog.aggregate([
    //     { $match: { $expr: { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] } } },
    //     { $group: { _id: null, myCount: { $sum: 1 } } },
    //     { $project: { _id: 0 } }
    // ]).then((result) => {
    //     // console.log(result[0].myCount);
    //     if (result.length > 0) {
    //         month = result[0].myCount
    //     }
    // })

    // // console.log("####### " + today, yesterday, month);
    // let summary = {
    //     today,
    //     yesterday,
    //     month
    // }
    // res.advancedResults.summary = summary
    // db.collection.find(<match>).sort(<sort>).allowDiskUse()
    res.status(200).json(res.advancedResults);
})

// @desc        Get routelogs summary
// @route       GET /sdp/routelogs/summary/info
// @access      Private(admin)
exports.summaryRoutelogs = asyncHandler(async (req, res, next) => {

    // console.log('inside summary student');
    var today = 0, yesterday = 0, month = 0

    // Ref: https://stackoverflow.com/a/37065412
    // console.log(req.query.reso);

    var daily_report_filter, yesterday_report_filter, monthly_report_filter

    // var delete_filter = { $eq: ["$deleted", false] }

    daily_report_filter = [
        // delete_filter,
        { $eq: [{ "$dayOfMonth": "$createdAt" }, { "$dayOfMonth": new Date() }] },
        { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
        { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
    ]

    var yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    // yesterdayDate ; 
    yesterday_report_filter = [
        // delete_filter,
        { $eq: [{ "$dayOfMonth": "$createdAt" }, { "$dayOfMonth": yesterdayDate }] },
        { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
        { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
    ]

    daily_report_filter = [
        // delete_filter,
        { $eq: [{ "$dayOfMonth": "$createdAt" }, { "$dayOfMonth": new Date() }] },
        { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
        { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
    ]

    monthly_report_filter = [
        // delete_filter,
        { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
        { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
    ]

    // Yesterday report
    await Routelog.aggregate([
        {
            $match: {
                $expr: {
                    $and: yesterday_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            yesterday = result[0].myCount
        }
    })

    // Daily report
    await Routelog.aggregate([
        {
            $match: {
                $expr: {
                    $and: daily_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            today = result[0].myCount
        }
    })

    // Monthly report
    await Routelog.aggregate([
        {
            $match: {
                $expr: {
                    $and: monthly_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            month = result[0].myCount
        }
    })

    var summary = {
        yesterday: yesterday,
        today: today,
        month: month
    }
    res.data = {
        success: true,
        data: summary
    }
    // res.advancedResults.summary = summary

    res.status(200).json(res.data);
})

// // @desc        Create new routelog
// // @route       POST /sdp/routelogs
// // @access      Private(admin,manager)
// exports.createRoutelog = asyncHandler(async (req, res, next) => {

//     // Add user to req.user
//     // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
//     // console.log(req.body.educationalQualification);
//     req.body.createdBy = req.user.id
//     const routelog = await Routelog.create(req.body);
//     res.status(201).json({
//         success: true,
//         data: routelog
//     });
// });

// @desc        Get single routelog
// @route       GET /sdp/routelogs/:id
// @access      Private(admin,manager) 
exports.getRoutelog = asyncHandler(async (req, res, next) => {

    // const routelog = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const routelogs = res.advancedResults.data
    // console.log(routelogs);
    routelogs.forEach(routelog => {
        if ((routelog.id == req.params.id) && (routelog.deleted == false)) {
            res.status(200).json({ success: true, data: routelog });
            found = 1
            // console.log(routelog)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Routelog not found with name ${req.params.id}`, 404)); // Handling if no routelogs found with correctly formatted _id
    }
    // if (!routelog[0]) {

    //     return next(new ErrorResponse(`Routelog not found with name ${req.params.name}`, 404)); // Handling if no routelogs found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: routelog[0] });
});

// // @desc        Edit single routelog
// // @route       PUT /sdp/routelogs/:id
// // @access      Private(admin,manager) 
// exports.editRoutelog = asyncHandler(async (req, res, next) => {

//     let routelog = await Routelog.findById(req.params.id);
//     // console.log(routelog);
//     if (!routelog) {
//         // return res.status(400).json({ success: false });
//         return next(new ErrorResponse(`Routelog does not exists`, 404));
//     }

//     // Make sure user is routelog owner
//     // if (routelog.user.toString() !== req.user.id && req.user.role !== 'admin') {
//     //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this routelog`, 401));
//     // }
//     req.body.updatedAt = new Date();
//     routelog = await Routelog.findByIdAndUpdate(req.params.id, req.body, {
//         new: true, // to return updated data
//         runValidators: true // to run mongoose validators to check updating data
//     });

//     res.status(200).json({ success: true, data: routelog });
// });

// // @desc        Delete single routelog
// // @route       DELETE /sdp/routelogs/:id
// // @access      Private(admin,manager) 
// exports.deleteRoutelog = asyncHandler(async (req, res, next) => {

//     let routelog = await Routelog.findById(req.params.id);
//     // console.log(routelog);
//     if (!routelog) {
//         // return res.status(400).json({ success: false });
//         return next(new ErrorResponse(`Routelog does not exists`, 404));
//     }

//     // Make sure user is routelog owner
//     // if (routelog.user.toString() !== req.user.id && req.user.role !== 'admin') {
//     //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this routelog`, 401));
//     // }
//     req.body.deleted = true;
//     routelog = await Routelog.findByIdAndUpdate(req.params.id, req.body, {
//         new: true, // to return updated data
//         runValidators: true // to run mongoose validators to check updating data
//     });

//     // res.status(200).json({ success: true, data: routelog });
//     res.status(200).json({ success: true, data: {} });
// });
