const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Admission = require('../models/Admission');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all admissions
// @route       GET /sdp/admissions
// @access      Private(admin,manager)
exports.getAdmissions = asyncHandler(async (req, res, next) => {

    res.status(200).json(res.advancedResults);
})

// @desc        Create new admission
// @route       POST /sdp/admissions
// @access      Private(admin,manager)
exports.createAdmission = asyncHandler(async (req, res, next) => {

    // Add user to req.user
    // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
    // console.log(req.body.educationalQualification);
    req.body.createdBy = req.user.id
    const admission = await Admission.create(req.body);
    res.status(201).json({
        success: true,
        data: admission
    });
});

// @desc        Get single admission
// @route       GET /sdp/admissions/:id
// @access      Private(admin,manager) 
exports.getAdmission = asyncHandler(async (req, res, next) => {

    // const admission = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const admissions = res.advancedResults.data
    // console.log(admissions);
    admissions.forEach(admission => {
        if ((admission._id == req.params.id) && (admission.deleted == false)) {
            res.status(200).json({ success: true, data: admission });
            found = 1
            // console.log(admission)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Admission not found with name ${req.params.id}`, 404)); // Handling if no admissions found with correctly formatted _id
    }
    // if (!admission[0]) {

    //     return next(new ErrorResponse(`Admission not found with name ${req.params.name}`, 404)); // Handling if no admissions found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: admission[0] });
});

// @desc        Edit single admission
// @route       PUT /sdp/admissions/:id
// @access      Private(admin,manager) 
exports.editAdmission = asyncHandler(async (req, res, next) => {

    let admission = await Admission.findById(req.params.id);
    // console.log(admission);
    if (!admission) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Admission does not exists`, 404));
    }

    // Make sure user is admission owner
    // if (admission.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this admission`, 401));
    // }
    req.body.updatedAt = new Date();
    admission = await Admission.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: admission });
});

// @desc        Delete single admission
// @route       DELETE /sdp/admissions/:id
// @access      Private(admin,manager) 
exports.deleteAdmission = asyncHandler(async (req, res, next) => {

    let admission = await Admission.findById(req.params.id);
    // console.log(admission);
    if (!admission) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Admission does not exists`, 404));
    }

    // Make sure user is admission owner
    // if (admission.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this admission`, 401));
    // }
    req.body.deleted = true;
    admission = await Admission.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: admission });
    res.status(200).json({ success: true, data: {} });
});

// Feb 2023 update

// @desc        Check duplicate admission details
// @route       POST /sdp/admissions/check
// @access      Private(admin,manager)
exports.checkAdmission = asyncHandler(async (req, res, next) => {

    let found = 0;
    // console.log(req.params);
    const admissions = res.advancedResults.data
    admissions.forEach(admission => {
        if ((req.params.roll == 'check') && (admission.student._id == req.body.student) && (admission.course._id == req.body.course) && (admission.deleted == false)) {
            res.status(200).json({ success: true, data: admission });
            found = 1
        }else if((req.params.roll == 'roll') && (admission.rollNo == req.body.roll) && (admission.deleted == false)){
            res.status(200).json({ success: true, data: admission });
            found = 1
        }
    });
    if (found == 0) {
        res.status(200).json({ success: false, data: `No duplicate admission details found. Please proceed further` });
        // return next(new ErrorResponse(`Admission not found with name ${req.params.id}`, 404)); // Handling if no admissions found with correctly formatted _id
    }
})