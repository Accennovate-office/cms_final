const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Loginlog = require('../models/Loginlog');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all loginlogs
// @login       GET /sdp/loginlogs
// @access      Private(admin,manager)
exports.getLoginlogs = asyncHandler(async (req, res, next) => {

    var today = 0, yesterday = 0, month = 0
    // Ref: https://stackoverflow.com/a/41157836
    await Loginlog.aggregate(
        [
            {
                // Ref: https://www.mongodb.com/community/forums/t/matching-with-month/5216/2
                $match: { $expr: { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] } }
            },
            {
                $group:
                {
                    _id:
                    {
                        day: { $dayOfMonth: "$createdAt" },
                        month: { $month: "$createdAt" },
                        year: { $year: "$createdAt" }
                    },
                    count: { $sum: 1 },
                    date: { $first: "$createdAt" }
                }
            },
            { $sort: { date: -1 } },
            {
                $project:
                {
                    date:
                    {
                        $dateToString: { format: "%Y-%m-%d", date: "$date" },
                    },
                    count: 1,
                    _id: 0
                }
            }
        ]).then((result) => {
            // console.log(result[0].count);
            // console.log(result[1].count);
            if (result.length > 0) {
                today = result[0].count
                if (result.length > 1) {
                    yesterday = result[1].count
                }
            }
        })

    await Loginlog.aggregate([
        { $match: { $expr: { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] } } },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result[0].myCount);
        if (result.length > 0) {
            month = result[0].myCount
        }
        
    })

    // console.log("####### " + today, yesterday, month);
    let summary = {
        today,
        yesterday,
        month
    }
    res.advancedResults.summary = summary

    res.status(200).json(res.advancedResults);
})

// // @desc        Create new loginlog
// // @login       POST /sdp/loginlogs
// // @access      Private(admin,manager)
// exports.createLoginlog = asyncHandler(async (req, res, next) => {

//     // Add user to req.user
//     // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
//     // console.log(req.body.educationalQualification);
//     req.body.createdBy = req.user.id
//     const loginlog = await Loginlog.create(req.body);
//     res.status(201).json({
//         success: true,
//         data: loginlog
//     });
// });

// @desc        Get single loginlog
// @login       GET /sdp/loginlogs/:id
// @access      Private(admin,manager) 
exports.getLoginlog = asyncHandler(async (req, res, next) => {

    // const loginlog = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const loginlogs = res.advancedResults.data
    // console.log(loginlogs);
    loginlogs.forEach(loginlog => {
        if ((loginlog.id == req.params.id) && (loginlog.deleted == false)) {
            res.status(200).json({ success: true, data: loginlog });
            found = 1
            // console.log(loginlog)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Loginlog not found with name ${req.params.id}`, 404)); // Handling if no loginlogs found with correctly formatted _id
    }
    // if (!loginlog[0]) {

    //     return next(new ErrorResponse(`Loginlog not found with name ${req.params.name}`, 404)); // Handling if no loginlogs found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: loginlog[0] });
});

// // @desc        Edit single loginlog
// // @login       PUT /sdp/loginlogs/:id
// // @access      Private(admin,manager) 
// exports.editLoginlog = asyncHandler(async (req, res, next) => {

//     let loginlog = await Loginlog.findById(req.params.id);
//     // console.log(loginlog);
//     if (!loginlog) {
//         // return res.status(400).json({ success: false });
//         return next(new ErrorResponse(`Loginlog does not exists`, 404));
//     }

//     // Make sure user is loginlog owner
//     // if (loginlog.user.toString() !== req.user.id && req.user.role !== 'admin') {
//     //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this loginlog`, 401));
//     // }
//     req.body.updatedAt = new Date();
//     loginlog = await Loginlog.findByIdAndUpdate(req.params.id, req.body, {
//         new: true, // to return updated data
//         runValidators: true // to run mongoose validators to check updating data
//     });

//     res.status(200).json({ success: true, data: loginlog });
// });

// // @desc        Delete single loginlog
// // @login       DELETE /sdp/loginlogs/:id
// // @access      Private(admin,manager) 
// exports.deleteLoginlog = asyncHandler(async (req, res, next) => {

//     let loginlog = await Loginlog.findById(req.params.id);
//     // console.log(loginlog);
//     if (!loginlog) {
//         // return res.status(400).json({ success: false });
//         return next(new ErrorResponse(`Loginlog does not exists`, 404));
//     }

//     // Make sure user is loginlog owner
//     // if (loginlog.user.toString() !== req.user.id && req.user.role !== 'admin') {
//     //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this loginlog`, 401));
//     // }
//     req.body.deleted = true;
//     loginlog = await Loginlog.findByIdAndUpdate(req.params.id, req.body, {
//         new: true, // to return updated data
//         runValidators: true // to run mongoose validators to check updating data
//     });

//     // res.status(200).json({ success: true, data: loginlog });
//     res.status(200).json({ success: true, data: {} });
// });
