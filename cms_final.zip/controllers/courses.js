const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Course = require('../models/Course');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// @desc        Get all courses
// @route       GET /sdp/courses
// @access      Private(Admin,Manager)
exports.getCourses = asyncHandler(async (req, res, next) => { // #### DONE ####

    // After using middleware for advanced results
    res.status(200).json(res.advancedResults);

    // const courses = await query;

    // res.status(200).json({
    //     success: true,
    //     count: courses.length,
    //     data: courses
    // });
});

// @desc        Get single course
// @route       GET /sdp/courses/:id
// @access      Private(Admin,Manager)
exports.getCourse = asyncHandler(async (req, res, next) => { // #### DONE ####
    const course = await Course.findById(req.params.id).populate({
        path: 'createdBy',
        // select: 'name description'
    });

    if (!course) {
        return next(new ErrorResponse(`No course with the id ${req.params.id}`), 404);
    }

    res.status(200).json({
        success: true,
        data: course
    });
});

// @desc        Add course
// @route       POST /sdp/courses
// @access      Private(Admin,Manager)
exports.addCourse = asyncHandler(async (req, res, next) => { // #### DONE ####

    req.body.createdBy = req.user.id;

    const course = await Course.create(req.body);

    res.status(200).json({
        success: true,
        data: course
    });
});

// @desc        Update course
// @route       PUT /sdp/courses/:id
// @access      Private
exports.updateCourse = asyncHandler(async (req, res, next) => { // #### DONE ####
    let course = await Course.findById(req.params.id);

    if (!course) {
        return next(new ErrorResponse(`No course with the id ${req.params.id}`), 404);
    }

    // // Make sure user is course owner
    // if (course.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to update course ${course._id}`, 401));
    // }
    req.body.updatedAt = new Date();
    course = await Course.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
    });

    res.status(200).json({
        success: true,
        data: course
    });
});

// @desc        Delete course
// @route       DELETE /sdp/courses/:id
// @access      Private(Admin,Manager)
exports.deleteCourse = asyncHandler(async (req, res, next) => { // #### DONE ####
    const course = await Course.findById(req.params.id);

    if (!course) {
        return next(new ErrorResponse(`No course with the id ${req.params.id}`), 404);
    }

    // // Make sure user is course owner
    // if (course.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete course ${course._id}`, 401));
    // }

    // await course.remove(); // Actual delete course
    req.body.deleted = true; // Fake delete course
    manager = await Course.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({
        success: true,
        data: {}
    });
});