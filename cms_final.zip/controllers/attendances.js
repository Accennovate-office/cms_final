const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Attendance = require('../models/Attendance');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');
// Code by Raj
const { json } = require("body-parser");
var moment = require("moment"); // require
// Code by Raj end
// @desc        Get all attendances
// @route       GET /sdp/attendances
// @access      Private(admin,manager)
exports.getAttendances = asyncHandler(async (req, res, next) => {
    // Code by Raj
    let attendances = await Attendance.find();
    res.status(200).json({ success: true, data: attendances });
    // Code by Raj end
    // res.status(200).json(res.advancedResults);
})

// @desc        Create new attendance
// @route       POST /sdp/attendances
// @access      Private(admin,manager)
exports.createAttendance = asyncHandler(async (req, res, next) => {

    // Add user to req.user
    // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
    // console.log(req.body.educationalQualification);
    console.log('inside create attendance');
    // req.body.createdBy = req.user.id
    const attendance = await Attendance.create(req.body);
    res.status(201).json({
        success: true,
        data: attendance
    });
});

// @desc        Get single attendance
// @route       GET /sdp/attendances/:id
// @access      Private(admin,manager) 
exports.getAttendance = asyncHandler(async (req, res, next) => {
    // Code by Raj
    let attendances = await Attendance.find({ biometricId: req.params.id });
    console.log(attendances)
    // code by Raj end
    // // const attendance = await res.advancedResults.find({ name: req.params.id, deleted: false });
    // let found = 0;
    // const attendances = res.advancedResults.data
    // // console.log(attendances);
    // attendances.forEach(attendance => {
    //     if ((attendance._id == req.params.id) && (attendance.deleted == false)) {
    //         res.status(200).json({ success: true, data: attendance });
    //         found = 1
    //         // console.log(attendance)
    //     }
    // });
    // if (found == 0) {
    //     return next(new ErrorResponse(`Attendance not found with name ${req.params.id}`, 404)); // Handling if no attendances found with correctly formatted _id
    // }
    // // if (!attendance[0]) {

    // //     return next(new ErrorResponse(`Attendance not found with name ${req.params.name}`, 404)); // Handling if no attendances found with correctly formatted _id
    // // }
    // // res.status(200).json({ success: true, data: attendance[0] });
});

// @desc        Edit single attendance
// @route       PUT /sdp/attendances/:id
// @access      Private(admin,manager) 
exports.editAttendance = asyncHandler(async (req, res, next) => {

    let attendance = await Attendance.findById(req.params.id);
    // console.log(attendance);
    if (!attendance) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Attendance does not exists`, 404));
    }

    // Make sure user is attendance owner
    // if (attendance.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this attendance`, 401));
    // }
    req.body.updatedAt = new Date();
    attendance = await Attendance.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: attendance });
});

// @desc        Delete single attendance
// @route       DELETE /sdp/attendances/:id
// @access      Private(admin,manager) 
exports.deleteAttendance = asyncHandler(async (req, res, next) => {

    let attendance = await Attendance.findById(req.params.id);
    // console.log(attendance);
    if (!attendance) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Attendance does not exists`, 404));
    }

    // Make sure user is attendance owner
    // if (attendance.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this attendance`, 401));
    // }
    req.body.deleted = true;
    attendance = await Attendance.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: attendance });
    res.status(200).json({ success: true, data: {} });
});

// Code by Raj
exports.getdailyAttendance = asyncHandler(async (req, res, next) => {
    console.log("inside")
    let queryObj = {};
    const startOfDay = new Date(new Date().setUTCHours(0, 0, 0, 0)).toISOString();
    const endOfDay = new Date(
        new Date().setUTCHours(23, 59, 59, 999)
    ).toISOString();

    queryObj.dateTime = {
        $gte: startOfDay,
        $lt: endOfDay,
    };

    let attendance = await Attendance.find(queryObj);
    let a = moment().startOf("isoweek").toDate();
    let b = moment().endOf("isoweek").toDate();
    console.log(a);
    console.log(b);

    res.status(200).json({ success: true, data: attendance });
});

exports.getYesterdayAttendance = asyncHandler(async (req, res, next) => {
    let queryObj = {};
    const startOfDay = moment().subtract(1, 'days').startOf('day').toDate();
    const endOfDay = moment().subtract(1, 'days').endOf('day').toDate();

    queryObj.dateTime = {
        $gte: startOfDay,
        $lt: endOfDay,
    };

    let attendance = await Attendance.find(queryObj);
    console.log(queryObj)
    res.status(200).json({ success: true, data: attendance });
});

exports.getmonthlyAttendance = asyncHandler(async (req, res, next) => {
    let queryObj = {};

    const startOfMonth = moment().startOf("month").toDate();
    const endOfMonth = moment().endOf("month").toDate();

    queryObj.dateTime = {
        $gte: startOfMonth,
        $lt: endOfMonth,
    };

    // await Attendance.deleteMany();
    let attendance = await Attendance.find(queryObj);

    res.status(200).json({ success: true, data: attendance });
});

exports.getPrevmonthAttendance = asyncHandler(async (req, res, next) => {
    const prevMonthStart = moment()
        .subtract(1, "month")
        .startOf("month")
        .toDate();
    const prevMonthEnd = moment().subtract(1, "month").endOf("month").toDate();

    let queryObj = {};
    queryObj.dateTime = {
        $gte: prevMonthStart,
        $lt: prevMonthEnd,
    };

    queryObj.dateTime = {
        $gte: prevMonthStart,
        $lt: prevMonthEnd,
    };

    let attendance = await Attendance.find(queryObj);
    console.log(attendance)
    res.status(200).json({ success: true, data: attendance });
});

exports.getCustomAttendance = asyncHandler(async (req, res, next) => {
    let urlParam = req.params.id;
    let biometricId = urlParam.slice(0, urlParam.indexOf("-"));
    let queryObj = { biometricId };
    if (urlParam.includes("monthly")) {
        const startOfMonth = moment().startOf("month").toDate();
        const endOfMonth = moment().endOf("month").toDate();

        queryObj.dateTime = {
            $gte: startOfMonth,
            $lt: endOfMonth,
        };
        console.log(queryObj);
        let attendance = await Attendance.find(queryObj);

        res.status(200).json({ success: true, data: attendance });
    }
    if (urlParam.includes("to")) {
        const startDate = new Date(
            urlParam.slice(urlParam.indexOf("-") + 1, urlParam.indexOf("to"))
        );
        const endDate = new Date(urlParam.slice(urlParam.indexOf("to") + 2));

        console.log(
            urlParam.slice(urlParam.indexOf("-") + 1, urlParam.indexOf("to"))
        );
        console.log(urlParam.slice(urlParam.indexOf("to") + 2));
        console.log(startDate);
        console.log(endDate);

        queryObj.dateTime = {
            $gte: startDate,
            $lt: endDate,
        };
        console.log(queryObj);
        let attendance = await Attendance.find(queryObj);

        res.status(200).json({ success: true, data: attendance });
    }
});

exports.getDuration = asyncHandler(async (req, res, next) => {
    let queryObj = {};
    const prevMonthStart = moment()
        .subtract(1, "month")
        .startOf("month")
        .toDate();
    const prevMonthEnd = moment().subtract(1, "month").endOf("month").toDate();
    console.log(prevMonthStart.getDate());
    console.log(prevMonthStart.getMonth() + 1);
    console.log(prevMonthEnd.getDate());
    console.log(prevMonthEnd.getMonth() + 1);
    queryObj.dateTime = {
        $gte: prevMonthStart,
        $lt: prevMonthEnd,
    };

    queryObj = {
        ...queryObj,
        biometricId: req.params.id,
        loginOrLogout: "Logout",
    };

    let duration = await Attendance.find({
        biometricId: req.params.id,
        loginOrLogout: "Logout",
    }).select("duration -_id");
    let hours = 0;
    duration.forEach((val) => {
        hours = hours + parseInt(val.duration.charAt(0));
    });
    res.status(200).json({ success: true, data: hours });
});
// Code by Raj end