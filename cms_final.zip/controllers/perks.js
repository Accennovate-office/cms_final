const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Perk = require('../models/Perk');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// @desc        Get all perks
// @route       GET /sdp/perks
// @access      Private(Admin,Manager)
exports.getPerks = asyncHandler(async (req, res, next) => { // #### DONE ####

    // Ref: https://stackoverflow.com/a/29364431
    const array = res.advancedResults.data
    // console.log(array);
    var result = [];
    array.reduce(function (res, value) {
        if (!res[value.user._id]) {
            res[value.user._id] = { id: value.user._id, name: value.user.name, points: 0 };
            result.push(res[value.user._id])
        }
        res[value.user._id].points += value.points;
        return res;
    }, {});

    result.sort(compareThirdColumn);

    function compareThirdColumn(a, b) {
        if (a.points === b.points) {
            return 0;
        }
        else {
            return (a.points > b.points) ? -1 : 1;
        }
    }

    // console.log(result)
    res.advancedResults.summary = result

    // After using middleware for advanced results
    res.status(200).json(res.advancedResults);

    // const perks = await query;

    // res.status(200).json({
    //     success: true,
    //     count: perks.length,
    //     data: perks
    // });
});

// @desc        Get single perk
// @route       GET /sdp/perks/:id
// @access      Private(Admin,Manager)
exports.getPerk = asyncHandler(async (req, res, next) => { // #### DONE ####
    const perk = await Perk.findById(req.params.id).populate({
        path: 'user createdBy',
        // select: 'name description'
    });

    if (!perk) {
        return next(new ErrorResponse(`No perk with the id ${req.params.id}`), 404);
    }

    res.status(200).json({
        success: true,
        data: perk
    });
});

// @desc        Add perk
// @route       POST /sdp/perks
// @access      Private(Admin,Manager)
exports.addPerk = asyncHandler(async (req, res, next) => { // #### DONE ####

    req.body.createdBy = req.user.id;

    const perk = await Perk.create(req.body);

    res.status(200).json({
        success: true,
        data: perk
    });
});

// @desc        Update perk
// @route       PUT /sdp/perks/:id
// @access      Private
exports.updatePerk = asyncHandler(async (req, res, next) => { // #### DONE ####
    let perk = await Perk.findById(req.params.id);

    if (!perk) {
        return next(new ErrorResponse(`No perk with the id ${req.params.id}`), 404);
    }

    // // Make sure user is perk owner
    // if (perk.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to update perk ${perk._id}`, 401));
    // }
    req.body.updatedAt = new Date();
    perk = await Perk.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
    });

    res.status(200).json({
        success: true,
        data: perk
    });
});

// @desc        Delete perk
// @route       DELETE /sdp/perks/:id
// @access      Private(Admin,Manager)
exports.deletePerk = asyncHandler(async (req, res, next) => { // #### DONE ####
    const perk = await Perk.findById(req.params.id);

    if (!perk) {
        return next(new ErrorResponse(`No perk with the id ${req.params.id}`), 404);
    }

    // // Make sure user is perk owner
    // if (perk.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete perk ${perk._id}`, 401));
    // }

    // await perk.remove(); // Actual delete perk
    req.body.deleted = true; // Fake delete perk
    manager = await Perk.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({
        success: true,
        data: {}
    });
});