const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Lecture = require('../models/Lecture');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all lectures
// @route       GET /sdp/lectures
// @access      Private(admin,manager)
exports.getLectures = asyncHandler(async (req, res, next) => {

    res.status(200).json(res.advancedResults)
})

// @desc        Create new lecture
// @route       POST /sdp/lectures
// @access      Private(admin,manager)
exports.createLecture = asyncHandler(async (req, res, next) => {

    // Add user to req.user
    // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
    // console.log(req.body.educationalQualification);
    req.body.createdBy = req.user.id
    const lecture = await Lecture.create(req.body);
    res.status(201).json({
        success: true,
        data: lecture
    });
});

// @desc        Get single lecture
// @route       GET /sdp/lectures/:id
// @access      Private(admin,manager) 
exports.getLecture = asyncHandler(async (req, res, next) => {

    // const lecture = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const lectures = res.advancedResults.data
    // console.log(lectures);
    lectures.forEach(lecture => {
        if ((lecture._id == req.params.id) && (lecture.deleted == false)) {
            res.status(200).json({ success: true, data: lecture });
            found = 1
            // console.log(lecture)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Lecture not found with name ${req.params.id}`, 404)); // Handling if no lectures found with correctly formatted _id
    }
    // if (!lecture[0]) {

    //     return next(new ErrorResponse(`Lecture not found with name ${req.params.name}`, 404)); // Handling if no lectures found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: lecture[0] });
});

// @desc        Edit single lecture
// @route       PUT /sdp/lectures/:id
// @access      Private(admin,manager) 
exports.editLecture = asyncHandler(async (req, res, next) => {

    let lecture = await Lecture.findById(req.params.id);
    // console.log(lecture);
    if (!lecture) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Lecture does not exists`, 404));
    }

    // Make sure user is lecture owner
    // if (lecture.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this lecture`, 401));
    // }
    req.body.updatedAt = new Date();
    lecture = await Lecture.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: lecture });
});

// @desc        Delete single lecture
// @route       DELETE /sdp/lectures/:id
// @access      Private(admin,manager) 
exports.deleteLecture = asyncHandler(async (req, res, next) => {

    let lecture = await Lecture.findById(req.params.id);
    // console.log(lecture);
    if (!lecture) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Lecture does not exists`, 404));
    }

    // Make sure user is lecture owner
    // if (lecture.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this lecture`, 401));
    // }
    req.body.deleted = true;
    lecture = await Lecture.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: lecture });
    res.status(200).json({ success: true, data: {} });
});
