const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Whatsapplog = require('../models/Whatsapplog');
// Code by Raj
const mqtt = require("mqtt");
var client = mqtt.connect("mqtt://broker.hivemq.com");
client.on("connect", function () {

    // var topic = 'VVTest/#'
    const getLiveData = "vvmmqtt/house/id"; // Working
    var topic = getLiveData
    client.subscribe(topic);
    console.log("Client subscribed to " + topic);
    // For enrolling new user
    // console.log("Registering for ID 6 .......")
    // client.publish("/smartbyte/fingerprint/mode/enroll", "61")

    // For deleting user
    // console.log("Deleting ID 78 .....")

});
exports.register = asyncHandler(async (req, res, next) => { // ##### DONE #####
    console.log("hello")
    client.publish("/smartbyte/fingerprint/mode/enroll", "62")
    // console.log(req.user);
    client.on("message", function (topic, message) {

        // console.log(message);
        const data = JSON.parse(message)
        res.send(data)
        // console.log(data,"hello")
        // console.log(data.id)
        // data.attendanceType = 'System'
        // console.log('------------------------------------')
        // console.log(data)
        // console.log(data.attendanceType)


        // Working code
        // const data = {
        //     user: '61d075c481794d1f44cb57cf',
        //     loginOrLogout: 'Logout',
        //     dateTime: '2022-03-04T10:49:56.820Z',
        //     currentJobTime: '8AM - 7PM',
        //     branch: 'Kalyan test'
        // };

        // createUser(data);

    });
    // res.render('admin/birthday_book', { layout: 'layouts/adminLayout', title: 'SDP Admin | Birthday Book', css: 'admin/birthday_book', js: 'admin/birthday_book', data: req.user });
});
// Code by Raj end

// @desc        Dashboard page (Frontend)
// @route       GET /sdp/admin/dashboard
// @access      Private(Admin)
exports.dashboardPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/dashboard', { layout: 'layouts/adminLayout', title: 'SDP Admin | Dashboard', css: 'admin/dashboard', js: 'admin/dashboard', data: req.user });
});

// @desc        Reports page (Frontend)
// @route       GET /sdp/admin/reports
// @access      Private(Admin)
exports.reportsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    var whatsapp_logs = await Whatsapplog.find({ 
        // _id: req.params.id, 
        deleted: false,
        body: `Thank You for visiting SmartByte Computer Education

        To know why you should join SmartByte please click on the link below
        
        Join today and start your Digital Journey with SmartByte`,
        errorMessage: null,
        errorCode: null
    })
    var unique_whatsapp_logs = await Whatsapplog.distinct("to");

    var whatsapp_enquiry_report = {
        totalMessages: whatsapp_logs.length,
        uniqueNumbers: unique_whatsapp_logs.length
    }
    // console.log(req.user);
    res.render('admin/reports', { layout: 'layouts/adminLayout', title: 'SDP Admin | Reports', css: 'admin/reports', js: 'admin/reports', data: req.user, reports: whatsapp_enquiry_report });
});

// @desc        All Tasks page (Frontend)
// @route       GET /sdp/admin/tasks
// @access      Private(Admin)
exports.tasksPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/task/all_tasks', { layout: 'layouts/adminLayout', title: 'SDP Admin | Tasks', css: 'admin/all_tasks', js: 'admin/all_tasks', data: req.user });
});

// @desc        Add Task page (Frontend)
// @route       GET /sdp/admin/addtask
// @access      Private(Admin)
exports.addTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/task/addtask', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Task', css: 'admin/addtask', js: 'admin/addtask', data: req.user });
});

// @desc        View Task page (Frontend)
// @route       GET /sdp/admin/viewtask
// @access      Private(Admin)
exports.viewTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/task/viewTask', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Task', css: 'admin/viewTask', js: 'admin/viewTask', data: req.user });
});

// @desc        Edit Task page (Frontend)
// @route       GET /sdp/admin/edittask
// @access      Private(Admin)
exports.editTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/task/edittask', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Task', css: 'admin/edittask', js: 'admin/edittask', data: req.user });
});

// @desc        Delete Task page (Frontend)
// @route       GET /sdp/admin/deletetask
// @access      Private(Admin)
exports.deleteTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/task/deletetask', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Task', css: 'admin/deletetask', js: 'admin/deletetask', data: req.user });
});

// @desc        All Branches page (Frontend)
// @route       GET /sdp/admin/branches
// @access      Private(Admin)
exports.branchesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/branch/all_branches', { layout: 'layouts/adminLayout', title: 'SDP Admin | Branches', css: 'admin/all_branches', js: 'admin/all_branches', data: req.user });
});

// @desc        Add Branch page (Frontend)
// @route       GET /sdp/admin/addbranch
// @access      Private(Admin)
exports.addBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/branch/addbranch', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Branch', css: 'admin/addbranch', js: 'admin/addbranch', data: req.user });
});

// @desc        View Branch page (Frontend)
// @route       GET /sdp/admin/viewbranch
// @access      Private(Admin)
exports.viewBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/branch/viewBranch', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Branch', css: 'admin/viewBranch', js: 'admin/viewBranch', data: req.user });
});

// @desc        Edit Branch page (Frontend)
// @route       GET /sdp/admin/editbranch
// @access      Private(Admin)
exports.editBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/branch/editbranch', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Branch', css: 'admin/editbranch', js: 'admin/editbranch', data: req.user });
});

// @desc        Delete Branch page (Frontend)
// @route       GET /sdp/admin/deletebranch
// @access      Private(Admin)
exports.deleteBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/branch/deletebranch', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Branch', css: 'admin/deletebranch', js: 'admin/deletebranch', data: req.user });
});

// @desc        All Courses page (Frontend)
// @route       GET /sdp/admin/courses
// @access      Private(Admin)
exports.coursesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/course/all_courses', { layout: 'layouts/adminLayout', title: 'SDP Admin | Courses', css: 'admin/all_courses', js: 'admin/all_courses', data: req.user });
});

// @desc        Add Course page (Frontend)
// @route       GET /sdp/admin/addcourse
// @access      Private(Admin)
exports.addCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/course/addcourse', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Course', css: 'admin/addcourse', js: 'admin/addcourse', data: req.user });
});

// @desc        View Course page (Frontend)
// @route       GET /sdp/admin/viewcourse
// @access      Private(Admin)
exports.viewCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/course/viewCourse', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Course', css: 'admin/viewCourse', js: 'admin/viewCourse', data: req.user });
});

// @desc        Edit Course page (Frontend)
// @route       GET /sdp/admin/editcourse
// @access      Private(Admin)
exports.editCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/course/editcourse', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Course', css: 'admin/editcourse', js: 'admin/editcourse', data: req.user });
});

// @desc        Delete Course page (Frontend)
// @route       GET /sdp/admin/deletecourse
// @access      Private(Admin)
exports.deleteCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/course/deletecourse', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Course', css: 'admin/deletecourse', js: 'admin/deletecourse', data: req.user });
});

// @desc        All Attendances page (Frontend)
// @route       GET /sdp/admin/attendances
// @access      Private(Admin)
exports.attendancesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/attendance/all_attendances', { layout: 'layouts/adminLayout', title: 'SDP Admin | Attendances', css: 'admin/all_attendances', js: 'admin/all_attendances', data: req.user });
});

// @desc        Add Attendance page (Frontend)
// @route       GET /sdp/admin/addattendance
// @access      Private(Admin)
exports.addAttendancePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/attendance/addattendance', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Attendance', css: 'admin/addattendance', js: 'admin/addattendance', data: req.user });
});

// @desc        View Attendance page (Frontend)
// @route       GET /sdp/admin/viewattendance
// @access      Private(Admin)
exports.viewAttendancePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/attendance/viewAttendance', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Attendance', css: 'admin/viewAttendance', js: 'admin/viewAttendance', data: req.user });
});

// @desc        Edit Attendance page (Frontend)
// @route       GET /sdp/admin/editattendance
// @access      Private(Admin)
exports.editAttendancePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/attendance/editattendance', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Attendance', css: 'admin/editattendance', js: 'admin/editattendance', data: req.user });
});

// @desc        Delete Attendance page (Frontend)
// @route       GET /sdp/admin/deleteattendance
// @access      Private(Admin)
exports.deleteAttendancePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/attendance/deleteattendance', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Attendance', css: 'admin/deleteattendance', js: 'admin/deleteattendance', data: req.user });
});

// @desc        All Managers page (Frontend)
// @route       GET /sdp/admin/managers
// @access      Private(Admin)
exports.managersPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/manager/all_managers', { layout: 'layouts/adminLayout', title: 'SDP Admin | Managers', css: 'admin/all_managers', js: 'admin/all_managers', data: req.user });
});

// @desc        Add Manager page (Frontend)
// @route       GET /sdp/admin/addmanager
// @access      Private(Admin)
exports.addManagerPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/manager/addmanager', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Manager', css: 'admin/addmanager', js: 'admin/addmanager', data: req.user });
});

// @desc        View Manager page (Frontend)
// @route       GET /sdp/admin/viewmanager
// @access      Private(Admin)
exports.viewManagerPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/manager/viewManager', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Manager', css: 'admin/viewManager', js: 'admin/viewManager', data: req.user });
});

// @desc        Edit Manager page (Frontend)
// @route       GET /sdp/admin/editmanager
// @access      Private(Admin)
exports.editManagerPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/manager/editmanager', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Manager', css: 'admin/editmanager', js: 'admin/editmanager', data: req.user });
});

// @desc        Delete Manager page (Frontend)
// @route       GET /sdp/admin/deletemanager
// @access      Private(Admin)
exports.deleteManagerPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/manager/deletemanager', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Manager', css: 'admin/deletemanager', js: 'admin/deletemanager', data: req.user });
});

// @desc        All Teachers page (Frontend)
// @route       GET /sdp/admin/teachers
// @access      Private(Admin)
exports.teachersPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/teacher/all_teachers', { layout: 'layouts/adminLayout', title: 'SDP Admin | Teachers', css: 'admin/all_teachers', js: 'admin/all_teachers', data: req.user });
});

// @desc        Add Teacher page (Frontend)
// @route       GET /sdp/admin/addteacher
// @access      Private(Admin)
exports.addTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/teacher/addteacher', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Teacher', css: 'admin/addteacher', js: 'admin/addteacher', data: req.user });
});

// @desc        View Teacher page (Frontend)
// @route       GET /sdp/admin/viewteacher
// @access      Private(Admin)
exports.viewTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/teacher/viewTeacher', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Teacher', css: 'admin/viewTeacher', js: 'admin/viewTeacher', data: req.user });
});

// @desc        Edit Teacher page (Frontend)
// @route       GET /sdp/admin/editteacher
// @access      Private(Admin)
exports.editTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/teacher/editteacher', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Teacher', css: 'admin/editteacher', js: 'admin/editteacher', data: req.user });
});

// @desc        Delete Teacher page (Frontend)
// @route       GET /sdp/admin/deleteteacher
// @access      Private(Admin)
exports.deleteTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/teacher/deleteteacher', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Teacher', css: 'admin/deleteteacher', js: 'admin/deleteteacher', data: req.user });
});

// @desc        All Enquiries page (Frontend)
// @route       GET /sdp/admin/enquiries
// @access      Private(Admin)
exports.enquiriesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/enquiry/all_enquiries', { layout: 'layouts/adminLayout', title: 'SDP Admin | Enquiries', css: 'admin/all_enquiries', js: 'admin/all_enquiries', data: req.user });
});

// @desc        Add Enquiry page (Frontend)
// @route       GET /sdp/admin/addenquiry
// @access      Private(Admin)
exports.addEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/enquiry/addenquiry', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Enquiry', css: 'admin/addenquiry', js: 'admin/addenquiry', data: req.user });
});

// @desc        View Enquiry page (Frontend)
// @route       GET /sdp/admin/viewenquiry
// @access      Private(Admin)
exports.viewEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/enquiry/viewEnquiry', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Enquiry', css: 'admin/viewEnquiry', js: 'admin/viewEnquiry', data: req.user });
});

// @desc        Edit Enquiry page (Frontend)
// @route       GET /sdp/admin/editenquiry
// @access      Private(Admin)
exports.editEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/enquiry/editenquiry', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Enquiry', css: 'admin/editenquiry', js: 'admin/editenquiry', data: req.user });
});

// @desc        Delete Enquiry page (Frontend)
// @route       GET /sdp/admin/deleteEnquiry
// @access      Private(Admin)
exports.deleteEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/Enquiry/deleteEnquiry', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Enquiry', css: 'admin/deleteEnquiry', js: 'admin/deleteEnquiry', data: req.user });
});

// @desc        All Students page (Frontend)
// @route       GET /sdp/admin/students
// @access      Private(Admin)
exports.studentsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/student/all_students', { layout: 'layouts/adminLayout', title: 'SDP Admin | Students', css: 'admin/all_students', js: 'admin/all_students', data: req.user });
});

// @desc        Add Student page (Frontend)
// @route       GET /sdp/admin/addstudent
// @access      Private(Admin)
exports.addStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/student/addstudent', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Student', css: 'admin/addstudent', js: 'admin/addstudent', data: req.user });
});

// @desc        View Student page (Frontend)
// @route       GET /sdp/admin/viewstudent
// @access      Private(Admin)
exports.viewStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    // console.log(req.query.student);
 
    res.render('admin/student/viewStudent', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Student', css: 'admin/viewStudent', js: 'admin/viewStudent', data: req.user });
});

// @desc        Edit Student page (Frontend)
// @route       GET /sdp/admin/editstudent
// @access      Private(Admin)
exports.editStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/student/editstudent', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Student', css: 'admin/editstudent', js: 'admin/editstudent', data: req.user });
});

// @desc        Delete Student page (Frontend)
// @route       GET /sdp/admin/deleteStudent
// @access      Private(Admin)
exports.deleteStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/Student/deleteStudent', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Student', css: 'admin/deleteStudent', js: 'admin/deleteStudent', data: req.user });
});

// @desc        All Admissions page (Frontend)
// @route       GET /sdp/admin/admissions
// @access      Private(Admin)
exports.admissionsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/admission/all_admissions', { layout: 'layouts/adminLayout', title: 'SDP Admin | Admissions', css: 'admin/all_admissions', js: 'admin/all_admissions', data: req.user });
});

// @desc        Add Admission page (Frontend)
// @route       GET /sdp/admin/addadmission
// @access      Private(Admin)
exports.addAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/admission/addadmission', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Admission', css: 'admin/addadmission', js: 'admin/addadmission', data: req.user });
});

// @desc        View Admission page (Frontend)
// @route       GET /sdp/admin/viewadmission
// @access      Private(Admin)
exports.viewAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/admission/viewAdmission', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Admission', css: 'admin/viewAdmission', js: 'admin/viewAdmission', data: req.user });
});

// @desc        Edit Admission page (Frontend)
// @route       GET /sdp/admin/editadmission
// @access      Private(Admin)
exports.editAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/admission/editadmission', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Admission', css: 'admin/editadmission', js: 'admin/editadmission', data: req.user });
});

// @desc        Delete Admission page (Frontend)
// @route       GET /sdp/admin/deleteadmission
// @access      Private(Admin)
exports.deleteAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/admission/deleteadmission', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Admission', css: 'admin/deleteadmission', js: 'admin/deleteadmission', data: req.user });
});

// @desc        Add Fee page (Frontend)
// @route       GET /sdp/admin/addfee
// @access      Private(Admin)
exports.addFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/fee/addfee', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Fee', css: 'admin/addfee', js: 'admin/addfee', data: req.user });
});

// @desc        All Fees page (Frontend)
// @route       GET /sdp/admin/fees
// @access      Private(Admin)
exports.feesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/fee/all_fees', { layout: 'layouts/adminLayout', title: 'SDP Admin | Fees', css: 'admin/all_fees', js: 'admin/all_fees', data: req.user });
});

// @desc        View Fee page (Frontend)
// @route       GET /sdp/admin/viewfee
// @access      Private(Admin)
exports.viewFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/fee/viewFee', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Fee', css: 'admin/viewFee', js: 'admin/viewFee', data: req.user });
});

// @desc        Edit Fee page (Frontend)
// @route       GET /sdp/admin/editfee
// @access      Private(Admin)
exports.editFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/fee/editfee', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Fee', css: 'admin/editfee', js: 'admin/editfee', data: req.user });
});

// @desc        Delete Fee page (Frontend)
// @route       GET /sdp/admin/deletefee
// @access      Private(Admin)
exports.deleteFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/fee/deletefee', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Fee', css: 'admin/deletefee', js: 'admin/deletefee', data: req.user });
});

// @desc        All Lectures page (Frontend)
// @route       GET /sdp/admin/lectures
// @access      Private(Admin)
exports.lecturesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/lecture/all_lectures', { layout: 'layouts/adminLayout', title: 'SDP Admin | Lectures', css: 'admin/all_lectures', js: 'admin/all_lectures', data: req.user });
});

// @desc        Add Lecture page (Frontend)
// @route       GET /sdp/admin/addlecture
// @access      Private(Admin)
exports.addLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/lecture/addlecture', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Lecture', css: 'admin/addlecture', js: 'admin/addlecture', data: req.user });
});

// @desc        View Lecture page (Frontend)
// @route       GET /sdp/admin/viewlecture
// @access      Private(Admin)
exports.viewLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/lecture/viewLecture', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Lecture', css: 'admin/viewLecture', js: 'admin/viewLecture', data: req.user });
});

// @desc        Edit Lecture page (Frontend)
// @route       GET /sdp/admin/editlecture
// @access      Private(Admin)
exports.editLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/lecture/editlecture', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Lecture', css: 'admin/editlecture', js: 'admin/editlecture', data: req.user });
});

// @desc        Delete Lecture page (Frontend)
// @route       GET /sdp/admin/deletelecture
// @access      Private(Admin)
exports.deleteLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/lecture/deletelecture', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Lecture', css: 'admin/deletelecture', js: 'admin/deletelecture', data: req.user });
});

// @desc        All Perks page (Frontend)
// @route       GET /sdp/admin/perks
// @access      Private(Admin)
exports.perksPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/perk/all_perks', { layout: 'layouts/adminLayout', title: 'SDP Admin | Perks', css: 'admin/all_perks', js: 'admin/all_perks', data: req.user });
});

// @desc        Add Perk page (Frontend)
// @route       GET /sdp/admin/addperk
// @access      Private(Admin)
exports.addPerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/perk/addperk', { layout: 'layouts/adminLayout', title: 'SDP Admin | Add Perk', css: 'admin/addperk', js: 'admin/addperk', data: req.user });
});

// @desc        View Perk page (Frontend)
// @route       GET /sdp/admin/viewperk
// @access      Private(Admin)
exports.viewPerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/perk/viewPerk', { layout: 'layouts/adminLayout', title: 'SDP Admin | View Perk', css: 'admin/viewPerk', js: 'admin/viewPerk', data: req.user });
});

// @desc        Edit Perk page (Frontend)
// @route       GET /sdp/admin/editperk
// @access      Private(Admin)
exports.editPerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/perk/editperk', { layout: 'layouts/adminLayout', title: 'SDP Admin | Edit Perk', css: 'admin/editperk', js: 'admin/editperk', data: req.user });
});

// @desc        Delete Perk page (Frontend)
// @route       GET /sdp/admin/deleteperk
// @access      Private(Admin)
exports.deletePerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/perk/deleteperk', { layout: 'layouts/adminLayout', title: 'SDP Admin | Delete Perk', css: 'admin/deleteperk', js: 'admin/deleteperk', data: req.user });
});

// @desc        Birthday Book page (Frontend)
// @route       GET /sdp/admin/birthday-book
// @access      Private(Admin)
exports.birthdayBookPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/birthday_book', { layout: 'layouts/adminLayout', title: 'SDP Admin | Birthday Book', css: 'admin/birthday_book', js: 'admin/birthday_book', data: req.user });
});

// @desc        Website Usage page (Frontend)
// @route       GET /sdp/admin/website-usage
// @access      Private(Admin)
exports.websiteUsagePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/route_logs', { layout: 'layouts/adminLayout', title: 'SDP Admin | Website Usage', css: 'admin/route_logs', js: 'admin/route_logs', data: req.user });
});

// @desc        Login Logs page (Frontend)
// @route       GET /sdp/admin/login-logs
// @access      Private(Admin)
exports.loginLogsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('admin/login_logs', { layout: 'layouts/adminLayout', title: 'SDP Admin | Login Logs', css: 'admin/login_logs', js: 'admin/login_logs', data: req.user });
});
