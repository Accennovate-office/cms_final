const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Topic = require('../models/Topic');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// @desc        Get all topics
// @route       GET /sdp/topics
// @access      Private(Admin,Manager)
exports.getTopics = asyncHandler(async (req, res, next) => { // #### DONE ####

    // After using middleware for advanced results
    // console.log(req.query.course);
    res.status(200).json(res.advancedResults);

    // const topics = await query;

    // res.status(200).json({
    //     success: true,
    //     count: topics.length,
    //     data: topics
    // });
});

// @desc        Get single topic
// @route       GET /sdp/topics/:id
// @access      Private(Admin,Manager)
exports.getTopic = asyncHandler(async (req, res, next) => { // #### DONE ####
    const topic = await Topic.findById(req.params.id).populate({
        path: 'createdBy',
        // select: 'name description'
    });

    if (!topic) {
        return next(new ErrorResponse(`No topic with the id ${req.params.id}`), 404);
    }

    res.status(200).json({
        success: true,
        data: topic
    });
});

// @desc        Add topic
// @route       POST /sdp/topics
// @access      Private(Admin,Manager)
exports.addTopic = asyncHandler(async (req, res, next) => { // #### DONE ####

    req.body.createdBy = req.user.id;

    const topic = await Topic.create(req.body);

    res.status(200).json({
        success: true,
        data: topic
    });
});

// @desc        Update topic
// @route       PUT /sdp/topics/:id
// @access      Private
exports.updateTopic = asyncHandler(async (req, res, next) => { // #### DONE ####
    let topic = await Topic.findById(req.params.id);

    if (!topic) {
        return next(new ErrorResponse(`No topic with the id ${req.params.id}`), 404);
    }

    // // Make sure user is topic owner
    // if (topic.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to update topic ${topic._id}`, 401));
    // }
    req.body.updatedAt = new Date();
    topic = await Topic.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
    });

    res.status(200).json({
        success: true,
        data: topic
    });
});

// @desc        Delete topic
// @route       DELETE /sdp/topics/:id
// @access      Private(Admin,Manager)
exports.deleteTopic = asyncHandler(async (req, res, next) => { // #### DONE ####
    const topic = await Topic.findById(req.params.id);

    if (!topic) {
        return next(new ErrorResponse(`No topic with the id ${req.params.id}`), 404);
    }

    // // Make sure user is topic owner
    // if (topic.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete topic ${topic._id}`, 401));
    // }

    // await topic.remove(); // Actual delete topic
    req.body.deleted = true; // Fake delete topic
    manager = await Topic.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({
        success: true,
        data: {}
    });
});