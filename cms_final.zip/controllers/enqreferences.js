const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Enqreference = require('../models/Enqreference');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all references
// @route       GET /sdp/references
// @access      Private(admin)
exports.getReferences = asyncHandler(async (req, res, next) => {

    // var month = 0, year = 0

    // if (req.user.role == 'admin') {
    //     console.log('admin')

    //     await Reference.aggregate([
    //         { $match: { $expr: { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] } } },
    //         { $group: { _id: null, myCount: { $sum: 1 } } },
    //         { $project: { _id: 0 } }
    //     ]).then((result) => {
    //         // console.log(result)
    //         // console.log(result[0].myCount);
    //         if (result.length != 0) {
    //             month = result[0].myCount
    //         }
    //     })

    //     await Reference.aggregate([
    //         { $match: { $expr: { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] } } },
    //         { $group: { _id: null, myCount: { $sum: 1 } } },
    //         { $project: { _id: 0 } }
    //     ]).then((result) => {
    //         // console.log(result)
    //         // console.log(result[0].myCount);
    //         if (result.length != 0) {
    //             year = result[0].myCount
    //         }
    //     })
    // } else {
    //     console.log('manager / teacher')

    //     await Reference.aggregate([
    //         {
    //             $match: {
    //                 $expr: {
    //                     $and: [
    //                         {
    //                             $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }],
    //                         }, {
    //                             $eq: ["$branch", req.user.branch]
    //                         }

    //                     ]
    //                 }
    //             }
    //         },
    //         { $group: { _id: null, myCount: { $sum: 1 } } },
    //         { $project: { _id: 0 } }
    //     ]).then((result) => {
    //         // console.log('Month ------------------------------------------------')
    //         console.log(result)
    //         // console.log(result[0].myCount);
    //         if (result.length != 0) {
    //             month = result[0].myCount
    //         }
    //     })

    //     await Reference.aggregate([
    //         {
    //             $match: {
    //                 $expr: {
    //                     $and: [
    //                         {
    //                             $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }],
    //                         }, {
    //                             $eq: ["$branch", req.user.branch]
    //                         }

    //                     ]
    //                 }
    //             }
    //         },
    //         { $group: { _id: null, myCount: { $sum: 1 } } },
    //         { $project: { _id: 0 } }
    //     ]).then((result) => {
    //         // console.log('Year ------------------------------------------------')
    //         console.log(result)
    //         // console.log(result[0].myCount);
    //         if (result.length != 0) {
    //             year = result[0].myCount
    //         }
    //     })
    // }


    // let summary = {
    //     month,
    //     year
    // }
    // res.advancedResults.summary = summary

    res.status(200).json(res.advancedResults);
})

// @desc        Create new reference
// @route       POST /sdp/references
// @access      Private(admin)
exports.createReference = asyncHandler(async (req, res, next) => {

    req.body.createdBy = req.user.id;
    const reference = await Enqreference.create(req.body);
    res.status(201).json({
        success: true,
        data: reference
    });
});

// @desc        Get single reference
// @route       GET /sdp/references/:id
// @access      Private(admin) 
exports.getReference = asyncHandler(async (req, res, next) => {

    // const reference = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const references = res.advancedResults.data
    // console.log(references);
    references.forEach(reference => {
        if ((reference._id == req.params.id) && (reference.deleted == false)) {
            res.status(200).json({ success: true, data: reference });
            found = 1
            // console.log(reference)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Reference not found with id ${req.params.id}`, 404)); // Handling if no references found with correctly formatted _id
    }
});

// @desc        Edit single reference
// @route       PUT /sdp/references/:id
// @access      Private(admin) 
exports.editReference = asyncHandler(async (req, res, next) => {

    let reference = await Enqreference.findById(req.params.id);
    // console.log(reference);
    if (!reference) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Reference does not exists`, 404));
    }

    req.body.updatedAt = new Date();
    reference = await Enqreference.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: reference });
});

// @desc        Delete single reference
// @route       DELETE /sdp/references/:id
// @access      Private(admin) 
exports.deleteReference = asyncHandler(async (req, res, next) => {

    let reference = await Enqreference.findById(req.params.id);
    // console.log(reference);
    if (!reference) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Reference does not exists`, 404));
    }

    req.body.deleted = true;
    reference = await Enqreference.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: reference });
    res.status(200).json({ success: true, data: {} });
});
