const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Manager = require('../models/Manager');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all managers
// @route       GET /sdp/managers
// @access      Private(admin)
exports.getManagers = asyncHandler(async (req, res, next) => {

    res.status(200).json(res.advancedResults);
})

// @desc        Create new manager
// @route       POST /sdp/managers
// @access      Private(admin)
exports.createManager = asyncHandler(async (req, res, next) => {

    // Add user to req.user
    // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
    // console.log(req.body.educationalQualification);
    const manager = await Manager.create(req.body);
    res.status(201).json({
        success: true,
        data: manager
    });
});

// @desc        Get single manager
// @route       GET /sdp/managers/:slug
// @access      Private(admin) 
exports.getManager = asyncHandler(async (req, res, next) => {

    // const manager = await res.advancedResults.find({ name: req.params.slug, deleted: false });
    let found = 0;
    const managers = res.advancedResults.data
    // console.log(managers);
    managers.forEach(manager => {
        if ((manager.user.slug == req.params.slug) && (manager.deleted == false)) {
            res.status(200).json({ success: true, data: manager });
            found = 1
            // console.log(manager)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Manager not found with name ${req.params.slug}`, 404)); // Handling if no managers found with correctly formatted _id
    }
    // if (!manager[0]) {

    //     return next(new ErrorResponse(`Manager not found with name ${req.params.name}`, 404)); // Handling if no managers found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: manager[0] });
});

// @desc        Edit single manager
// @route       PUT /sdp/managers/:id
// @access      Private(admin) 
exports.editManager = asyncHandler(async (req, res, next) => {

    let manager = await Manager.findById(req.params.id);
    // console.log(manager);
    if (!manager) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Manager does not exists`, 404));
    }

    // Make sure user is manager owner
    // if (manager.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this manager`, 401));
    // }
    req.body.updatedAt = new Date();
    manager = await Manager.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: manager });
});

// @desc        Delete single manager
// @route       DELETE /sdp/managers/:id
// @access      Private(admin) 
exports.deleteManager = asyncHandler(async (req, res, next) => {

    let manager = await Manager.findById(req.params.id);
    // console.log(manager);
    if (!manager) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Manager does not exists`, 404));
    }

    // Make sure user is manager owner
    // if (manager.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this manager`, 401));
    // }
    req.body.deleted = true;
    manager = await Manager.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: manager });
    res.status(200).json({ success: true, data: {} });
});
