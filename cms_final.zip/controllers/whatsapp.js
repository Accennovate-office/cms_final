const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Whatsapplog = require('../models/Whatsapplog');
const client = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN); 

var company_name = `SmartByte Computer Education`
var teachers_whatsapp_group_link = `https://chat.whatsapp.com/K8qxuaMuVB53p71aGd8iXo`
var kalyan_students_whatsapp_group_link = `https://chat.whatsapp.com/Im0jqPohhdX0QSE49PO6tR`
var dombivli_students_whatsapp_group_link = `https://chat.whatsapp.com/CwCtOlUdvScE8Y9ZwGiM7Q`
var thane_students_whatsapp_group_link = `https://chat.whatsapp.com/L892sdJRuuA8w4NQCVI5np`
var footer = `Team SmartByte`

// @desc        Welcome whatsapp message to CMS users
// @route       POST /sdp/whatsapp/welcome
// @access      Private/Admin/Manager/Teacher
exports.welcome = asyncHandler(async (req, res, next) => { // ##### DONE #####
    
    // console.log(req.body.phone);
    client.messages 
    .create({ 
        body: 
        `Welcome ${req.body.name}

        We are happy to see that you have joined us.
        
        You account has been added to SmartByte Computer Education, ${req.body.branch} branch as a ${req.body.role}
        
        Below given are your login credentials. Keep it safe.
        
        Email: ${req.body.email}
        Password: ${req.body.password}
        
        For any issues or queries contact on 8452917270`, 
        from: 'whatsapp:+918452917270',       
        to: `whatsapp:+91${req.body.phone}` 
    }) 
    .then(message => {
        // console.log(message);
        if (message.sid) {
            Whatsapplog.create({
                from: message.from,
                to: message.to,
                body: message.body,
                numSegments: message.numSegments,
                direction: message.direction,
                sid: message.sid,
                price: message.price,
                errorMessage: message.errorMessage,
                numMedia: message.numMedia,
                errorCode: message.errorCode,
                priceUnit: message.priceUnit,
                user: req.user.id
            });
            res.status(201).json({
                success: true,
                data: 'Whatsapp welcome message send'
            });
        } else {
            return next(new ErrorResponse('Unable to send whatsapp message', 500));
        }
    });


});

// @desc        Enquiry whatsapp message to students
// @route       POST /sdp/whatsapp/enquiry
// @access      Private/Admin/Manager/Teacher
exports.enquiry = asyncHandler(async (req, res, next) => { // ##### DONE #####
    
    // console.log(req.body.phone);
    client.messages 
    .create({ 
        body: `Thank You for visiting SmartByte Computer Education

        To know why you should join SmartByte please click on the link below
        
        Join today and start your Digital Journey with SmartByte`, 
        from: 'whatsapp:+918452917270',       
        to: `whatsapp:+91${req.body.phone}` 
    }) 
    .then(message => {
        // console.log(message);
        if (message.sid) {
            Whatsapplog.create({
                from: message.from,
                to: message.to,
                body: message.body,
                numSegments: message.numSegments,
                direction: message.direction,
                sid: message.sid,
                price: message.price,
                errorMessage: message.errorMessage,
                numMedia: message.numMedia,
                errorCode: message.errorCode,
                priceUnit: message.priceUnit,
                user: req.user.id
            });
            res.status(201).json({
                success: true,
                data: 'Whatsapp enquiry message send'
            });
        } else {
            return next(new ErrorResponse('Unable to send whatsapp message', 500));
        }
    });

});

// @desc        Welcome whatsapp message to CMS users
// @route       POST /sdp/whatsapp/welcometeacher
// @access      Private/Admin/Manager
exports.welcomeTeacher = asyncHandler(async (req, res, next) => { // ##### DONE #####
    
    // console.log(req.body.phone);
    client.messages 
    .create({ 
        body: `Thank you ${req.body.name} for joining ${company_name}. 

Please join the group to get all the updates - ${teachers_whatsapp_group_link}
        
Thank you!
${footer}`, 
        from: 'whatsapp:+918452917270',       
        to: `whatsapp:+91${req.body.phone}` 
    }) 
    .then(message => {
        // console.log(message);
        if (message.sid) {
            Whatsapplog.create({
                from: message.from,
                to: message.to,
                body: message.body,
                numSegments: message.numSegments,
                direction: message.direction,
                sid: message.sid,
                price: message.price,
                errorMessage: message.errorMessage,
                numMedia: message.numMedia,
                errorCode: message.errorCode,
                priceUnit: message.priceUnit,
                user: req.user.id
            });
            res.status(201).json({
                success: true,
                data: 'Whatsapp welcome message send'
            });
        } else {
            return next(new ErrorResponse('Unable to send whatsapp message', 500));
        }
    });


});

// @desc        Welcome whatsapp message to Smartbyte students
// @route       POST /sdp/whatsapp/welcomestudent
// @access      Private/Admin/Manager/Teacher
exports.welcomeStudent = asyncHandler(async (req, res, next) => { // ##### DONE #####
    
    var students_whatsapp_group_link = ``
    var studentBranch = req.body.branch
    
    var thaneBranches = ['Sawarkar Nagar Branch,Thane']
    var kalyanBranches = ['Tilak Chowk Kalyan', 'RAMBAUG KALYAN', 'tatapower kalyan', 'Khadakpada Kalyan', 'Kalyan']
    var dombivliBranches = ['Gupte Road', 'Head Office', 'Dombivli Anand Nagar']

    if (kalyanBranches.includes(studentBranch)) {
        students_whatsapp_group_link = kalyan_students_whatsapp_group_link
    } else if (dombivliBranches.includes(studentBranch)) {
        students_whatsapp_group_link = dombivli_students_whatsapp_group_link
    } else if(thaneBranches.includes(studentBranch)) {
        students_whatsapp_group_link = thane_students_whatsapp_group_link
    }
    // console.log(req.body.phone);
    client.messages 
    .create({ 
        body: `Thank you ${req.body.name} for joining ${company_name} and starting your learning journey with us

Please join this group - ${students_whatsapp_group_link}
        
You will get all the information about lectures, free courses and events in this group
        
Thank you!
Happy Learning!
${footer}`, 
        from: 'whatsapp:+918452917270',       
        to: `whatsapp:+91${req.body.phone}` 
    }) 
    .then(message => {
        // console.log(message);
        if (message.sid) {
            Whatsapplog.create({
                from: message.from,
                to: message.to,
                body: message.body,
                numSegments: message.numSegments,
                direction: message.direction,
                sid: message.sid,
                price: message.price,
                errorMessage: message.errorMessage,
                numMedia: message.numMedia,
                errorCode: message.errorCode,
                priceUnit: message.priceUnit,
                user: req.user.id
            });
            res.status(201).json({
                success: true,
                data: 'Whatsapp welcome message send'
            });
        } else {
            return next(new ErrorResponse('Unable to send whatsapp message', 500));
        }
    });


});

// @desc        Sample
// @route       GET /sdp/whatsapp/alert
// @access      Private/Admin/Manager
exports.alert = asyncHandler(async (req, res, next) => { // ##### DONE #####

    var whatsapp_logs = await Whatsapplog.find({ 
        // _id: req.params.id, 
        deleted: false,
        body: `Thank You for visiting SmartByte Computer Education

        To know why you should join SmartByte please click on the link below
        
        Join today and start your Digital Journey with SmartByte`,
        errorMessage: null,
        errorCode: null
    })

    var unique_whatsapp_logs = await Whatsapplog.distinct("to");
    var count_excluding_demo

    res.status(201).json({
        success: true,
        data: whatsapp_logs.length,
        unique: unique_whatsapp_logs,
        unique_count: unique_whatsapp_logs.length
    });

});

// // @desc        Send welcome mail to user
// // @route       POST /sdp/users/mail
// // @access      Private/Admin/Manager
// exports.welcomeMail = asyncHandler(async (req, res, next) => { // ##### DONE #####

//     const user = req.body;
//     // console.log('Inside send email');
//     // console.log(user);
//     // Send mail after creating new user(manager/teacher)
//     try {
//         await sendWelcomeEmail({
//             email: user.email,
//             first_name: user.name.split(' ')[0],
//             branch_name: user.branch,
//             user_role: user.role,
//             user_email: user.email,
//             user_password: user.password
//         });

//         res.status(200).json({
//             success: true,
//             data: `Welcome mail sent on email ${user.email}. Ask to check Spam and other folders for welcome mail`
//         });
//     } catch (err) {
//         console.log(err);

//         // return next(new ErrorResponse(err, 500));
//         return next(new ErrorResponse('Email could not be sent', 500));
//     }

// });