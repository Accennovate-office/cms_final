const crypto = require('crypto');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const User = require('../models/User');
const Loginlog = require('../models/Loginlog');
const { sendForgotEmail } = require('../utils/sendEmail');
require('dotenv').config();

var API_KEY = process.env.MAIL_API

// Register user functionality no need for now
// // @desc        Register user
// // @route       POST /sdp/auth/register
// // @access      Public
// exports.register = asyncHandler(async (req, res, next) => {
//     const { name, email, password, role } = req.body;

//     // Create user
//     const user = await User.create({
//         name,
//         email,
//         password,
//         role
//     });

//     // Create token 
//     sendTokenResponse(user, 200, res);

// });

// @desc        Login user page (Frontend)
// @route       GET /sdp/auth/login
// @access      Public 
exports.loginPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    res.render('layouts/loginLayout', { title: 'SDP | Login', css: 'login', js: 'login' });
});

// @desc        Login user
// @route       POST /sdp/auth/login
// @access      Public 
exports.login = asyncHandler(async (req, res, next) => { // ##### DONE #####
    const { email, password } = req.body;

    // Validate email & password
    if (!email || !password) {
        return next(new ErrorResponse('Please provide an email and password', 400));
    }

    // Check for user
    const user = await User.findOne({ email, deleted: 0 }).select('+password'); // because we added 'select': false in User model

    if (!user) {
        // Create login logs
        Loginlog.create({
            email,
            password,
            isSuccess: 0
        });
        // console.log("Fail 1");
        return next(new ErrorResponse('Invalid credentials', 401)); // 401 is unauthorized
    }

    // Check if password matches
    const isMatch = await user.matchPassword(password);

    if (!isMatch) {
        // Create login logs
        Loginlog.create({
            email,
            password,
            isSuccess: 0
        });
        // console.log("Fail 2");
        return next(new ErrorResponse('Invalid credentials', 401)); // 401 is unauthorized
    }

    const id = user._id;
    // Create login logs
    Loginlog.create({
        email,
        password,
        isSuccess: 1,
        user: id
    });

    sendTokenResponse(user, 200, res);

});

// @desc        Log user out / clear cookie
// @route       GET /sdp/auth/logout
// @access      Private
exports.logout = asyncHandler(async (req, res, next) => { // ##### DONE #####
    res.cookie('token', 'none', {
        expires: new Date(Date.now() + 10*1000),
        httpOnly: true
    })

    res.status(200).json({
        success: true,
        data: {}
    });
});

// @desc        Get current logged in user
// @route       GET /sdp/auth/me
// @access      Private
exports.getMe = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(`IP > ${req.ip}`);
    if (req.user == null) {
        return next(new ErrorResponse('You are not logged in', 401)); // 401 is unauthorized
    }
    const user = await User.findById(req.user.id);

    res.status(200).json({
        success: true,
        data: user
    });
});

// @desc        Update password
// @route       PUT /sdp/auth/updatepassword
// @access      Private
exports.updatePassword = asyncHandler(async (req, res, next) => { // ##### DONE #####
    const user = await User.findById(req.user.id).select('+password');

    // Check current password
    if (!(await user.matchPassword(req.body.currentPassword))) {
        return next(new ErrorResponse('Current password is incorrect', 401));
    }

    // If current password is correct then save new password
    if (req.user.role == 'admin') {
        user.password = req.body.newPassword;
        user.passwordUpdated = Date.now();
        await user.save({ validateBeforeSave: false });
    } else {
        user.password = req.body.newPassword;
        user.passwordUpdated = Date.now();
        await user.save();
    }


    sendTokenResponse(user, 200, res);
});

// @desc        Update user details
// @route       PUT /sdp/auth/updatedetails
// @access      Private
exports.updateDetails = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // This can be updated only by respective users, not by others
    const fieldsToUpdate = {
        name: req.body.name,
        email: req.body.email,
        updatedAt: Date.now()
    }

    const user = await User.findByIdAndUpdate(req.user.id, fieldsToUpdate, {
        new: true,
        runValidators: true
    });

    // console.log(`User: ${user}`);

    res.status(200).json({
        success: true,
        data: user
    });
});

// @desc        Forgot password page (Frontend)
// @route       GET /sdp/auth/forgotpassword
// @access      Public 
exports.forgotPasswordPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    res.render('layouts/loginLayout', { title: 'SDP | Forgot Password', css: 'login', js: 'forgotpassword' });
});

// @desc        Forgot password
// @route       POST /sdp/auth/forgotpassword
// @access      Public
exports.forgotPassword = asyncHandler(async (req, res, next) => { // ##### DONE #####
    const user = await User.findOne({ email: req.body.email });

    if (!user) {
        return next(new ErrorResponse('There is no user with that email', 404));
    }

    // Get reset token
    const resetToken = user.getResetPasswordToken();

    await user.save({ validateBeforeSave: false });

    // Create reset url
    const resetUrl = `${req.protocol}://${req.get('host')}/sdp/auth/resetpassword/${resetToken}`;
    // protocol=http(s), host=domainName

    // const message = `<h1>Reset Your Password</h1><br> <h2>You are receiving this email because you (or someone else) has requested the reset of password.</h2><br> Please make a PUT request to: \n\n ${resetUrl}`;
    // While in frontend only button with link embedded can be added for user to click

    res.status(200).json({
        success: true,
        data: `Reset Password link sent on email ${user.email}. Link is valid for 10 minutes.
        Also check Spam and other folders for reset mail`,
        resetLink: resetUrl,
        apiKey: API_KEY,
        to: user.email
    });
    // try {
        // Old working code start
        // await sendForgotEmail({
        //     email: user.email,
        //     // subject: 'Reset Password',
        //     name: user.name,
        //     resetUrl: resetUrl
        // }).then((result) => {
        //     console.log(result)
        //     // console.log(result[0].myCount);
        // })
        // Old working code end

//     } catch (err) {
//         // If anything goes wrong clear token & expire in database
//         console.log(err);
//         user.resetPasswordToken = undefined;
//         user.resetPasswordExpire = undefined;

//         await user.save({ validateBeforeSave: false });

//         return next(new ErrorResponse('Email could not be sent', 500));
//     }

//     // res.status(200).json({
//     //     success: true,
//     //     data: user
//     // });
});

// @desc        Reset password page (Frontend)
// @route       GET /sdp/auth/resetpassword/:resettoken
// @access      Public 
exports.resetPasswordPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    res.render('layouts/loginLayout', { title: 'SDP | Reset Password', css: 'login', js: 'resetpassword' });
});

// @desc        Reset password
// @route       PUT /sdp/auth/resetpassword/:resettoken
// @access      Public
exports.resetPassword = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // Get hashed token
    const resetPasswordToken = crypto.createHash('sha256').update(req.params.resettoken).digest('hex');

    const user = await User.findOne({
        resetPasswordToken,
        resetPasswordExpire: { $gt: Date.now() } // to check if token is expired or not using greaterThan function
    });

    if (!user) {
        return next(new ErrorResponse('Your link is either invalid or expired. Click on Forgot Password to generate new link', 400));
    }

    // Set new password
    if (req.user.role == 'admin') {
        user.password = req.body.password;
        user.resetPasswordToken = undefined;
        user.resetPasswordExpire = undefined;
        user.passwordUpdated = Date.now();
        await user.save({ validateBeforeSave: false });
    } else {
        user.password = req.body.password;
        user.resetPasswordToken = undefined;
        user.resetPasswordExpire = undefined;
        user.passwordUpdated = Date.now();
        await user.save();
    }


    sendTokenResponse(user, 200, res);

});

// Get token from model, create cookie and send response
const sendTokenResponse = (user, statusCode, res) => { // ##### DONE #####
    // Create token
    const token = user.getSignedJwtToken();

    const options = {
        expires: new Date(Date.now() + process.env.JWT_COOKIE_EXPIRE * 60 * 60 * 1000), // To convert it into mins
        httpOnly: true
    };

    // Commented below if-condition temporarily to test on AWS
    // if (process.env.NODE_ENV === 'production') {
    //     options.secure = true; // To make cookie accessible only with https://
    // }

    res
        .status(statusCode)
        .cookie('token', token, options)
        .json({
            success: true,
            token
        });
}
