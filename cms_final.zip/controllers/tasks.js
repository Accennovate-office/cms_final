const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Task = require('../models/Task');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');

// @desc        Get all tasks
// @route       GET /sdp/tasks
// @access      Private(Admin,Manager)
exports.getTasks = asyncHandler(async (req, res, next) => { // #### DONE ####

    // After using middleware for advanced results
    res.status(200).json(res.advancedResults);

    // const tasks = await query;

    // res.status(200).json({
    //     success: true,
    //     count: tasks.length,
    //     data: tasks
    // });
});

// @desc        Get single task
// @route       GET /sdp/tasks/:id
// @access      Private(Admin,Manager)
exports.getTask = asyncHandler(async (req, res, next) => { // #### DONE ####
    const task = await Task.findById(req.params.id).populate({
        path: 'category subcategory createdBy',
        // select: 'name description'
    });

    if (!task) {
        return next(new ErrorResponse(`No task with the id ${req.params.id}`), 404);
    }

    res.status(200).json({
        success: true,
        data: task
    });
});

// @desc        Add task
// @route       POST /sdp/tasks
// @access      Private(Admin,Manager)
exports.addTask = asyncHandler(async (req, res, next) => { // #### DONE ####

    req.body.createdBy = req.user.id
    req.body.branch = req.user.branch
    if (req.user.role == 'teacher') {
        req.body.byTeacher = true
    }
    const task = await Task.create(req.body);

    res.status(200).json({
        success: true,
        data: task
    });
});

// @desc        Update task
// @route       PUT /sdp/tasks/:id
// @access      Private
exports.updateTask = asyncHandler(async (req, res, next) => { // #### DONE ####
    let task = await Task.findById(req.params.id);

    if (!task) {
        return next(new ErrorResponse(`No task with the id ${req.params.id}`), 404);
    }

    // Make sure user is task owner
    // if (task.user.toString() !== req.user.id || req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to update task ${task._id}`, 401));
    // }

    // Validation to update tasks
    if (req.user.role == 'teacher' && task.createdBy._id != req.user.id) {
        // console.log('----------------------------------------------------------------------')
        // console.log('I am teacher but cannot update');
        return next(new ErrorResponse(`You are not authorized to update this task`, 401));
    } else if (req.user.role == 'manager' && task.branch != req.user.branch) {
        // console.log('----------------------------------------------------------------------')
        // console.log('I am manager but cannot update');
        return next(new ErrorResponse(`You are not authorized to update this task`, 401));
    } else {
        // console.log('----------------------------------------------------------------------')
        // console.log('I can update');
        req.body.updatedAt = new Date();
        task = await Task.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });

        res.status(200).json({
            success: true,
            data: task
        });
    }

});

// @desc        Delete task
// @route       DELETE /sdp/tasks/:id
// @access      Private(Admin,Manager)
exports.deleteTask = asyncHandler(async (req, res, next) => { // #### DONE ####
    const task = await Task.findById(req.params.id);

    if (!task) {
        return next(new ErrorResponse(`No task with the id ${req.params.id}`), 404);
    }

    // // Make sure user is task owner
    // if (task.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete task ${task._id}`, 401));
    // }

    // Validation to update tasks
    if (req.user.role == 'teacher' && task.createdBy._id != req.user.id) {
        // console.log('----------------------------------------------------------------------')
        // console.log('I am teacher but cannot update');
        return next(new ErrorResponse(`You are not authorized to update this task`, 401));
    } else if (req.user.role == 'manager' && task.branch != req.user.branch) {
        // console.log('----------------------------------------------------------------------')
        // console.log('I am manager but cannot update');
        return next(new ErrorResponse(`You are not authorized to update this task`, 401));
    } else {
        // console.log('----------------------------------------------------------------------')
        // console.log('I can update');

        // await task.remove(); // Actual delete task
        req.body.deleted = true; // Fake delete task
        manager = await Task.findByIdAndUpdate(req.params.id, req.body, {
            new: true, // to return updated data
            runValidators: true // to run mongoose validators to check updating data
        });

        res.status(200).json({
            success: true,
            data: {}
        });
    }

});