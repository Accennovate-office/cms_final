const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc        Dashboard page (Frontend)
// @route       GET /sdp/manager/dashboard
// @access      Private(Manager)
exports.dashboardPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/dashboard', { layout: 'layouts/managerLayout', title: 'SDP Manager | Dashboard', css: 'manager/dashboard', js: 'manager/dashboard', data: req.user });
});

// @desc        All Tasks page (Frontend)
// @route       GET /sdp/manager/tasks
// @access      Private(Manager)
exports.tasksPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/task/all_tasks', { layout: 'layouts/managerLayout', title: 'SDP Manager | Tasks', css: 'manager/all_tasks', js: 'manager/all_tasks', data: req.user });
});

// @desc        Add Task page (Frontend)
// @route       GET /sdp/manager/addtask
// @access      Private(Manager)
exports.addTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/task/addtask', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Task', css: 'manager/addtask', js: 'manager/addtask', data: req.user });
});

// @desc        View Task page (Frontend)
// @route       GET /sdp/manager/viewtask
// @access      Private(Manager)
exports.viewTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/task/viewTask', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Task', css: 'manager/viewTask', js: 'manager/viewTask', data: req.user });
});

// @desc        Edit Task page (Frontend)
// @route       GET /sdp/manager/edittask
// @access      Private(Manager)
exports.editTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/task/edittask', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Task', css: 'manager/edittask', js: 'manager/edittask', data: req.user });
});

// @desc        Delete Task page (Frontend)
// @route       GET /sdp/manager/deletetask
// @access      Private(Manager)
exports.deleteTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/task/deletetask', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Task', css: 'manager/deletetask', js: 'manager/deletetask', data: req.user });
});

// @desc        All Branches page (Frontend)
// @route       GET /sdp/manager/branches
// @access      Private(Manager)
exports.branchesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/branch/all_branches', { layout: 'layouts/managerLayout', title: 'SDP Manager | Branches', css: 'manager/all_branches', js: 'manager/all_branches', data: req.user });
});

// @desc        Add Branch page (Frontend)
// @route       GET /sdp/manager/addbranch
// @access      Private(Manager)
exports.addBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/branch/addbranch', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Branch', css: 'manager/addbranch', js: 'manager/addbranch', data: req.user });
});

// @desc        View Branch page (Frontend)
// @route       GET /sdp/manager/viewbranch
// @access      Private(Manager)
exports.viewBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/branch/viewBranch', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Branch', css: 'manager/viewBranch', js: 'manager/viewBranch', data: req.user });
});

// @desc        Edit Branch page (Frontend)
// @route       GET /sdp/manager/editbranch
// @access      Private(Manager)
exports.editBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/branch/editbranch', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Branch', css: 'manager/editbranch', js: 'manager/editbranch', data: req.user });
});

// @desc        Delete Branch page (Frontend)
// @route       GET /sdp/manager/deletebranch
// @access      Private(Manager)
exports.deleteBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/branch/deletebranch', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Branch', css: 'manager/deletebranch', js: 'manager/deletebranch', data: req.user });
});

// @desc        All Courses page (Frontend)
// @route       GET /sdp/manager/courses
// @access      Private(Manager)
exports.coursesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/course/all_courses', { layout: 'layouts/managerLayout', title: 'SDP Manager | Courses', css: 'manager/all_courses', js: 'manager/all_courses', data: req.user });
});

// @desc        Add Course page (Frontend)
// @route       GET /sdp/manager/addcourse
// @access      Private(Manager)
exports.addCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/course/addcourse', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Course', css: 'manager/addcourse', js: 'manager/addcourse', data: req.user });
});

// @desc        View Course page (Frontend)
// @route       GET /sdp/manager/viewcourse
// @access      Private(Manager)
exports.viewCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/course/viewCourse', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Course', css: 'manager/viewCourse', js: 'manager/viewCourse', data: req.user });
});

// @desc        Edit Course page (Frontend)
// @route       GET /sdp/manager/editcourse
// @access      Private(Manager)
exports.editCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/course/editcourse', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Course', css: 'manager/editcourse', js: 'manager/editcourse', data: req.user });
});

// @desc        Delete Course page (Frontend)
// @route       GET /sdp/manager/deletecourse
// @access      Private(Manager)
exports.deleteCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/course/deletecourse', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Course', css: 'manager/deletecourse', js: 'manager/deletecourse', data: req.user });
});

// @desc        All Teachers page (Frontend)
// @route       GET /sdp/manager/teachers
// @access      Private(Manager)
exports.teachersPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/teacher/all_teachers', { layout: 'layouts/managerLayout', title: 'SDP Manager | Teachers', css: 'manager/all_teachers', js: 'manager/all_teachers', data: req.user });
});

// @desc        Add Teacher page (Frontend)
// @route       GET /sdp/manager/addteacher
// @access      Private(Manager)
exports.addTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/teacher/addteacher', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Teacher', css: 'manager/addteacher', js: 'manager/addteacher', data: req.user });
});

// @desc        View Teacher page (Frontend)
// @route       GET /sdp/manager/viewteacher
// @access      Private(Manager)
exports.viewTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/teacher/viewTeacher', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Teacher', css: 'manager/viewTeacher', js: 'manager/viewTeacher', data: req.user });
});

// @desc        Edit Teacher page (Frontend)
// @route       GET /sdp/manager/editteacher
// @access      Private(Manager)
exports.editTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/teacher/editteacher', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Teacher', css: 'manager/editteacher', js: 'manager/editteacher', data: req.user });
});

// @desc        Delete Teacher page (Frontend)
// @route       GET /sdp/manager/deleteteacher
// @access      Private(Manager)
exports.deleteTeacherPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/teacher/deleteteacher', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Teacher', css: 'manager/deleteteacher', js: 'manager/deleteteacher', data: req.user });
});

// @desc        All Enquiries page (Frontend)
// @route       GET /sdp/manager/enquiries
// @access      Private(Manager)
exports.enquiriesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/enquiry/all_enquiries', { layout: 'layouts/managerLayout', title: 'SDP Manager | Enquiries', css: 'manager/all_enquiries', js: 'manager/all_enquiries', data: req.user });
});

// @desc        Add Enquiry page (Frontend)
// @route       GET /sdp/manager/addenquiry
// @access      Private(Manager)
exports.addEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/enquiry/addenquiry', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Enquiry', css: 'manager/addenquiry', js: 'manager/addenquiry', data: req.user });
});

// @desc        View Enquiry page (Frontend)
// @route       GET /sdp/manager/viewenquiry
// @access      Private(Manager)
exports.viewEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/enquiry/viewEnquiry', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Enquiry', css: 'manager/viewEnquiry', js: 'manager/viewEnquiry', data: req.user });
});

// @desc        Edit Enquiry page (Frontend)
// @route       GET /sdp/manager/editenquiry
// @access      Private(Manager)
exports.editEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/enquiry/editenquiry', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Enquiry', css: 'manager/editenquiry', js: 'manager/editenquiry', data: req.user });
});

// @desc        Delete Enquiry page (Frontend)
// @route       GET /sdp/manager/deleteEnquiry
// @access      Private(Manager)
exports.deleteEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/Enquiry/deleteEnquiry', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Enquiry', css: 'manager/deleteEnquiry', js: 'manager/deleteEnquiry', data: req.user });
});

// @desc        All Students page (Frontend)
// @route       GET /sdp/manager/students
// @access      Private(Manager)
exports.studentsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/student/all_students', { layout: 'layouts/managerLayout', title: 'SDP Manager | Students', css: 'manager/all_students', js: 'manager/all_students', data: req.user });
});

// @desc        Add Student page (Frontend)
// @route       GET /sdp/manager/addstudent
// @access      Private(Manager)
exports.addStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/student/addstudent', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Student', css: 'manager/addstudent', js: 'manager/addstudent', data: req.user });
});

// @desc        View Student page (Frontend)
// @route       GET /sdp/manager/viewstudent
// @access      Private(Manager)
exports.viewStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/student/viewStudent', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Student', css: 'manager/viewStudent', js: 'manager/viewStudent', data: req.user });
});

// @desc        Edit Student page (Frontend)
// @route       GET /sdp/manager/editstudent
// @access      Private(Manager)
exports.editStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/student/editstudent', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Student', css: 'manager/editstudent', js: 'manager/editstudent', data: req.user });
});

// @desc        Delete Student page (Frontend)
// @route       GET /sdp/manager/deleteStudent
// @access      Private(Manager)
exports.deleteStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/Student/deleteStudent', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Student', css: 'manager/deleteStudent', js: 'manager/deleteStudent', data: req.user });
});

// @desc        All Admissions page (Frontend)
// @route       GET /sdp/manager/admissions
// @access      Private(Manager)
exports.admissionsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/admission/all_admissions', { layout: 'layouts/managerLayout', title: 'SDP Manager | Admissions', css: 'manager/all_admissions', js: 'manager/all_admissions', data: req.user });
});

// @desc        Add Admission page (Frontend)
// @route       GET /sdp/manager/addadmission
// @access      Private(Manager)
exports.addAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/admission/addadmission', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Admission', css: 'manager/addadmission', js: 'manager/addadmission', data: req.user });
});

// @desc        View Admission page (Frontend)
// @route       GET /sdp/manager/viewadmission
// @access      Private(Manager)
exports.viewAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/admission/viewAdmission', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Admission', css: 'manager/viewAdmission', js: 'manager/viewAdmission', data: req.user });
});

// @desc        Edit Admission page (Frontend)
// @route       GET /sdp/manager/editadmission
// @access      Private(Manager)
exports.editAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/admission/editadmission', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Admission', css: 'manager/editadmission', js: 'manager/editadmission', data: req.user });
});

// @desc        Delete Admission page (Frontend)
// @route       GET /sdp/manager/deleteadmission
// @access      Private(Manager)
exports.deleteAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/admission/deleteadmission', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Admission', css: 'manager/deleteadmission', js: 'manager/deleteadmission', data: req.user });
});

// @desc        Add Fee page (Frontend)
// @route       GET /sdp/manager/addfee
// @access      Private(Manager)
exports.addFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/fee/addfee', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Fee', css: 'manager/addfee', js: 'manager/addfee', data: req.user });
});

// @desc        All Fees page (Frontend)
// @route       GET /sdp/manager/fees
// @access      Private(Manager)
exports.feesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/fee/all_fees', { layout: 'layouts/managerLayout', title: 'SDP Manager | Fees', css: 'manager/all_fees', js: 'manager/all_fees', data: req.user });
});

// @desc        View Fee page (Frontend)
// @route       GET /sdp/manager/viewfee
// @access      Private(Manager)
exports.viewFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/fee/viewFee', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Fee', css: 'manager/viewFee', js: 'manager/viewFee', data: req.user });
});

// @desc        Edit Fee page (Frontend)
// @route       GET /sdp/manager/editfee
// @access      Private(Manager)
exports.editFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/fee/editfee', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Fee', css: 'manager/editfee', js: 'manager/editfee', data: req.user });
});

// @desc        Delete Fee page (Frontend)
// @route       GET /sdp/manager/deletefee
// @access      Private(Manager)
exports.deleteFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/fee/deletefee', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Fee', css: 'manager/deletefee', js: 'manager/deletefee', data: req.user });
});

// @desc        All Lectures page (Frontend)
// @route       GET /sdp/manager/lectures
// @access      Private(Manager)
exports.lecturesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/lecture/all_lectures', { layout: 'layouts/managerLayout', title: 'SDP Manager | Lectures', css: 'manager/all_lectures', js: 'manager/all_lectures', data: req.user });
});

// @desc        Add Lecture page (Frontend)
// @route       GET /sdp/manager/addlecture
// @access      Private(Manager)
exports.addLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/lecture/addlecture', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Lecture', css: 'manager/addlecture', js: 'manager/addlecture', data: req.user });
});

// @desc        View Lecture page (Frontend)
// @route       GET /sdp/manager/viewlecture
// @access      Private(Manager)
exports.viewLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/lecture/viewLecture', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Lecture', css: 'manager/viewLecture', js: 'manager/viewLecture', data: req.user });
});

// @desc        Edit Lecture page (Frontend)
// @route       GET /sdp/manager/editlecture
// @access      Private(Manager)
exports.editLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/lecture/editlecture', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Lecture', css: 'manager/editlecture', js: 'manager/editlecture', data: req.user });
});

// @desc        Delete Lecture page (Frontend)
// @route       GET /sdp/manager/deletelecture
// @access      Private(Manager)
exports.deleteLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/lecture/deletelecture', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Lecture', css: 'manager/deletelecture', js: 'manager/deletelecture', data: req.user });
});

// @desc        All Perks page (Frontend)
// @route       GET /sdp/manager/perks
// @access      Private(Manager)
exports.perksPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/perk/all_perks', { layout: 'layouts/managerLayout', title: 'SDP Manager | Perks', css: 'manager/all_perks', js: 'manager/all_perks', data: req.user });
});

// @desc        Add Perk page (Frontend)
// @route       GET /sdp/manager/addperk
// @access      Private(Manager)
exports.addPerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/perk/addperk', { layout: 'layouts/managerLayout', title: 'SDP Manager | Add Perk', css: 'manager/addperk', js: 'manager/addperk', data: req.user });
});

// @desc        View Perk page (Frontend)
// @route       GET /sdp/manager/viewperk
// @access      Private(Manager)
exports.viewPerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/perk/viewPerk', { layout: 'layouts/managerLayout', title: 'SDP Manager | View Perk', css: 'manager/viewPerk', js: 'manager/viewPerk', data: req.user });
});

// @desc        Edit Perk page (Frontend)
// @route       GET /sdp/manager/editperk
// @access      Private(Manager)
exports.editPerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/perk/editperk', { layout: 'layouts/managerLayout', title: 'SDP Manager | Edit Perk', css: 'manager/editperk', js: 'manager/editperk', data: req.user });
});

// @desc        Delete Perk page (Frontend)
// @route       GET /sdp/manager/deleteperk
// @access      Private(Manager)
exports.deletePerkPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/perk/deleteperk', { layout: 'layouts/managerLayout', title: 'SDP Manager | Delete Perk', css: 'manager/deleteperk', js: 'manager/deleteperk', data: req.user });
});

// @desc        Birthday Book page (Frontend)
// @route       GET /sdp/manager/birthday-book
// @access      Private(Manager)
exports.birthdayBookPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('manager/birthday_book', { layout: 'layouts/managerLayout', title: 'SDP Manager | Birthday Book', css: 'manager/birthday_book', js: 'manager/birthday_book', data: req.user });
});
