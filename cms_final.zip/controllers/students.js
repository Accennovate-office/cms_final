const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Student = require('../models/Student');
const Admission = require('../models/Admission');
const Lecture = require('../models/Lecture');
const Fee = require('../models/Fee');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');
const { isEmptyObject, data } = require('jquery');
// New
var db = require('../config/db');


// @desc        Get all students
// @route       GET /sdp/students
// @access      Private(admin)
exports.getStudents = asyncHandler(async (req, res, next) => {

    // // Sample code for first data
    // let firstData = res.advancedResults.data[0]
    // console.log(firstData);
    // let admData = await Admission.find({deleted:false, student: firstData._id}).populate('course teacher').select('fees')
    // console.log('Admission data ---');
    // console.log(admData);
    // let feeData = await Fee.find({deleted:false, student: firstData._id}).select('feesPaid')
    // console.log('Fees data ---');
    // console.log(feeData);
    // res.advancedResults.data[0].courses = admData

    var dataFetch = res.advancedResults.data

    for (let i = 0; i < dataFetch.length; i++) {
        const studentData = dataFetch[i];
        let admData = await Admission.find({deleted:false, student: studentData._id}).populate('course teacher').select('fees')
        let feeData = await Fee.find({deleted:false, student: studentData._id}).select('feesPaid')
        res.advancedResults.data[i].courses = admData
        res.advancedResults.data[i].fees = feeData
    }

    res.status(200).json(res.advancedResults);
})

// @desc        Get all students
// @route       GET /sdp/students/birthday/data
// @access      Private(admin)
exports.birthdayStudents = asyncHandler(async (req, res, next) => {

    res.status(200).json(res.advancedResults);
})

// @desc        Get students summary
// @route       GET /sdp/students/summary/info
// @access      Private(admin)
exports.summaryStudents = asyncHandler(async (req, res, next) => {

    // console.log('inside summary student');
    var today = 0, month = 0, year = 0, total = 0

    // Ref: https://stackoverflow.com/a/37065412
    // console.log(req.query.reso);

    var daily_report_filter, monthly_report_filter, yearly_report_filter, total_report_filter;

    var delete_filter = { $eq: ["$deleted", false] }
    var branch_filter = { $eq: ["$branch", req.user.branch] }

    if (req.user.role == 'admin') {
        // console.log('admin')

        daily_report_filter = [
            delete_filter,
            { $eq: [{ "$dayOfMonth": "$createdAt" }, { "$dayOfMonth": new Date() }] },
            { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
        ]

        monthly_report_filter = [
            delete_filter,
            { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
        ]

        yearly_report_filter = [
            delete_filter,
            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }
        ]

        total_report_filter = [
            delete_filter
        ]

    } else {
        // console.log('manager / teacher')

        daily_report_filter = [
            delete_filter,
            { $eq: [{ "$dayOfMonth": "$createdAt" }, { "$dayOfMonth": new Date() }] },
            { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }, 
            branch_filter
        ]

        monthly_report_filter = [
            delete_filter,
            { $eq: [{ "$month": "$createdAt" }, { "$month": new Date() }] },
            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }, 
            branch_filter
        ]

        yearly_report_filter = [
            delete_filter,
            { $eq: [{ "$year": "$createdAt" }, { "$year": new Date() }] }, 
            branch_filter
        ]

        total_report_filter = [
            delete_filter,
            branch_filter
        ]
        
    }

    // Daily report
    await Student.aggregate([
        {
            $match: {
                $expr: {
                    $and: daily_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            today = result[0].myCount
        }
    })

    // Monthly report
    await Student.aggregate([
        {
            $match: {
                $expr: {
                    $and: monthly_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            month = result[0].myCount
        }
    })

    // Yearly report
    await Student.aggregate([
        {
            $match: {
                $expr: {
                    $and: yearly_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            year = result[0].myCount
        }
    })

    // Total report
    await Student.aggregate([
        {
            $match: {
                $expr: {
                    $and: total_report_filter
                }
            }
        },
        { $group: { _id: null, myCount: { $sum: 1 } } },
        { $project: { _id: 0 } }
    ]).then((result) => {
        // console.log('Year ------------------------------------------------')
        // console.log(result)
        // console.log(result[0].myCount);
        if (result.length != 0) {
            total = result[0].myCount
        }
    })

    var summary = {
        today: today,
        month: month,
        year: year,
        total: total
    }
    res.data = {
        success: true,
        data: summary
    }
    // res.advancedResults.summary = summary

    res.status(200).json(res.data);
})

// @desc        Get all students only name & id
// @route       GET /sdp/students/special/data
// @access      Private(admin)
exports.specialData = asyncHandler(async (req, res, next) => {
    
    var filter
    let userRole = req.user.role
    if (userRole == 'manager' || userRole == 'teacher') {
        filter = {deleted: false, branch: req.user.branch}
    } else {
        filter = {deleted: false}
    }
    var studentsData = await Student.find(filter).select('firstName middleName lastName').sort({createdAt: -1})
    let response = {
        success: true,
        count: studentsData.length,
        data: studentsData
    }
    res.response = response
    res.status(200).json(res.response);
})

// @desc        Create new student
// @route       POST /sdp/students
// @access      Private(admin)
exports.createStudent = asyncHandler(async (req, res, next) => {

    req.body.createdBy = req.user.id;
    const student = await Student.create(req.body);
    res.status(201).json({
        success: true,
        data: student
    });
});

// @desc        Get single student
// @route       GET /sdp/students/:id
// @access      Private(admin) 
exports.getStudent = asyncHandler(async (req, res, next) => {

    // const student = await res.advancedResults.find({ name: req.params.id, deleted: false });
    var student = await Student.findOne({ 
        _id: req.params.id, 
        deleted: false 
    }).populate('reference createdBy'); // .explain()
    var admissions = await Admission.find({ 
        student: req.params.id,
        deleted: false
    }).populate('course teacher createdBy')
    var lectures = await Lecture.find({
        student: `${student.firstName} ${student.middleName} ${student.lastName}`,
        deleted: false
    }).populate('teacher course createdBy')
    var fees = await Fee.find({
        student: req.params.id,
        deleted: false
    }).populate('student collectedBy createdBy')
    // console.log(admissions);
    // console.log(student);
    // console.log(fees);
    if (student && student.length === 0) {
        res.status(404).json({ success: false, error: 'Student not found' });
        // return next(new ErrorResponse(`Student not found`, 404)); // Handling if no students found with correctly formatted _id
        // return next(new ErrorResponse(`Student not found with id ${req.params.id}`, 404)); // Handling if no students found with correctly formatted _id
        // console.log('Student not found ->');
    } else {
        res.status(200).json({ 
            success: true, 
            data: student, 
            courses: admissions, 
            lectures: lectures,
            fees: fees
        });
    }
    // console.log('Single student found above');
    // let found = 0;
    // const students = res.advancedResults.data
    // // console.log(students);
    // students.forEach(student => {
    //     if ((student._id == req.params.id) && (student.deleted == false)) {
    //         res.status(200).json({ success: true, data: student });
    //         found = 1
    //         console.log(student)
    //     }
    // });
    // if (found == 0) {
    //     return next(new ErrorResponse(`Student not found with id ${req.params.id}`, 404)); // Handling if no students found with correctly formatted _id
    // }
});

// @desc        Edit single student
// @route       PUT /sdp/students/:id
// @access      Private(admin) 
exports.editStudent = asyncHandler(async (req, res, next) => {

    let student = await Student.findById(req.params.id);
    // console.log(student);
    if (!student) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Student does not exists`, 404));
    }

    req.body.updatedAt = new Date();
    student = await Student.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: student });
});

// @desc        Delete single student
// @route       DELETE /sdp/students/:id
// @access      Private(admin) 
exports.deleteStudent = asyncHandler(async (req, res, next) => {

    let student = await Student.findById(req.params.id);
    // console.log(student);
    if (!student) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Student does not exists`, 404));
    }

    req.body.deleted = true;
    student = await Student.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: student });
    res.status(200).json({ success: true, data: {} });
});

// Feb 2023 update

// @desc        Get student phone if exists
// @route       Get /sdp/students/:phone
// @access      Admin, Managers, Teachers
exports.checkPhone = asyncHandler(async (req, res, next) => {

    // const student = await res.advancedResults.find({ name: req.params.id, deleted: false });
    let found = 0;
    const students = res.advancedResults.data
    // console.log(students);
    students.forEach(student => {
        if ((student.phone1 == req.params.phone || student.phone2 == req.params.phone || student.parentPhone == req.params.phone) && (student.deleted == false)) {
            res.status(200).json({ success: true, data: student });
            found = 1
            // console.log(student)
        }
    });
    if (found == 0) {
        res.status(200).json({ success: false, data: `Student not found with phone ${req.params.phone}. Please proceed further` });
        // return next(new ErrorResponse(`Student not found with phone ${req.params.phone}. Please proceed further`, 404)); // Handling if no students found with correctly formatted _id
    }
});