const path = require('path');
const ErrorResponse = require('../utils/errorResponse');
// Importing model of bootcamp
const Teacher = require('../models/Teacher');
// Commented try-catch because now asyncHandler will handle that for us
const asyncHandler = require('../middleware/async');


// @desc        Get all teachers
// @route       GET /sdp/teachers
// @access      Private(admin,manager)
exports.getTeachers = asyncHandler(async (req, res, next) => {

    var allTeachersData
    if (req.user.role === 'admin') {
        allTeachersData = await Teacher.find({deleted:false}).sort({createdAt:-1}).populate('user');
    } else {
        allTeachersData = await Teacher.find({deleted:false,branch:req.user.branch}).sort({createdAt:-1}).populate('user');
    }
    res.advancedResults.alldata = allTeachersData
    res.advancedResults.alldatacount = allTeachersData.length
    res.status(200).json(res.advancedResults);
})

// @desc        Create new teacher
// @route       POST /sdp/teachers
// @access      Private(admin,manager)
exports.createTeacher = asyncHandler(async (req, res, next) => {

    // console.log('inside create teacher controller');
    // Add user to req.user
    req.body.createdBy = req.user.id
    // req.body.user = req.user.id; // req.user is must for id (This line is to add self-user)
    // console.log(req.body.bank);
    // console.log(req.body.PAN);
    // console.log('----------------------------------');
    const teacher = await Teacher.create(req.body);
    // console.log(teacher);
    res.status(201).json({
        success: true,
        data: teacher
    });
});

// @desc        Get single teacher
// @route       GET /sdp/teachers/:id
// @access      Private(admin,manager) 
exports.getTeacher = asyncHandler(async (req, res, next) => {

    // const teacher = await res.advancedResults.find({ name: req.params.id, deleted: false });
    var found = 0;
    const teachers = res.advancedResults.data
    // console.log(teachers);
    // console.log(req.params.id);
    teachers.forEach(teacher => {
        // console.log(teacher.user._id == req.params.id);
        // console.log(teacher.deleted == false);
        // console.log('------------------------')
        if (teacher.user._id == req.params.id && teacher.deleted == false) {
        // if ((teacher.id == req.params.id) && (teacher.deleted == false)) {
            // console.log('Teacher found');
            found = 1
            res.status(200).json({ success: true, data: teacher });
            // console.log(teacher)
        }
    });
    if (found == 0) {
        return next(new ErrorResponse(`Teacher not found with name ${req.params.id}`, 404)); // Handling if no teachers found with correctly formatted _id
    }
    // if (!teacher[0]) {

    //     return next(new ErrorResponse(`Teacher not found with name ${req.params.name}`, 404)); // Handling if no teachers found with correctly formatted _id
    // }
    // res.status(200).json({ success: true, data: teacher[0] });
});

// @desc        Edit single teacher
// @route       PUT /sdp/teachers/:id
// @access      Private(admin,manager) 
exports.editTeacher = asyncHandler(async (req, res, next) => {

    let teacher = await Teacher.findById(req.params.id);
    // console.log(teacher);
    console.log('Updating teacher -----------------------')
    if (!teacher) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Teacher does not exists`, 404));
    }

    // Make sure user is teacher owner
    // if (teacher.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this teacher`, 401));
    // }
    req.body.updatedAt = new Date();
    teacher = await Teacher.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    res.status(200).json({ success: true, data: teacher });
});

// @desc        Delete single teacher
// @route       DELETE /sdp/teachers/:id
// @access      Private(admin,manager) 
exports.deleteTeacher = asyncHandler(async (req, res, next) => {

    let teacher = await Teacher.findById(req.params.id);
    // console.log(teacher);
    if (!teacher) {
        // return res.status(400).json({ success: false });
        return next(new ErrorResponse(`Teacher does not exists`, 404));
    }

    // Make sure user is teacher owner
    // if (teacher.user.toString() !== req.user.id && req.user.role !== 'admin') {
    //     return next(new ErrorResponse(`User ${req.params.id} is not authorized to update this teacher`, 401));
    // }
    req.body.deleted = true;
    teacher = await Teacher.findByIdAndUpdate(req.params.id, req.body, {
        new: true, // to return updated data
        runValidators: true // to run mongoose validators to check updating data
    });

    // res.status(200).json({ success: true, data: teacher });
    res.status(200).json({ success: true, data: {} });
});
