const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const User = require('../models/User');
const Birthday = require('../models/Birthday');
const { sendWelcomeEmail, sendBirthdayEmail } = require('../utils/sendEmail');

// @desc        Get all users
// @route       GET /sdp/users
// @access      Private/Admin/Manager
exports.getUsers = asyncHandler(async (req, res, next) => { // ##### DONE #####
    res.status(200).json(res.advancedResults);
});

// @desc        Get all birthday mail records
// @route       GET /sdp/users/birthdays
// @access      Private/Admin/Manager
exports.getUsersBirthdays = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log('Birthday records');
    res.status(200).json(res.advancedResults);
});

// @desc        Get single user
// @route       GET /sdp/users/:slug
// @access      Private/Admin/Manager
// Deleted users can be viewed only by admin
exports.getUser = asyncHandler(async (req, res, next) => { // ##### DONE #####

    if (!res.restrictManagerFind) {
        return next(new ErrorResponse('User not found', 404));
    }

    res.status(200).json({
        success: true,
        data: res.restrictManagerFind
    });
});

// @desc        Create user
// @route       POST /sdp/users
// @access      Private/Admin/Manager
exports.createUser = asyncHandler(async (req, res, next) => { // ##### DONE #####

    const user = await User.create(req.body);
    res.status(201).json({
        success: true,
        data: user
    });

});

// @desc        Send welcome mail to user
// @route       POST /sdp/users/mail
// @access      Private/Admin/Manager
exports.welcomeMail = asyncHandler(async (req, res, next) => { // ##### DONE #####

    const user = req.body;
    // console.log('Inside send email');
    // console.log(user);
    // Send mail after creating new user(manager/teacher)
    try {
        await sendWelcomeEmail({
            email: user.email,
            first_name: user.name.split(' ')[0],
            branch_name: user.branch,
            user_role: user.role,
            user_email: user.email,
            user_password: user.password
        });

        res.status(200).json({
            success: true,
            data: `Welcome mail sent on email ${user.email}. Ask to check Spam and other folders for welcome mail`
        });
    } catch (err) {
        console.log(err);

        // return next(new ErrorResponse(err, 500));
        return next(new ErrorResponse('Email could not be sent', 500));
    }

});

// @desc        Update user
// @route       PUT /sdp/users/:slug
// @access      Private/Admin
exports.updateUser = asyncHandler(async (req, res, next) => { // ##### DONE #####

    if (!res.restrictManagerFind) {
        return next(new ErrorResponse('User not found', 404));
    }

    const user = await User.findByIdAndUpdate(res.restrictManagerFind._id, req.body, {
        new: true,
        runValidators: true
    });

    res.status(200).json({
        success: true,
        data: user
    });
});

// @desc        Delete user
// @route       DELETE /sdp/users/:slug
// @access      Private/Admin
exports.deleteUser = asyncHandler(async (req, res, next) => { // ##### DONE #####

    if (!res.restrictManagerFind) {
        return next(new ErrorResponse('User not found', 404));
    }

    await User.findByIdAndDelete(res.restrictManagerFind._id); // Actual delete query
    // await User.findByIdAndUpdate(res.restrictManagerFind._id, { deleted: 1 }); // Dummy delete query

    res.status(200).json({
        success: true,
        data: {}
    });
});

// @desc        Send birthday mail to user
// @route       POST /sdp/users/mail/birthday
// @access      Private/Admin/Manager
exports.birthdayMail = asyncHandler(async (req, res, next) => { // ##### DONE #####

    const user = req.body;
    // console.log('Inside birthday controller');
    try {
        await sendBirthdayEmail({
            email: user.email,
            name: user.name,
            message: user.message,
            subject: user.subject
        });
        await Birthday.create({
            name: user.name,
            email: user.email,
            createdBy: req.user.id
        });

        res.status(200).json({
            success: true,
            data: `Birthday mail sent on email ${user.email}. Ask to check Spam and other folders for birthday mail`
        });
    } catch (err) {
        console.log(err);

        // return next(new ErrorResponse(err, 500));
        return next(new ErrorResponse('Email could not be sent', 500));
    }

});