const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc        Dashboard page (Frontend)
// @route       GET /sdp/teacher/dashboard
// @access      Private(Teacher)
exports.dashboardPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/dashboard', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Dashboard', css: 'teacher/dashboard', js: 'teacher/dashboard', data: req.user });
});

// @desc        All Tasks page (Frontend)
// @route       GET /sdp/teacher/tasks
// @access      Private(Teacher)
exports.tasksPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/task/all_tasks', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Tasks', css: 'teacher/all_tasks', js: 'teacher/all_tasks', data: req.user });
});

// @desc        Add Task page (Frontend)
// @route       GET /sdp/teacher/addtask
// @access      Private(Teacher)
exports.addTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/task/addtask', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Task', css: 'teacher/addtask', js: 'teacher/addtask', data: req.user });
});

// @desc        View Task page (Frontend)
// @route       GET /sdp/teacher/viewtask
// @access      Private(Teacher)
exports.viewTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/task/viewTask', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Task', css: 'teacher/viewTask', js: 'teacher/viewTask', data: req.user });
});

// @desc        Edit Task page (Frontend)
// @route       GET /sdp/teacher/edittask
// @access      Private(Teacher)
exports.editTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/task/edittask', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Task', css: 'teacher/edittask', js: 'teacher/edittask', data: req.user });
});

// @desc        Delete Task page (Frontend)
// @route       GET /sdp/teacher/deletetask
// @access      Private(Teacher)
exports.deleteTaskPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/task/deletetask', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Task', css: 'teacher/deletetask', js: 'teacher/deletetask', data: req.user });
});

// @desc        All Branches page (Frontend)
// @route       GET /sdp/teacher/branches
// @access      Private(Teacher)
exports.branchesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/branch/all_branches', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Branches', css: 'teacher/all_branches', js: 'teacher/all_branches', data: req.user });
});

// @desc        Add Branch page (Frontend)
// @route       GET /sdp/teacher/addbranch
// @access      Private(Teacher)
exports.addBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/branch/addbranch', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Branch', css: 'teacher/addbranch', js: 'teacher/addbranch', data: req.user });
});

// @desc        View Branch page (Frontend)
// @route       GET /sdp/teacher/viewbranch
// @access      Private(Teacher)
exports.viewBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/branch/viewBranch', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Branch', css: 'teacher/viewBranch', js: 'teacher/viewBranch', data: req.user });
});

// @desc        Edit Branch page (Frontend)
// @route       GET /sdp/teacher/editbranch
// @access      Private(Teacher)
exports.editBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/branch/editbranch', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Branch', css: 'teacher/editbranch', js: 'teacher/editbranch', data: req.user });
});

// @desc        Delete Branch page (Frontend)
// @route       GET /sdp/teacher/deletebranch
// @access      Private(Teacher)
exports.deleteBranchPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/branch/deletebranch', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Branch', css: 'teacher/deletebranch', js: 'teacher/deletebranch', data: req.user });
});

// @desc        All Courses page (Frontend)
// @route       GET /sdp/teacher/courses
// @access      Private(Teacher)
exports.coursesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/course/all_courses', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Courses', css: 'teacher/all_courses', js: 'teacher/all_courses', data: req.user });
});

// @desc        Add Course page (Frontend)
// @route       GET /sdp/teacher/addcourse
// @access      Private(Teacher)
exports.addCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/course/addcourse', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Course', css: 'teacher/addcourse', js: 'teacher/addcourse', data: req.user });
});

// @desc        View Course page (Frontend)
// @route       GET /sdp/teacher/viewcourse
// @access      Private(Teacher)
exports.viewCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/course/viewCourse', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Course', css: 'teacher/viewCourse', js: 'teacher/viewCourse', data: req.user });
});

// @desc        Edit Course page (Frontend)
// @route       GET /sdp/teacher/editcourse
// @access      Private(Teacher)
exports.editCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/course/editcourse', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Course', css: 'teacher/editcourse', js: 'teacher/editcourse', data: req.user });
});

// @desc        Delete Course page (Frontend)
// @route       GET /sdp/teacher/deletecourse
// @access      Private(Teacher)
exports.deleteCoursePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/course/deletecourse', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Course', css: 'teacher/deletecourse', js: 'teacher/deletecourse', data: req.user });
});

// @desc        All Enquiries page (Frontend)
// @route       GET /sdp/teacher/enquiries
// @access      Private(Teacher)
exports.enquiriesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/enquiry/all_enquiries', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Enquiries', css: 'teacher/all_enquiries', js: 'teacher/all_enquiries', data: req.user });
});

// @desc        Add Enquiry page (Frontend)
// @route       GET /sdp/teacher/addenquiry
// @access      Private(Teacher)
exports.addEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/enquiry/addenquiry', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Enquiry', css: 'teacher/addenquiry', js: 'teacher/addenquiry', data: req.user });
});

// @desc        View Enquiry page (Frontend)
// @route       GET /sdp/teacher/viewenquiry
// @access      Private(Teacher)
exports.viewEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/enquiry/viewEnquiry', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Enquiry', css: 'teacher/viewEnquiry', js: 'teacher/viewEnquiry', data: req.user });
});

// @desc        Edit Enquiry page (Frontend)
// @route       GET /sdp/teacher/editenquiry
// @access      Private(Teacher)
exports.editEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/enquiry/editenquiry', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Enquiry', css: 'teacher/editenquiry', js: 'teacher/editenquiry', data: req.user });
});

// @desc        Delete Enquiry page (Frontend)
// @route       GET /sdp/teacher/deleteEnquiry
// @access      Private(Teacher)
exports.deleteEnquiryPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/Enquiry/deleteEnquiry', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Enquiry', css: 'teacher/deleteEnquiry', js: 'teacher/deleteEnquiry', data: req.user });
});

// @desc        All Students page (Frontend)
// @route       GET /sdp/teacher/students
// @access      Private(Teacher)
exports.studentsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/student/all_students', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Students', css: 'teacher/all_students', js: 'teacher/all_students', data: req.user });
});

// @desc        Add Student page (Frontend)
// @route       GET /sdp/teacher/addstudent
// @access      Private(Teacher)
exports.addStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/student/addstudent', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Student', css: 'teacher/addstudent', js: 'teacher/addstudent', data: req.user });
});

// @desc        View Student page (Frontend)
// @route       GET /sdp/teacher/viewstudent
// @access      Private(Teacher)
exports.viewStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/student/viewStudent', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Student', css: 'teacher/viewStudent', js: 'teacher/viewStudent', data: req.user });
});

// @desc        Edit Student page (Frontend)
// @route       GET /sdp/teacher/editstudent
// @access      Private(Teacher)
exports.editStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/student/editstudent', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Student', css: 'teacher/editstudent', js: 'teacher/editstudent', data: req.user });
});

// @desc        Delete Student page (Frontend)
// @route       GET /sdp/teacher/deleteStudent
// @access      Private(Teacher)
exports.deleteStudentPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/Student/deleteStudent', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Student', css: 'teacher/deleteStudent', js: 'teacher/deleteStudent', data: req.user });
});

// @desc        All Admissions page (Frontend)
// @route       GET /sdp/teacher/admissions
// @access      Private(Teacher)
exports.admissionsPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/admission/all_admissions', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Admissions', css: 'teacher/all_admissions', js: 'teacher/all_admissions', data: req.user });
});

// @desc        Add Admission page (Frontend)
// @route       GET /sdp/teacher/addadmission
// @access      Private(Teacher)
exports.addAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/admission/addadmission', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Admission', css: 'teacher/addadmission', js: 'teacher/addadmission', data: req.user });
});

// @desc        View Admission page (Frontend)
// @route       GET /sdp/teacher/viewadmission
// @access      Private(Teacher)
exports.viewAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/admission/viewAdmission', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Admission', css: 'teacher/viewAdmission', js: 'teacher/viewAdmission', data: req.user });
});

// @desc        Edit Admission page (Frontend)
// @route       GET /sdp/teacher/editadmission
// @access      Private(Teacher)
exports.editAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/admission/editadmission', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Admission', css: 'teacher/editadmission', js: 'teacher/editadmission', data: req.user });
});

// @desc        Delete Admission page (Frontend)
// @route       GET /sdp/teacher/deleteadmission
// @access      Private(Teacher)
exports.deleteAdmissionPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/admission/deleteadmission', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Admission', css: 'teacher/deleteadmission', js: 'teacher/deleteadmission', data: req.user });
});

// @desc        Add Fee page (Frontend)
// @route       GET /sdp/teacher/addfee
// @access      Private(Teacher)
exports.addFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/fee/addfee', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Fee', css: 'teacher/addfee', js: 'teacher/addfee', data: req.user });
});

// @desc        All Fees page (Frontend)
// @route       GET /sdp/teacher/fees
// @access      Private(Teacher)
exports.feesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/fee/all_fees', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Fees', css: 'teacher/all_fees', js: 'teacher/all_fees', data: req.user });
});

// @desc        View Fee page (Frontend)
// @route       GET /sdp/teacher/viewfee
// @access      Private(Teacher)
exports.viewFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/fee/viewFee', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Fee', css: 'teacher/viewFee', js: 'teacher/viewFee', data: req.user });
});

// @desc        Edit Fee page (Frontend)
// @route       GET /sdp/teacher/editfee
// @access      Private(Teacher)
exports.editFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/fee/editfee', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Fee', css: 'teacher/editfee', js: 'teacher/editfee', data: req.user });
});

// @desc        Delete Fee page (Frontend)
// @route       GET /sdp/teacher/deletefee
// @access      Private(Teacher)
exports.deleteFeePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/fee/deletefee', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Fee', css: 'teacher/deletefee', js: 'teacher/deletefee', data: req.user });
});

// @desc        All Lectures page (Frontend)
// @route       GET /sdp/teacher/lectures
// @access      Private(Teacher)
exports.lecturesPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/lecture/all_lectures', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Lectures', css: 'teacher/all_lectures', js: 'teacher/all_lectures', data: req.user });
});

// @desc        Add Lecture page (Frontend)
// @route       GET /sdp/teacher/addlecture
// @access      Private(Teacher)
exports.addLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/lecture/addlecture', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Add Lecture', css: 'teacher/addlecture', js: 'teacher/addlecture', data: req.user });
});

// @desc        View Lecture page (Frontend)
// @route       GET /sdp/teacher/viewlecture
// @access      Private(Teacher)
exports.viewLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/lecture/viewLecture', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | View Lecture', css: 'teacher/viewLecture', js: 'teacher/viewLecture', data: req.user });
});

// @desc        Edit Lecture page (Frontend)
// @route       GET /sdp/teacher/editlecture
// @access      Private(Teacher)
exports.editLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/lecture/editlecture', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Edit Lecture', css: 'teacher/editlecture', js: 'teacher/editlecture', data: req.user });
});

// @desc        Delete Lecture page (Frontend)
// @route       GET /sdp/teacher/deletelecture
// @access      Private(Teacher)
exports.deleteLecturePage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/lecture/deletelecture', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Delete Lecture', css: 'teacher/deletelecture', js: 'teacher/deletelecture', data: req.user });
});

// @desc        Birthday Book page (Frontend)
// @route       GET /sdp/teacher/birthday-book
// @access      Private(Teacher)
exports.birthdayBookPage = asyncHandler(async (req, res, next) => { // ##### DONE #####
    // console.log(req.user);
    res.render('teacher/birthday_book', { layout: 'layouts/teacherLayout', title: 'SDP Teacher | Birthday Book', css: 'teacher/birthday_book', js: 'teacher/birthday_book', data: req.user });
});
