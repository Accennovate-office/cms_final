const express = require('express');
const { getFollowups, createFollowup, getFollowup, editFollowup, deleteFollowup, 
    getCount } = require('../controllers/followups');

// Models
const Followup = require('../models/Followup');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all followups routes
router.use(protect);
router.use(authorize('admin', 'manager', 'teacher'));

router.route('/')
    .get(advancedResults(Followup, 'takenby enquiry createdBy'), getFollowups)
    .post(createFollowup);

router.route('/:id')
    .get(advancedResults(Followup, 'takenby enquiry createdBy'), getFollowup)
    .put(editFollowup)
    .delete(deleteFollowup);

router.route('/count/:id')
    .get(getCount)

module.exports = router;