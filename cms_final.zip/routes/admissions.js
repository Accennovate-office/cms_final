const express = require('express');
const { getAdmissions, createAdmission, getAdmission, editAdmission, deleteAdmission, checkAdmission } = require('../controllers/admissions');

// Models
const Admission = require('../models/Admission');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize, restrictManagerCreate } = require('../middleware/auth');

const router = express.Router();

// To protect all admissions routes
router.use(protect)
router.use(authorize('admin', 'manager', 'teacher'))
// router.use(restrictManagerFind)

// Restrict manager find in admissions ###########################################
router.route('/')
    .get(advancedResults(Admission, 'student course teacher createdBy'), getAdmissions) // Ref: https://stackoverflow.com/a/32473842
    .post(restrictManagerCreate, createAdmission);

router.route('/:id')
    .get(advancedResults(Admission, 'student course teacher createdBy'), getAdmission)
    .put(advancedResults(Admission), editAdmission)
    .delete(advancedResults(Admission), deleteAdmission)

router.route('/:roll')
    .post(advancedResults(Admission, 'student course'), checkAdmission)

module.exports = router;