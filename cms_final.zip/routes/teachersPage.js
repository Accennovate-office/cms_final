const express = require('express');
const { dashboardPage, profilePage, studentsPage, studentsProfilePage } = require('../controllers/teachers');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all teachers routes
router.use(protect);
router.use(authorize('teacher'));

// router.post('/register', register);
router.get('/dashboard', dashboardPage);
router.get('/profile', profilePage);
router.get('/students', studentsPage);
router.get('/students/:slug', studentsProfilePage);

// Teachers routes will execute from auth routes
// router.get('/logout', logout);
// router.get('/me', protect, getMe);
// router.put('/updatedetails', protect, authorize('admin'), updateDetails); //Self update email, name only for admin
// router.put('/updatepassword', protect, updatePassword);

module.exports = router;