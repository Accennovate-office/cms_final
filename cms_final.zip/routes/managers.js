const express = require('express');
const { getManagers, createManager, getManager, editManager, deleteManager } = require('../controllers/managers');

// Models
const Manager = require('../models/Manager');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all managers routes
router.use(protect)
router.use(authorize('admin'))

router.route('/')
    .get(advancedResults(Manager, 'user'), getManagers)
    .post(createManager);

router.route('/:slug')
    .get(advancedResults(Manager, 'user'), getManager)

router.route('/:id')
    .put(editManager)
    .delete(deleteManager)

module.exports = router;