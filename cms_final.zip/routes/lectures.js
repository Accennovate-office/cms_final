const express = require('express');
const { getLectures, createLecture, getLecture, editLecture, deleteLecture } = require('../controllers/lectures');

// Models
const Lecture = require('../models/Lecture');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize, restrictManagerCreate } = require('../middleware/auth');

const router = express.Router();

// To protect all lectures routes
router.use(protect)
router.use(authorize('admin', 'manager', 'teacher'))
// router.use(restrictManagerFind)

// Restrict manager find in lectures ###########################################
router.route('/')
    .get(advancedResults(Lecture, 'teacher course createdBy'), getLectures) // Ref: https://stackoverflow.com/a/32473842
    .post(restrictManagerCreate, createLecture);

router.route('/:id')
    .get(advancedResults(Lecture, 'teacher course createdBy'), getLecture)
    .put(advancedResults(Lecture), editLecture)
    .delete(advancedResults(Lecture), deleteLecture)

module.exports = router;