const express = require('express');
const { getTasks, getTask, addTask, updateTask, deleteTask } = require('../controllers/tasks');

// Importing middleware and model to use advanced queries
const Task = require('../models/Task');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside task like bootcamps/:bootcampId/tasks

// All routes below this will be protected and only accessible for admin
router.use(protect);
router.use(authorize('admin', 'manager', 'teacher'));

router.route('/')
    .get(advancedResults(Task, 'category subcategory createdBy'), getTasks)
    .post(addTask);
router.route('/:id')
    .get(getTask)
    .put(updateTask)
    .delete(deleteTask);

module.exports = router;