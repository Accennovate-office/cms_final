const express = require('express');
const { welcome, welcomeTeacher, welcomeStudent, enquiry, alert } = require('../controllers/whatsapp');

// Middlewares
// const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside course like bootcamps/:bootcampId/courses

// All routes below this will be protected
router.use(protect);
router.use(authorize('admin', 'manager', 'teacher'));

// router.route('/')
//     .get(authorize('admin', 'manager', 'teacher'), advancedResults(User), getUsers)
//     .post(authorize('admin', 'manager'), restrictManagerCreate, createUser);
//     // .post(createUser); // Testing

router.route('/welcome').post(welcome)
router.route('/welcometeacher').post(welcomeTeacher)
router.route('/welcomestudent').post(welcomeStudent)
router.route('/enquiry').post(enquiry)
router.route('/alert').get(authorize('admin'), alert)

module.exports = router;