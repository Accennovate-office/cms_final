const express = require('express');
const { getCourses, getCourse, addCourse, updateCourse, deleteCourse } = require('../controllers/courses');

// Importing middleware and model to use advanced queries
const Course = require('../models/Course');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside course like bootcamps/:bootcampId/courses

// All routes below this will be protected and only accessible for admin
router.use(protect);
// router.use(authorize('admin'));

router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Course, 'createdBy'), getCourses)
    .post(authorize('admin'), addCourse);
router.route('/:id')
    .get(authorize('admin', 'manager', 'teacher'), getCourse)
    .put(authorize('admin'), updateCourse)
    .delete(authorize('admin'), deleteCourse);

module.exports = router;