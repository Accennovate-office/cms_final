const express = require('express');
const { getReferences, createReference, getReference, editReference, deleteReference } = require('../controllers/references');

// Models
const Reference = require('../models/Reference');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all students routes
router.use(protect)
router.use(authorize('admin', 'manager', 'teacher'))

router.route('/')
    .get(advancedResults(Reference, 'student createdBy'), getReferences)
    .post(createReference);

router.route('/:id')
    .get(advancedResults(Reference, 'student createdBy'), getReference)
    .put(editReference)
    .delete(deleteReference)

module.exports = router;