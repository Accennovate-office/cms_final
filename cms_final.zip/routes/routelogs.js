const express = require('express');
const { getRoutelogs, summaryRoutelogs, getRoutelog } = require('../controllers/routelogs');

// Models
const Routelog = require('../models/Routelog');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all routelogs routes
router.use(protect)
router.use(authorize('admin'))
// router.use(restrictManagerFind)

// Restrict manager find in routelogs ###########################################
router.route('/')
    .get(advancedResults(Routelog), getRoutelogs) // Ref: https://stackoverflow.com/a/32473842
// .post(restrictManagerCreate, createRoutelog);

router.route('/:id')
    .get(advancedResults(Routelog), getRoutelog)
// .put(advancedResults(Routelog), editRoutelog)
// .delete(advancedResults(Routelog), deleteRoutelog)

router.route('/summary/info')
    .get(summaryRoutelogs);

module.exports = router;