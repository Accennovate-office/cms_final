const express = require('express');
const { loginPage, forgotPasswordPage, resetPasswordPage,
    login, logout, getMe, forgotPassword, resetPassword, updateDetails, updatePassword, errorPage } = require('../controllers/auth');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// router.post('/register', register);
router.get('/login', loginPage);
router.post('/login', login);

router.get('/logout', logout);
router.get('/me', protect, getMe);
router.put('/updatedetails', protect, authorize('admin'), updateDetails); //Self update email, name only for admin
router.put('/updatepassword', protect, updatePassword);

router.get('/forgotpassword', forgotPasswordPage);
router.post('/forgotpassword', forgotPassword);

router.get('/resetpassword/:resettoken', resetPasswordPage);
router.put('/resetpassword/:resettoken', resetPassword);

module.exports = router;