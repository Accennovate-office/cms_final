const express = require('express');
const { getTopics, getTopic, addTopic, updateTopic, deleteTopic } = require('../controllers/topics');

// Importing middleware and model to use advanced queries
const Topic = require('../models/Topic');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside topic like bootcamps/:bootcampId/topics

// All routes below this will be protected and only accessible for admin
router.use(protect);
// router.use(authorize('admin'))

router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Topic), getTopics)
    // .get(authorize('admin', 'manager', 'teacher'), advancedResults(Topic, 'course createdBy'), getTopics)
    .post(authorize('admin'), addTopic);
router.route('/:id')
    .get(authorize('admin', 'manager', 'teacher'), getTopic)
    .put(authorize('admin'), updateTopic)
    .delete(authorize('admin'), deleteTopic);

module.exports = router;