const express = require('express');
const { getReferences, createReference, getReference, editReference, deleteReference } = require('../controllers/enqreferences');

// Models
const Enqreference = require('../models/Enqreference');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all students routes
router.use(protect)
router.use(authorize('admin', 'manager', 'teacher'))

router.route('/')
    .get(advancedResults(Enqreference, 'student createdBy'), getReferences)
    .post(createReference);

router.route('/:id')
    .get(advancedResults(Enqreference, 'student createdBy'), getReference)
    .put(editReference)
    .delete(deleteReference)

module.exports = router;