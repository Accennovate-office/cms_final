const express = require('express');
const { getFees, createFee, getFee, editFee, deleteFee } = require('../controllers/fees');

// Models
const Fee = require('../models/Fee');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize, restrictManagerCreate } = require('../middleware/auth');

const router = express.Router();

// To protect all fees routes
router.use(protect)
router.use(authorize('admin', 'manager', 'teacher'))
// router.use(restrictManagerFind)

// Restrict manager find in fees ###########################################
router.route('/')
    .get(advancedResults(Fee, 'student collectedBy createdBy'), getFees) // Ref: https://stackoverflow.com/a/32473842
    .post(restrictManagerCreate, createFee);

router.route('/:id')
    .get(advancedResults(Fee, 'student collectedBy createdBy'), getFee)
    .put(advancedResults(Fee), editFee)
    .delete(advancedResults(Fee), deleteFee)

module.exports = router;