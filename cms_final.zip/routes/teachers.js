const express = require('express');
const { getTeachers, createTeacher, getTeacher, editTeacher, deleteTeacher } = require('../controllers/teachers');

// Models
const Teacher = require('../models/Teacher');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize, restrictManagerCreate } = require('../middleware/auth');

const router = express.Router();

// To protect all teachers routes
router.use(protect)
// router.use(authorize('admin', 'manager', 'teacher'))
// router.use(restrictManagerFind)

// Restrict manager find in teachers ###########################################
router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Teacher, 'user'), getTeachers)
    .post(authorize('admin', 'manager'), restrictManagerCreate, createTeacher);

router.route('/:id')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Teacher, 'user'), getTeacher)
    .put(authorize('admin', 'manager'), editTeacher)
    .delete(authorize('admin', 'manager'), deleteTeacher)

module.exports = router;