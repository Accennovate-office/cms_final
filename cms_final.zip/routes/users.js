const express = require('express');
const { getUsers, getUsersBirthdays, getUser, createUser, welcomeMail, updateUser, deleteUser, birthdayMail } = require('../controllers/users');

// Importing middleware and model to use advanced queries
const User = require('../models/User');
const Birthday = require('../models/Birthday');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const restrictManagerFind = require('../middleware/restrictManagerFind');
const { protect, authorize, restrictManagerCreate } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside course like bootcamps/:bootcampId/courses

// All routes below this will be protected
router.use(protect);
// router.use(authorize('admin', 'manager', 'teacher'));

// Admin - get all managers, teachers
// Manager - get all teachers from same branch only
router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(User), getUsers)
    .post(authorize('admin', 'manager'), restrictManagerCreate, createUser);
    // .post(createUser); // Testing

router.route('/birthdays')
    .get(advancedResults(Birthday, 'createdBy'), getUsersBirthdays)

router.route('/mail').post(authorize('admin', 'manager'), welcomeMail)
router.route('/mail/birthday').post(authorize('admin', 'manager', 'teacher'), birthdayMail)

router.route('/:slug')
    .get(authorize('admin', 'manager', 'teacher'), restrictManagerFind(), getUser)
    .put(authorize('admin', 'manager'), restrictManagerFind(), updateUser)
    .delete(authorize('admin', 'manager'), restrictManagerFind(), deleteUser);


module.exports = router;