const express = require('express');
const { getTaskcategorys, getTaskcategory, addTaskcategory, deleteTaskcategory } = require('../controllers/taskcategorys');

// Importing middleware and model to use advanced queries
const Taskcategory = require('../models/Taskcategory');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside taskcategory like bootcamps/:bootcampId/taskcategorys

// All routes below this will be protected and only accessible for admin
router.use(protect);
// router.use(authorize('admin', 'manager'));

router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Taskcategory, 'createdBy'), getTaskcategorys)
    .post(authorize('admin'), addTaskcategory);
router.route('/:id')
    .get(authorize('admin'), getTaskcategory)
    // .put(updateTaskcategory)
    .delete(authorize('admin'), deleteTaskcategory);

module.exports = router;