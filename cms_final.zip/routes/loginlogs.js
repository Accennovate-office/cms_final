const express = require('express');
const { getLoginlogs, getLoginlog } = require('../controllers/loginlogs');

// Models
const Loginlog = require('../models/Loginlog');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all loginlogs logins
router.use(protect)
router.use(authorize('admin'))
// router.use(restrictManagerFind)

// Restrict manager find in loginlogs ###########################################
router.route('/')
    .get(advancedResults(Loginlog, 'user'), getLoginlogs) // Ref: https://stackoverflow.com/a/32473842
// .post(restrictManagerCreate, createLoginlog);

router.route('/:id')
    .get(advancedResults(Loginlog, 'user'), getLoginlog)
// .put(advancedResults(Loginlog), editLoginlog)
// .delete(advancedResults(Loginlog), deleteLoginlog)

module.exports = router;