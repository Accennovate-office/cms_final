const express = require('express');
const { dashboardPage,
    tasksPage, addTaskPage, viewTaskPage, editTaskPage, deleteTaskPage,
    branchesPage, addBranchPage, viewBranchPage, editBranchPage, deleteBranchPage,
    coursesPage, addCoursePage, viewCoursePage, editCoursePage, deleteCoursePage,
    teachersPage, addTeacherPage, viewTeacherPage, editTeacherPage, deleteTeacherPage,
    enquiriesPage, addEnquiryPage, viewEnquiryPage, editEnquiryPage, deleteEnquiryPage,
    studentsPage, addStudentPage, viewStudentPage, editStudentPage, deleteStudentPage,
    admissionsPage, addAdmissionPage, viewAdmissionPage, editAdmissionPage, deleteAdmissionPage,
    feesPage, addFeePage, viewFeePage, editFeePage, deleteFeePage,
    lecturesPage, addLecturePage, viewLecturePage, editLecturePage, deleteLecturePage,
    perksPage, addPerkPage, viewPerkPage, editPerkPage, deletePerkPage,
    birthdayBookPage } = require('../controllers/manager');
const { protect, authorize } = require('../middleware/auth');
// const { updatePassword } = require('../controllers/auth'); // Code by Raj

const router = express.Router();

// To protect all teachers routes
router.use(protect);
router.use(authorize('manager'));

// router.post('/register', register);
router.get('/dashboard', dashboardPage);

// Task routes
router.get('/tasks', tasksPage);
router.get('/addtask', addTaskPage);
router.get('/viewtask', viewTaskPage);
router.get('/edittask', editTaskPage);
router.get('/deletetask', deleteTaskPage);

// Branch routes
router.get('/branches', branchesPage);
router.get('/addbranch', addBranchPage);
router.get('/viewbranch', viewBranchPage);
router.get('/editbranch', editBranchPage);
router.get('/deletebranch', deleteBranchPage);

// Course routes
router.get('/courses', coursesPage);
router.get('/addcourse', addCoursePage);
router.get('/viewcourse', viewCoursePage);
router.get('/editcourse', editCoursePage);
router.get('/deletecourse', deleteCoursePage);

// Teacher routes
router.get('/teachers', teachersPage);
router.get('/addteacher', addTeacherPage);
router.get('/viewteacher', viewTeacherPage);
router.get('/editteacher', editTeacherPage);
router.get('/deleteteacher', deleteTeacherPage);

// Enquiry routes
router.get('/enquiries', enquiriesPage);
router.get('/addenquiry', addEnquiryPage);
router.get('/viewenquiry', viewEnquiryPage);
router.get('/editenquiry', editEnquiryPage);
router.get('/deleteenquiry', deleteEnquiryPage);

// Student routes
router.get('/students', studentsPage);
router.get('/addstudent', addStudentPage);
router.get('/viewstudent', viewStudentPage);
router.get('/editstudent', editStudentPage);
router.get('/deletestudent', deleteStudentPage);

// Admission routes
router.get('/admissions', admissionsPage);
router.get('/addadmission', addAdmissionPage);
router.get('/viewadmission', viewAdmissionPage);
router.get('/editadmission', editAdmissionPage);
router.get('/deleteadmission', deleteAdmissionPage);

// Fee routes
router.get('/fees', feesPage);
router.get('/addfee', addFeePage);
router.get('/viewfee', viewFeePage);
router.get('/editfee', editFeePage);
router.get('/deletefee', deleteFeePage);

// Lecture routes
router.get('/lectures', lecturesPage);
router.get('/addlecture', addLecturePage);
router.get('/viewlecture', viewLecturePage);
router.get('/editlecture', editLecturePage);
router.get('/deletelecture', deleteLecturePage);

// Perk routes
router.get('/perks', perksPage);
router.get('/addperk', addPerkPage);
router.get('/viewperk', viewPerkPage);
router.get('/editperk', editPerkPage);
router.get('/deleteperk', deletePerkPage);

// Birthday Book
router.get('/birthday-book', birthdayBookPage);

// Teachers routes will execute from auth routes
// router.get('/logout', logout);
// router.get('/me', protect, getMe);
// router.put('/updatedetails', protect, authorize('manager'), updateDetails); //Self update email, name only for manager
// router.put('/updatepassword', protect, updatePassword);

module.exports = router;