const express = require('express');
const { getRegistrations, createRegistration, getRegistration } = require('../controllers/registration');

// Models
const Registration = require('../models/Registration');
// const Registration = require('../models/Registration');
// const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();


// To protect all Registrations routes
router.use(protect)
router.use(authorize('admin'))
// router.use(authorize('admin', 'manager', 'teacher'))

router.route('/').post(createRegistration);
router.route('/').get(advancedResults(Registration, 'user'), getRegistrations) // Ref: https://stackoverflow.com/a/32473842
// router.route("/biometric").post(updateRegistration)

router.route('/:id')    
    .get( getRegistration )

module.exports = router;