const express = require('express');
const { getBranches, createBranch, getBranch, editBranch, deleteBranch } = require('../controllers/branches');

// Models
const Branch = require('../models/Branch');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all branches routes
router.use(protect)
// router.use(authorize('admin'))

router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Branch), getBranches)
    .post(authorize('admin'), createBranch);

router.route('/:name')
    .get(authorize('admin', 'manager', 'teacher'), getBranch)

router.route('/:id')
    .put(authorize('admin'), editBranch)
    .delete(authorize('admin'), deleteBranch)

module.exports = router;