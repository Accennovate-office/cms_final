const express = require('express');
const { getStudents, createStudent, getStudent, editStudent, deleteStudent, 
    checkPhone, summaryStudents, specialData, birthdayStudents } = require('../controllers/students');

// Models
const Student = require('../models/Student');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all students routes
router.use(protect)
router.use(authorize('admin', 'manager', 'teacher'))

router.route('/')
    .get(advancedResults(Student, 'reference createdBy'), getStudents)
    // .get(advancedResults(Student), getStudents)
    .post(createStudent);

router.route('/special/data')
    .get(specialData);

router.route('/:id')
    .get(advancedResults(Student, 'reference createdBy'), getStudent)
    .put(editStudent)
    .delete(deleteStudent)

// Feb 2023 update
router.route('/:phone')
    .post(advancedResults(Student, 'reference createdBy'), checkPhone);

router.route('/summary/info')
    .get(summaryStudents);

router.route('/birthday/data')
    .get(advancedResults(Student), birthdayStudents);

module.exports = router;