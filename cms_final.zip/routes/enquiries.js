const express = require('express');
const { getEnquiries, createEnquiry, getEnquiry, editEnquiry, deleteEnquiry } = require('../controllers/enquiries');

// Models
const Enquiry = require('../models/Enquiry');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all enquiries routes
router.use(protect);
router.use(authorize('admin', 'manager', 'teacher'));

router.route('/')
    .get(advancedResults(Enquiry, 'reference takenby createdBy'), getEnquiries)
    .post(createEnquiry);

router.route('/:id')
    .get(advancedResults(Enquiry, 'reference takenby createdBy'), getEnquiry)
    .put(editEnquiry)
    .delete(deleteEnquiry)

module.exports = router;