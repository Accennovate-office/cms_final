const express = require('express');
const { getAttendances, createAttendance, getAttendance, editAttendance, deleteAttendance,
    // Code by Raj
    updateAttendance,
    getPrevmonthAttendance,
    getdailyAttendance,
    getYesterdayAttendance,
    getweeklyAttendance,
    getmonthlyAttendance,
    getDuration,
    getCustomAttendance,
    // Code by Raj end 
} = require('../controllers/attendances');

// Models
const Attendance = require('../models/Attendance');
const User = require('../models/User');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/').post(createAttendance);

// To protect all attendances routes
router.use(protect)
router.use(authorize('admin')) // Line deleted by Raj
// Code by Raj
router.route("/data/:id").get(getAttendance);
router.route("/duration/:id").get(getDuration);
router.route("/custom/:id").get(getCustomAttendance);
router.route("/dailyAttendance").get(getdailyAttendance);
router.route("/monthlyAttendance").get(getmonthlyAttendance);
router.route("/yesterdayAttendance").get(getYesterdayAttendance);
router.route("/prevMonthlyAttendance").get(getPrevmonthAttendance);
router.route("/prevmonthAttendance").get(getPrevmonthAttendance);
// Code by Raj end
// router.use(authorize('admin', 'manager', 'teacher'))

// router.route('/').get(advancedResults(Attendance, 'user'), getAttendances) // Ref: https://stackoverflow.com/a/32473842

// router.route('/:id')
//     .get(advancedResults(Attendance, 'user'), getAttendance)
//     .put(advancedResults(Attendance), editAttendance)
//     .delete(advancedResults(Attendance), deleteAttendance)

module.exports = router;