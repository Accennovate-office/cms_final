const express = require('express');
const { dashboardPage,
    tasksPage, addTaskPage, viewTaskPage, editTaskPage, deleteTaskPage,
    branchesPage, addBranchPage, viewBranchPage, editBranchPage, deleteBranchPage,
    coursesPage, addCoursePage, viewCoursePage, editCoursePage, deleteCoursePage,
    enquiriesPage, addEnquiryPage, viewEnquiryPage, editEnquiryPage, deleteEnquiryPage,
    studentsPage, addStudentPage, viewStudentPage, editStudentPage, deleteStudentPage,
    admissionsPage, addAdmissionPage, viewAdmissionPage, editAdmissionPage, deleteAdmissionPage,
    feesPage, addFeePage, viewFeePage, editFeePage, deleteFeePage,
    lecturesPage, addLecturePage, viewLecturePage, editLecturePage, deleteLecturePage,
    birthdayBookPage } = require('../controllers/teacher');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// To protect all teachers routes
router.use(protect);
router.use(authorize('teacher'));

// router.post('/register', register);
router.get('/dashboard', dashboardPage);

// Task routes
router.get('/tasks', tasksPage);
router.get('/addtask', addTaskPage);
router.get('/viewtask', viewTaskPage);
router.get('/edittask', editTaskPage);
router.get('/deletetask', deleteTaskPage);

// Branch routes
router.get('/branches', branchesPage);
router.get('/addbranch', addBranchPage);
router.get('/viewbranch', viewBranchPage);
router.get('/editbranch', editBranchPage);
router.get('/deletebranch', deleteBranchPage);

// Course routes
router.get('/courses', coursesPage);
router.get('/addcourse', addCoursePage);
router.get('/viewcourse', viewCoursePage);
router.get('/editcourse', editCoursePage);
router.get('/deletecourse', deleteCoursePage);

// Enquiry routes
router.get('/enquiries', enquiriesPage);
router.get('/addenquiry', addEnquiryPage);
router.get('/viewenquiry', viewEnquiryPage);
router.get('/editenquiry', editEnquiryPage);
router.get('/deleteenquiry', deleteEnquiryPage);

// Student routes
router.get('/students', studentsPage);
router.get('/addstudent', addStudentPage);
router.get('/viewstudent', viewStudentPage);
router.get('/editstudent', editStudentPage);
router.get('/deletestudent', deleteStudentPage);

// Admission routes
router.get('/admissions', admissionsPage);
router.get('/addadmission', addAdmissionPage);
router.get('/viewadmission', viewAdmissionPage);
router.get('/editadmission', editAdmissionPage);
router.get('/deleteadmission', deleteAdmissionPage);

// Fee routes
router.get('/fees', feesPage);
router.get('/addfee', addFeePage);
router.get('/viewfee', viewFeePage);
router.get('/editfee', editFeePage);
router.get('/deletefee', deleteFeePage);

// Lecture routes
router.get('/lectures', lecturesPage);
router.get('/addlecture', addLecturePage);
router.get('/viewlecture', viewLecturePage);
router.get('/editlecture', editLecturePage);
router.get('/deletelecture', deleteLecturePage);

// Birthday Book
router.get('/birthday-book', birthdayBookPage);

// Teachers routes will execute from auth routes
// router.get('/logout', logout);
// router.get('/me', protect, getMe);
// router.put('/updatedetails', protect, authorize('teacher'), updateDetails); //Self update email, name only for teacher
// router.put('/updatepassword', protect, updatePassword);

module.exports = router;