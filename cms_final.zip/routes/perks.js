const express = require('express');
const { getPerks, getPerk, addPerk, updatePerk, deletePerk } = require('../controllers/perks');

// Importing middleware and model to use advanced queries
const Perk = require('../models/Perk');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside perk like bootcamps/:bootcampId/perks

// All routes below this will be protected and only accessible for admin
router.use(protect);
router.use(authorize('admin', 'manager'));

router.route('/')
    .get(advancedResults(Perk, 'user createdBy'), getPerks)
    .post(addPerk);
router.route('/:id')
    .get(getPerk)
    .put(updatePerk)
    .delete(deletePerk);

module.exports = router;