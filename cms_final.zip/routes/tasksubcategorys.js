const express = require('express');
const { getTasksubcategorys, getTasksubcategory, addTasksubcategory, deleteTasksubcategory } = require('../controllers/tasksubcategorys');

// Importing middleware and model to use advanced queries
const Tasksubcategory = require('../models/Tasksubcategory');

// Middlewares
const advancedResults = require('../middleware/advancedResults');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true }); // mergeParams is used to bring in others routes inside tasksubcategory like bootcamps/:bootcampId/tasksubcategorys

// All routes below this will be protected and only accessible for admin
router.use(protect);
// router.use(authorize('admin', 'manager'));

router.route('/')
    .get(authorize('admin', 'manager', 'teacher'), advancedResults(Tasksubcategory, 'category createdBy'), getTasksubcategorys)
    .post(authorize('admin'), addTasksubcategory);
router.route('/:id')
    .get(authorize('admin'), getTasksubcategory)
    // .put(updateTasksubcategory)
    .delete(authorize('admin'), deleteTasksubcategory);

module.exports = router;