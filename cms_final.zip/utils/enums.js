exports.followupTypes = {
    'Phone_call': 1,
    'Home_visit': 2
};

// module.exports.followupTypes = {
//     1: 'Phone_call',
//     2: 'Home_visit'
// };