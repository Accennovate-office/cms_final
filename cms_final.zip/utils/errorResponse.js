class ErrorResponse extends Error { // extending default error class
    constructor(message, statusCode) { // constructor is just a method that runs when we instantiate an object from the class
        super(message); // the error class which we are extending we want to call that constructor, that can be done with super. It has its own message properties but we'll pass our message into that.
        this.statusCode = statusCode; // Creating custom property on this class called statusCode
    }
}

module.exports = ErrorResponse;