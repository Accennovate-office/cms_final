const sgMail = require('@sendgrid/mail');

exports.sendForgotEmail = async (options) => {

    sgMail.setApiKey(process.env.CMS_SMARTBYTE_API_KEY);
    const msg = {
        to: options.email,
        from: {
            email: process.env.FROM_EMAIL,
            name: process.env.FROM_NAME
        },
        templateId: process.env.FORGOT_PASSWORD_EMAIL_TEMPLATE_ID,
        dynamicTemplateData: {
            name: options.name,
            resetUrl: options.resetUrl,
            email: options.email
        },
        // subject: options.subject,
        // html: options.message
    };

    await sgMail.send(msg)
        .then(() => {
            console.log('Email sent')
        })
        .catch((error) => {
            console.error(error)
    });
}

exports.resetPasswordEmail = async (data) => {
    const template = `
    <!-- Forgot password email template -->
    <div class="container" style="font-family: Arial, sans-serif;max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 20px;">
    <div class="header" style="text-align: center;">
        <img src="http://testing-cms-env.eba-m3ab5e5p.ap-south-1.elasticbeanstalk.com/images/smartbyte_logo.png" alt="SmartByte Logo" style="max-width: 150px; height: auto;">
        <h1>Password Reset Confirmation</h1>
        <p>Thank you for using our service. If you requested to reset your password, please click the button below.</p>
    </div>
    <img src="https://plus.unsplash.com/premium_photo-1681487746049-c39357159f69?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cGFzc3dvcmRzfGVufDB8fDB8fHww" alt="Reset Password" style="width: 100%;">
    <div class="content" style="margin-top: 20px; text-align: center;">
        <a href="https://reset-password-link.com" class="button" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #ffffff; text-decoration: none; border-radius: 5px;">Reset Password</a>
        <p>If you didn't request a password reset, you can ignore this email.</p>
        <!-- <p>If you have any further questions, please do not hesitate to <a href="https://your-contact-link.com">contact us</a>.</p> -->
    </div>
    <div style="margin-top: 20px; text-align: center;">
        <br>
        <p>Sincerely,</p>
        <p>SmartByte Computer Education Team</p>
    </div>
    <div class="header" style="text-align: center;">
        <img src="http://testing-cms-env.eba-m3ab5e5p.ap-south-1.elasticbeanstalk.com/images/smartbyte_logo.png" alt="SmartByte Logo" style="width: 70%; margin: 0 auto;">
    </div>
    <footer class="footer" style="text-align: center; color: gray; margin-top: 20px;">
        <i>Copyright (C) 2023 SmartByte Computer Education. All rights reserved.</i>
    </footer>
    </div>`
}

exports.sendWelcomeEmail = async (options2) => {

    sgMail.setApiKey(process.env.CMS_SMARTBYTE_API_KEY);
    const msg2 = {
        to: options2.email,
        from: {
            email: process.env.FROM_EMAIL,
            name: process.env.FROM_NAME
        },
        templateId: process.env.WELCOME_EMAIL_TEMPLATE_ID,
        dynamicTemplateData: {
            first_name: options2.first_name,
            branch_name: options2.branch_name,
            user_role: options2.user_role,
            user_email: options2.user_email,
            user_password: options2.user_password
        },
        // subject: options2.subject,
        // html: options2.message
    };

    await sgMail.send(msg2)
}

exports.sendBirthdayEmail = async (options3) => {

    sgMail.setApiKey(process.env.CMS_SMARTBYTE_API_KEY);
    const msg2 = {
        to: options3.email,
        from: {
            email: process.env.FROM_EMAIL,
            name: process.env.FROM_NAME
        },
        templateId: process.env.BIRTHDAY_EMAIL_TEMPLATE_ID,
        dynamicTemplateData: {
            name: options3.name,
            message: options3.message,
            subject: options3.subject
        },
        // subject: options3.subject,
        // html: options3.message
    };

    await sgMail.send(msg2)
}

// const nodemailer = require("nodemailer");

// // async..await is not allowed in global scope, must use a wrapper
// const sendEmail = async (options) => {

//     const transporter = nodemailer.createTransport({
//         host: process.env.SMTP_HOST,
//         port: process.env.SMTP_PORT,
//         auth: {
//             user: process.env.SMTP_EMAIL, 
//             pass: process.env.SMTP_PASSWORD
//         },
//     });

//     const message = {
//         from: `${process.env.FROM_NAME} <${process.env.FROM_EMAIL}>`,
//         to: options.email,
//         subject: options.subject,
//         text: options.message,
//         // html: "<b>Hello world?</b>", // html body
//     };

//     const info  = await transporter.sendMail(message);

//     console.log("Message sent: %s", info.messageId);
// }
