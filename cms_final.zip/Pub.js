const mqtt = require("mqtt");

var client = mqtt.connect("mqtt://broker.hivemq.com");


client.on("connect", function () {

    // setInterval(function () {

    // var random = Math.random() * 50;

    // console.log(random);

    // if (random < 30) {
    var msg = {
        name: 'Ashish',
        id: 123,
        datetime: '2022-03-04T10:49:56.820Z'
    }
    client.publish("IOT Test", JSON.stringify(msg));
    console.log(msg);

    // }

    // }), 30000;

})