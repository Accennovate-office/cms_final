# lecture-schedule-manager

A small computer teaching organization management system. To manage their tasks like:
- Manage students
- Manage staff & teachers
- Manage courses
- Manage attendance
- Manage multiple branches by respective managers
- Other tasks of manager

## Tech Stack
### Frontend - HTML, CSS, JS, Jquery, AJAX, Bootstrap
### Backend - NodeJS, Express
### Database - MongoDB Atlas
